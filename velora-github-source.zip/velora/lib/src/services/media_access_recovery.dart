import 'package:flutter/services.dart';

import '../models/overlays.dart';
import '../models/project.dart';

/// Structured, non-mutating description of a media reference that Android can
/// no longer read. The project remains untouched until the user picks a file.
class MediaAccessIssue {
  const MediaAccessIssue({
    required this.name,
    required this.kind,
    this.assetId,
    this.stickerId,
  });

  final String name;
  final MediaKind kind;
  final String? assetId;
  final String? stickerId;

  bool get isSticker => stickerId != null;

  static MediaAccessIssue? fromPlatformException(Object error) {
    if (error is! PlatformException || error.code != 'media_access_lost') {
      return null;
    }
    final raw = error.details;
    if (raw is! Map) return null;
    final details = Map<Object?, Object?>.from(raw);
    final assetId = details['assetId']?.toString();
    final stickerId = details['stickerId']?.toString();
    if ((assetId == null || assetId.isEmpty) &&
        (stickerId == null || stickerId.isEmpty)) {
      return null;
    }
    return MediaAccessIssue(
      name: details['name']?.toString() ?? 'ملف وسائط',
      kind: mediaKindFromString(details['kind']),
      assetId: assetId?.isEmpty == true ? null : assetId,
      stickerId: stickerId?.isEmpty == true ? null : stickerId,
    );
  }
}

/// Rebinds an existing asset ID to a newly picked URI while leaving every clip,
/// trim, overlay, project ID, and other asset unchanged.
VeloraProject replaceProjectAssetReference(
  VeloraProject project, {
  required String assetId,
  required MediaAsset replacement,
}) {
  final index = project.assets.indexWhere((asset) => asset.id == assetId);
  if (index < 0) throw const FormatException('الأصل المطلوب لم يعد موجودًا في المشروع.');
  final previous = project.assets[index];
  if (previous.kind != replacement.kind) {
    throw const FormatException('نوع الملف الجديد لا يطابق نوع الوسيط المفقود.');
  }

  final requiredEndMs = <int>[
    ...project.videoTrack
        .where((clip) => clip.assetId == assetId)
        .map((clip) => clip.trimEndMs),
    ...project.audioTrack
        .where((clip) => clip.assetId == assetId)
        .map((clip) => clip.trimEndMs),
    for (final track in project.videoOverlayTracks)
      ...track.clips
          .where((clip) => clip.assetId == assetId)
          .map((clip) => clip.trimEndMs),
  ].fold<int>(0, (largest, end) => end > largest ? end : largest);
  if (replacement.kind != MediaKind.image &&
      replacement.durationMs > 0 &&
      replacement.durationMs < requiredEndMs) {
    throw FormatException(
      'الملف الجديد أقصر من الجزء المستخدم في المشروع (${requiredEndMs} ms).',
    );
  }

  final updatedAssets = List<MediaAsset>.of(project.assets);
  updatedAssets[index] = MediaAsset(
    id: previous.id,
    uri: replacement.uri,
    name: replacement.name,
    mimeType: replacement.mimeType,
    kind: replacement.kind,
    durationMs: replacement.durationMs,
    width: replacement.width,
    height: replacement.height,
    sizeBytes: replacement.sizeBytes,
  );
  return project.copyWith(assets: updatedAssets);
}

/// Replaces only a sticker's file metadata; its identity, timing, and layout
/// are preserved exactly.
VeloraProject replaceProjectStickerReference(
  VeloraProject project, {
  required String stickerId,
  required MediaAsset replacement,
}) {
  if (replacement.kind != MediaKind.image ||
      (replacement.mimeType != 'image/png' && replacement.mimeType != 'image/webp')) {
    throw const FormatException('اختر ملصق PNG أو WebP.');
  }
  final index = project.stickerOverlays.indexWhere((item) => item.id == stickerId);
  if (index < 0) throw const FormatException('الملصق المطلوب لم يعد موجودًا في المشروع.');
  final previous = project.stickerOverlays[index];
  final updated = List<StickerOverlay>.of(project.stickerOverlays);
  updated[index] = StickerOverlay(
    id: previous.id,
    uri: replacement.uri,
    name: replacement.name,
    mimeType: replacement.mimeType,
    startMs: previous.startMs,
    endMs: previous.endMs,
    positionX: previous.positionX,
    positionY: previous.positionY,
    widthFraction: previous.widthFraction,
  );
  return project.copyWith(stickerOverlays: updated);
}
