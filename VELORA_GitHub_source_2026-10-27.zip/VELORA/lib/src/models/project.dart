enum MediaKind { video, image, audio, unsupported }

MediaKind mediaKindFromString(Object? value) {
  return MediaKind.values.firstWhere(
    (kind) => kind.name == value,
    orElse: () => MediaKind.unsupported,
  );
}

class MediaAsset {
  const MediaAsset({
    required this.id,
    required this.uri,
    required this.name,
    required this.mimeType,
    required this.kind,
    required this.durationMs,
    required this.width,
    required this.height,
    required this.sizeBytes,
  });

  final String id;
  final String uri;
  final String name;
  final String mimeType;
  final MediaKind kind;
  final int durationMs;
  final int width;
  final int height;
  final int sizeBytes;

  factory MediaAsset.fromMap(Map<String, dynamic> map) => MediaAsset(
    id: map['id'] as String,
    uri: map['uri'] as String,
    name: map['name'] as String? ?? 'وسيط بلا اسم',
    mimeType: map['mimeType'] as String? ?? 'application/octet-stream',
    kind: mediaKindFromString(map['kind']),
    durationMs: (map['durationMs'] as num?)?.toInt() ?? 0,
    width: (map['width'] as num?)?.toInt() ?? 0,
    height: (map['height'] as num?)?.toInt() ?? 0,
    sizeBytes: (map['sizeBytes'] as num?)?.toInt() ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'uri': uri,
    'name': name,
    'mimeType': mimeType,
    'kind': kind.name,
    'durationMs': durationMs,
    'width': width,
    'height': height,
    'sizeBytes': sizeBytes,
  };
}

class TimelineClip {
  const TimelineClip({
    required this.id,
    required this.assetId,
    required this.trimStartMs,
    required this.trimEndMs,
  });

  final String id;
  final String assetId;
  final int trimStartMs;
  final int trimEndMs;

  int get durationMs => trimEndMs - trimStartMs;

  TimelineClip copyWith({int? trimStartMs, int? trimEndMs}) => TimelineClip(
    id: id,
    assetId: assetId,
    trimStartMs: trimStartMs ?? this.trimStartMs,
    trimEndMs: trimEndMs ?? this.trimEndMs,
  );

  factory TimelineClip.fromMap(Map<String, dynamic> map) => TimelineClip(
    id: map['id'] as String,
    assetId: map['assetId'] as String,
    trimStartMs: (map['trimStartMs'] as num?)?.toInt() ?? 0,
    trimEndMs: (map['trimEndMs'] as num?)?.toInt() ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'assetId': assetId,
    'trimStartMs': trimStartMs,
    'trimEndMs': trimEndMs,
  };
}

class VeloraProject {
  const VeloraProject({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.assets,
    required this.videoTrack,
    required this.audioTrack,
  });

  final String id;
  final String name;
  final String createdAt;
  final List<MediaAsset> assets;
  final List<TimelineClip> videoTrack;
  final List<TimelineClip> audioTrack;

  factory VeloraProject.empty({required String id, required String name}) =>
      VeloraProject(
        id: id,
        name: name,
        createdAt: DateTime.now().toUtc().toIso8601String(),
        assets: const [],
        videoTrack: const [],
        audioTrack: const [],
      );

  factory VeloraProject.fromMap(Map<String, dynamic> map) => VeloraProject(
    id: map['id'] as String,
    name: map['name'] as String? ?? 'مشروع جديد',
    createdAt: map['createdAt'] as String? ?? '',
    assets: ((map['assets'] as List<dynamic>?) ?? const [])
        .map(
          (item) => MediaAsset.fromMap(Map<String, dynamic>.from(item as Map)),
        )
        .toList(),
    videoTrack: ((map['videoTrack'] as List<dynamic>?) ?? const [])
        .map(
          (item) =>
              TimelineClip.fromMap(Map<String, dynamic>.from(item as Map)),
        )
        .toList(),
    audioTrack: ((map['audioTrack'] as List<dynamic>?) ?? const [])
        .map(
          (item) =>
              TimelineClip.fromMap(Map<String, dynamic>.from(item as Map)),
        )
        .toList(),
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'createdAt': createdAt,
    'assets': assets.map((asset) => asset.toMap()).toList(),
    'videoTrack': videoTrack.map((clip) => clip.toMap()).toList(),
    'audioTrack': audioTrack.map((clip) => clip.toMap()).toList(),
  };

  VeloraProject copyWith({
    String? name,
    List<MediaAsset>? assets,
    List<TimelineClip>? videoTrack,
    List<TimelineClip>? audioTrack,
  }) => VeloraProject(
    id: id,
    name: name ?? this.name,
    createdAt: createdAt,
    assets: assets ?? this.assets,
    videoTrack: videoTrack ?? this.videoTrack,
    audioTrack: audioTrack ?? this.audioTrack,
  );

  MediaAsset? assetById(String assetId) {
    for (final asset in assets) {
      if (asset.id == assetId) return asset;
    }
    return null;
  }
}

String newLocalId() =>
    '${DateTime.now().microsecondsSinceEpoch}_${DateTime.now().millisecond}';
