import 'project.dart';

/// Pure geometry shared with the Media3 framing effect. Dimensions are rounded
/// to even values for H.264 compatibility; the requested ratio still controls
/// the visible crop/letterbox independently of that rounding.
double previewStageAspectRatio({
  required VideoFrameSettings settings,
  required bool timelineMode,
  required double? timelineSourceAspectRatio,
  required double? selectedSourceAspectRatio,
}) {
  final target = settings.targetAspectRatio;
  if (target != null) return target;
  if (timelineMode &&
      timelineSourceAspectRatio != null &&
      timelineSourceAspectRatio.isFinite &&
      timelineSourceAspectRatio > 0) {
    return timelineSourceAspectRatio;
  }
  if (selectedSourceAspectRatio != null &&
      selectedSourceAspectRatio.isFinite &&
      selectedSourceAspectRatio > 0) {
    return selectedSourceAspectRatio;
  }
  return 16 / 9;
}

class FrameGeometry {
  const FrameGeometry({
    required this.outputWidth,
    required this.outputHeight,
    required this.scaleX,
    required this.scaleY,
    required this.translateX,
    required this.translateY,
  });

  final int outputWidth;
  final int outputHeight;
  final double scaleX;
  final double scaleY;
  final double translateX;
  final double translateY;
}

FrameGeometry computeFrameGeometry({
  required int sourceWidth,
  required int sourceHeight,
  required int outputHeight,
  required VideoFrameSettings settings,
}) {
  if (sourceWidth <= 0 || sourceHeight <= 0 || outputHeight <= 0) {
    throw ArgumentError('Frame dimensions must be positive');
  }
  final quarterTurns = settings.rotationQuarterTurns;
  final rotatedWidth = quarterTurns.isOdd ? sourceHeight : sourceWidth;
  final rotatedHeight = quarterTurns.isOdd ? sourceWidth : sourceHeight;
  final sourceAspect = rotatedWidth / rotatedHeight;
  final targetAspect = settings.targetAspectRatio;

  if (targetAspect == null) {
    final width = _evenDimension(outputHeight * sourceAspect);
    return FrameGeometry(
      outputWidth: width,
      outputHeight: outputHeight,
      scaleX: 1,
      scaleY: 1,
      translateX: 0,
      translateY: 0,
    );
  }

  var scaleX = 1.0;
  var scaleY = 1.0;
  if (settings.fitMode == FrameFitMode.fit) {
    if (sourceAspect > targetAspect) {
      scaleY = targetAspect / sourceAspect;
    } else {
      scaleX = sourceAspect / targetAspect;
    }
  } else {
    if (sourceAspect > targetAspect) {
      scaleX = sourceAspect / targetAspect;
    } else {
      scaleY = targetAspect / sourceAspect;
    }
  }
  final translateX = (1 - scaleX) * settings.positionX;
  final translateY = (1 - scaleY) * settings.positionY;
  return FrameGeometry(
    outputWidth: _evenDimension(outputHeight * targetAspect),
    outputHeight: outputHeight,
    scaleX: scaleX,
    scaleY: scaleY,
    translateX: translateX,
    translateY: translateY,
  );
}

int _evenDimension(double value) {
  final rounded = (value / 2).round() * 2;
  return rounded < 2 ? 2 : rounded;
}
