package com.velora.app

import org.junit.Assert.assertEquals
import org.junit.Test

@androidx.media3.common.util.UnstableApi
class VideoAudioExtractionTest {
    @Test
    fun extractedAudioDurationUsesTheVideoClipSpeedCurve() {
        val clip = mapOf(
            "id" to "video-clip",
            "trimStartMs" to 1_000L,
            "trimEndMs" to 5_000L,
            "speedRampPoints" to listOf(
                mapOf("timeMs" to 1_000L, "speed" to 2.0),
                mapOf("timeMs" to 5_000L, "speed" to 2.0),
            ),
        )

        assertEquals(2_000L, ProjectClipMotion.timingFromMap(clip).outputDurationMs)
    }
}
