import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';

void main() {
  test('text, subtitle and sticker layers persist and participate in history', () {
    final initial = VeloraProject.empty(id: 'overlay-project', name: 'Layers');
    final text = TextOverlay(
      id: 'title-1',
      text: 'مرحبا بالعالم',
      startMs: 500,
      endMs: 2600,
      templateId: 'outline',
      fontFamily: 'serif',
      fontSizeScale: 0.07,
      colorArgb: 0xFFFFD166,
      backgroundArgb: 0xB8000000,
      alignment: OverlayTextAlignment.start,
      shadow: true,
      outlineWidthScale: 0.004,
      positionX: 0.3,
      positionY: 0.45,
    );
    final subtitle = const SubtitleCue(
      id: 'sub-1',
      text: 'ترجمة عربية',
      startMs: 1000,
      endMs: 2200,
    );
    final sticker = const StickerOverlay(
      id: 'sticker-1',
      uri: 'content://stickers/1',
      name: 'star.webp',
      mimeType: 'image/webp',
      startMs: 700,
      endMs: 2400,
      positionX: 0.8,
      positionY: 0.25,
      widthFraction: 0.3,
    );
    final changed = initial.copyWith(
      textOverlays: [text],
      subtitleTrack: [subtitle],
      stickerOverlays: [sticker],
    );

    final reopened = VeloraProject.fromMap(changed.toMap());
    expect(reopened.textOverlays.single.text, text.text);
    expect(reopened.textOverlays.single.fontFamily, 'serif');
    expect(reopened.textOverlays.single.positionX, 0.3);
    expect(reopened.textOverlays.single.backgroundArgb, 0xB8000000);
    expect(reopened.textOverlays.single.alignment, OverlayTextAlignment.start);
    expect(reopened.textOverlays.single.outlineWidthScale, 0.004);
    expect(reopened.subtitleTrack.single.startMs, 1000);
    expect(reopened.stickerOverlays.single.uri, sticker.uri);
    expect(reopened.stickerOverlays.single.widthFraction, 0.3);
    expect(reopened.subtitleTrack.single.isVisibleAt(1000), isTrue);
    expect(reopened.subtitleTrack.single.isVisibleAt(2200), isFalse);
    expect(reopened.stickerOverlays.single.isVisibleAt(699), isFalse);
    expect(reopened.stickerOverlays.single.isVisibleAt(700), isTrue);

    final history = ProjectHistory(initial);
    history.record(changed);
    expect(history.undo()!.textOverlays, isEmpty);
    expect(history.redo()!.subtitleTrack.single.text, subtitle.text);
  });

  test('SRT parser reads comma or dot milliseconds and preserves cue ordering', () {
    const srt = '''
1
00:00:02,500 --> 00:00:04,000
مرحبا بالعالم

2
00:00:00.250 --> 00:00:01.500
السطر الأول
السطر الثاني

invalid block
''';

    final cues = SubtitleCue.parseSrt(srt);
    expect(cues, hasLength(2));
    expect(cues.first.startMs, 250);
    expect(cues.first.endMs, 1500);
    expect(cues.first.text, 'السطر الأول\nالسطر الثاني');
    expect(cues.last.startMs, 2500);
    expect(cues.last.endMs, 4000);
  });

  test('timestamped speech segments become bounded editable subtitle cues', () {
    final cues = subtitleCuesFromSpeechSegments(
      const [
        TimedSpeechSegment(text: '  مساء الخير  ', startMs: 900, endMs: 1_500),
        TimedSpeechSegment(text: 'مقطع خارج النهاية', startMs: 1_800, endMs: 2_500),
        TimedSpeechSegment(text: 'بداية سالبة', startMs: -200, endMs: 100),
        TimedSpeechSegment(text: '   ', startMs: 200, endMs: 300),
        TimedSpeechSegment(text: 'مدة معكوسة', startMs: 400, endMs: 350),
      ],
      durationMs: 2_000,
    );

    expect(cues.map((cue) => cue.text), ['بداية سالبة', 'مساء الخير', 'مقطع خارج النهاية']);
    expect(cues.map((cue) => [cue.startMs, cue.endMs]), [
      [0, 100],
      [900, 1_500],
      [1_800, 2_000],
    ]);
    expect(cues.every((cue) => cue.endMs > cue.startMs), isTrue);
    expect(cues.map((cue) => cue.id).toSet(), hasLength(cues.length));
    final initial = VeloraProject.empty(id: 'speech-subtitles', name: 'Speech');
    final history = ProjectHistory(initial);
    history.record(initial.copyWith(subtitleTrack: cues));
    expect(history.undo()!.subtitleTrack, isEmpty);
    expect(history.redo()!.subtitleTrack.map((cue) => cue.text), cues.map((cue) => cue.text));
    expect(
      subtitleCuesFromSpeechSegments(
        const [TimedSpeechSegment(text: 'لا تُنشأ', startMs: 0, endMs: 100)],
        durationMs: 0,
      ),
      isEmpty,
    );
  });

  test('SRT writer sorts, validates and round-trips generated cue times and text', () {
    const source = [
      SubtitleCue(id: 'late', text: 'مرحبًا\nبالعالم', startMs: 3_723_004, endMs: 3_725_500),
      SubtitleCue(id: 'early', text: '  بداية  ', startMs: 250, endMs: 1_500),
      SubtitleCue(id: 'invalid', text: 'لا تُصدر', startMs: 900, endMs: 900),
      SubtitleCue(id: 'empty', text: '  ', startMs: 100, endMs: 200),
    ];

    final srt = SubtitleCue.toSrt(source);
    expect(srt, contains('1\n00:00:00,250 --> 00:00:01,500\nبداية'));
    expect(srt, contains('2\n01:02:03,004 --> 01:02:05,500\nمرحبًا\nبالعالم'));
    expect(srt, isNot(contains('لا تُصدر')));
    final parsed = SubtitleCue.parseSrt(srt);
    expect(parsed.map((cue) => [cue.startMs, cue.endMs, cue.text]), [
      [250, 1_500, 'بداية'],
      [3_723_004, 3_725_500, 'مرحبًا\nبالعالم'],
    ]);
    expect(SubtitleCue.toSrt(const []), isEmpty);
  });

  test('text timing is start-inclusive and end-exclusive; templates remain editable', () {
    final original = TextOverlay(
      id: 't',
      text: 'عنوان',
      startMs: 100,
      endMs: 500,
    );
    expect(original.isVisibleAt(100), isTrue);
    expect(original.isVisibleAt(499), isTrue);
    expect(original.isVisibleAt(500), isFalse);

    final banner = applyTextTemplate(original, 'banner').copyWith(
      text: 'عنوان معدّل',
      positionY: 0.2,
    );
    expect(banner.backgroundArgb, 0xB8000000);
    expect(banner.text, 'عنوان معدّل');
    expect(banner.positionY, 0.2);
  });
}
