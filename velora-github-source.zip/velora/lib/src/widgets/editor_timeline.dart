import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../models/clip_motion.dart';
import '../models/overlays.dart';
import '../models/project.dart';
import '../models/timeline_ops.dart';
import '../models/timeline_position.dart';
import '../models/video_overlays.dart';
import '../models/video_transitions.dart';

typedef VideoClipReorderCallback = void Function(
  String draggedClipId,
  String targetClipId,
  bool insertAfterTarget,
);
typedef VideoClipTrimCallback = Future<void> Function(
  String clipId, {
  required bool moveStart,
  required int requestedMs,
});
typedef VideoTransitionBoundaryCallback = void Function(int boundaryIndex);
typedef TimedClipTapCallback = void Function(String clipId);
typedef TimedClipMoveCallback = void Function(
  String clipId,
  int requestedOutputStartMs,
);

/// Project-backed timeline overview with video reorder and trim gestures.
class EditorTimeline extends StatefulWidget {
  const EditorTimeline({
    super.key,
    required this.project,
    required this.playheadPositionMs,
    required this.selectedVideoClipId,
    required this.onVideoClipTap,
    this.selectedVideoOverlayClipId,
    this.selectedAudioClipId,
    this.selectedTextOverlayId,
    this.selectedSubtitleCueId,
    this.selectedStickerOverlayId,
    this.onTextOverlayTap,
    this.onTextOverlayMove,
    this.onSubtitleCueTap,
    this.onSubtitleCueMove,
    this.onStickerOverlayTap,
    this.onStickerOverlayMove,
    this.onVideoClipReorder,
    this.onVideoClipTrim,
    this.onVideoOverlayTap,
    this.onVideoOverlayMove,
    this.onAudioClipTap,
    this.onAudioClipMove,
    this.onVideoTransitionTap,
    this.allowVideoReorder = true,
  });

  static const double pixelsPerMillisecond = 0.06;

  final VeloraProject project;
  final int playheadPositionMs;
  final String? selectedVideoClipId;
  final ValueChanged<TimelineClip> onVideoClipTap;
  final String? selectedVideoOverlayClipId;
  final String? selectedAudioClipId;
  final String? selectedTextOverlayId;
  final String? selectedSubtitleCueId;
  final String? selectedStickerOverlayId;
  final TimedClipTapCallback? onTextOverlayTap;
  final TimedClipMoveCallback? onTextOverlayMove;
  final TimedClipTapCallback? onSubtitleCueTap;
  final TimedClipMoveCallback? onSubtitleCueMove;
  final TimedClipTapCallback? onStickerOverlayTap;
  final TimedClipMoveCallback? onStickerOverlayMove;
  final VideoClipReorderCallback? onVideoClipReorder;
  final VideoClipTrimCallback? onVideoClipTrim;
  final TimedClipTapCallback? onVideoOverlayTap;
  final TimedClipMoveCallback? onVideoOverlayMove;
  final TimedClipTapCallback? onAudioClipTap;
  final TimedClipMoveCallback? onAudioClipMove;
  final VideoTransitionBoundaryCallback? onVideoTransitionTap;
  final bool allowVideoReorder;

  @override
  State<EditorTimeline> createState() => _EditorTimelineState();
}

class _EditorTimelineState extends State<EditorTimeline> {
  static const double _labelWidth = 68;
  // Card default margin (4 px per side) plus this card's 12 px horizontal padding.
  static const double _cardHorizontalInset = 32;
  static const double _minimumPixelsPerMillisecond = 0.012;
  static const double _maximumPixelsPerMillisecond = 0.24;

  double _pixelsPerMillisecond = EditorTimeline.pixelsPerMillisecond;
  double _scaleStartPixelsPerMillisecond = EditorTimeline.pixelsPerMillisecond;
  double? _scaleAnchorTimeMs;
  double _lastViewportWidth = 0;
  int _lastRulerEndMs = 1000;
  double? _pendingScrollOffset;
  bool _scrollCorrectionScheduled = false;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _timelineViewportKey = GlobalKey();

  VeloraProject get project => widget.project;
  int get playheadPositionMs => widget.playheadPositionMs;
  String? get selectedVideoClipId => widget.selectedVideoClipId;
  String? get selectedVideoOverlayClipId => widget.selectedVideoOverlayClipId;
  String? get selectedAudioClipId => widget.selectedAudioClipId;
  String? get selectedTextOverlayId => widget.selectedTextOverlayId;
  String? get selectedSubtitleCueId => widget.selectedSubtitleCueId;
  String? get selectedStickerOverlayId => widget.selectedStickerOverlayId;
  ValueChanged<TimelineClip> get onVideoClipTap => widget.onVideoClipTap;

  String? _movingTimedClipKey;
  int _movingTimedClipStartMs = 0;
  double _movingTimedClipDeltaPx = 0;
  double? _movingTimedClipPointerDownX;
  final Map<String, double> _timedClipPointerDownXs = <String, double>{};
  final Map<String, double> _trimPointerDownXs = <String, double>{};

  int _displayTimedClipStart(String key, int startMs) =>
      key == _movingTimedClipKey
      ? (startMs + _movingTimedClipDeltaPx / _pixelsPerMillisecond)
            .round()
            .clamp(0, 1 << 53)
            .toInt()
      : startMs;

  void _beginTimedClipDrag(String key, int startMs, DragStartDetails details) {
    final pointerDownX = _timedClipPointerDownXs.remove(key);
    setState(() {
      _movingTimedClipKey = key;
      _movingTimedClipStartMs = startMs;
      _movingTimedClipPointerDownX = pointerDownX;
      // Drag updates start after Flutter's touch-slop threshold. Include the
      // displacement from the original pointer-down position.
      _movingTimedClipDeltaPx = pointerDownX == null
          ? 0
          : details.globalPosition.dx - pointerDownX;
    });
  }

  void _updateTimedClipDrag(String key, DragUpdateDetails details) {
    if (_movingTimedClipKey != key) return;
    final pointerDownX = _movingTimedClipPointerDownX;
    setState(() {
      _movingTimedClipDeltaPx = pointerDownX == null
          ? _movingTimedClipDeltaPx + details.delta.dx
          : details.globalPosition.dx - pointerDownX;
    });
  }

  void _finishTimedClipDrag(
    String key,
    TimedClipMoveCallback? callback,
    String clipId,
  ) {
    if (_movingTimedClipKey != key) return;
    final requestedStartMs =
        (_movingTimedClipStartMs +
                _movingTimedClipDeltaPx / _pixelsPerMillisecond)
            .round()
            .clamp(0, 1 << 53)
            .toInt();
    final changed = requestedStartMs != _movingTimedClipStartMs;
    _timedClipPointerDownXs.remove(key);
    setState(() {
      _movingTimedClipKey = null;
      _movingTimedClipStartMs = 0;
      _movingTimedClipDeltaPx = 0;
      _movingTimedClipPointerDownX = null;
    });
    if (changed) callback?.call(clipId, requestedStartMs);
  }

  void _cancelTimedClipDrag(String key) {
    _timedClipPointerDownXs.remove(key);
    if (_movingTimedClipKey != key) return;
    setState(() {
      _movingTimedClipKey = null;
      _movingTimedClipStartMs = 0;
      _movingTimedClipDeltaPx = 0;
      _movingTimedClipPointerDownX = null;
    });
  }

  double _fitPixelsPerMillisecond(int endMs, double viewportWidth) {
    final availableWidth = math.max(1.0, viewportWidth - _labelWidth);
    final scale = availableWidth / math.max(1, endMs);
    return math.min(scale, _maximumPixelsPerMillisecond).toDouble();
  }

  double _minimumScaleForExtent(int endMs, double viewportWidth) => math.min(
    _minimumPixelsPerMillisecond,
    _fitPixelsPerMillisecond(endMs, viewportWidth),
  );

  Offset? _viewportLocalPoint(Offset globalPoint) {
    final renderObject = _timelineViewportKey.currentContext
        ?.findRenderObject();
    if (renderObject is! RenderBox || !renderObject.hasSize) return null;
    return renderObject.globalToLocal(globalPoint);
  }

  void _beginPinch(Offset globalFocalPoint) {
    final localPoint = _viewportLocalPoint(globalFocalPoint);
    if (localPoint == null) return;
    final scrollOffset =
        _pendingScrollOffset ??
        (_scrollController.hasClients ? _scrollController.offset : 0.0);
    final contentX = scrollOffset + localPoint.dx;
    _scaleStartPixelsPerMillisecond = _pixelsPerMillisecond;
    _scaleAnchorTimeMs = ((contentX - _labelWidth) / _pixelsPerMillisecond)
        .clamp(0, _lastRulerEndMs)
        .toDouble();
  }

  void _updatePinch(Offset globalFocalPoint, double scaleFactor) {
    final anchorTimeMs = _scaleAnchorTimeMs;
    final localPoint = _viewportLocalPoint(globalFocalPoint);
    if (anchorTimeMs == null || localPoint == null) return;
    final minimumScale = _minimumScaleForExtent(
      _lastRulerEndMs,
      _lastViewportWidth,
    );
    final nextScale = (_scaleStartPixelsPerMillisecond * scaleFactor)
        .clamp(minimumScale, _maximumPixelsPerMillisecond)
        .toDouble();
    if (nextScale != _pixelsPerMillisecond) {
      setState(() => _pixelsPerMillisecond = nextScale);
    }
    final targetOffset = _labelWidth + anchorTimeMs * nextScale - localPoint.dx;
    _queueScrollOffset(targetOffset);
  }

  void _finishPinch() {
    _scaleAnchorTimeMs = null;
  }

  void _fitTimelineToScreen(double fitScale) {
    setState(() => _pixelsPerMillisecond = fitScale);
    _queueScrollOffset(0);
  }

  void _queueScrollOffset(double offset) {
    _pendingScrollOffset = offset;
    if (_scrollCorrectionScheduled) return;
    _scrollCorrectionScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollCorrectionScheduled = false;
      final targetOffset = _pendingScrollOffset;
      _pendingScrollOffset = null;
      if (!mounted || targetOffset == null || !_scrollController.hasClients)
        return;
      final position = _scrollController.position;
      if (!position.hasContentDimensions) return;
      _scrollController.jumpTo(
        targetOffset
            .clamp(position.minScrollExtent, position.maxScrollExtent)
            .toDouble(),
      );
    });
  }

  String? _draggedClipId;
  String? _dropTargetClipId;
  bool _dropAfterTarget = false;
  final GlobalKey _timelineContentKey = GlobalKey();
  String? _trimClipId;
  bool _trimMoveStart = false;
  int? _trimRequestedMs;
  int? _trimBaselineStartMs;
  int? _trimOriginalBoundaryMs;
  double _trimPointerOffsetPx = 0;

  void _setDropTarget(String draggedId, String targetId, bool afterTarget) {
    if (_draggedClipId != draggedId ||
        _dropTargetClipId != targetId ||
        _dropAfterTarget != afterTarget) {
      setState(() {
        _draggedClipId = draggedId;
        _dropTargetClipId = targetId;
        _dropAfterTarget = afterTarget;
      });
    }
  }

  void _clearDragState() {
    if (_draggedClipId == null && _dropTargetClipId == null) return;
    setState(() {
      _draggedClipId = null;
      _dropTargetClipId = null;
      _dropAfterTarget = false;
    });
  }

  List<TimelineClip>? _proposedVideoOrder() {
    final draggedId = _draggedClipId;
    final targetId = _dropTargetClipId;
    if (draggedId == null || targetId == null) return null;
    final sourceIndex = project.videoTrack.indexWhere(
      (clip) => clip.id == draggedId,
    );
    final targetIndex = project.videoTrack.indexWhere(
      (clip) => clip.id == targetId,
    );
    if (sourceIndex < 0 || targetIndex < 0) return null;
    final candidate = List<TimelineClip>.of(project.videoTrack)
      ..removeAt(sourceIndex);
    final targetAfterRemoval = candidate.indexWhere(
      (clip) => clip.id == targetId,
    );
    if (targetAfterRemoval < 0) return null;
    candidate.insert(
      targetAfterRemoval + (_dropAfterTarget ? 1 : 0),
      project.videoTrack[sourceIndex],
    );
    return candidate;
  }

  TimelineClip? _activeTrimClip() {
    final clipId = _trimClipId;
    if (clipId == null) return null;
    final index = project.videoTrack.indexWhere((clip) => clip.id == clipId);
    return index < 0 ? null : project.videoTrack[index];
  }

  double _transitionMarkerTimeMs(
    int boundaryIndex,
    TransitionTimelineLayout layout,
  ) {
    final nextClipStartMs = layout.startOfClip(boundaryIndex + 1);
    final stored = _storedTransitionAtBoundary(boundaryIndex);
    final active = layout.activeTransitionsByBoundary[boundaryIndex];
    return stored != null && active?.id == stored.id
        ? (nextClipStartMs + stored.durationMs / 2).toDouble()
        : nextClipStartMs.toDouble();
  }

  String _shortTransitionLabel(VideoTransitionType type) => switch (type) {
    VideoTransitionType.fade => 'تلاشي',
    VideoTransitionType.dissolve => 'ذوبان',
    VideoTransitionType.slide => 'انزلاق',
    VideoTransitionType.zoom => 'تكبير',
    VideoTransitionType.spin => 'دوران',
    VideoTransitionType.wipe => 'مسح',
    VideoTransitionType.blur => 'تمويه',
  };

  VideoTransition? _storedTransitionAtBoundary(int boundaryIndex) {
    if (boundaryIndex < 0 || boundaryIndex + 1 >= project.videoTrack.length) {
      return null;
    }
    final fromId = project.videoTrack[boundaryIndex].id;
    final toId = project.videoTrack[boundaryIndex + 1].id;
    for (final transition in project.videoTransitions) {
      if (transition.fromClipId == fromId && transition.toClipId == toId) {
        return transition;
      }
    }
    return null;
  }

  TimelineClip? _rawTrimPreviewClip() {
    final clip = _activeTrimClip();
    final requestedMs = _trimRequestedMs;
    if (clip == null || requestedMs == null) return null;
    final sourceDurationMs = project.assetById(clip.assetId)?.durationMs ?? 0;
    return updateClipTrimBoundary(
      clip,
      moveStart: _trimMoveStart,
      requestedMs: requestedMs,
      sourceDurationMs: sourceDurationMs,
    );
  }

  VideoClipTrimResult? _currentTrimResult() {
    final clip = _activeTrimClip();
    final requestedMs = _trimRequestedMs;
    if (clip == null || requestedMs == null) return null;
    return trimVideoClipSafely(
      videoTrack: project.videoTrack,
      transitions: project.videoTransitions,
      clipId: clip.id,
      moveStart: _trimMoveStart,
      requestedMs: requestedMs,
      sourceDurationMs: project.assetById(clip.assetId)?.durationMs ?? 0,
    );
  }

  void _beginTrim(
    TimelineClip clip,
    bool moveStart,
    DragStartDetails details, {
    required double pointerDownGlobalX,
  }) {
    if (widget.onVideoClipTrim == null) return;
    final index = project.videoTrack.indexWhere((item) => item.id == clip.id);
    if (index < 0) return;
    final layout = layoutVideoTransitions(
      project.videoTrack.map((item) => item.id).toList(),
      project.videoTrack.map((item) => item.effectiveDurationMs).toList(),
      project.videoTransitions,
    );
    final baselineStartMs = layout.startOfClip(index);
    final boundaryTimelineMs = moveStart
        ? baselineStartMs
        : baselineStartMs + clip.effectiveDurationMs;
    final renderObject = _timelineContentKey.currentContext?.findRenderObject();
    final boundaryGlobalX = renderObject is RenderBox
        ? renderObject
              .localToGlobal(
                Offset(
                  _labelWidth + boundaryTimelineMs * _pixelsPerMillisecond,
                  0,
                ),
              )
              .dx
        : details.globalPosition.dx;
    setState(() {
      _trimClipId = clip.id;
      _trimMoveStart = moveStart;
      _trimBaselineStartMs = baselineStartMs;
      _trimOriginalBoundaryMs = moveStart ? clip.trimStartMs : clip.trimEndMs;
      _trimRequestedMs = _trimOriginalBoundaryMs;
      _trimPointerOffsetPx = pointerDownGlobalX - boundaryGlobalX;
    });
    _updateTrimFromGlobal(details.globalPosition);
  }

  void _updateTrimFromGlobal(Offset globalPosition) {
    final clip = _activeTrimClip();
    final baselineStartMs = _trimBaselineStartMs;
    if (clip == null || baselineStartMs == null) return;
    final renderObject = _timelineContentKey.currentContext?.findRenderObject();
    if (renderObject is! RenderBox || !renderObject.hasSize) return;
    final adjustedPointer = Offset(
      globalPosition.dx - _trimPointerOffsetPx,
      globalPosition.dy,
    );
    final localPosition = renderObject.globalToLocal(adjustedPointer);
    final timelineMs =
        ((localPosition.dx - _labelWidth) / _pixelsPerMillisecond)
            .round()
            .clamp(0, 9007199254740991)
            .toInt();
    final sourceDurationMs = project.assetById(clip.assetId)?.durationMs ?? 0;
    int requestedMs;
    if (sourceDurationMs > 0) {
      final outputClockAtTrimStart = sourceOffsetToOutputMs(
        clip.trimStartMs,
        0,
        clip.effectiveSpeedRampPoints,
      );
      final desiredOutputClock =
          outputClockAtTrimStart + timelineMs - baselineStartMs;
      requestedMs = outputOffsetToSourceMs(
        desiredOutputClock,
        0,
        sourceDurationMs,
        clip.effectiveSpeedRampPoints,
      );
    } else {
      // Unknown source length: permit inward trimming only; never guess an
      // extension beyond the source range already represented by this clip.
      final localOutputOffset = (timelineMs - baselineStartMs)
          .clamp(0, clip.effectiveDurationMs)
          .toInt();
      requestedMs =
          clip.trimStartMs +
          outputOffsetToSourceMs(
            localOutputOffset,
            clip.trimStartMs,
            clip.trimEndMs,
            clip.effectiveSpeedRampPoints,
          );
    }
    if (requestedMs != _trimRequestedMs && mounted) {
      setState(() => _trimRequestedMs = requestedMs);
    }
  }

  void _finishTrim() {
    final clipId = _trimClipId;
    final requestedMs = _trimRequestedMs;
    final originalBoundaryMs = _trimOriginalBoundaryMs;
    final moveStart = _trimMoveStart;
    if (clipId != null) {
      _trimPointerDownXs.remove(
        'timeline-trim-$clipId-${moveStart ? 'start' : 'end'}',
      );
    }
    setState(() {
      _trimClipId = null;
      _trimRequestedMs = null;
      _trimBaselineStartMs = null;
      _trimOriginalBoundaryMs = null;
      _trimPointerOffsetPx = 0;
    });
    if (clipId == null ||
        requestedMs == null ||
        requestedMs == originalBoundaryMs ||
        widget.onVideoClipTrim == null) {
      return;
    }
    unawaited(
      widget.onVideoClipTrim!(
        clipId,
        moveStart: moveStart,
        requestedMs: requestedMs,
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final trimResult = _currentTrimResult();
      final rawTrimPreviewClip = _rawTrimPreviewClip();
      final displayTrack = trimResult != null && trimResult.accepted
          ? trimResult.track!
          : project.videoTrack;
      final videoLayout = layoutVideoTransitions(
        displayTrack.map((clip) => clip.id).toList(),
        displayTrack.map((clip) => clip.effectiveDurationMs).toList(),
        project.videoTransitions,
      );
      final audioDisplayTrack = project.audioTrack
          .map(
            (clip) => clip.copyWith(
              timelineStartMs: displayTrack.isEmpty
                  ? clip.timelineStartMs
                  : projectTimelineMsToOutputMs(
                      displayTrack,
                      clip.timelineStartMs,
                      transitions: project.videoTransitions,
                    ),
            ),
          )
          .toList(growable: false);
      final audioPlacements = _placeAudioClips(audioDisplayTrack);
      final audioEndMs = audioPlacements.fold<int>(
        0,
        (latest, placement) =>
            math.max(latest, placement.clip.timelineEndMs).toInt(),
      );
      final overlayPlacements = <_VideoOverlayPlacement>[];
      for (
        var trackIndex = 0;
        trackIndex < project.videoOverlayTracks.length;
        trackIndex++
      ) {
        final track = project.videoOverlayTracks[trackIndex];
        for (final clip in track.clips) {
          if (clip.durationMs <= 0) continue;
          final outputStartMs = displayTrack.isEmpty
              ? clip.timelineStartMs
              : projectTimelineMsToOutputMs(
                  displayTrack,
                  clip.timelineStartMs,
                  transitions: project.videoTransitions,
                );
          overlayPlacements.add(
            _VideoOverlayPlacement(
              trackName: track.name,
              trackIndex: trackIndex,
              clip: clip,
              outputStartMs: outputStartMs,
            ),
          );
        }
      }
      final overlayEndMs = overlayPlacements.fold<int>(
        0,
        (latest, placement) => math
            .max(latest, placement.outputStartMs + placement.clip.durationMs)
            .toInt(),
      );
      int toOutputMs(int projectMs) => displayTrack.isEmpty
          ? projectMs
          : projectTimelineMsToOutputMs(
              displayTrack,
              projectMs,
              transitions: project.videoTransitions,
            );
      final timedOverlayPlacements = <_TimedOverlayPlacement>[];
      for (final text in project.textOverlays) {
        final start = toOutputMs(text.startMs);
        final end = toOutputMs(text.endMs);
        if (end > start) {
          timedOverlayPlacements.add(
            _TimedOverlayPlacement(
              id: text.id,
              label: text.text,
              startMs: start,
              durationMs: end - start,
              isText: true,
            ),
          );
        }
      }
      for (final cue in project.subtitleTrack) {
        final start = toOutputMs(cue.startMs);
        final end = toOutputMs(cue.endMs);
        if (end > start) {
          timedOverlayPlacements.add(
            _TimedOverlayPlacement(
              id: cue.id,
              label: cue.text,
              startMs: start,
              durationMs: end - start,
              isText: false,
              isSubtitle: true,
            ),
          );
        }
      }
      for (final sticker in project.stickerOverlays) {
        final start = toOutputMs(sticker.startMs);
        final end = toOutputMs(sticker.endMs);
        if (end > start) {
          timedOverlayPlacements.add(
            _TimedOverlayPlacement(
              id: sticker.id,
              label: sticker.name,
              startMs: start,
              durationMs: end - start,
              isText: false,
              isSubtitle: false,
            ),
          );
        }
      }
      final timedOverlayEndMs = timedOverlayPlacements.fold<int>(
        0,
        (latest, placement) =>
            math.max(latest, placement.startMs + placement.durationMs).toInt(),
      );
      final timelineEndMs = math
          .max(
            videoLayout.totalDurationMs,
            math.max(
              math.max(math.max(audioEndMs, overlayEndMs), timedOverlayEndMs),
              playheadPositionMs,
            ),
          )
          .toInt();
      final rulerEndMs = timelineEndMs > 0 ? timelineEndMs : 1000;
      final viewportWidth = math
          .max(1.0, constraints.maxWidth - _cardHorizontalInset)
          .toDouble();
      _lastViewportWidth = viewportWidth;
      _lastRulerEndMs = rulerEndMs;
      final fitScale = _fitPixelsPerMillisecond(rulerEndMs, viewportWidth);
      final contentWidth = math
          .max(viewportWidth, _labelWidth + rulerEndMs * _pixelsPerMillisecond)
          .toDouble();
      final audioLaneCount = audioPlacements.fold<int>(
        1,
        (maximum, placement) => math.max(maximum, placement.lane + 1).toInt(),
      );
      const rulerHeight = 34.0;
      const videoTop = 42.0;
      const videoHeight = 48.0;
      const rowGap = 8.0;
      const audioLaneHeight = 34.0;
      const overlayLaneHeight = 34.0;
      final overlayTop = videoTop + videoHeight + rowGap;
      final videoOverlayEnd =
          overlayTop +
          overlayPlacements.length * overlayLaneHeight +
          (overlayPlacements.isEmpty ? 0 : rowGap);
      final timedOverlayTop = videoOverlayEnd;
      final audioTop =
          timedOverlayTop +
          timedOverlayPlacements.length * overlayLaneHeight +
          (timedOverlayPlacements.isEmpty ? 0 : rowGap);
      final audioHeight = math
          .max(44.0, audioLaneCount * audioLaneHeight)
          .toDouble();
      final contentHeight = audioTop + audioHeight;
      final tickStepMs = _tickStep(_pixelsPerMillisecond);
      final proposedOrder = _proposedVideoOrder();
      final reorderPreview = _draggedClipId == null || _dropTargetClipId == null
          ? null
          : reorderVideoClipSafely(
              videoTrack: project.videoTrack,
              transitions: project.videoTransitions,
              draggedClipId: _draggedClipId!,
              targetClipId: _dropTargetClipId!,
              insertAfterTarget: _dropAfterTarget,
            );
      final children = <Widget>[
        Positioned.fill(child: ColoredBox(color: const Color(0xFF111820))),
        Positioned(
          left: 0,
          top: 0,
          width: _labelWidth - 1,
          height: contentHeight,
          child: const ColoredBox(color: Color(0xFF202B36)),
        ),
        Positioned(
          left: _labelWidth,
          top: rulerHeight,
          right: 0,
          bottom: 0,
          child: const ColoredBox(color: Color(0xFF17212A)),
        ),
        Positioned(
          left: 8,
          top: videoTop + 14,
          width: _labelWidth - 14,
          child: const Directionality(
            textDirection: TextDirection.rtl,
            child: Text(
              'مرئي',
              maxLines: 1,
              style: TextStyle(color: Color(0xFFDCE5EC), fontSize: 12),
            ),
          ),
        ),
        Positioned(
          left: 8,
          top: audioTop + 10,
          width: _labelWidth - 14,
          child: const Directionality(
            textDirection: TextDirection.rtl,
            child: Text(
              'صوت',
              maxLines: 1,
              style: TextStyle(color: Color(0xFFFFD69A), fontSize: 12),
            ),
          ),
        ),
      ];
      for (var index = 0; index < overlayPlacements.length; index++) {
        children.add(
          Positioned(
            left: 8,
            top: overlayTop + index * overlayLaneHeight + 9,
            width: _labelWidth - 14,
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Text(
                'طبقة ${overlayPlacements[index].trackIndex + 1}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Color(0xFFB7D9F8), fontSize: 11),
              ),
            ),
          ),
        );
      }

      for (var index = 0; index < timedOverlayPlacements.length; index++) {
        final placement = timedOverlayPlacements[index];
        children.add(
          Positioned(
            left: 8,
            top: timedOverlayTop + index * overlayLaneHeight + 9,
            width: _labelWidth - 14,
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Text(
                placement.isSubtitle
                    ? 'ترجمة'
                    : (placement.isText ? 'نص' : 'ملصق'),
                maxLines: 1,
                style: TextStyle(
                  color: placement.isSubtitle
                      ? const Color(0xFF9BD6C4)
                      : (placement.isText
                            ? const Color(0xFFF4D27A)
                            : const Color(0xFFD8B6F3)),
                  fontSize: 11,
                ),
              ),
            ),
          ),
        );
      }

      for (var tickMs = 0; tickMs <= rulerEndMs; tickMs += tickStepMs) {
        final x = _labelWidth + tickMs * _pixelsPerMillisecond;
        children.add(
          Positioned(
            key: ValueKey('timeline-ruler-tick-$tickMs'),
            left: x,
            top: 0,
            width: 1,
            height: contentHeight,
            child: ColoredBox(color: const Color(0x223F5263)),
          ),
        );
        children.add(
          Positioned(
            left: x + 4,
            top: 7,
            child: Text(
              _formatClock(tickMs),
              style: const TextStyle(color: Color(0xFF9EADB9), fontSize: 10),
            ),
          ),
        );
      }

      if (project.videoTrack.isEmpty) {
        children.add(
          Positioned(
            left: _labelWidth + 8,
            top: videoTop + 15,
            child: const Text(
              'لا توجد مقاطع مرئية',
              style: TextStyle(color: Color(0xFF91A0AC), fontSize: 11),
            ),
          ),
        );
      }
      if (audioPlacements.isEmpty) {
        children.add(
          Positioned(
            left: _labelWidth + 8,
            top: audioTop + 13,
            child: const Text(
              'لا توجد مقاطع صوتية',
              style: TextStyle(color: Color(0xFF91A0AC), fontSize: 11),
            ),
          ),
        );
      }

      for (var index = 0; index < displayTrack.length; index++) {
        final clip = displayTrack[index];
        final durationMs = clip.effectiveDurationMs;
        if (durationMs <= 0) continue;
        final startMs = videoLayout.startOfClip(index);
        final assetName = project.assetById(clip.assetId)?.name ?? clip.id;
        final selected = clip.id == selectedVideoClipId;
        children.add(
          Positioned(
            key: ValueKey('timeline-video-${clip.id}'),
            left: _labelWidth + startMs * _pixelsPerMillisecond,
            top: videoTop + 4,
            width: math.max(4.0, durationMs * _pixelsPerMillisecond).toDouble(),
            height: videoHeight - 8,
            child: _buildVideoClipWidget(
              clip: clip,
              assetName: assetName,
              startMs: startMs,
              durationMs: durationMs,
              selected: selected,
              trimDurationPreviewMs: _trimClipId == clip.id
                  ? rawTrimPreviewClip?.effectiveDurationMs
                  : null,
              trimRejected:
                  _trimClipId == clip.id && (trimResult?.accepted == false),
            ),
          ),
        );
      }

      final trimmingClip = _activeTrimClip();
      if (trimmingClip != null && rawTrimPreviewClip != null) {
        final trimIndex = displayTrack.indexWhere(
          (clip) => clip.id == trimmingClip.id,
        );
        if (trimIndex >= 0) {
          final trimStartMs = videoLayout.startOfClip(trimIndex);
          final trimDurationMs = rawTrimPreviewClip.effectiveDurationMs;
          final badgeCenterX =
              _labelWidth +
              (trimStartMs + trimDurationMs / 2) * _pixelsPerMillisecond;
          children.add(
            Positioned(
              left: math.max(_labelWidth, badgeCenterX - 42).toDouble(),
              top: videoTop - 15,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: trimResult?.accepted == false
                      ? const Color(0xFF6A3B27)
                      : const Color(0xFF153B3A),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(
                    color: trimResult?.accepted == false
                        ? const Color(0xFFFFB26F)
                        : const Color(0xFF69DCCB),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  child: Text(
                    'المدة: ${_formatPrecise(trimDurationMs)}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          );
        }
      }

      if (widget.onVideoTransitionTap != null) {
        for (
          var boundaryIndex = 0;
          boundaryIndex + 1 < displayTrack.length;
          boundaryIndex++
        ) {
          final stored = _storedTransitionAtBoundary(boundaryIndex);
          final active = videoLayout.activeTransitionsByBoundary[boundaryIndex];
          final isActive = stored != null && active?.id == stored.id;
          final markerTimeMs = _transitionMarkerTimeMs(
            boundaryIndex,
            videoLayout,
          );
          var nearestBoundaryDistancePx = double.infinity;
          if (boundaryIndex > 0) {
            nearestBoundaryDistancePx = math
                .min(
                  nearestBoundaryDistancePx,
                  (markerTimeMs -
                              _transitionMarkerTimeMs(
                                boundaryIndex - 1,
                                videoLayout,
                              ))
                          .abs() *
                      _pixelsPerMillisecond,
                )
                .toDouble();
          }
          if (boundaryIndex + 2 < displayTrack.length) {
            nearestBoundaryDistancePx = math
                .min(
                  nearestBoundaryDistancePx,
                  (_transitionMarkerTimeMs(boundaryIndex + 1, videoLayout) -
                              markerTimeMs)
                          .abs() *
                      _pixelsPerMillisecond,
                )
                .toDouble();
          }
          final markerWidth = stored == null
              ? 30.0
              : nearestBoundaryDistancePx.isInfinite
              ? 88.0
              : math
                    .max(34.0, math.min(88.0, nearestBoundaryDistancePx - 6))
                    .toDouble();
          final fullLabel = stored == null
              ? 'إضافة انتقال'
              : '${stored.type.label} · ${_formatPrecise(stored.durationMs)}';
          final visibleLabel = stored == null
              ? fullLabel
              : '${_shortTransitionLabel(stored.type)} · ${_formatPrecise(stored.durationMs)}';
          final tooltipMessage = stored == null
              ? 'إضافة انتقال بين المقطعين'
              : '$fullLabel · ${isActive ? 'مفعّل في المعاينة' : 'غير فعّال حاليًا'}';
          children.add(
            Positioned(
              key: ValueKey('timeline-transition-boundary-$boundaryIndex'),
              left: math
                  .max(
                    _labelWidth,
                    _labelWidth +
                        markerTimeMs * _pixelsPerMillisecond -
                        markerWidth / 2,
                  )
                  .toDouble(),
              top: videoTop - 18,
              width: markerWidth,
              height: 22,
              child: Tooltip(
                message: tooltipMessage,
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    key: ValueKey('timeline-transition-edit-$boundaryIndex'),
                    borderRadius: BorderRadius.circular(7),
                    onTap: () => widget.onVideoTransitionTap!(boundaryIndex),
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: stored == null
                            ? const Color(0xFF17212A)
                            : isActive
                            ? const Color(0xFF263B43)
                            : const Color(0xFF4A3325),
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          color: stored == null
                              ? const Color(0xFF9BEBDD)
                              : isActive
                              ? const Color(0xFF70DCCB)
                              : const Color(0xFFFFB46D),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              stored == null
                                  ? Icons.add_rounded
                                  : isActive
                                  ? Icons.auto_awesome_rounded
                                  : Icons.warning_amber_rounded,
                              size: 13,
                              color: stored != null && !isActive
                                  ? const Color(0xFFFFC384)
                                  : const Color(0xFFBDF8EE),
                            ),
                            if (stored != null) ...[
                              const SizedBox(width: 3),
                              Flexible(
                                child: Text(
                                  visibleLabel,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        }
      }

      for (var index = 0; index < overlayPlacements.length; index++) {
        final placement = overlayPlacements[index];
        final clip = placement.clip;
        final startKey = 'overlay:${clip.id}';
        final startMs = _displayTimedClipStart(
          startKey,
          placement.outputStartMs,
        );
        final assetName = project.assetById(clip.assetId)?.name ?? clip.id;
        final selected = clip.id == selectedVideoOverlayClipId;
        children.add(
          Positioned(
            key: ValueKey('timeline-overlay-${clip.id}'),
            left: _labelWidth + startMs * _pixelsPerMillisecond,
            top: overlayTop + index * overlayLaneHeight + 2,
            width: math
                .max(4.0, clip.durationMs * _pixelsPerMillisecond)
                .toDouble(),
            height: overlayLaneHeight - 4,
            child: Tooltip(
              message:
                  '${placement.trackName} · $assetName · ${_formatPrecise(startMs)}–${_formatPrecise(startMs + clip.durationMs)}',
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => widget.onVideoOverlayTap?.call(clip.id),
                onHorizontalDragDown: widget.onVideoOverlayMove == null
                    ? null
                    : (details) => _timedClipPointerDownXs[startKey] =
                          details.globalPosition.dx,
                onHorizontalDragStart: widget.onVideoOverlayMove == null
                    ? null
                    : (details) =>
                          _beginTimedClipDrag(startKey, startMs, details),
                onHorizontalDragUpdate: widget.onVideoOverlayMove == null
                    ? null
                    : (details) => _updateTimedClipDrag(startKey, details),
                onHorizontalDragEnd: widget.onVideoOverlayMove == null
                    ? null
                    : (_) => _finishTimedClipDrag(
                        startKey,
                        widget.onVideoOverlayMove,
                        clip.id,
                      ),
                onHorizontalDragCancel: widget.onVideoOverlayMove == null
                    ? null
                    : () => _cancelTimedClipDrag(startKey),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: selected
                        ? const Color(0xFF346B9A)
                        : const Color(0xFF294B6A),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFFB7D9F8)
                          : const Color(0xFF78A9D0),
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Center(
                      child: Text(
                        '$assetName · ${_formatPrecise(clip.durationMs)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFEAF5FF),
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }

      for (var index = 0; index < timedOverlayPlacements.length; index++) {
        final placement = timedOverlayPlacements[index];
        final keyPrefix = placement.isSubtitle
            ? 'subtitle'
            : (placement.isText ? 'text' : 'sticker');
        final dragKey = '$keyPrefix:${placement.id}';
        final startMs = _displayTimedClipStart(dragKey, placement.startMs);
        final selected = placement.isSubtitle
            ? placement.id == selectedSubtitleCueId
            : (placement.isText
                  ? placement.id == selectedTextOverlayId
                  : placement.id == selectedStickerOverlayId);
        final moveCallback = placement.isSubtitle
            ? widget.onSubtitleCueMove
            : (placement.isText
                  ? widget.onTextOverlayMove
                  : widget.onStickerOverlayMove);
        final tapCallback = placement.isSubtitle
            ? widget.onSubtitleCueTap
            : (placement.isText
                  ? widget.onTextOverlayTap
                  : widget.onStickerOverlayTap);
        children.add(
          Positioned(
            key: ValueKey('timeline-$keyPrefix-${placement.id}'),
            left: _labelWidth + startMs * _pixelsPerMillisecond,
            top: timedOverlayTop + index * overlayLaneHeight + 2,
            width: math
                .max(4.0, placement.durationMs * _pixelsPerMillisecond)
                .toDouble(),
            height: overlayLaneHeight - 4,
            child: Tooltip(
              message:
                  '${placement.label} · ${_formatPrecise(startMs)}–${_formatPrecise(startMs + placement.durationMs)}',
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => tapCallback?.call(placement.id),
                onHorizontalDragDown: moveCallback == null
                    ? null
                    : (details) => _timedClipPointerDownXs[dragKey] =
                          details.globalPosition.dx,
                onHorizontalDragStart: moveCallback == null
                    ? null
                    : (details) =>
                          _beginTimedClipDrag(dragKey, startMs, details),
                onHorizontalDragUpdate: moveCallback == null
                    ? null
                    : (details) => _updateTimedClipDrag(dragKey, details),
                onHorizontalDragEnd: moveCallback == null
                    ? null
                    : (_) => _finishTimedClipDrag(
                        dragKey,
                        moveCallback,
                        placement.id,
                      ),
                onHorizontalDragCancel: moveCallback == null
                    ? null
                    : () => _cancelTimedClipDrag(dragKey),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: selected
                        ? (placement.isSubtitle
                              ? const Color(0xFF2B6B5C)
                              : (placement.isText
                                    ? const Color(0xFF8B741F)
                                    : const Color(0xFF69427F)))
                        : (placement.isSubtitle
                              ? const Color(0xFF245749)
                              : (placement.isText
                                    ? const Color(0xFF66571F)
                                    : const Color(0xFF513763))),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFFFFE6A5)
                          : (placement.isSubtitle
                                ? const Color(0xFF8ED1BB)
                                : (placement.isText
                                      ? const Color(0xFFD6BC61)
                                      : const Color(0xFFC59BE2))),
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Center(
                      child: Text(
                        placement.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFFFF7E8),
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }

      for (final placement in audioPlacements) {
        final clip = placement.clip;
        final startKey = 'audio:${clip.id}';
        final startMs = _displayTimedClipStart(startKey, clip.timelineStartMs);
        final durationMs = clip.durationMs;
        final assetName = project.assetById(clip.assetId)?.name ?? clip.id;
        final selected = clip.id == selectedAudioClipId;
        children.add(
          Positioned(
            key: ValueKey('timeline-audio-${clip.id}'),
            left: _labelWidth + startMs * _pixelsPerMillisecond,
            top: audioTop + placement.lane * audioLaneHeight + 2,
            width: math.max(4.0, durationMs * _pixelsPerMillisecond).toDouble(),
            height: audioLaneHeight - 4,
            child: Tooltip(
              message:
                  '$assetName · ${_formatPrecise(startMs)}–${_formatPrecise(startMs + durationMs)} · ${_formatPrecise(durationMs)}',
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => widget.onAudioClipTap?.call(clip.id),
                onHorizontalDragDown: widget.onAudioClipMove == null
                    ? null
                    : (details) => _timedClipPointerDownXs[startKey] =
                          details.globalPosition.dx,
                onHorizontalDragStart: widget.onAudioClipMove == null
                    ? null
                    : (details) =>
                          _beginTimedClipDrag(startKey, startMs, details),
                onHorizontalDragUpdate: widget.onAudioClipMove == null
                    ? null
                    : (details) => _updateTimedClipDrag(startKey, details),
                onHorizontalDragEnd: widget.onAudioClipMove == null
                    ? null
                    : (_) => _finishTimedClipDrag(
                        startKey,
                        widget.onAudioClipMove,
                        clip.id,
                      ),
                onHorizontalDragCancel: widget.onAudioClipMove == null
                    ? null
                    : () => _cancelTimedClipDrag(startKey),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: selected
                        ? const Color(0xFF936A2F)
                        : const Color(0xFF795728),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFFFFE1A9)
                          : const Color(0xFFD4A85B),
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Center(
                      child: Text(
                        '$assetName  ·  ${_formatPrecise(durationMs)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFFFF2D8),
                          fontSize: 10,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }

      final playheadX =
          _labelWidth +
          playheadPositionMs.clamp(0, rulerEndMs) * _pixelsPerMillisecond;
      children.add(
        Positioned(
          key: const ValueKey('timeline-playhead'),
          left: playheadX,
          top: 0,
          bottom: 0,
          width: 2,
          child: const IgnorePointer(
            child: ColoredBox(color: Color(0xFFFF5E68)),
          ),
        ),
      );
      children.add(
        Positioned(
          left: playheadX - 4,
          top: 0,
          width: 10,
          height: 8,
          child: const DecoratedBox(
            decoration: BoxDecoration(
              color: Color(0xFFFF5E68),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(4)),
            ),
          ),
        ),
      );

      return Card(
        clipBehavior: Clip.antiAlias,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Text(
                    'الخط الزمني',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  Flexible(
                    child: Text(
                      'المؤشر ${_formatPrecise(playheadPositionMs)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFFAFBAC5),
                        fontSize: 12,
                      ),
                    ),
                  ),
                  IconButton(
                    key: const ValueKey('timeline-fit-button'),
                    tooltip: 'ملاءمة الخط الزمني',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => _fitTimelineToScreen(fitScale),
                    icon: const Icon(Icons.zoom_out_map_rounded, size: 19),
                  ),
                ],
              ),
              if (widget.onVideoClipReorder != null) ...[
                const SizedBox(height: 8),
                _buildReorderPreview(proposedOrder, reorderPreview),
              ],
              const SizedBox(height: 8),
              Directionality(
                textDirection: TextDirection.ltr,
                child: SizedBox(
                  key: const ValueKey('timeline-scroll-viewport'),
                  width: viewportWidth,
                  height: contentHeight,
                  child: RawGestureDetector(
                    key: _timelineViewportKey,
                    behavior: HitTestBehavior.translucent,
                    gestures: <Type, GestureRecognizerFactory>{
                      _TwoFingerScaleRecognizer:
                          GestureRecognizerFactoryWithHandlers<
                            _TwoFingerScaleRecognizer
                          >(
                            () => _TwoFingerScaleRecognizer(debugOwner: this),
                            (recognizer) => recognizer
                              ..onStart = _beginPinch
                              ..onUpdate = _updatePinch
                              ..onEnd = _finishPinch,
                          ),
                    },
                    child: SingleChildScrollView(
                      key: const ValueKey('timeline-scroll-view'),
                      controller: _scrollController,
                      scrollDirection: Axis.horizontal,
                      child: SizedBox(
                        key: _timelineContentKey,
                        width: contentWidth,
                        height: contentHeight,
                        child: Stack(
                          clipBehavior: Clip.hardEdge,
                          children: children,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );

  Widget _buildVideoClipWidget({
    required TimelineClip clip,
    required String assetName,
    required int startMs,
    required int durationMs,
    required bool selected,
    required int? trimDurationPreviewMs,
    required bool trimRejected,
  }) {
    final canReorder =
        widget.allowVideoReorder && widget.onVideoClipReorder != null;
    final canTrim = widget.onVideoClipTrim != null;
    final block = GestureDetector(
      key: ValueKey('timeline-video-tap-${clip.id}'),
      behavior: HitTestBehavior.opaque,
      onTap: () => onVideoClipTap(clip),
      child: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              color: selected
                  ? const Color(0xFF168C91)
                  : const Color(0xFF315F86),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: selected
                    ? const Color(0xFF8AF1E3)
                    : const Color(0xFF5C8FB5),
                width: selected ? 2 : 1,
              ),
            ),
          ),
          if (durationMs * _pixelsPerMillisecond >= 48)
            Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (canReorder)
                    const Icon(
                      Icons.drag_indicator,
                      color: Color(0xFFD9E8F3),
                      size: 14,
                    ),
                  Flexible(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Text(
                        '${trimRejected ? '⚠ ' : ''}$assetName  ·  '
                        '${_formatPrecise(trimDurationPreviewMs ?? durationMs)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: trimRejected
                              ? const Color(0xFFFFD08A)
                              : Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          if (canReorder)
            Positioned.fill(
              child: Row(
                children: [
                  _buildDropHalf(clip, insertAfterTarget: false),
                  _buildDropHalf(clip, insertAfterTarget: true),
                ],
              ),
            ),
          if (canTrim) ...[
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              width: 14,
              child: _buildTrimHandle(clip, moveStart: true),
            ),
            Positioned(
              right: 0,
              top: 0,
              bottom: 0,
              width: 14,
              child: _buildTrimHandle(clip, moveStart: false),
            ),
          ],
        ],
      ),
    );

    final draggable = canReorder
        ? LongPressDraggable<String>(
            data: clip.id,
            maxSimultaneousDrags: 1,
            onDragStarted: () {
              setState(() {
                _draggedClipId = clip.id;
                _dropTargetClipId = null;
                _dropAfterTarget = false;
              });
            },
            onDragEnd: (_) => _clearDragState(),
            feedback: Material(
              color: Colors.transparent,
              child: Container(
                constraints: const BoxConstraints(maxWidth: 220),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 9,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF168C91),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: const [
                    BoxShadow(color: Colors.black54, blurRadius: 8),
                  ],
                ),
                child: Text(
                  assetName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
            childWhenDragging: Opacity(opacity: 0.35, child: block),
            child: block,
          )
        : block;
    return Semantics(
      button: true,
      label:
          '$assetName · ${_formatPrecise(startMs)}–${_formatPrecise(startMs + durationMs)} · ${_formatPrecise(durationMs)}',
      hint: [
        if (canReorder) 'اضغط مطولًا واسحب لإعادة الترتيب',
        if (canTrim) 'اسحب مقبض الطرف لقص بداية المقطع أو نهايته',
        if (!canTrim && !canReorder) 'اختر هذا المقطع',
      ].join('؛ '),
      child: draggable,
    );
  }

  Widget _buildTrimHandle(TimelineClip clip, {required bool moveStart}) {
    final key = 'timeline-trim-${clip.id}-${moveStart ? 'start' : 'end'}';
    return GestureDetector(
      key: ValueKey(key),
      behavior: HitTestBehavior.opaque,
      onHorizontalDragDown: (details) =>
          _trimPointerDownXs[key] = details.globalPosition.dx,
      onHorizontalDragStart: (details) => _beginTrim(
        clip,
        moveStart,
        details,
        pointerDownGlobalX:
            _trimPointerDownXs.remove(key) ?? details.globalPosition.dx,
      ),
      onHorizontalDragUpdate: (details) =>
          _updateTrimFromGlobal(details.globalPosition),
      onHorizontalDragEnd: (_) => _finishTrim(),
      onHorizontalDragCancel: _finishTrim,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xAA0B1720),
          borderRadius: BorderRadius.horizontal(
            left: moveStart ? const Radius.circular(5) : Radius.zero,
            right: moveStart ? Radius.zero : const Radius.circular(5),
          ),
          border: Border(
            left: moveStart
                ? const BorderSide(color: Color(0xFFB6FFF0), width: 2)
                : BorderSide.none,
            right: moveStart
                ? BorderSide.none
                : const BorderSide(color: Color(0xFFB6FFF0), width: 2),
          ),
        ),
        child: const Center(
          child: SizedBox(
            width: 3,
            height: 18,
            child: ColoredBox(color: Color(0xFFE4FFF9)),
          ),
        ),
      ),
    );
  }

  Widget _buildDropHalf(
    TimelineClip targetClip, {
    required bool insertAfterTarget,
  }) => Expanded(
    child: DragTarget<String>(
      onWillAcceptWithDetails: (details) =>
          widget.allowVideoReorder &&
          widget.onVideoClipReorder != null &&
          details.data != targetClip.id,
      onMove: (details) =>
          _setDropTarget(details.data, targetClip.id, insertAfterTarget),
      onLeave: (draggedId) {
        if (_draggedClipId == draggedId &&
            _dropTargetClipId == targetClip.id &&
            _dropAfterTarget == insertAfterTarget) {
          setState(() {
            _dropTargetClipId = null;
            _dropAfterTarget = false;
          });
        }
      },
      onAcceptWithDetails: (details) {
        widget.onVideoClipReorder?.call(
          details.data,
          targetClip.id,
          insertAfterTarget,
        );
        _clearDragState();
      },
      builder: (context, candidateData, rejectedData) => DecoratedBox(
        decoration: BoxDecoration(
          color: candidateData.isNotEmpty
              ? const Color(0x55A5F2EB)
              : Colors.transparent,
          border: candidateData.isNotEmpty
              ? Border.all(color: const Color(0xFF8AF1E3), width: 2)
              : null,
        ),
        child: const SizedBox.expand(),
      ),
    ),
  );

  Widget _buildReorderPreview(
    List<TimelineClip>? proposedOrder,
    VideoTrackReorderResult? result,
  ) {
    final accepted = result?.accepted ?? false;
    final status = proposedOrder == null
        ? widget.allowVideoReorder
              ? 'اضغط مطولًا واسحب لإعادة الترتيب'
              : 'إعادة الترتيب غير متاحة الآن'
        : result == null
        ? 'معاينة الترتيب'
        : result.accepted
        ? 'ترتيب مقترح'
        : 'ترتيب غير صالح';
    final message = proposedOrder != null && result != null && !result.accepted
        ? result.rejectionReason ?? 'سيُرفض هذا الترتيب'
        : status;
    return SizedBox(
      height: 40,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: proposedOrder == null
              ? const Color(0x221F303A)
              : accepted
              ? const Color(0x3326A69A)
              : const Color(0x333A2023),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: proposedOrder == null
                ? const Color(0x334F6372)
                : accepted
                ? const Color(0xFF347F79)
                : const Color(0xFF8D4B4B),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(
            children: [
              Flexible(
                flex: 2,
                child: Tooltip(
                  message: message,
                  child: Text(
                    proposedOrder == null ? status : 'معاينة: $status',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: proposedOrder == null
                          ? const Color(0xFFAFBAC5)
                          : accepted
                          ? const Color(0xFFBDEEE5)
                          : const Color(0xFFFFD5D5),
                      fontSize: 10,
                    ),
                  ),
                ),
              ),
              if (proposedOrder != null) ...[
                const SizedBox(width: 6),
                Expanded(
                  flex: 5,
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (
                            var index = 0;
                            index < proposedOrder.length;
                            index++
                          ) ...[
                            Chip(
                              visualDensity: VisualDensity.compact,
                              label: Text(
                                project
                                        .assetById(proposedOrder[index].assetId)
                                        ?.name ??
                                    proposedOrder[index].id,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (index + 1 < proposedOrder.length)
                              const Icon(
                                Icons.arrow_forward_rounded,
                                size: 14,
                                color: Color(0xFFAFBAC5),
                              ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  static int _tickStep(double pixelsPerMillisecond) {
    final targetMs = 80 / pixelsPerMillisecond;
    final magnitude = math
        .pow(10, (math.log(targetMs) / math.ln10).floor())
        .toDouble();
    final normalized = targetMs / magnitude;
    final niceStep = normalized <= 1
        ? 1
        : normalized <= 2
        ? 2
        : normalized <= 5
        ? 5
        : 10;
    return math.max(1, (niceStep * magnitude).round()).toInt();
  }

  static String _formatClock(int milliseconds) {
    final seconds = milliseconds ~/ 1000;
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  static String _formatPrecise(int milliseconds) {
    final seconds = milliseconds / 1000;
    return '${seconds.toStringAsFixed(seconds >= 10 ? 1 : 2)}ث';
  }

  static List<_AudioPlacement> _placeAudioClips(List<TimelineClip> clips) {
    final ordered =
        clips
            .where((clip) => clip.timelineStartMs >= 0 && clip.durationMs > 0)
            .toList()
          ..sort((a, b) {
            final byStart = a.timelineStartMs.compareTo(b.timelineStartMs);
            return byStart != 0 ? byStart : a.id.compareTo(b.id);
          });
    final laneEnds = <int>[];
    final placements = <_AudioPlacement>[];
    for (final clip in ordered) {
      var lane = laneEnds.indexWhere((end) => end <= clip.timelineStartMs);
      if (lane < 0) {
        lane = laneEnds.length;
        laneEnds.add(clip.timelineEndMs);
      } else {
        laneEnds[lane] = clip.timelineEndMs;
      }
      placements.add(_AudioPlacement(clip: clip, lane: lane));
    }
    return placements;
  }
}

class _TimedOverlayPlacement {
  const _TimedOverlayPlacement({
    required this.id,
    required this.label,
    required this.startMs,
    required this.durationMs,
    required this.isText,
    this.isSubtitle = false,
  });

  final String id;
  final String label;
  final int startMs;
  final int durationMs;
  final bool isText;
  final bool isSubtitle;
}

class _AudioPlacement {
  const _AudioPlacement({required this.clip, required this.lane});

  final TimelineClip clip;
  final int lane;
}

class _VideoOverlayPlacement {
  const _VideoOverlayPlacement({
    required this.trackName,
    required this.trackIndex,
    required this.clip,
    required this.outputStartMs,
  });

  final String trackName;
  final int trackIndex;
  final VideoOverlayClip clip;
  final int outputStartMs;
}

/// Joins the arena only after two tracked pointers change their span beyond
/// touch slop, so a second finger by itself does not cancel taps or drags.
class _TwoFingerScaleRecognizer extends OneSequenceGestureRecognizer {
  _TwoFingerScaleRecognizer({super.debugOwner});

  ValueChanged<Offset>? onStart;
  void Function(Offset globalFocalPoint, double scaleFactor)? onUpdate;
  VoidCallback? onEnd;

  final Map<int, Offset> _pointerLocations = <int, Offset>{};
  Offset _initialFocalPoint = Offset.zero;
  double _initialSpan = 0;
  bool _isScaling = false;
  bool _gestureRejected = false;

  @override
  String get debugDescription => 'two-finger timeline scale';

  List<int> get _trackedPointerIds =>
      _pointerLocations.keys.take(2).toList(growable: false);

  List<Offset> get _trackedLocations => _trackedPointerIds
      .map((pointer) => _pointerLocations[pointer]!)
      .toList(growable: false);

  Offset get _focalPoint {
    final points = _trackedLocations;
    return points.length < 2 ? Offset.zero : (points[0] + points[1]) / 2;
  }

  double get _currentSpan {
    final points = _trackedLocations;
    return points.length < 2 ? 0 : (points[0] - points[1]).distance;
  }

  bool _samePair(List<int> first, List<int> second) =>
      first.length == second.length &&
      first.asMap().entries.every((entry) => entry.value == second[entry.key]);

  void _rebase({required bool notifyScaleOwner}) {
    final pointerIds = _trackedPointerIds;
    if (pointerIds.length < 2) return;
    _initialFocalPoint = _focalPoint;
    _initialSpan = _currentSpan;
    if (notifyScaleOwner && _isScaling) onStart?.call(_initialFocalPoint);
  }

  @override
  void addAllowedPointer(PointerDownEvent event) {
    final previousPair = _trackedPointerIds;
    super.addAllowedPointer(event);
    _pointerLocations[event.pointer] = event.position;
    if (_gestureRejected || _pointerLocations.length < 2) return;
    final nextPair = _trackedPointerIds;
    final pairChanged = !_samePair(previousPair, nextPair);
    if (_isScaling) {
      if (pairChanged) _rebase(notifyScaleOwner: true);
      // A pointer added mid-scale has its own arena; join it without changing
      // the current scale baseline or interrupting the active gesture.
      resolve(GestureDisposition.accepted);
      return;
    }
    if (_initialSpan == 0 || pairChanged) {
      _rebase(notifyScaleOwner: false);
    }
  }

  @override
  void handleEvent(PointerEvent event) {
    if (event is PointerMoveEvent) {
      _pointerLocations[event.pointer] = event.position;
      if (_gestureRejected || _pointerLocations.length < 2) return;

      final currentSpan = _currentSpan;
      if (_initialSpan <= 0 && currentSpan > 0) {
        _rebase(notifyScaleOwner: false);
      }
      if (!_isScaling &&
          _initialSpan > 0 &&
          (currentSpan - _initialSpan).abs() >= kTouchSlop) {
        // Discard pre-slop movement so recognition starts without a scale jump.
        _rebase(notifyScaleOwner: false);
        resolve(GestureDisposition.accepted);
      }
      if (_isScaling && _initialSpan > 0) {
        onUpdate?.call(_focalPoint, currentSpan / _initialSpan);
      }
    } else if (event is PointerUpEvent || event is PointerCancelEvent) {
      final previousPair = _trackedPointerIds;
      _pointerLocations.remove(event.pointer);
      final nextPair = _trackedPointerIds;
      final pairChanged = !_samePair(previousPair, nextPair);

      if (_isScaling && nextPair.length < 2) {
        _isScaling = false;
        onEnd?.call();
        _gestureRejected = _pointerLocations.isNotEmpty;
      } else if (!_gestureRejected && nextPair.length >= 2 && pairChanged) {
        _rebase(notifyScaleOwner: _isScaling);
      } else if (!_isScaling && nextPair.length >= 2 && pairChanged) {
        _rebase(notifyScaleOwner: false);
      }

      stopTrackingPointer(event.pointer);
      if (_pointerLocations.isEmpty) _gestureRejected = false;
    }
  }

  @override
  void acceptGesture(int pointer) {
    if (_gestureRejected || _pointerLocations.length < 2 || _isScaling) return;
    _isScaling = true;
    onStart?.call(_initialFocalPoint);
  }

  @override
  void rejectGesture(int pointer) {
    if (_isScaling) {
      _isScaling = false;
      onEnd?.call();
    }
    _gestureRejected = _pointerLocations.isNotEmpty;
  }

  @override
  void didStopTrackingLastPointer(int pointer) {
    if (_isScaling) {
      _isScaling = false;
      onEnd?.call();
    }
    _pointerLocations.clear();
    _gestureRejected = false;
  }
}
