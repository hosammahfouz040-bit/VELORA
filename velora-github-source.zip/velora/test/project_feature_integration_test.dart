import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_overlays.dart';
import 'package:velora/src/models/video_transitions.dart';

void main() {
  test('split preserves every feature clock through undo/redo', () {
    const assets = <MediaAsset>[
      MediaAsset(
        id: 'a-asset', uri: 'content://a', name: 'a.mp4', mimeType: 'video/mp4',
        kind: MediaKind.video, durationMs: 1000, width: 1920, height: 1080, sizeBytes: 10,
      ),
      MediaAsset(
        id: 'b-asset', uri: 'content://b', name: 'b.mp4', mimeType: 'video/mp4',
        kind: MediaKind.video, durationMs: 1000, width: 1080, height: 1920, sizeBytes: 10,
      ),
      MediaAsset(
        id: 'c-asset', uri: 'content://c', name: 'c.mp4', mimeType: 'video/mp4',
        kind: MediaKind.video, durationMs: 1000, width: 1280, height: 720, sizeBytes: 10,
      ),
      MediaAsset(
        id: 'pip-asset', uri: 'content://pip', name: 'pip.mp4', mimeType: 'video/mp4',
        kind: MediaKind.video, durationMs: 4000, width: 640, height: 480, sizeBytes: 10,
      ),
      MediaAsset(
        id: 'audio-asset', uri: 'content://audio', name: 'music.m4a', mimeType: 'audio/mp4',
        kind: MediaKind.audio, durationMs: 5000, width: 0, height: 0, sizeBytes: 10,
      ),
    ];
    const videoTrack = <TimelineClip>[
      TimelineClip(id: 'a', assetId: 'a-asset', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(
        id: 'b', assetId: 'b-asset', trimStartMs: 0, trimEndMs: 1000,
        timelineStartMs: 321, volume: 0.45, fadeInMs: 120, fadeOutMs: 130,
        transformKeyframes: [
          ClipTransformKeyframe(timeMs: 200, positionX: 0.1, opacity: 0.7),
        ],
        speedRampPoints: [SpeedRampPoint(timeMs: 0, speed: 1)],
      ),
      TimelineClip(id: 'c', assetId: 'c-asset', trimStartMs: 0, trimEndMs: 1000),
    ];
    const transitions = <VideoTransition>[
      VideoTransition(
        id: 'ab', fromClipId: 'a', toClipId: 'b',
        type: VideoTransitionType.dissolve, durationMs: 100,
      ),
      VideoTransition(
        id: 'bc', fromClipId: 'b', toClipId: 'c',
        type: VideoTransitionType.spin, durationMs: 100, intensity: 0.7,
      ),
    ];
    const audio = TimelineClip(
      id: 'music', assetId: 'audio-asset', trimStartMs: 200, trimEndMs: 4200,
      timelineStartMs: 900, volume: 0.65, fadeInMs: 300, fadeOutMs: 500,
    );
    const pip = VideoOverlayTrack(
      id: 'pip-track', name: 'PIP', clips: [
        VideoOverlayClip(
          id: 'pip-clip', assetId: 'pip-asset', trimStartMs: 100, trimEndMs: 1300,
          timelineStartMs: 2300, positionX: 0.72, positionY: 0.24,
          widthFraction: 0.31, heightFraction: 0.4,
        ),
      ],
    );
    const text = TextOverlay(
      id: 'title', text: 'اختبار', startMs: 950, endMs: 1050,
      positionX: 0.4, positionY: 0.2,
    );
    const subtitle = SubtitleCue(id: 'sub', text: 'سطر', startMs: 1000, endMs: 1100);
    const sticker = StickerOverlay(
      id: 'sticker', uri: 'content://sticker', name: 'sticker.png', mimeType: 'image/png',
      startMs: 1050, endMs: 1150, positionX: 0.8, positionY: 0.7,
    );
    const frame = VideoFrameSettings(
      aspectRatio: '9:16', fitMode: FrameFitMode.fill,
      positionX: 0.4, positionY: -0.3, rotationQuarterTurns: 1,
      flipHorizontal: true,
    );
    final project = VeloraProject(
      id: 'integration', name: 'تكامل', createdAt: '2026-10-28T00:00:00.000Z',
      assets: assets, videoTrack: videoTrack, audioTrack: const [audio],
      frameSettings: frame, videoTransitions: transitions,
      videoOverlayTracks: const [pip], textOverlays: const [text],
      subtitleTrack: const [subtitle], stickerOverlays: const [sticker],
    );

    final originalIds = project.videoTrack.map((clip) => clip.id).toList();
    final originalDurations = project.videoTrack.map((clip) => clip.durationMs).toList();
    final originalOutputDuration = visualTimelineDurationMs(
      project.videoTrack, transitions: project.videoTransitions,
    );
    final originalTextStart = mapTransitionTimelineMs(
      text.startMs, originalIds, originalDurations, project.videoTransitions,
    );
    final originalTextEnd = mapTransitionTimelineMs(
      text.endMs, originalIds, originalDurations, project.videoTransitions,
    );
    final originalAudioStart = mapTransitionTimelineMs(
      audio.timelineStartMs, originalIds, originalDurations, project.videoTransitions,
    );
    final originalPipStart = mapTransitionTimelineMs(
      pip.clips.single.timelineStartMs, originalIds, originalDurations, project.videoTransitions,
    );

    final splitSecondId = 'b-second';
    final splitTrack = splitClipAtPosition(
      project.videoTrack, 'b', playheadMs: 1200, secondClipId: splitSecondId,
      sourceDurationMs: 1000, clipTimelineStartMsOverride: 900,
    );
    expect(splitTrack, isNotNull);
    final splitClips = splitTrack!;
    final splitTransitions = transitionsAfterClipSplit(
      project.videoTransitions,
      originalClipId: 'b',
      secondClipId: splitSecondId,
      firstSegmentDurationMs: splitClips.firstWhere((clip) => clip.id == 'b').durationMs,
      secondSegmentDurationMs: splitClips.firstWhere((clip) => clip.id == splitSecondId).durationMs,
    );
    final changed = project.copyWith(
      videoTrack: splitClips,
      videoTransitions: splitTransitions,
    );

    expect(changed.videoTransitions.map((item) => (item.fromClipId, item.toClipId)), [
      ('a', 'b'), ('b-second', 'c'),
    ]);
    expect(
      visualTimelineDurationMs(changed.videoTrack, transitions: changed.videoTransitions),
      originalOutputDuration,
    );
    expect(changed.videoTrack[1].trimEndMs, 300);
    expect(changed.videoTrack[2].trimStartMs, 300);
    for (final splitSegment in [changed.videoTrack[1], changed.videoTrack[2]]) {
      expect(splitSegment.timelineStartMs, videoTrack[1].timelineStartMs);
      expect(splitSegment.volume, videoTrack[1].volume);
      expect(splitSegment.fadeInMs, videoTrack[1].fadeInMs);
      expect(splitSegment.fadeOutMs, videoTrack[1].fadeOutMs);
      expect(
        splitSegment.transformKeyframes.map((point) => point.toMap()).toList(),
        videoTrack[1].transformKeyframes.map((point) => point.toMap()).toList(),
      );
      expect(
        splitSegment.speedRampPoints.map((point) => point.toMap()).toList(),
        videoTrack[1].speedRampPoints.map((point) => point.toMap()).toList(),
      );
    }
    final changedIds = changed.videoTrack.map((clip) => clip.id).toList();
    final changedDurations = changed.videoTrack.map((clip) => clip.durationMs).toList();
    expect(
      mapTransitionTimelineMs(text.startMs, changedIds, changedDurations, changed.videoTransitions),
      originalTextStart,
    );
    expect(
      mapTransitionTimelineMs(text.endMs, changedIds, changedDurations, changed.videoTransitions),
      originalTextEnd,
    );
    expect(
      mapTransitionTimelineMs(audio.timelineStartMs, changedIds, changedDurations, changed.videoTransitions),
      originalAudioStart,
    );
    expect(
      mapTransitionTimelineMs(pip.clips.single.timelineStartMs, changedIds, changedDurations, changed.videoTransitions),
      originalPipStart,
    );
    final pipEndAtOutputBoundary = (originalPipStart + pip.clips.single.durationMs)
        .clamp(0, originalOutputDuration)
        .toInt();
    expect(pipEndAtOutputBoundary, originalOutputDuration);

    final history = ProjectHistory(project);
    history.record(changed);
    final serialized = VeloraProject.fromMap(changed.toMap());
    expect(serialized.toMap(), changed.toMap());
    expect(serialized.audioTrack.single.timelineStartMs, audio.timelineStartMs);
    expect(serialized.audioTrack.single.volume, audio.volume);
    expect(serialized.videoOverlayTracks.single.clips.single.timelineStartMs, 2300);
    expect(serialized.videoOverlayTracks.single.clips.single.durationMs, 1200);
    expect(serialized.frameSettings, frame);
    expect(serialized.textOverlays.single.startMs, text.startMs);
    expect(serialized.subtitleTrack.single.endMs, subtitle.endMs);
    expect(serialized.stickerOverlays.single.startMs, sticker.startMs);

    expect(history.undo()!.toMap(), project.toMap());
    expect(history.redo()!.toMap(), changed.toMap());
  });
}
