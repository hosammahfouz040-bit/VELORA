package com.velora.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MultipleInputVideoGraph
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.CompositionPlayer
import androidx.media3.ui.PlayerView
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

class VeloraPreviewFactory : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    @UnstableApi
    override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
        val parameters = args as? Map<*, *> ?: emptyMap<Any, Any>()
        val uri = parameters["uri"]?.toString().orEmpty()
        val kind = parameters["kind"]?.toString().orEmpty()
        val positionMs = (parameters["positionMs"] as? Number)?.toLong() ?: 0L
        val timelineMode = parameters["timelineMode"] as? Boolean ?: false
        val imageDurationMs = (parameters["imageDurationMs"] as? Number)?.toLong() ?: 5_000L
        return VeloraPreviewView(context, uri, kind, positionMs, timelineMode, imageDurationMs)
    }
}

/** One player is owned by the active platform view and controlled by Flutter. */
@OptIn(ExperimentalApi::class)
@UnstableApi
internal object VeloraPreviewPlayerRegistry {
    data class AudioClip(
        val id: String,
        val uri: String,
        val trimStartMs: Long,
        val trimEndMs: Long,
        val timelineStartMs: Long,
        val volume: Float,
        val fadeInMs: Long,
        val fadeOutMs: Long,
    ) {
        val durationMs: Long get() = trimEndMs - trimStartMs
        val timelineEndMs: Long get() = timelineStartMs + durationMs
    }

    private data class Configuration(
        val items: List<MediaItem>,
        val durationsMs: List<Long>,
        val startIndex: Int,
        val startPositionMs: Long,
        val playWhenReady: Boolean,
        val audioClips: List<AudioClip>,
        val frameSettings: ProjectFrameSettings,
        val colorSettings: ProjectColorSettings,
        val composition: Composition? = null,
        val compositionPositionMs: Long? = null,
        val totalDurationMs: Long? = null,
    )

    private var activePlayer: ExoPlayer? = null
    private var activeCompositionPlayer: CompositionPlayer? = null
    private var compositionPlayerContext: Context? = null
    private var lastAppliedPlayer: ExoPlayer? = null
    private var lastAppliedFrameSettings: ProjectFrameSettings? = null
    private var lastAppliedColorSettings: ProjectColorSettings? = null
    private var pendingConfiguration: Configuration? = null
    private var lastError: String? = null
    private var audioLanes: List<List<AudioClip>> = emptyList()
    private val audioPlayers = mutableListOf<ExoPlayer>()
    private val activeAudioClips = mutableListOf<AudioClip?>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioSyncRunnable = object : Runnable {
        override fun run() {
            val visualPlayer: Player? = activeCompositionPlayer ?: activePlayer
            if (
                visualPlayer != null &&
                visualPlayer.playWhenReady &&
                visualPlayer.playbackState != Player.STATE_ENDED
            ) {
                syncAudioAt(
                    timelinePositionMs(visualPlayer),
                    shouldPlay = visualPlayer.isPlaying,
                )
                mainHandler.postDelayed(this, 50L)
            } else {
                audioPlayers.forEach { it.pause() }
            }
        }
    }

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            lastError = error.message ?: error.errorCodeName
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            lastError = null
        }
    }

    fun attach(
        player: ExoPlayer,
        fallbackItem: MediaItem,
        fallbackPositionMs: Long,
        fallbackDurationMs: Long,
    ) {
        activePlayer?.takeIf { it !== player }?.removeListener(listener)
        activePlayer = player
        player.addListener(listener)
        val configuration = pendingConfiguration ?: Configuration(
            items = listOf(fallbackItem),
            durationsMs = listOf(fallbackDurationMs),
            startIndex = 0,
            startPositionMs = fallbackPositionMs,
            playWhenReady = false,
            audioClips = emptyList(),
            frameSettings = ProjectFrameSettings(),
            colorSettings = ProjectColorSettings(),
        )
        try {
            if (configuration.composition == null) apply(player, configuration) else player.pause()
        } catch (error: Exception) {
            lastError = error.message ?: "تعذّر إعداد معاينة الوسائط"
            player.clearMediaItems()
        }
    }

    fun attachCompositionPlayer(player: CompositionPlayer, context: Context) {
        activeCompositionPlayer?.takeIf { it !== player }?.removeListener(listener)
        activeCompositionPlayer = player
        compositionPlayerContext = context.applicationContext
        player.addListener(listener)
        val configuration = pendingConfiguration
        if (configuration?.composition != null) {
            applyComposition(player, configuration)
        }
    }

    fun detachCompositionPlayer(player: CompositionPlayer) {
        player.removeListener(listener)
        if (activeCompositionPlayer === player) {
            activeCompositionPlayer = null
            compositionPlayerContext = null
            mainHandler.removeCallbacks(audioSyncRunnable)
            releaseAudioPlayers()
        }
    }

    fun configureTimeline(
        items: List<MediaItem>,
        durationsMs: List<Long>,
        startIndex: Int,
        startPositionMs: Long,
        playWhenReady: Boolean,
        audioClips: List<AudioClip>,
        frameSettings: ProjectFrameSettings,
        colorSettings: ProjectColorSettings,
        composition: Composition,
        compositionPositionMs: Long,
        totalDurationMs: Long,
    ) {
        require(items.isNotEmpty()) { "The visual timeline is empty" }
        require(items.size == durationsMs.size) { "Timeline item metadata is inconsistent" }
        val configuration = Configuration(
            items = items,
            durationsMs = durationsMs,
            startIndex = startIndex.coerceIn(0, items.lastIndex),
            startPositionMs = startPositionMs.coerceAtLeast(0L),
            playWhenReady = playWhenReady,
            audioClips = audioClips,
            frameSettings = frameSettings,
            colorSettings = colorSettings,
            composition = composition,
            compositionPositionMs = compositionPositionMs.coerceAtLeast(0L),
            totalDurationMs = totalDurationMs.coerceAtLeast(0L),
        )
        pendingConfiguration = configuration
        lastError = null
        activePlayer?.pause()
        activeCompositionPlayer?.let { applyComposition(it, configuration) }
    }

    fun setSource(
        item: MediaItem,
        positionMs: Long,
        durationMs: Long,
        frameSettings: ProjectFrameSettings = ProjectFrameSettings(),
        colorSettings: ProjectColorSettings = ProjectColorSettings(),
    ) {
        val configuration = Configuration(
            items = listOf(item),
            durationsMs = listOf(durationMs),
            startIndex = 0,
            startPositionMs = positionMs.coerceAtLeast(0L),
            playWhenReady = false,
            audioClips = emptyList(),
            frameSettings = frameSettings,
            colorSettings = colorSettings,
        )
        pendingConfiguration = configuration
        lastError = null
        activeCompositionPlayer?.pause()
        activePlayer?.let { apply(it, configuration) }
    }

    fun clear() {
        pendingConfiguration = null
        lastError = null
        mainHandler.removeCallbacks(audioSyncRunnable)
        activePlayer?.let { player ->
            player.pause()
            player.clearMediaItems()
        }
        activeCompositionPlayer?.pause()
        audioLanes = emptyList()
        releaseAudioPlayers()
    }

    fun seekTo(mediaItemIndex: Int, clipPositionMs: Long, compositionPositionMs: Long? = null) {
        val configuration = pendingConfiguration
        val configuredDuration = configuration?.durationsMs?.getOrNull(mediaItemIndex) ?: 0L
        val safePosition = if (configuredDuration > 0L) {
            clipPositionMs.coerceIn(0L, configuredDuration)
        } else {
            clipPositionMs.coerceAtLeast(0L)
        }
        if (configuration != null && mediaItemIndex in configuration.items.indices) {
            pendingConfiguration = configuration.copy(
                startIndex = mediaItemIndex,
                startPositionMs = safePosition,
                compositionPositionMs = compositionPositionMs ?: (
                    configuration.durationsMs.take(mediaItemIndex).sum() + safePosition
                ),
            )
            lastError = null
        }

        val timelinePosition = compositionPositionMs ?: configuration?.let { current ->
            current.compositionPositionMs
                ?: current.durationsMs.take(mediaItemIndex).sum() + safePosition
        } ?: safePosition
        val compositionPlayer = activeCompositionPlayer
        if (compositionPlayer != null && configuration?.composition != null) {
            compositionPlayer.seekTo(timelinePosition)
            lastError = null
            syncAudioAt(timelinePosition, shouldPlay = compositionPlayer.isPlaying, forceSeek = true)
            return
        }
        val player = activePlayer
        if (player != null && mediaItemIndex in 0 until player.mediaItemCount) {
            player.seekTo(mediaItemIndex, safePosition)
            lastError = null
            syncAudioAt(timelinePosition, shouldPlay = player.isPlaying, forceSeek = true)
        }
    }

    fun play() {
        pendingConfiguration = pendingConfiguration?.copy(playWhenReady = true)
        val compositionPlayer = activeCompositionPlayer
        if (compositionPlayer != null && pendingConfiguration?.composition != null) {
            compositionPlayer.play()
            syncAudioAt(compositionPlayer.currentPosition, shouldPlay = true, forceSeek = true)
            mainHandler.removeCallbacks(audioSyncRunnable)
            mainHandler.post(audioSyncRunnable)
            return
        }
        activePlayer?.play()
        val player = activePlayer
        if (player != null) {
            syncAudioAt(timelinePositionMs(player), shouldPlay = true, forceSeek = true)
            mainHandler.removeCallbacks(audioSyncRunnable)
            mainHandler.post(audioSyncRunnable)
        }
    }

    fun pause() {
        pendingConfiguration = pendingConfiguration?.copy(playWhenReady = false)
        mainHandler.removeCallbacks(audioSyncRunnable)
        activeCompositionPlayer?.pause()
        activePlayer?.pause()
        audioPlayers.forEach { it.pause() }
    }

    fun state(): Map<String, Any?> {
        val compositionPlayer = activeCompositionPlayer?.takeIf { pendingConfiguration?.composition != null }
        val player: Player? = compositionPlayer ?: activePlayer
        val configuration = pendingConfiguration
        val compositionPositionMs = compositionPlayer?.currentPosition?.coerceAtLeast(0L)
        val cursor = if (compositionPositionMs != null && configuration != null) {
            timelineCursor(configuration.durationsMs, compositionPositionMs)
        } else null
        return mapOf(
            "isPlaying" to (player?.isPlaying ?: false),
            "mediaItemIndex" to (cursor?.first ?: player?.currentMediaItemIndex ?: -1),
            "positionMs" to (cursor?.second ?: player?.currentPosition ?: 0L),
            "timelinePositionMs" to compositionPositionMs,
            "playbackState" to when (player?.playbackState) {
                Player.STATE_BUFFERING -> "buffering"
                Player.STATE_READY -> "ready"
                Player.STATE_ENDED -> "ended"
                else -> "idle"
            },
            "error" to lastError,
        )
    }

    fun detach(player: ExoPlayer) {
        player.removeListener(listener)
        if (activePlayer === player) {
            activePlayer = null
            if (activeCompositionPlayer == null) {
                mainHandler.removeCallbacks(audioSyncRunnable)
                releaseAudioPlayers()
            }
        }
    }

    private fun apply(player: ExoPlayer, configuration: Configuration) {
        player.pause()
        if (configuration.items.isEmpty()) {
            player.clearMediaItems()
            releaseAudioPlayers()
            return
        }
        val index = configuration.startIndex.coerceIn(0, configuration.items.lastIndex)
        val durationMs = configuration.durationsMs[index]
        val positionMs = if (durationMs > 0L) {
            configuration.startPositionMs.coerceIn(0L, durationMs)
        } else {
            configuration.startPositionMs.coerceAtLeast(0L)
        }
        if (
            lastAppliedPlayer !== player ||
            lastAppliedFrameSettings != configuration.frameSettings ||
            lastAppliedColorSettings != configuration.colorSettings
        ) {
            val effects = ProjectFrameEffects.createPreview(configuration.frameSettings) +
                ProjectColorEffects.create(configuration.colorSettings)
            if (lastAppliedPlayer === player || effects.isNotEmpty()) {
                player.setVideoEffects(effects)
            }
            lastAppliedPlayer = player
            lastAppliedFrameSettings = configuration.frameSettings
            lastAppliedColorSettings = configuration.colorSettings
        }
        player.setMediaItems(configuration.items, index, positionMs)
        player.prepare()
        val totalDurationMs = configuration.durationsMs.sum()
        audioLanes = buildAudioLanes(configuration.audioClips, totalDurationMs)
        ensureAudioPlayers(player.applicationContext, audioLanes.size)
        val timelineStartMs = configuration.durationsMs.take(index).sum() + positionMs
        if (configuration.playWhenReady) {
            player.play()
            syncAudioAt(timelineStartMs, shouldPlay = true, forceSeek = true)
            mainHandler.removeCallbacks(audioSyncRunnable)
            mainHandler.post(audioSyncRunnable)
        } else {
            player.pause()
            mainHandler.removeCallbacks(audioSyncRunnable)
            syncAudioAt(timelineStartMs, shouldPlay = false, forceSeek = true)
        }
    }

    private fun applyComposition(player: CompositionPlayer, configuration: Configuration) {
        val composition = configuration.composition ?: return
        player.pause()
        val index = configuration.startIndex.coerceIn(0, configuration.durationsMs.lastIndex)
        val durationMs = configuration.durationsMs[index]
        val localPositionMs = if (durationMs > 0L) {
            configuration.startPositionMs.coerceIn(0L, durationMs)
        } else {
            configuration.startPositionMs.coerceAtLeast(0L)
        }
        val compositionPositionMs = configuration.compositionPositionMs
            ?: (configuration.durationsMs.take(index).sum() + localPositionMs)
        player.setComposition(composition, compositionPositionMs)
        player.prepare()
        val totalDurationMs = configuration.totalDurationMs ?: configuration.durationsMs.sum()
        audioLanes = buildAudioLanes(configuration.audioClips, totalDurationMs)
        ensureAudioPlayers(compositionPlayerContext ?: throw IllegalStateException("Preview context is missing"), audioLanes.size)
        if (configuration.playWhenReady) {
            player.play()
            syncAudioAt(compositionPositionMs, shouldPlay = true, forceSeek = true)
            mainHandler.removeCallbacks(audioSyncRunnable)
            mainHandler.post(audioSyncRunnable)
        } else {
            mainHandler.removeCallbacks(audioSyncRunnable)
            syncAudioAt(compositionPositionMs, shouldPlay = false, forceSeek = true)
        }
    }

    private fun timelineCursor(durationsMs: List<Long>, positionMs: Long): Pair<Int, Long>? {
        if (durationsMs.isEmpty()) return null
        var remaining = positionMs.coerceAtLeast(0L)
        durationsMs.forEachIndexed { index, duration ->
            if (remaining < duration || index == durationsMs.lastIndex) {
                return index to remaining.coerceIn(0L, duration)
            }
            remaining -= duration
        }
        return durationsMs.lastIndex to durationsMs.last()
    }

    private fun timelinePositionMs(player: Player): Long {
        if (player === activeCompositionPlayer) return player.currentPosition.coerceAtLeast(0L)
        val exoPlayer = player as? ExoPlayer ?: return player.currentPosition.coerceAtLeast(0L)
        val configuration = pendingConfiguration ?: return exoPlayer.currentPosition.coerceAtLeast(0L)
        val itemIndex = exoPlayer.currentMediaItemIndex
        if (itemIndex !in configuration.durationsMs.indices) return 0L
        return configuration.durationsMs.take(itemIndex).sum() + exoPlayer.currentPosition.coerceAtLeast(0L)
    }

    private fun buildAudioLanes(clips: List<AudioClip>, totalDurationMs: Long): List<List<AudioClip>> {
        if (totalDurationMs <= 0L) return emptyList()
        val lanes = mutableListOf<MutableList<AudioClip>>()
        val laneEnds = mutableListOf<Long>()
        for (clip in clips.sortedWith(compareBy<AudioClip> { it.timelineStartMs }.thenBy { it.id })) {
            if (clip.durationMs <= 0L || clip.timelineStartMs >= totalDurationMs) continue
            val clippedDurationMs = minOf(clip.durationMs, totalDurationMs - clip.timelineStartMs)
            val effective = clip.copy(trimEndMs = clip.trimStartMs + clippedDurationMs)
            val laneIndex = laneEnds.indexOfFirst { it <= effective.timelineStartMs }
                .let { if (it < 0) laneEnds.size else it }
            if (laneIndex == lanes.size) lanes.add(mutableListOf())
            if (laneIndex == laneEnds.size) laneEnds.add(effective.timelineEndMs)
            else laneEnds[laneIndex] = effective.timelineEndMs
            lanes[laneIndex].add(effective)
        }
        return lanes
    }

    private fun ensureAudioPlayers(context: Context, requestedCount: Int) {
        while (audioPlayers.size > requestedCount) {
            audioPlayers.removeAt(audioPlayers.lastIndex).release()
            activeAudioClips.removeAt(activeAudioClips.lastIndex)
        }
        while (audioPlayers.size < requestedCount) {
            val player = ExoPlayer.Builder(context).build().apply {
                setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    false,
                )
                volume = 0f
            }
            audioPlayers += player
            activeAudioClips += null
        }
    }

    private fun releaseAudioPlayers() {
        audioPlayers.forEach { it.release() }
        audioPlayers.clear()
        activeAudioClips.clear()
    }

    private fun syncAudioAt(
        timelinePositionMs: Long,
        shouldPlay: Boolean,
        forceSeek: Boolean = false,
    ) {
        audioLanes.forEachIndexed { laneIndex, lane ->
            val player = audioPlayers.getOrNull(laneIndex) ?: return@forEachIndexed
            val clip = lane.firstOrNull {
                timelinePositionMs >= it.timelineStartMs && timelinePositionMs < it.timelineEndMs
            }
            if (clip == null) {
                player.pause()
                player.volume = 0f
                activeAudioClips[laneIndex] = null
                return@forEachIndexed
            }

            val localPositionMs = (timelinePositionMs - clip.timelineStartMs).coerceIn(0L, clip.durationMs)
            val clipChanged = activeAudioClips.getOrNull(laneIndex) != clip
            if (clipChanged) {
                val item = MediaItem.Builder()
                    .setUri(Uri.parse(clip.uri))
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(clip.trimStartMs)
                            .setEndPositionMs(clip.trimEndMs)
                            .build(),
                    )
                    .build()
                player.pause()
                player.setMediaItem(item, localPositionMs)
                player.prepare()
                activeAudioClips[laneIndex] = clip
            } else if (forceSeek || kotlin.math.abs(player.currentPosition - localPositionMs) > 100L) {
                player.seekTo(localPositionMs)
            }

            val fadeIn = if (clip.fadeInMs > 0L) {
                (localPositionMs.toFloat() / clip.fadeInMs).coerceIn(0f, 1f)
            } else 1f
            val remainingMs = clip.durationMs - localPositionMs
            val fadeOut = if (clip.fadeOutMs > 0L) {
                (remainingMs.toFloat() / clip.fadeOutMs).coerceIn(0f, 1f)
            } else 1f
            player.volume = (clip.volume * fadeIn * fadeOut).coerceIn(0f, 1f)
            if (shouldPlay) player.play() else player.pause()
        }
    }
}

@OptIn(ExperimentalApi::class)
@UnstableApi
private class VeloraPreviewView(
    context: Context,
    uriText: String,
    kind: String,
    initialPositionMs: Long,
    timelineMode: Boolean,
    imageDurationMs: Long,
) : PlatformView {
    private var player: ExoPlayer? = null
    private var compositionPlayer: CompositionPlayer? = null
    private var imageExecutor: ExecutorService? = null
    private var imageLoadTask: Future<*>? = null
    private var previewImage: ImageView? = null
    private var imageLayoutListener: View.OnLayoutChangeListener? = null
    @Volatile private var disposed = false
    @Volatile private var previewBitmap: Bitmap? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val root: View = when {
        timelineMode -> createPlayerView(
            context,
            uriText,
            kind,
            initialPositionMs,
            imageDurationMs,
            timelineMode = true,
        )
        kind == "video" || kind == "image" -> createPlayerView(
            context,
            uriText,
            kind,
            initialPositionMs,
            imageDurationMs,
            timelineMode = false,
        )
        else -> TextView(context).apply {
            text = "المعاينة متاحة للفيديو والصورة"
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
    }

    private fun createPlayerView(
        context: Context,
        uriText: String,
        kind: String,
        initialPositionMs: Long,
        imageDurationMs: Long,
        timelineMode: Boolean,
    ): View {
        val playerView = PlayerView(context).apply {
            useController = !timelineMode
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        if (timelineMode) {
            // MultiInputVideoGraph is required for true multi-sequence PIP composition.
            val composition = CompositionPlayer.Builder(context)
                .setVideoGraphFactory(MultipleInputVideoGraph.Factory())
                .build()
            compositionPlayer = composition
            playerView.player = composition
            VeloraPreviewPlayerRegistry.attachCompositionPlayer(composition, context)
        } else {
            val itemBuilder = MediaItem.Builder().setUri(Uri.parse(uriText))
            val fallbackDuration = if (kind == "image") imageDurationMs else 0L
            if (kind == "image") itemBuilder.setImageDurationMs(imageDurationMs.coerceAtLeast(1L))
            val exoPlayer = ExoPlayer.Builder(context).build()
            player = exoPlayer
            playerView.player = exoPlayer
            VeloraPreviewPlayerRegistry.attach(
                exoPlayer,
                itemBuilder.build(),
                initialPositionMs.coerceAtLeast(0L),
                fallbackDuration,
            )
        }
        return playerView
    }

    private fun createImage(context: Context, uriText: String): View {
        val frame = FrameLayout(context)
        val image = ImageView(context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "معاينة صورة"
        }
        val failureLabel = TextView(context).apply {
            text = "تعذّر تحميل الصورة"
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            visibility = View.GONE
        }
        frame.addView(
            image,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        frame.addView(
            failureLabel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )

        val executor = Executors.newSingleThreadExecutor()
        imageExecutor = executor
        previewImage = image
        var decodeStarted = false
        fun startDecodeWhenSized() {
            if (decodeStarted || disposed || executor.isShutdown) return
            val targetWidth = image.width
            val targetHeight = image.height
            if (targetWidth <= 0 || targetHeight <= 0) return
            decodeStarted = true
            imageLayoutListener?.let(image::removeOnLayoutChangeListener)
            imageLayoutListener = null
            imageLoadTask = executor.submit {
                val bitmap = try {
                    decodePreviewBitmap(
                        context,
                        Uri.parse(uriText),
                        targetWidth,
                        targetHeight,
                    )
                } catch (_: Exception) {
                    null
                }
                val posted = mainHandler.post {
                    if (disposed || executor.isShutdown) {
                        bitmap?.recycle()
                    } else if (bitmap == null) {
                        failureLabel.visibility = View.VISIBLE
                    } else {
                        previewBitmap = bitmap
                        image.setImageBitmap(bitmap)
                    }
                }
                if (!posted) bitmap?.recycle()
            }
        }
        val layoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            startDecodeWhenSized()
        }
        imageLayoutListener = layoutListener
        image.addOnLayoutChangeListener(layoutListener)
        image.post { startDecodeWhenSized() }
        return frame
    }

    private fun decodePreviewBitmap(
        context: Context,
        uri: Uri,
        targetWidth: Int,
        targetHeight: Int,
    ): Bitmap? {
        if (Thread.currentThread().isInterrupted || disposed) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val scale = minOf(
            1.0,
            targetWidth.toDouble() / bounds.outWidth,
            targetHeight.toDouble() / bounds.outHeight,
        )
        val desiredWidth = (bounds.outWidth * scale).toInt().coerceAtLeast(1)
        val desiredHeight = (bounds.outHeight * scale).toInt().coerceAtLeast(1)
        var sampleSize = 1
        while (sampleSize <= Int.MAX_VALUE / 2) {
            val nextSample = sampleSize * 2
            if (
                bounds.outWidth / nextSample < desiredWidth ||
                bounds.outHeight / nextSample < desiredHeight
            ) {
                break
            }
            sampleSize = nextSample
        }
        if (Thread.currentThread().isInterrupted || disposed) return null
        val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
    }

    override fun getView(): View = root

    override fun dispose() {
        disposed = true
        imageLayoutListener?.let { listener ->
            previewImage?.removeOnLayoutChangeListener(listener)
        }
        imageLayoutListener = null
        previewImage = null
        imageLoadTask?.cancel(true)
        imageExecutor?.shutdownNow()
        imageExecutor = null
        previewBitmap?.recycle()
        previewBitmap = null
        compositionPlayer?.let { active ->
            VeloraPreviewPlayerRegistry.detachCompositionPlayer(active)
            active.stop()
            active.release()
        }
        compositionPlayer = null
        player?.let { active ->
            VeloraPreviewPlayerRegistry.detach(active)
            active.release()
        }
        player = null
    }
}
