import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_support/target_platform.dart';

import 'package:velora/src/models/project.dart';
import 'package:velora/src/screens/editor_screen.dart';

const _nativeChannel = MethodChannel('velora/native');

class _NativeRecorder {
  final savedProjects = <Map<String, dynamic>>[];

  void install() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          switch (call.method) {
            case 'saveProject':
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
              return null;
            case 'pausePreview':
            case 'clearPreview':
              return null;
            default:
              throw StateError('Unexpected native call: ${call.method}');
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );
  }
}

VeloraProject _project() => const VeloraProject(
  id: 'transform-keyframe-ui',
  name: 'اختبار الإطارات المفتاحية',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [
    MediaAsset(
      id: 'asset',
      uri: 'content://media/video/1',
      name: 'clip.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 5000,
      width: 1920,
      height: 1080,
      sizeBytes: 1,
    ),
  ],
  videoTrack: [
    TimelineClip(id: 'clip', assetId: 'asset', trimStartMs: 0, trimEndMs: 5000),
  ],
  audioTrack: [],
);

Map<String, dynamic> _savedClip(_NativeRecorder recorder) {
  final track = recorder.savedProjects.last['videoTrack'] as List;
  return Map<String, dynamic>.from(track.single as Map);
}

List<Map<String, dynamic>> _savedFrames(_NativeRecorder recorder) =>
    (_savedClip(recorder)['transformKeyframes'] as List)
        .map((row) => Map<String, dynamic>.from(row as Map))
        .toList();

void main() {
  testWidgetsOnPlatform(
    'single selected clip adds, edits, deletes and history restores keyframes',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _NativeRecorder()..install();

      await tester.pumpWidget(
        MaterialApp(home: EditorScreen(project: _project())),
      );
      await tester.pump();
      final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip'));
      await tester.ensureVisible(clipTap);
      await tester.tap(clipTap);
      await tester.pumpAndSettle();

      expect(
        find.byKey(const ValueKey('clip-transform-keyframes-clip')),
        findsOneWidget,
      );
      final addButton = find.byKey(
        const ValueKey('add-transform-keyframe-clip'),
      );
      await tester.ensureVisible(addButton);
      expect(tester.widget<OutlinedButton>(addButton).onPressed, isNotNull);
      await tester.tap(addButton);
      await tester.pumpAndSettle();

      expect(_savedFrames(recorder), [
        {
          'timeMs': 0,
          'positionX': 0.0,
          'positionY': 0.0,
          'scale': 1.0,
          'rotationDegrees': 0.0,
          'opacity': 1.0,
          'interpolation': 'smooth',
        },
      ]);

      final positionX = find.byKey(
        const ValueKey('transform-keyframe-x-clip-0'),
      );
      await tester.ensureVisible(positionX);
      var xSlider = tester.widget<Slider>(positionX);
      xSlider.onChanged!(0.5);
      await tester.pump();
      xSlider = tester.widget<Slider>(positionX);
      xSlider.onChangeEnd!(0.5);
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['positionX'], 0.5);

      final scaleKey = find.byKey(
        const ValueKey('transform-keyframe-scale-clip-0'),
      );
      await tester.ensureVisible(scaleKey);
      var scaleSlider = tester.widget<Slider>(scaleKey);
      scaleSlider.onChanged!(2.0);
      await tester.pump();
      scaleSlider = tester.widget<Slider>(scaleKey);
      scaleSlider.onChangeEnd!(2.0);
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['scale'], 2.0);

      final rotationKey = find.byKey(
        const ValueKey('transform-keyframe-rotation-clip-0'),
      );
      await tester.ensureVisible(rotationKey);
      var rotationSlider = tester.widget<Slider>(rotationKey);
      rotationSlider.onChanged!(90.0);
      await tester.pump();
      rotationSlider = tester.widget<Slider>(rotationKey);
      rotationSlider.onChangeEnd!(90.0);
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['rotationDegrees'], 90.0);

      final editTime = find.byKey(
        const ValueKey('edit-transform-keyframe-time-clip'),
      );
      await tester.ensureVisible(editTime);
      await tester.tap(editTime);
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextField).last, '1000');
      await tester.tap(find.text('تطبيق'));
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['timeMs'], 1000);
      expect(_savedFrames(recorder).single['positionX'], 0.5);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['timeMs'], 0);
      expect(_savedFrames(recorder).single['positionX'], 0.5);

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['timeMs'], 1000);

      final deleteFrame = find.byKey(
        const ValueKey('delete-transform-keyframe-clip'),
      );
      await tester.ensureVisible(deleteFrame);
      await tester.tap(deleteFrame);
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder), isEmpty);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(_savedFrames(recorder).single['timeMs'], 1000);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );
}
