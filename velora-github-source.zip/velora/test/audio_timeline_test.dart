import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/audio_timeline.dart';
import 'package:velora/src/models/project.dart';

TimelineClip _clip(String id, int startMs, int durationMs) => TimelineClip(
  id: id,
  assetId: 'asset-$id',
  trimStartMs: 0,
  trimEndMs: durationMs,
  timelineStartMs: startMs,
);

void main() {
  test('layout honors independent positions and mixes overlapping clips', () {
    final clips = [
      _clip('later', 5000, 2000),
      _clip('first', 0, 4000),
      _clip('overlap', 2000, 3000),
    ];

    final spans = layoutAudioTrack(clips, projectDurationMs: 8000);
    expect(spans.map((span) => span.clip.id), ['first', 'overlap', 'later']);
    expect(spans.map((span) => span.lane), [0, 1, 0]);
    expect(spans.map((span) => (span.startMs, span.endMs)), [
      (0, 4000),
      (2000, 5000),
      (5000, 7000),
    ]);
    // Layout is playback-only; it must not reorder persisted/UI track order.
    expect(clips.map((clip) => clip.id), ['later', 'first', 'overlap']);
  });

  test('layout trims clips at video end and skips clips beyond it', () {
    final spans = layoutAudioTrack(
      [_clip('tail', 4000, 3000), _clip('offscreen', 7000, 1000)],
      projectDurationMs: 5000,
    );
    expect(spans, hasLength(1));
    expect(spans.single.startMs, 4000);
    expect(spans.single.endMs, 5000);
  });

  test('moving an audio clip clamps its timeline start and retains other edits', () {
    final clip = _clip('move', 500, 2000).copyWith(
      trimStartMs: 300,
      trimEndMs: 2300,
      volume: 0.4,
      fadeInMs: 250,
      fadeOutMs: 350,
    );
    final moved = moveAudioClipToPosition(
      clip,
      requestedMs: -100,
      projectDurationMs: 9000,
    );
    expect(moved?.timelineStartMs, 0);
    expect(moved?.trimStartMs, 300);
    expect(moved?.trimEndMs, 2300);
    expect(moved?.volume, 0.4);
    expect(moved?.fadeInMs, 250);
    expect(moved?.fadeOutMs, 350);
    expect(
      moveAudioClipToPosition(
        clip,
        requestedMs: 10000,
        projectDurationMs: 9000,
      )?.timelineStartMs,
      9000,
    );
    expect(
      moveAudioClipToPosition(
        clip,
        requestedMs: 500,
        projectDurationMs: 9000,
      ),
      isNull,
    );
  });

  test('audio project duration is based on latest positioned clip end', () {
    expect(
      audioTimelineDurationMs([_clip('a', 1000, 2500), _clip('b', 5000, 700)]),
      5700,
    );
  });
}
