import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/clip_motion.dart';
import '../models/overlays.dart';
import '../models/project.dart';
import '../models/project_history.dart';
import '../models/project_templates.dart';
import '../models/timeline_ops.dart';
import '../models/timeline_position.dart';
import '../models/video_overlays.dart';
import '../models/video_transitions.dart';
import '../models/video_filter_presets.dart';
import '../services/native_bridge.dart';
import '../services/media_access_recovery.dart';
import '../theme.dart';
import '../widgets/editor_timeline.dart';
import 'export_screen.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.project});

  final VeloraProject project;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late VeloraProject _project;
  late ProjectHistory _history;
  Timer? _stateTimer;
  final TextEditingController _overlayTextController = TextEditingController();
  final TextEditingController _keyframeTimeController = TextEditingController();
  bool _configured = false;
  bool _configuring = false;
  bool _playing = false;
  bool _saving = false;
  bool _hasUnsavedChanges = false;
  bool _importingMedia = false;
  bool _exportingNavigation = false;
  bool _pollInProgress = false;
  bool _isScrubbing = false;
  bool _projectOperationInProgress = false;
  int _previewGeneration = 0;
  int _positionMs = 0;
  int _durationMs = 0;
  String? _selectedTimelineClipId;
  String? _extractingAudioClipId;
  String? _selectedVideoOverlayClipId;
  String? _selectedAudioClipId;
  String? _selectedTextOverlayId;
  String? _selectedSubtitleCueId;
  String? _selectedStickerOverlayId;
  int? _videoOverlayStartDraftMs;
  int? _videoOverlayDurationDraftMs;
  int? _audioStartDraftMs;
  int? _audioSourceStartDraftMs;
  int? _audioDurationDraftMs;
  double? _audioVolumeDraft;
  int? _audioFadeInDraftMs;
  int? _audioFadeOutDraftMs;
  double? _videoAudioVolumeDraft;
  int? _videoAudioFadeInDraftMs;
  int? _videoAudioFadeOutDraftMs;
  int? _textStartDraftMs;
  int? _textDurationDraftMs;
  TextOverlay? _textStyleDraft;
  int? _stickerStartDraftMs;
  int? _stickerDurationDraftMs;
  StickerOverlay? _stickerDraft;
  String? _colorDraftClipId;
  VideoColorSettings? _colorDraftSettings;
  String? _speedDraftClipId;
  List<SpeedRampPoint>? _speedDraftPoints;
  bool _speedDraftIsCurve = false;
  String? _expandedSpeedCurveClipId;
  String? _constantSpeedControlClipId;
  int? _selectedTransformKeyframeTimeMs;
  ClipTransformKeyframe? _transformKeyframeDraft;
  TimelinePosition? _pendingTimelinePosition;
  String? _error;
  MediaAccessIssue? _mediaAccessIssue;

  bool get _hasVisualTrack => _project.videoTrack.isNotEmpty;
  bool get _isAndroid => defaultTargetPlatform == TargetPlatform.android;

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _history = ProjectHistory(_project);
    _durationMs = _visualDurationMs;
    WidgetsBinding.instance.addPostFrameCallback((_) => _configurePreview());
  }

  int get _visualDurationMs => visualTimelineDurationMs(
    _project.videoTrack,
    transitions: _project.videoTransitions,
  );

  bool _captureMediaAccessIssue(Object error) {
    final issue = MediaAccessIssue.fromPlatformException(error);
    if (issue == null) return false;
    if (!mounted) return true;
    setState(() {
      _mediaAccessIssue = issue;
      _configured = false;
      _configuring = false;
      _playing = false;
      _error = null;
    });
    return true;
  }

  String _mediaPickerFailure(Object error, String fallback) {
    if (error is PlatformException &&
        error.code == 'media_permission_not_persisted') {
      return 'لم يُغيّر المشروع: لم يمنح موفّر الملفات إذن قراءة دائمًا. اختر الملف من موفّر مستندات يدعم الوصول الدائم، أو من موقع محلي.';
    }
    return '$fallback$error';
  }

  Future<void> _configurePreview({TimelinePosition? preferredPosition}) async {
    if (!mounted || !_isAndroid || !_hasVisualTrack || _configuring) return;
    _stateTimer?.cancel();
    setState(() {
      _configuring = true;
      _error = null;
    });
    try {
      await NativeBridge.configurePreviewTimeline(
        _project,
        startIndex: preferredPosition?.clipIndex ?? 0,
        clipPositionMs: preferredPosition?.clipPositionMs ?? 0,
        timelinePositionMs: preferredPosition?.timelinePositionMs ?? 0,
        playWhenReady: false,
      );
      if (!mounted) return;
      setState(() {
        _configured = true;
        _configuring = false;
        _mediaAccessIssue = null;
        _positionMs = preferredPosition?.timelinePositionMs ?? 0;
        _durationMs = _visualDurationMs;
      });
      _stateTimer?.cancel();
      _stateTimer = Timer.periodic(
        const Duration(milliseconds: 300),
        (_) => _refreshPreviewState(),
      );
      final pendingPosition = _pendingTimelinePosition;
      _pendingTimelinePosition = null;
      if (pendingPosition != null) {
        await _seekPreviewToPosition(pendingPosition);
      }
      await _refreshPreviewState();
    } catch (error) {
      _pendingTimelinePosition = null;
      if (_captureMediaAccessIssue(error) || !mounted) return;
      setState(() {
        _configuring = false;
        _error = 'تعذّر إعداد المعاينة: $error';
      });
    }
  }

  Future<void> _selectTimelineVideoClip(TimelineClip clip) async {
    final clipIndex = _project.videoTrack.indexWhere(
      (item) => item.id == clip.id,
    );
    if (clipIndex < 0) return;
    final position = timelinePositionForClipOffset(
      _project.videoTrack,
      clipIndex: clipIndex,
      clipPositionMs: 0,
      transitions: _project.videoTransitions,
    );
    if (position == null) return;
    setState(() {
      _selectedTimelineClipId = clip.id;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _selectedTextOverlayId = null;
      _selectedSubtitleCueId = null;
      _selectedStickerOverlayId = null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _speedDraftIsCurve = false;
      _expandedSpeedCurveClipId = null;
      _constantSpeedControlClipId = null;
      final keyframes = _visibleTransformKeyframes(clip);
      _selectedTransformKeyframeTimeMs = keyframes.isEmpty
          ? null
          : keyframes.first.timeMs;
      _transformKeyframeDraft = null;
      _positionMs = position.timelinePositionMs;
      _isScrubbing = false;
      _error = null;
    });
    if (!_isAndroid) return;
    if (_configuring) {
      _pendingTimelinePosition = position;
      return;
    }
    if (!_configured) {
      await _configurePreview(preferredPosition: position);
      return;
    }
    await _seekPreviewToPosition(position);
  }

  void _selectVideoOverlayClip(String clipId) {
    final exists = _project.videoOverlayTracks.any(
      (track) => track.clips.any((clip) => clip.id == clipId),
    );
    if (!exists) return;
    setState(() {
      _selectedTimelineClipId = null;
      _selectedVideoOverlayClipId = clipId;
      _selectedAudioClipId = null;
      _selectedTextOverlayId = null;
      _selectedSubtitleCueId = null;
      _selectedStickerOverlayId = null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _error = null;
    });
  }

  void _selectAudioClip(String clipId) {
    if (!_project.audioTrack.any((clip) => clip.id == clipId)) return;
    setState(() {
      _selectedTimelineClipId = null;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = clipId;
      _selectedTextOverlayId = null;
      _selectedSubtitleCueId = null;
      _selectedStickerOverlayId = null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _error = null;
    });
  }

  void _selectTextOverlay(String id) {
    if (!_project.textOverlays.any((item) => item.id == id)) return;
    setState(() {
      _selectedTimelineClipId = null;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _selectedTextOverlayId = id;
      _selectedSubtitleCueId = null;
      _selectedStickerOverlayId = null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _error = null;
    });
  }

  void _selectSubtitleCue(String id) {
    if (!_project.subtitleTrack.any((cue) => cue.id == id)) return;
    setState(() {
      _selectedTimelineClipId = null;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _selectedTextOverlayId = null;
      _selectedSubtitleCueId = id;
      _selectedStickerOverlayId = null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _error = null;
    });
  }

  void _selectStickerOverlay(String id) {
    if (!_project.stickerOverlays.any((item) => item.id == id)) return;
    setState(() {
      _selectedTimelineClipId = null;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _selectedTextOverlayId = null;
      _selectedSubtitleCueId = null;
      _selectedStickerOverlayId = id;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _error = null;
    });
  }

  Future<void> _seekPreviewToPosition(TimelinePosition position) async {
    if (!_isAndroid) return;
    try {
      await NativeBridge.seekPreviewTo(
        mediaItemIndex: position.clipIndex,
        clipPositionMs: position.clipPositionMs,
        timelinePositionMs: position.timelinePositionMs,
      );
      if (mounted) setState(() => _positionMs = position.timelinePositionMs);
    } catch (error) {
      if (mounted)
        setState(() => _error = 'تعذّر الانتقال إلى المقطع المحدد: $error');
    }
  }

  Future<void> _reorderVideoClip(
    String draggedClipId,
    String targetClipId,
    bool insertAfterTarget,
  ) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final result = reorderVideoClipSafely(
      videoTrack: _project.videoTrack,
      transitions: _project.videoTransitions,
      draggedClipId: draggedClipId,
      targetClipId: targetClipId,
      insertAfterTarget: insertAfterTarget,
    );
    if (!result.accepted) {
      final message = result.rejectionReason ?? 'تعذّر اعتماد ترتيب المقاطع.';
      setState(() => _error = message);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 5)),
      );
      return;
    }
    if (!result.changed) return;

    final updatedTrack = result.track!;
    final updatedProject = _project.copyWith(videoTrack: updatedTrack);
    final updatedDurationMs = visualTimelineDurationMs(
      updatedTrack,
      transitions: updatedProject.videoTransitions,
    );
    final movedClipIndex = updatedTrack.indexWhere(
      (clip) => clip.id == draggedClipId,
    );
    final previewPosition = timelinePositionForClipOffset(
      updatedTrack,
      clipIndex: movedClipIndex,
      clipPositionMs: 0,
      transitions: updatedProject.videoTransitions,
    );
    if (previewPosition == null) {
      const message = 'تعذّر تحديد موضع المقطع بعد الترتيب؛ لم يُعتمد التغيير.';
      setState(() => _error = message);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text(message)));
      return;
    }

    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _durationMs = updatedDurationMs;
      _positionMs = previewPosition.timelinePositionMs;
      _selectedTimelineClipId = draggedClipId;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange(
        preferredPosition: previewPosition,
      );
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<void> _refreshPreviewState() async {
    if (!mounted || !_configured || _pollInProgress) return;
    _pollInProgress = true;
    final previewGeneration = _previewGeneration;
    try {
      final state = await NativeBridge.getPreviewState();
      if (!mounted || previewGeneration != _previewGeneration || !_configured) {
        return;
      }
      final rawPosition = state['timelinePositionMs'];
      final position = rawPosition is num ? rawPosition.round() : _positionMs;
      final stateError = state['error']?.toString();
      setState(() {
        if (!_isScrubbing) _positionMs = position.clamp(0, _durationMs).toInt();
        _playing = state['isPlaying'] == true;
        if (stateError != null && stateError.isNotEmpty) {
          _configured = false;
          _playing = false;
          _error = stateError;
        }
      });
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر قراءة حالة المعاينة: $error');
    } finally {
      _pollInProgress = false;
    }
  }

  Future<void> _seekTo(int requestedPositionMs) async {
    if (!_configured || _durationMs <= 0) return;
    final target = requestedPositionMs.clamp(0, _durationMs).toInt();
    final position = timelinePositionAt(
      _project.videoTrack,
      target,
      transitions: _project.videoTransitions,
    );
    if (position == null) return;
    setState(() {
      _positionMs = target;
      _error = null;
    });
    try {
      await NativeBridge.seekPreviewTo(
        mediaItemIndex: position.clipIndex,
        clipPositionMs: position.clipPositionMs,
        timelinePositionMs: target,
      );
    } catch (error) {
      if (mounted)
        setState(() => _error = 'تعذّر البحث في الخط الزمني: $error');
    }
  }

  TimelinePosition? _splitPositionAtPlayhead() {
    if (!_hasVisualTrack || _durationMs <= 0) return null;
    final position = timelinePositionAt(
      _project.videoTrack,
      _positionMs,
      transitions: _project.videoTransitions,
    );
    if (position == null ||
        position.clipIndex < 0 ||
        position.clipIndex >= _project.videoTrack.length) {
      return null;
    }
    final clip = _project.videoTrack[position.clipIndex];
    final sourceDurationMs = _project.assetById(clip.assetId)?.durationMs ?? 0;
    if (position.sourcePositionMs <= clip.trimStartMs ||
        position.sourcePositionMs >= clip.trimEndMs ||
        (sourceDurationMs > 0 && clip.trimEndMs > sourceDurationMs)) {
      return null;
    }
    final firstSegment = clip.copyWith(trimEndMs: position.sourcePositionMs);
    final secondSegment = clip.copyWith(trimStartMs: position.sourcePositionMs);
    if (firstSegment.effectiveDurationMs <= 0 ||
        secondSegment.effectiveDurationMs <= 0) {
      return null;
    }
    return position;
  }

  Future<void> _nudgeTrimBoundary(
    TimelineClip clip, {
    required bool moveStart,
    required int deltaMs,
  }) async {
    final currentMs = moveStart ? clip.trimStartMs : clip.trimEndMs;
    await _applyTrimBoundary(
      clip,
      moveStart: moveStart,
      requestedMs: currentMs + deltaMs,
    );
  }

  Future<void> _editTrimBoundary(
    TimelineClip clip, {
    required bool moveStart,
  }) async {
    final currentMs = moveStart ? clip.trimStartMs : clip.trimEndMs;
    final controller = TextEditingController(
      text: _formatSecondsInput(currentMs),
    );
    final entered = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(moveStart ? 'تعديل بداية المقطع' : 'تعديل نهاية المقطع'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'الوقت بالثواني',
            hintText: 'مثال: 1.250',
          ),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (entered == null || !mounted) return;
    final requestedMs = parseTimelineSeconds(entered);
    if (requestedMs == null) {
      setState(() => _error = 'أدخل وقتًا صحيحًا بالثواني.');
      return;
    }
    await _applyTrimBoundary(
      clip,
      moveStart: moveStart,
      requestedMs: requestedMs,
    );
  }

  Future<void> _applyTimelineTrimById(
    String clipId, {
    required bool moveStart,
    required int requestedMs,
  }) async {
    final index = _project.videoTrack.indexWhere((item) => item.id == clipId);
    if (index < 0) return;
    await _applyTrimBoundary(
      _project.videoTrack[index],
      moveStart: moveStart,
      requestedMs: requestedMs,
    );
  }

  Future<void> _applyTrimBoundary(
    TimelineClip clip, {
    required bool moveStart,
    required int requestedMs,
  }) async {
    if (_projectOperationInProgress || _saving || _exportingNavigation) return;
    final clipIndex = _project.videoTrack.indexWhere(
      (item) => item.id == clip.id,
    );
    if (clipIndex < 0) return;
    final currentClip = _project.videoTrack[clipIndex];
    final sourceDurationMs =
        _project.assetById(currentClip.assetId)?.durationMs ?? 0;
    final trimResult = trimVideoClipSafely(
      videoTrack: _project.videoTrack,
      transitions: _project.videoTransitions,
      clipId: currentClip.id,
      moveStart: moveStart,
      requestedMs: requestedMs,
      sourceDurationMs: sourceDurationMs,
    );
    if (!trimResult.accepted) {
      setState(
        () => _error =
            trimResult.rejectionReason ?? 'رُفض القص للحفاظ على الانتقالات.',
      );
      return;
    }
    if (!trimResult.changed) return;

    final updatedTrack = trimResult.track!;
    final updatedProject = _project.copyWith(videoTrack: updatedTrack);
    final updatedDurationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    final updatedPositionMs = _positionMs.clamp(0, updatedDurationMs).toInt();

    // Commit locally and record only a real trim change before touching preview.
    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _durationMs = updatedDurationMs;
      _positionMs = updatedPositionMs;
      _selectedTimelineClipId = currentClip.id;
      _selectedVideoOverlayClipId = null;
      _selectedAudioClipId = null;
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });

    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange();
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<void> _editTransitionBoundary(int boundaryIndex) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final limits = videoTransitionDurationLimits(
      videoTrack: _project.videoTrack,
      transitions: _project.videoTransitions,
      boundaryIndex: boundaryIndex,
    );
    if (!limits.accepted) {
      final message =
          limits.rejectionReason ?? 'لا يمكن إعداد انتقال عند هذا الحد.';
      setState(() => _error = message);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(message)));
      return;
    }

    final fromClip = _project.videoTrack[boundaryIndex];
    final toClip = _project.videoTrack[boundaryIndex + 1];
    VideoTransition? existing;
    for (final transition in _project.videoTransitions) {
      if (transition.fromClipId == fromClip.id &&
          transition.toClipId == toClip.id) {
        existing = transition;
        break;
      }
    }
    final currentTransition = existing;
    final supportedTypes = VideoTransitionType.values
        .where((type) => type.supported)
        .toList(growable: false);
    if (supportedTypes.isEmpty) {
      const message = 'لا توجد أنواع انتقال مدعومة في المعاينة الحالية.';
      setState(() => _error = message);
      return;
    }

    var selectedType =
        currentTransition != null && currentTransition.type.supported
        ? currentTransition.type
        : supportedTypes.first;
    var direction = currentTransition?.direction ?? 'right';
    var intensity = currentTransition?.intensity ?? 1.0;
    final minimumDurationMs = limits.minDurationMs;
    final maximumDurationMs = limits.maxDurationMs;
    final durationSeed =
        currentTransition?.durationMs ??
        (maximumDurationMs < 300 ? maximumDurationMs : 300);
    var durationMs = durationSeed
        .clamp(minimumDurationMs, maximumDurationMs)
        .toInt();
    final savedDurationOutOfRange =
        currentTransition != null &&
        (currentTransition.durationMs < minimumDurationMs ||
            currentTransition.durationMs > maximumDurationMs);
    final fromName = _project.assetById(fromClip.assetId)?.name ?? fromClip.id;
    final toName = _project.assetById(toClip.assetId)?.name ?? toClip.id;
    // An out-of-range saved value is shown separately from the safe suggestion.
    // Start with an empty field and require an explicit valid choice before Apply.
    final durationController = TextEditingController(
      text: savedDurationOutOfRange ? '' : '$durationMs',
    );
    var durationInputValid = !savedDurationOutOfRange;
    // Changing only the type must not authorize the seeded safe duration.
    var durationExplicitlyConfirmed = !savedDurationOutOfRange;
    final selection = await showDialog<(VideoTransitionType, int, String, double)>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('إعداد الانتقال'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  '$fromName  ←  $toName',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (currentTransition != null &&
                    !currentTransition.type.supported) ...[
                  const SizedBox(height: 8),
                  Text(
                    'النوع المحفوظ «${currentTransition.type.label}» غير مدعوم في المعاينة. اختر نوعًا مدعومًا لاستبداله.',
                    style: const TextStyle(
                      color: Colors.orangeAccent,
                      fontSize: 12,
                    ),
                  ),
                ],
                if (savedDurationOutOfRange) ...[
                  const SizedBox(height: 8),
                  Text(
                    'المدة المحفوظة: ${currentTransition!.durationMs} مللي ثانية.',
                    style: const TextStyle(
                      color: Colors.orangeAccent,
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    'المدة الآمنة المقترحة: $durationMs مللي ثانية. أدخل مدة صالحة أو حرّك المنزلق لتأكيد اختيارك؛ لن تُطبّق القيمة المقترحة تلقائيًا.',
                    style: const TextStyle(
                      color: Colors.orangeAccent,
                      fontSize: 12,
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                DropdownButton<VideoTransitionType>(
                  value: selectedType,
                  isExpanded: true,
                  items: [
                    for (final type in supportedTypes)
                      DropdownMenuItem(value: type, child: Text(type.label)),
                  ],
                  onChanged: (value) {
                    if (value != null)
                      setDialogState(() => selectedType = value);
                  },
                ),
                const SizedBox(height: 4),
                Text(
                  selectedType.description,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFFAFBAC5),
                  ),
                ),
                if (selectedType == VideoTransitionType.slide) ...[
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    key: const ValueKey('transition-direction-dropdown'),
                    value: direction,
                    decoration: const InputDecoration(
                      labelText: 'اتجاه الانزلاق',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'left', child: Text('من اليسار')),
                      DropdownMenuItem(
                        value: 'right',
                        child: Text('من اليمين'),
                      ),
                      DropdownMenuItem(value: 'up', child: Text('من الأسفل')),
                      DropdownMenuItem(value: 'down', child: Text('من الأعلى')),
                    ],
                    onChanged: (value) {
                      if (value != null)
                        setDialogState(() => direction = value);
                    },
                  ),
                ],
                if (selectedType == VideoTransitionType.zoom ||
                    selectedType == VideoTransitionType.spin) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Expanded(child: Text('قوة الحركة')),
                      Text('${(intensity * 100).round()}%'),
                    ],
                  ),
                  Slider(
                    key: const ValueKey('transition-intensity-slider'),
                    min: 0,
                    max: 1,
                    divisions: 10,
                    value: intensity.clamp(0, 1).toDouble(),
                    onChanged: (value) =>
                        setDialogState(() => intensity = value),
                  ),
                ],
                const SizedBox(height: 8),
                Text(
                  'المدة المختارة: $durationMs مللي ثانية (${(durationMs / 1000).toStringAsFixed(2)}ث)',
                ),
                TextField(
                  controller: durationController,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'المدة بالمللي ثانية',
                    suffixText: 'ms',
                  ),
                  onChanged: (text) {
                    final parsed = int.tryParse(text);
                    setDialogState(() {
                      durationInputValid =
                          parsed != null &&
                          parsed >= minimumDurationMs &&
                          parsed <= maximumDurationMs;
                      if (durationInputValid) {
                        durationMs = parsed!;
                        durationExplicitlyConfirmed = true;
                      }
                    });
                  },
                ),
                Slider(
                  key: const ValueKey('transition-duration-slider'),
                  min: minimumDurationMs.toDouble(),
                  max: maximumDurationMs.toDouble(),
                  divisions: maximumDurationMs - minimumDurationMs > 100
                      ? 100
                      : maximumDurationMs > minimumDurationMs
                      ? maximumDurationMs - minimumDurationMs
                      : null,
                  value: durationMs.toDouble(),
                  label: '$durationMs ms',
                  onChanged: maximumDurationMs <= minimumDurationMs
                      ? null
                      : (value) => setDialogState(() {
                          durationMs = value
                              .round()
                              .clamp(minimumDurationMs, maximumDurationMs)
                              .toInt();
                          durationController.value = TextEditingValue(
                            text: '$durationMs',
                            selection: TextSelection.collapsed(
                              offset: '$durationMs'.length,
                            ),
                          );
                          durationInputValid = true;
                          durationExplicitlyConfirmed = true;
                        }),
                ),
                Text(
                  'النطاق الآمن مع الانتقالات المجاورة: $minimumDurationMs–$maximumDurationMs مللي ثانية',
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFFAFBAC5),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'بعد التطبيق، شغّل المعاينة أو حرّك المؤشر عبر الحد لمشاهدة الانتقال الفعلي؛ يستخدم التصدير الإعداد نفسه.',
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFFAFBAC5),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              key: const ValueKey('transition-apply-button'),
              onPressed: durationInputValid && durationExplicitlyConfirmed
                  ? () => Navigator.of(dialogContext)
                        .pop((selectedType, durationMs, direction, intensity))
                  : null,
              child: const Text('تطبيق'),
            ),
          ],
        ),
      ),
    );
    durationController.dispose();
    if (selection == null || !mounted) return;
    await _applyVideoTransition(
      boundaryIndex,
      type: selection.$1,
      durationMs: selection.$2,
      direction: selection.$3,
      intensity: selection.$4,
    );
  }

  Future<void> _applyVideoTransition(
    int boundaryIndex, {
    required VideoTransitionType type,
    required int durationMs,
    String? direction,
    double? intensity,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final result = setVideoTransitionSafely(
      videoTrack: _project.videoTrack,
      transitions: _project.videoTransitions,
      boundaryIndex: boundaryIndex,
      type: type,
      durationMs: durationMs,
      newTransitionId: newLocalId(),
      direction: direction,
      intensity: intensity,
    );
    if (!result.accepted) {
      final message =
          result.rejectionReason ??
          'رُفض الانتقال للحفاظ على صلاحية الحدود المجاورة.';
      if (mounted) {
        setState(() => _error = message);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(message)));
      }
      return;
    }
    if (!result.changed) return;

    final updatedProject = _project.copyWith(
      videoTransitions: result.transitions,
    );
    final updatedDurationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    final clampedPositionMs = _positionMs.clamp(0, updatedDurationMs).toInt();
    final previewPosition = timelinePositionAt(
      updatedProject.videoTrack,
      clampedPositionMs,
      transitions: updatedProject.videoTransitions,
    );
    if (previewPosition == null) {
      setState(
        () => _error =
            'تعذّر تحديد موضع المعاينة بعد تعديل الانتقال؛ لم يُعتمد التغيير.',
      );
      return;
    }

    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _durationMs = updatedDurationMs;
      _positionMs = previewPosition.timelinePositionMs;
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange(
        preferredPosition: previewPosition,
      );
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<void> _splitAtPlayhead() async {
    if (_projectOperationInProgress || _saving || _exportingNavigation) return;
    final position = _splitPositionAtPlayhead();
    if (position == null) {
      setState(() => _error = 'حرّك المؤشر إلى داخل مقطع صالح لتقسيمه.');
      return;
    }

    final clip = _project.videoTrack[position.clipIndex];
    final secondClipId = newLocalId();
    final splitTrack = splitClipAtPosition(
      _project.videoTrack,
      position.clipId,
      playheadMs: _positionMs,
      secondClipId: secondClipId,
      sourceDurationMs: _project.assetById(clip.assetId)?.durationMs ?? 0,
      sourceSplitPositionMs: position.sourcePositionMs,
    );
    if (splitTrack == null) {
      setState(() => _error = 'تعذّر تقسيم المقطع عند هذا الموضع.');
      return;
    }

    final firstSegmentIndex = splitTrack.indexWhere(
      (item) => item.id == clip.id,
    );
    final secondSegmentIndex = splitTrack.indexWhere(
      (item) => item.id == secondClipId,
    );
    if (firstSegmentIndex < 0 ||
        secondSegmentIndex < 0 ||
        splitTrack[firstSegmentIndex].effectiveDurationMs <= 0 ||
        splitTrack[secondSegmentIndex].effectiveDurationMs <= 0) {
      setState(
        () => _error = 'لا يمكن تقسيم المقطع إلى جزأين صالحين للمعاينة.',
      );
      return;
    }

    final updatedTransitions = transitionsAfterClipSplit(
      _project.videoTransitions,
      originalClipId: clip.id,
      secondClipId: secondClipId,
      firstSegmentDurationMs: splitTrack[firstSegmentIndex].effectiveDurationMs,
      secondSegmentDurationMs:
          splitTrack[secondSegmentIndex].effectiveDurationMs,
    );
    final updatedProject = _project.copyWith(
      videoTrack: splitTrack,
      videoTransitions: updatedTransitions,
    );
    final updatedDurationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    final originalDurationMs = visualTimelineDurationMs(
      _project.videoTrack,
      transitions: _project.videoTransitions,
    );
    if (!splitPreservesTransitionSchedule(
      originalTransitions: _project.videoTransitions,
      splitTransitions: updatedTransitions,
      originalClipId: clip.id,
      secondClipId: secondClipId,
      originalTimelineDurationMs: originalDurationMs,
      splitTimelineDurationMs: updatedDurationMs,
    )) {
      setState(
        () => _error = 'لا يمكن التقسيم عند هذا الموضع؛ لأنه سيقصّر انتقالًا قائمًا أو يزيله أو يغيّر مدة الخط الزمني.',
      );
      return;
    }

    final splitPreviewPosition = timelinePositionForClipOffset(
      updatedProject.videoTrack,
      clipIndex: secondSegmentIndex,
      clipPositionMs: 0,
      transitions: updatedProject.videoTransitions,
    );
    if (splitPreviewPosition == null) {
      setState(() => _error = 'تعذّر تحديد بداية الجزء الثاني للمعاينة.');
      return;
    }
    final updatedPositionMs = splitPreviewPosition.timelinePositionMs
        .clamp(0, updatedDurationMs)
        .toInt();

    // The split is one complete-project history step, committed before preview work.
    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _durationMs = updatedDurationMs;
      _positionMs = updatedPositionMs;
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });

    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange(
        preferredPosition: splitPreviewPosition,
      );
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<void> _undoProject() async {
    if (_projectOperationInProgress || _saving || _exportingNavigation) return;
    final restoredProject = _history.undo();
    if (restoredProject != null) await _restoreProject(restoredProject);
  }

  Future<void> _redoProject() async {
    if (_projectOperationInProgress || _saving || _exportingNavigation) return;
    final restoredProject = _history.redo();
    if (restoredProject != null) await _restoreProject(restoredProject);
  }

  Future<void> _restoreProject(VeloraProject restoredProject) async {
    final previousOverlayId = _selectedVideoOverlayClipId;
    final previousAudioId = _selectedAudioClipId;
    final previousTextId = _selectedTextOverlayId;
    final previousSubtitleId = _selectedSubtitleCueId;
    final previousStickerId = _selectedStickerOverlayId;
    final restoredTextIds = restoredProject.textOverlays
        .map((item) => item.id)
        .toSet();
    final restoredSubtitleIds = restoredProject.subtitleTrack
        .map((item) => item.id)
        .toSet();
    final restoredStickerIds = restoredProject.stickerOverlays
        .map((item) => item.id)
        .toSet();
    final restoredOverlayIds = restoredProject.videoOverlayTracks
        .expand((track) => track.clips)
        .map((clip) => clip.id)
        .toSet();
    final restoredAudioIds = restoredProject.audioTrack
        .map((clip) => clip.id)
        .toSet();
    final restoredDurationMs = visualTimelineDurationMs(
      restoredProject.videoTrack,
      transitions: restoredProject.videoTransitions,
    );
    final restoredSelectedClip = restoredProject.videoTrack.where(
      (clip) => clip.id == _selectedTimelineClipId,
    );
    final restoredKeyframes = restoredSelectedClip.isEmpty
        ? const <ClipTransformKeyframe>[]
        : _visibleTransformKeyframes(restoredSelectedClip.first);
    final selectedFrameStillExists = restoredKeyframes.any(
      (frame) => frame.timeMs == _selectedTransformKeyframeTimeMs,
    );
    setState(() {
      _project = restoredProject;
      _selectedTransformKeyframeTimeMs = selectedFrameStillExists
          ? _selectedTransformKeyframeTimeMs
          : (restoredKeyframes.isEmpty ? null : restoredKeyframes.first.timeMs);
      _transformKeyframeDraft = null;
      _selectedVideoOverlayClipId =
          previousOverlayId != null &&
              restoredOverlayIds.contains(previousOverlayId)
          ? previousOverlayId
          : null;
      _selectedAudioClipId =
          previousAudioId != null && restoredAudioIds.contains(previousAudioId)
          ? previousAudioId
          : null;
      _selectedTextOverlayId =
          previousTextId != null && restoredTextIds.contains(previousTextId)
          ? previousTextId
          : null;
      _selectedSubtitleCueId =
          previousSubtitleId != null &&
              restoredSubtitleIds.contains(previousSubtitleId)
          ? previousSubtitleId
          : null;
      _selectedStickerOverlayId =
          previousStickerId != null &&
              restoredStickerIds.contains(previousStickerId)
          ? previousStickerId
          : null;
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _speedDraftIsCurve = false;
      _expandedSpeedCurveClipId = null;
      _constantSpeedControlClipId = null;
      _durationMs = restoredDurationMs;
      _positionMs = _positionMs.clamp(0, restoredDurationMs).toInt();
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(restoredProject);
      await _reconfigurePreviewAfterProjectChange();
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<bool> _saveEditedProject(VeloraProject project) async {
    try {
      await NativeBridge.saveProject(project);
      if (mounted) setState(() => _hasUnsavedChanges = false);
      return true;
    } catch (_) {
      if (mounted) setState(() => _hasUnsavedChanges = true);
      return false;
    }
  }

  Future<void> _reselectUnavailableMedia() async {
    final issue = _mediaAccessIssue;
    if (issue == null ||
        _importingMedia ||
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation) {
      return;
    }
    setState(() {
      _importingMedia = true;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      final replacement = issue.isSticker
          ? await NativeBridge.pickSticker()
          : await NativeBridge.pickReplacementMedia(issue.kind);
      if (!mounted || replacement == null) return;
      _validateImportAsset(replacement);
      final updatedProject = issue.isSticker
          ? replaceProjectStickerReference(
              _project,
              stickerId: issue.stickerId!,
              replacement: replacement,
            )
          : replaceProjectAssetReference(
              _project,
              assetId: issue.assetId!,
              replacement: replacement,
            );
      _history.record(updatedProject);
      setState(() {
        _project = updatedProject;
        _mediaAccessIssue = null;
        _error = null;
      });
      final saved = await _saveEditedProject(updatedProject);
      if (!saved && mounted) {
        setState(
          () => _error = 'تم تحديث الرابط في المحرر، لكن تعذّر حفظه على الجهاز؛ أعد المحاولة قبل الإغلاق.',
        );
      }
      await _reconfigurePreviewAfterProjectChange();
    } on FormatException catch (error) {
      if (mounted) setState(() => _error = error.message);
    } catch (error) {
      if (mounted) {
        setState(
          () => _error = _mediaPickerFailure(
            error,
            'تعذّرت إعادة اختيار الملف: ',
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _importingMedia = false;
          _projectOperationInProgress = false;
        });
      }
    }
  }

  Future<void> _retrySaveEditedProject() async {
    if (!_hasUnsavedChanges ||
        _saving ||
        _projectOperationInProgress ||
        _exportingNavigation) {
      return;
    }
    setState(() => _saving = true);
    try {
      await _saveEditedProject(_project);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _reconfigurePreviewAfterProjectChange({
    TimelinePosition? preferredPosition,
  }) async {
    if (!mounted || !_isAndroid) return;
    _previewGeneration++;
    if (!_hasVisualTrack) {
      try {
        await NativeBridge.clearPreview();
      } catch (error) {
        if (mounted)
          setState(
            () => _error =
                'تم تطبيق التعديل محليًا، لكن تعذّر تحديث المعاينة: $error',
          );
      }
      if (mounted) {
        setState(() {
          _configured = false;
          _configuring = false;
          _playing = false;
        });
      }
      return;
    }

    final position =
        preferredPosition ??
        timelinePositionAt(
          _project.videoTrack,
          _positionMs,
          transitions: _project.videoTransitions,
        );
    if (position == null) {
      setState(() {
        _configured = false;
        _configuring = false;
        _playing = false;
        _error = 'تم تطبيق التعديل محليًا، لكن تعذّر تحديد موضع المعاينة بعد التعديل.';
      });
      return;
    }

    setState(() {
      _configured = false;
      _configuring = true;
    });
    try {
      await NativeBridge.configurePreviewTimeline(
        _project,
        startIndex: position.clipIndex,
        clipPositionMs: position.clipPositionMs,
        timelinePositionMs: position.timelinePositionMs,
        playWhenReady: _playing,
      );
      if (!mounted) return;
      setState(() {
        _configured = true;
        _configuring = false;
        _mediaAccessIssue = null;
      });
      await _refreshPreviewState();
    } catch (error) {
      if (_captureMediaAccessIssue(error) || !mounted) return;
      setState(() {
        _configured = false;
        _configuring = false;
        _playing = false;
        final previewError =
            'تم تطبيق التعديل محليًا، لكن تعذّرت إعادة تهيئة المعاينة: $error';
        _error = _error == null ? previewError : '$_error\n$previewError';
      });
    }
  }

  Future<void> _commitMultitrackProject(
    VeloraProject updatedProject, {
    String? selectedOverlayClipId,
    String? selectedAudioClipId,
    String? selectedTextOverlayId,
    String? selectedSubtitleCueId,
    String? selectedStickerOverlayId,
  }) async {
    final updatedDurationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      if (selectedOverlayClipId != null) {
        _selectedVideoOverlayClipId = selectedOverlayClipId;
        _selectedAudioClipId = null;
        _selectedTextOverlayId = null;
        _selectedSubtitleCueId = null;
        _selectedStickerOverlayId = null;
        _selectedTimelineClipId = null;
      }
      if (selectedAudioClipId != null) {
        _selectedAudioClipId = selectedAudioClipId;
        _selectedVideoOverlayClipId = null;
        _selectedTextOverlayId = null;
        _selectedSubtitleCueId = null;
        _selectedStickerOverlayId = null;
        _selectedTimelineClipId = null;
      }
      if (selectedTextOverlayId != null) {
        _selectedTextOverlayId = selectedTextOverlayId;
        _selectedSubtitleCueId = null;
        _selectedStickerOverlayId = null;
        _selectedVideoOverlayClipId = null;
        _selectedAudioClipId = null;
        _selectedTimelineClipId = null;
      }
      if (selectedSubtitleCueId != null) {
        _selectedSubtitleCueId = selectedSubtitleCueId;
        _selectedTextOverlayId = null;
        _selectedStickerOverlayId = null;
        _selectedVideoOverlayClipId = null;
        _selectedAudioClipId = null;
        _selectedTimelineClipId = null;
      }
      if (selectedStickerOverlayId != null) {
        _selectedStickerOverlayId = selectedStickerOverlayId;
        _selectedTextOverlayId = null;
        _selectedSubtitleCueId = null;
        _selectedVideoOverlayClipId = null;
        _selectedAudioClipId = null;
        _selectedTimelineClipId = null;
      }
      _textStartDraftMs = null;
      _textDurationDraftMs = null;
      _textStyleDraft = null;
      _stickerStartDraftMs = null;
      _stickerDurationDraftMs = null;
      _stickerDraft = null;
      _videoOverlayStartDraftMs = null;
      _videoOverlayDurationDraftMs = null;
      _audioStartDraftMs = null;
      _audioSourceStartDraftMs = null;
      _audioDurationDraftMs = null;
      _audioVolumeDraft = null;
      _audioFadeInDraftMs = null;
      _audioFadeOutDraftMs = null;
      _videoAudioVolumeDraft = null;
      _videoAudioFadeInDraftMs = null;
      _videoAudioFadeOutDraftMs = null;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _speedDraftIsCurve = false;
      _expandedSpeedCurveClipId = null;
      _constantSpeedControlClipId = null;
      _transformKeyframeDraft = null;
      _durationMs = updatedDurationMs;
      _positionMs = _positionMs.clamp(0, updatedDurationMs).toInt();
      _isScrubbing = false;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange();
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  void _moveVideoOverlayOnTimeline(String clipId, int outputStartMs) {
    unawaited(_saveVideoOverlaySettings(clipId, outputStartMs: outputStartMs));
  }

  Future<void> _saveVideoOverlaySettings(
    String clipId, {
    int? outputStartMs,
    int? durationMs,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    var trackIndex = -1;
    var clipIndex = -1;
    for (var index = 0; index < _project.videoOverlayTracks.length; index++) {
      final found = _project.videoOverlayTracks[index].clips.indexWhere(
        (clip) => clip.id == clipId,
      );
      if (found >= 0) {
        if (trackIndex >= 0) return;
        trackIndex = index;
        clipIndex = found;
      }
    }
    if (trackIndex < 0) return;
    final track = _project.videoOverlayTracks[trackIndex];
    final current = track.clips[clipIndex];
    final asset = _project.assetById(current.assetId);
    if (asset == null ||
        (asset.kind != MediaKind.video && asset.kind != MediaKind.image)) {
      return;
    }
    final maxSourceDuration = (asset.durationMs - current.trimStartMs)
        .clamp(1, 1 << 53)
        .toInt();
    var nextDuration =
        (durationMs ?? _videoOverlayDurationDraftMs ?? current.durationMs)
            .clamp(1, maxSourceDuration)
            .toInt();
    if (_durationMs > 0) {
      nextDuration = nextDuration.clamp(1, _durationMs).toInt();
    }
    final currentOutputStart = _project.videoTrack.isEmpty
        ? current.timelineStartMs
        : projectTimelineMsToOutputMs(
            _project.videoTrack,
            current.timelineStartMs,
            transitions: _project.videoTransitions,
          );
    final requestedOutputStart =
        outputStartMs ?? _videoOverlayStartDraftMs ?? currentOutputStart;
    final maxOutputStart = _durationMs > 0
        ? math.max(0, _durationMs - nextDuration).toInt()
        : 1 << 53;
    final boundedOutputStart = requestedOutputStart
        .clamp(0, maxOutputStart)
        .toInt();
    final nextTimelineStart = _project.videoTrack.isEmpty
        ? boundedOutputStart
        : outputTimelineMsToProjectMs(
            _project.videoTrack,
            boundedOutputStart,
            transitions: _project.videoTransitions,
          );
    final nextClip = current.copyWith(
      trimEndMs: current.trimStartMs + nextDuration,
      timelineStartMs: nextTimelineStart,
    );
    if (nextClip.trimEndMs == current.trimEndMs &&
        nextClip.timelineStartMs == current.timelineStartMs) {
      setState(() {
        _videoOverlayStartDraftMs = null;
        _videoOverlayDurationDraftMs = null;
      });
      return;
    }
    final clips = List<VideoOverlayClip>.of(track.clips)
      ..[clipIndex] = nextClip;
    final tracks = List<VideoOverlayTrack>.of(_project.videoOverlayTracks)
      ..[trackIndex] = track.copyWith(clips: clips);
    await _commitMultitrackProject(
      _project.copyWith(videoOverlayTracks: tracks),
      selectedOverlayClipId: clipId,
    );
  }

  void _moveAudioClipOnTimeline(String clipId, int outputStartMs) {
    unawaited(_saveAudioClipSettings(clipId, outputStartMs: outputStartMs));
  }

  Future<void> _saveAudioClipSettings(
    String clipId, {
    int? outputStartMs,
    int? sourceStartMs,
    int? durationMs,
    double? volume,
    int? fadeInMs,
    int? fadeOutMs,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final matches = _project.audioTrack
        .where((clip) => clip.id == clipId)
        .toList(growable: false);
    if (matches.length != 1) return;
    final index = _project.audioTrack.indexWhere((clip) => clip.id == clipId);
    final current = matches.single;
    final asset = _project.assetById(current.assetId);
    if (asset == null ||
        asset.kind != MediaKind.audio ||
        asset.durationMs <= 0) {
      return;
    }
    final nextSourceStart =
        (sourceStartMs ?? _audioSourceStartDraftMs ?? current.trimStartMs)
            .clamp(0, asset.durationMs - 1)
            .toInt();
    final sourceCapacity = asset.durationMs - nextSourceStart;
    final currentOutputStart = _project.videoTrack.isEmpty
        ? current.timelineStartMs
        : projectTimelineMsToOutputMs(
            _project.videoTrack,
            current.timelineStartMs,
            transitions: _project.videoTransitions,
          );
    final requestedOutputStart =
        outputStartMs ?? _audioStartDraftMs ?? currentOutputStart;
    var requestedDuration =
        (durationMs ?? _audioDurationDraftMs ?? current.durationMs)
            .clamp(1, sourceCapacity)
            .toInt();
    if (_durationMs > 0)
      requestedDuration = requestedDuration.clamp(1, _durationMs).toInt();
    final maxOutputStart = _durationMs > 0
        ? math.max(0, _durationMs - requestedDuration).toInt()
        : 1 << 53;
    final boundedOutputStart = requestedOutputStart
        .clamp(0, maxOutputStart)
        .toInt();
    if (_durationMs > 0) {
      requestedDuration = requestedDuration
          .clamp(1, math.max(1, _durationMs - boundedOutputStart))
          .toInt();
    }
    final nextTimelineStart = _project.videoTrack.isEmpty
        ? boundedOutputStart
        : outputTimelineMsToProjectMs(
            _project.videoTrack,
            boundedOutputStart,
            transitions: _project.videoTransitions,
          );
    final nextVolume = (volume ?? _audioVolumeDraft ?? current.volume)
        .clamp(0.0, 1.0)
        .toDouble();
    final nextFadeInMs = (fadeInMs ?? _audioFadeInDraftMs ?? current.fadeInMs)
        .clamp(0, requestedDuration)
        .toInt();
    final nextFadeOutMs =
        (fadeOutMs ?? _audioFadeOutDraftMs ?? current.fadeOutMs)
            .clamp(0, requestedDuration)
            .toInt();
    final nextClip = current.copyWith(
      trimStartMs: nextSourceStart,
      trimEndMs: nextSourceStart + requestedDuration,
      timelineStartMs: nextTimelineStart,
      volume: nextVolume,
      fadeInMs: nextFadeInMs,
      fadeOutMs: nextFadeOutMs,
    );
    if (nextClip.trimStartMs == current.trimStartMs &&
        nextClip.trimEndMs == current.trimEndMs &&
        nextClip.timelineStartMs == current.timelineStartMs &&
        nextClip.volume == current.volume &&
        nextClip.fadeInMs == current.fadeInMs &&
        nextClip.fadeOutMs == current.fadeOutMs) {
      setState(() {
        _audioStartDraftMs = null;
        _audioSourceStartDraftMs = null;
        _audioDurationDraftMs = null;
        _audioVolumeDraft = null;
        _audioFadeInDraftMs = null;
        _audioFadeOutDraftMs = null;
      });
      return;
    }
    final audioTrack = List<TimelineClip>.of(_project.audioTrack)
      ..[index] = nextClip;
    await _commitMultitrackProject(
      _project.copyWith(audioTrack: audioTrack),
      selectedAudioClipId: clipId,
    );
  }

  Future<void> _saveVideoClipAudioSettings(
    String clipId, {
    double? volume,
    int? fadeInMs,
    int? fadeOutMs,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final index = _project.videoTrack.indexWhere((clip) => clip.id == clipId);
    if (index < 0) return;
    final current = _project.videoTrack[index];
    final asset = _project.assetById(current.assetId);
    if (asset == null || asset.kind != MediaKind.video) return;
    final durationMs = current.effectiveDurationMs.clamp(0, 1 << 53).toInt();
    final nextVolume = (volume ?? _videoAudioVolumeDraft ?? current.volume)
        .clamp(0.0, 1.0)
        .toDouble();
    final nextFadeInMs =
        (fadeInMs ?? _videoAudioFadeInDraftMs ?? current.fadeInMs)
            .clamp(0, durationMs)
            .toInt();
    final nextFadeOutMs =
        (fadeOutMs ?? _videoAudioFadeOutDraftMs ?? current.fadeOutMs)
            .clamp(0, durationMs)
            .toInt();
    if (nextVolume == current.volume &&
        nextFadeInMs == current.fadeInMs &&
        nextFadeOutMs == current.fadeOutMs) {
      setState(() {
        _videoAudioVolumeDraft = null;
        _videoAudioFadeInDraftMs = null;
        _videoAudioFadeOutDraftMs = null;
      });
      return;
    }
    final videoTrack = List<TimelineClip>.of(_project.videoTrack)
      ..[index] = current.copyWith(
        volume: nextVolume,
        fadeInMs: nextFadeInMs,
        fadeOutMs: nextFadeOutMs,
      );
    await _commitMultitrackProject(_project.copyWith(videoTrack: videoTrack));
  }

  Widget _buildEmbeddedAudioControls(TimelineClip clip, bool disabled) {
    final durationMs = clip.effectiveDurationMs.clamp(0, 1 << 53).toInt();
    final volume = (_videoAudioVolumeDraft ?? clip.volume)
        .clamp(0.0, 1.0)
        .toDouble();
    final fadeInMs = (_videoAudioFadeInDraftMs ?? clip.fadeInMs)
        .clamp(0, durationMs)
        .toInt();
    final fadeOutMs = (_videoAudioFadeOutDraftMs ?? clip.fadeOutMs)
        .clamp(0, durationMs)
        .toInt();

    void commit() => unawaited(
      _saveVideoClipAudioSettings(
        clip.id,
        volume: _videoAudioVolumeDraft,
        fadeInMs: _videoAudioFadeInDraftMs,
        fadeOutMs: _videoAudioFadeOutDraftMs,
      ),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('صوت الفيديو الأصلي'),
        Text('مستوى الصوت: ${(volume * 100).round()}٪'),
        Slider(
          key: ValueKey('video-audio-volume-${clip.id}'),
          min: 0,
          max: 1,
          divisions: 100,
          value: volume,
          onChanged: disabled
              ? null
              : (value) => setState(() => _videoAudioVolumeDraft = value),
          onChangeEnd: disabled ? null : (_) => commit(),
        ),
        Text('تلاشي تدريجي عند البداية: ${_formatDuration(fadeInMs)}'),
        Slider(
          key: ValueKey('video-audio-fade-in-${clip.id}'),
          min: 0,
          max: math.max(1, durationMs).toDouble(),
          divisions: durationMs > 1 ? math.min(100, durationMs).toInt() : null,
          value: fadeInMs.toDouble(),
          onChanged: disabled || durationMs <= 0
              ? null
              : (value) =>
                    setState(() => _videoAudioFadeInDraftMs = value.round()),
          onChangeEnd: disabled ? null : (_) => commit(),
        ),
        Text('تلاشي تدريجي عند النهاية: ${_formatDuration(fadeOutMs)}'),
        Slider(
          key: ValueKey('video-audio-fade-out-${clip.id}'),
          min: 0,
          max: math.max(1, durationMs).toDouble(),
          divisions: durationMs > 1 ? math.min(100, durationMs).toInt() : null,
          value: fadeOutMs.toDouble(),
          onChanged: disabled || durationMs <= 0
              ? null
              : (value) =>
                    setState(() => _videoAudioFadeOutDraftMs = value.round()),
          onChangeEnd: disabled ? null : (_) => commit(),
        ),
      ],
    );
  }

  Future<void> _commitAudioDraft(TimelineClip clip) async {
    await _saveAudioClipSettings(
      clip.id,
      outputStartMs: _audioStartDraftMs,
      sourceStartMs: _audioSourceStartDraftMs,
      durationMs: _audioDurationDraftMs,
      volume: _audioVolumeDraft,
      fadeInMs: _audioFadeInDraftMs,
      fadeOutMs: _audioFadeOutDraftMs,
    );
  }

  Future<void> _extractAudioFromVideoClip(String clipId) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final clipIndex = _project.videoTrack.indexWhere(
      (clip) => clip.id == clipId,
    );
    if (clipIndex < 0) return;
    final clip = _project.videoTrack[clipIndex];
    final sourceAsset = _project.assetById(clip.assetId);
    if (sourceAsset == null || sourceAsset.kind != MediaKind.video) return;

    setState(() {
      _extractingAudioClipId = clipId;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      final extractedAsset = await NativeBridge.extractVideoAudio(
        sourceAsset,
        clip,
      );
      if (!mounted) return;
      _validateImportAsset(extractedAsset);
      if (extractedAsset.kind != MediaKind.audio ||
          extractedAsset.durationMs <= 0) {
        throw const FormatException('لم يُنتج الاستخراج ملفًا صوتيًا صالحًا.');
      }

      final assets = List<MediaAsset>.of(_project.assets);
      final audioTrack = List<TimelineClip>.of(_project.audioTrack);
      final projectAssetId =
          assets.any((asset) => asset.id == extractedAsset.id)
          ? newLocalId()
          : extractedAsset.id;
      final projectAsset = projectAssetId == extractedAsset.id
          ? extractedAsset
          : MediaAsset(
              id: projectAssetId,
              uri: extractedAsset.uri,
              name: extractedAsset.name,
              mimeType: extractedAsset.mimeType,
              kind: extractedAsset.kind,
              durationMs: extractedAsset.durationMs,
              width: extractedAsset.width,
              height: extractedAsset.height,
              sizeBytes: extractedAsset.sizeBytes,
            );
      if (assets.any((asset) => asset.uri == projectAsset.uri)) {
        throw const FormatException(
          'ملف الصوت المستخرج موجود بالفعل في المشروع.',
        );
      }
      assets.add(projectAsset);

      // Convert the selected clip's actual output start back to project time.
      // This keeps alignment through both speed mapping and transition overlaps;
      // the rendered audio file's duration already includes this clip's current speed.
      final clipStart = timelinePositionForClipOffset(
        _project.videoTrack,
        clipIndex: clipIndex,
        clipPositionMs: 0,
        transitions: _project.videoTransitions,
      );
      if (clipStart == null) {
        throw const FormatException('تعذّر تحديد بداية المقطع في الخط الزمني.');
      }
      final sourceTimelineStartMs = outputTimelineMsToProjectMs(
        _project.videoTrack,
        clipStart.timelinePositionMs,
        transitions: _project.videoTransitions,
      );
      final extractedDurationMs = math
          .min(projectAsset.durationMs, clip.effectiveDurationMs)
          .toInt();
      if (extractedDurationMs <= 0) {
        throw const FormatException('مدة الصوت المستخرج غير صالحة.');
      }
      final audioClip = TimelineClip(
        id: newLocalId(),
        assetId: projectAsset.id,
        trimStartMs: 0,
        trimEndMs: extractedDurationMs,
        timelineStartMs: sourceTimelineStartMs,
      );
      audioTrack.add(audioClip);
      final updatedProject = _project.copyWith(
        assets: assets,
        audioTrack: audioTrack,
      );
      await _commitMultitrackProject(
        updatedProject,
        selectedAudioClipId: audioClip.id,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'استُخرج الصوت وفق القص والسرعة الحالية، وأُضيف كمقطع مستقل.',
            ),
          ),
        );
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر استخراج صوت الفيديو: $error');
    } finally {
      if (mounted) {
        setState(() {
          _extractingAudioClipId = null;
          _projectOperationInProgress = false;
        });
      }
    }
  }

  int _overlayProjectToOutput(int projectMs) => _project.videoTrack.isEmpty
      ? projectMs
      : projectTimelineMsToOutputMs(
          _project.videoTrack,
          projectMs,
          transitions: _project.videoTransitions,
        );

  int _overlayOutputToProject(int outputMs) => _project.videoTrack.isEmpty
      ? outputMs
      : outputTimelineMsToProjectMs(
          _project.videoTrack,
          outputMs,
          transitions: _project.videoTransitions,
        );

  (int, int) _newOverlayTimeRange() {
    final startOutput = _positionMs
        .clamp(0, math.max(0, _durationMs - 1))
        .toInt();
    final endOutput = math.min(_durationMs, startOutput + 3_000).toInt();
    final startProject = _overlayOutputToProject(startOutput);
    var endProject = _overlayOutputToProject(endOutput);
    if (endProject <= startProject) endProject = startProject + 1;
    return (startProject, endProject);
  }

  Future<Map<String, String>?> _promptOverlayText({
    String initialText = '',
    String initialTemplate = 'classic',
  }) async {
    final controller = _overlayTextController..text = initialText;
    var template = initialTemplate;
    return await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(initialText.isEmpty ? 'نص جديد' : 'تحرير النص'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                key: const ValueKey('overlay-text-input'),
                controller: controller,
                autofocus: true,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'النص',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: template,
                decoration: const InputDecoration(labelText: 'قالب البداية'),
                items:
                    const ['classic', 'banner', 'outline', 'subtitle', 'emoji']
                        .map(
                          (id) => DropdownMenuItem(
                            value: id,
                            child: Text(overlayTemplateName(id)),
                          ),
                        )
                        .toList(),
                onChanged: (value) {
                  if (value != null) setDialogState(() => template = value);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, {
                'text': controller.text.trim(),
                'template': template,
              }),
              child: const Text('تم'),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _pickSubtitleImportMode() => showDialog<String>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('استيراد ترجمة SRT'),
      content: const Text(
        'هل تريد إضافة المقاطع إلى الترجمة الحالية أم استبدالها؟',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: const Text('إلغاء'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, 'append'),
          child: const Text('إضافة'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext, 'replace'),
          child: const Text('استبدال'),
        ),
      ],
    ),
  );

  Future<void> _importSubtitleFile() async {
    if (_projectOperationInProgress ||
        _saving ||
        _importingMedia ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0)
      return;
    setState(() {
      _importingMedia = true;
      _error = null;
    });
    try {
      final source = await NativeBridge.pickSubtitleFile();
      if (!mounted || source == null) return;
      final parsed = SubtitleCue.parseSrt(source);
      if (parsed.isEmpty) {
        setState(() => _error = 'لم يتم العثور على مقاطع SRT صالحة في الملف.');
        return;
      }
      final mode = await _pickSubtitleImportMode();
      if (!mounted || mode == null) return;
      final cues = <SubtitleCue>[];
      for (final cue in parsed) {
        final startOutput = cue.startMs.clamp(0, _durationMs).toInt();
        final endOutput = cue.endMs.clamp(0, _durationMs).toInt();
        if (endOutput <= startOutput) continue;
        cues.add(
          cue.copyWith(
            startMs: _overlayOutputToProject(startOutput),
            endMs: _overlayOutputToProject(endOutput),
          ),
        );
      }
      if (cues.isEmpty) {
        setState(() => _error = 'مقاطع الملف تقع خارج مدة الفيديو الحالية.');
        return;
      }
      final nextTrack = <SubtitleCue>[
        if (mode == 'append') ..._project.subtitleTrack,
        ...cues,
      ]..sort((a, b) => a.startMs.compareTo(b.startMs));
      await _commitMultitrackProject(
        _project.copyWith(subtitleTrack: nextTrack),
        selectedSubtitleCueId: cues.first.id,
      );
      if (mounted) setState(() => _error = null);
    } on PlatformException catch (error) {
      if (mounted)
        setState(() => _error = error.message ?? 'تعذّر استيراد ملف الترجمة.');
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر استيراد ملف الترجمة: $error');
    } finally {
      if (mounted) setState(() => _importingMedia = false);
    }
  }

  Future<void> _addSubtitleCue() async {
    if (_projectOperationInProgress ||
        _saving ||
        _importingMedia ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0)
      return;
    final (startMs, endMs) = _newOverlayTimeRange();
    final id = newLocalId();
    final cue = SubtitleCue(id: id, text: '', startMs: startMs, endMs: endMs);
    final edited = await _showSubtitleCueDialog(cue);
    if (!mounted || edited == null) return;
    await _commitMultitrackProject(
      _project.copyWith(
        subtitleTrack: [..._project.subtitleTrack, edited]
          ..sort((a, b) => a.startMs.compareTo(b.startMs)),
      ),
      selectedSubtitleCueId: id,
    );
  }

  Future<SubtitleCue?> _showSubtitleCueDialog(SubtitleCue cue) async {
    final textController = TextEditingController(text: cue.text);
    final startController = TextEditingController(
      text: (_overlayProjectToOutput(cue.startMs) / 1000).toStringAsFixed(2),
    );
    final endController = TextEditingController(
      text: (_overlayProjectToOutput(cue.endMs) / 1000).toStringAsFixed(2),
    );
    String? error;
    try {
      return await showDialog<SubtitleCue>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) => AlertDialog(
            title: Text(
              cue.text.isEmpty ? 'مقطع ترجمة جديد' : 'تحرير مقطع الترجمة',
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: textController,
                    autofocus: true,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'النص',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: startController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'البداية (ثانية)',
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: endController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'النهاية (ثانية)',
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      error!,
                      style: const TextStyle(color: Colors.redAccent),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () {
                  final start = double.tryParse(startController.text.trim());
                  final end = double.tryParse(endController.text.trim());
                  if (textController.text.trim().isEmpty ||
                      start == null ||
                      end == null ||
                      start < 0 ||
                      end <= start ||
                      end * 1000 > _durationMs + 1000) {
                    setDialogState(
                      () => error = 'أدخل نصًا ووقتَي بداية ونهاية صالحين ضمن مدة الفيديو.',
                    );
                    return;
                  }
                  final startOutput = (start * 1000)
                      .round()
                      .clamp(0, _durationMs)
                      .toInt();
                  final endOutput = (end * 1000)
                      .round()
                      .clamp(0, _durationMs)
                      .toInt();
                  if (endOutput <= startOutput) {
                    setDialogState(
                      () => error = 'يجب أن تكون النهاية بعد البداية.',
                    );
                    return;
                  }
                  final startProject = _overlayOutputToProject(startOutput);
                  var endProject = _overlayOutputToProject(endOutput);
                  if (endProject <= startProject) endProject = startProject + 1;
                  Navigator.pop(
                    dialogContext,
                    cue.copyWith(
                      text: textController.text.trim(),
                      startMs: startProject,
                      endMs: endProject,
                    ),
                  );
                },
                child: const Text('حفظ'),
              ),
            ],
          ),
        ),
      );
    } finally {
      textController.dispose();
      startController.dispose();
      endController.dispose();
    }
  }

  Future<void> _editSubtitleCue(String id) async {
    final index = _project.subtitleTrack.indexWhere((cue) => cue.id == id);
    if (index < 0) return;
    final cue = _project.subtitleTrack[index];
    final edited = await _showSubtitleCueDialog(cue);
    if (!mounted || edited == null) return;
    final cues = List<SubtitleCue>.of(_project.subtitleTrack)..[index] = edited;
    cues.sort((a, b) => a.startMs.compareTo(b.startMs));
    await _commitMultitrackProject(
      _project.copyWith(subtitleTrack: cues),
      selectedSubtitleCueId: id,
    );
  }

  Future<void> _moveSubtitleCue(String id, int outputStartMs) async {
    final index = _project.subtitleTrack.indexWhere((cue) => cue.id == id);
    if (index < 0) return;
    final cue = _project.subtitleTrack[index];
    final startOutput = _overlayProjectToOutput(cue.startMs);
    final endOutput = _overlayProjectToOutput(cue.endMs);
    final duration = math.max(1, endOutput - startOutput).toInt();
    final boundedStart = outputStartMs
        .clamp(0, math.max(0, _durationMs - duration))
        .toInt();
    final nextStartProject = _overlayOutputToProject(boundedStart);
    var nextEndProject = _overlayOutputToProject(
      math.min(_durationMs, boundedStart + duration).toInt(),
    );
    if (nextEndProject <= nextStartProject)
      nextEndProject = nextStartProject + 1;
    final next = cue.copyWith(startMs: nextStartProject, endMs: nextEndProject);
    final cues = List<SubtitleCue>.of(_project.subtitleTrack)..[index] = next;
    cues.sort((a, b) => a.startMs.compareTo(b.startMs));
    await _commitMultitrackProject(
      _project.copyWith(subtitleTrack: cues),
      selectedSubtitleCueId: id,
    );
  }

  Future<void> _deleteSubtitleCue(String id) async {
    final cues = _project.subtitleTrack.where((cue) => cue.id != id).toList();
    if (cues.length == _project.subtitleTrack.length) return;
    setState(() => _selectedSubtitleCueId = null);
    await _commitMultitrackProject(_project.copyWith(subtitleTrack: cues));
  }

  Future<void> _addTextOverlay() async {
    if (_projectOperationInProgress ||
        _saving ||
        _importingMedia ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0)
      return;
    final result = await _promptOverlayText();
    if (!mounted || result == null || result['text']!.isEmpty) return;
    final (startMs, endMs) = _newOverlayTimeRange();
    final id = newLocalId();
    var overlay = TextOverlay(
      id: id,
      text: result['text']!,
      startMs: startMs,
      endMs: endMs,
    );
    overlay = applyTextTemplate(overlay, result['template']!);
    await _commitMultitrackProject(
      _project.copyWith(textOverlays: [..._project.textOverlays, overlay]),
      selectedTextOverlayId: id,
    );
  }

  Future<void> _editTextOverlay(String id) async {
    final index = _project.textOverlays.indexWhere((item) => item.id == id);
    if (index < 0) return;
    final current = _project.textOverlays[index];
    final result = await _promptOverlayText(
      initialText: current.text,
      initialTemplate: current.templateId,
    );
    if (!mounted || result == null || result['text']!.isEmpty) return;
    final next = applyTextTemplate(
      (_textStyleDraft ?? current).copyWith(text: result['text']),
      result['template']!,
    );
    await _saveTextOverlaySettings(id, style: next);
  }

  Future<void> _addEmojiOverlay(String emoji) async {
    if (_projectOperationInProgress ||
        _saving ||
        _importingMedia ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0)
      return;
    final (startMs, endMs) = _newOverlayTimeRange();
    final id = newLocalId();
    final overlay = applyTextTemplate(
      TextOverlay(
        id: id,
        text: emoji,
        startMs: startMs,
        endMs: endMs,
        templateId: 'emoji',
      ),
      'emoji',
    );
    await _commitMultitrackProject(
      _project.copyWith(textOverlays: [..._project.textOverlays, overlay]),
      selectedTextOverlayId: id,
    );
  }

  Future<void> _chooseEmoji() async {
    const emojis = [
      '😀',
      '😍',
      '😂',
      '🥳',
      '😎',
      '🤔',
      '😭',
      '😡',
      '❤️',
      '🔥',
      '✨',
      '🎉',
      '👍',
      '👏',
      '💯',
      '🌟',
      '🌈',
      '💡',
      '🎬',
      '🚀',
    ];
    final emoji = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: emojis
                .map(
                  (item) => IconButton(
                    tooltip: item,
                    iconSize: 32,
                    onPressed: () => Navigator.pop(sheetContext, item),
                    icon: Text(item, style: const TextStyle(fontSize: 28)),
                  ),
                )
                .toList(),
          ),
        ),
      ),
    );
    if (emoji != null && mounted) await _addEmojiOverlay(emoji);
  }

  Future<void> _addStickerOverlay() async {
    if (_importingMedia ||
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0)
      return;
    setState(() {
      _importingMedia = true;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      final asset = await NativeBridge.pickSticker();
      if (!mounted || asset == null) return;
      if (asset.kind != MediaKind.image ||
          (asset.mimeType != 'image/png' && asset.mimeType != 'image/webp')) {
        setState(() => _error = 'اختر ملصق PNG أو WebP بخلفية شفافة.');
        return;
      }
      final (startMs, endMs) = _newOverlayTimeRange();
      final sticker = StickerOverlay(
        id: newLocalId(),
        uri: asset.uri,
        name: asset.name,
        mimeType: asset.mimeType,
        startMs: startMs,
        endMs: endMs,
      );
      await _commitMultitrackProject(
        _project.copyWith(
          stickerOverlays: [..._project.stickerOverlays, sticker],
        ),
        selectedStickerOverlayId: sticker.id,
      );
    } catch (error) {
      if (mounted) {
        setState(
          () => _error = _mediaPickerFailure(error, 'تعذّر استيراد الملصق: '),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _importingMedia = false;
          _projectOperationInProgress = false;
        });
      }
    }
  }

  Future<void> _saveTextOverlaySettings(
    String id, {
    int? outputStartMs,
    int? durationMs,
    TextOverlay? style,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring)
      return;
    final index = _project.textOverlays.indexWhere((item) => item.id == id);
    if (index < 0) return;
    final current = _project.textOverlays[index];
    final currentStart = _overlayProjectToOutput(current.startMs);
    final currentEnd = _overlayProjectToOutput(current.endMs);
    final requestedDuration =
        (durationMs ?? _textDurationDraftMs ?? currentEnd - currentStart)
            .clamp(1, math.max(1, _durationMs))
            .toInt();
    final maximumStart = math.max(0, _durationMs - requestedDuration).toInt();
    final outputStart = (outputStartMs ?? _textStartDraftMs ?? currentStart)
        .clamp(0, maximumStart)
        .toInt();
    final nextDuration = requestedDuration
        .clamp(1, math.max(1, _durationMs - outputStart))
        .toInt();
    final startProject = _overlayOutputToProject(outputStart);
    var endProject = _overlayOutputToProject(outputStart + nextDuration);
    if (endProject <= startProject) endProject = startProject + 1;
    final next = (style ?? _textStyleDraft ?? current).copyWith(
      startMs: startProject,
      endMs: endProject,
    );
    final items = List<TextOverlay>.of(_project.textOverlays)..[index] = next;
    await _commitMultitrackProject(
      _project.copyWith(textOverlays: items),
      selectedTextOverlayId: id,
    );
  }

  Future<void> _saveStickerSettings(
    String id, {
    int? outputStartMs,
    int? durationMs,
    StickerOverlay? draft,
  }) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring)
      return;
    final index = _project.stickerOverlays.indexWhere((item) => item.id == id);
    if (index < 0) return;
    final current = _project.stickerOverlays[index];
    final currentStart = _overlayProjectToOutput(current.startMs);
    final currentEnd = _overlayProjectToOutput(current.endMs);
    final requestedDuration =
        (durationMs ?? _stickerDurationDraftMs ?? currentEnd - currentStart)
            .clamp(1, math.max(1, _durationMs))
            .toInt();
    final maximumStart = math.max(0, _durationMs - requestedDuration).toInt();
    final outputStart = (outputStartMs ?? _stickerStartDraftMs ?? currentStart)
        .clamp(0, maximumStart)
        .toInt();
    final nextDuration = requestedDuration
        .clamp(1, math.max(1, _durationMs - outputStart))
        .toInt();
    final startProject = _overlayOutputToProject(outputStart);
    var endProject = _overlayOutputToProject(outputStart + nextDuration);
    if (endProject <= startProject) endProject = startProject + 1;
    final next = (draft ?? _stickerDraft ?? current).copyWith(
      startMs: startProject,
      endMs: endProject,
    );
    final items = List<StickerOverlay>.of(_project.stickerOverlays)
      ..[index] = next;
    await _commitMultitrackProject(
      _project.copyWith(stickerOverlays: items),
      selectedStickerOverlayId: id,
    );
  }

  void _moveTextOverlayOnTimeline(String id, int outputStartMs) {
    unawaited(_saveTextOverlaySettings(id, outputStartMs: outputStartMs));
  }

  void _moveStickerOnTimeline(String id, int outputStartMs) {
    unawaited(_saveStickerSettings(id, outputStartMs: outputStartMs));
  }

  Future<void> _deleteTextOverlay(String id) async {
    final items = _project.textOverlays.where((item) => item.id != id).toList();
    if (items.length == _project.textOverlays.length) return;
    setState(() => _selectedTextOverlayId = null);
    await _commitMultitrackProject(_project.copyWith(textOverlays: items));
  }

  Future<void> _deleteStickerOverlay(String id) async {
    final items = _project.stickerOverlays
        .where((item) => item.id != id)
        .toList();
    if (items.length == _project.stickerOverlays.length) return;
    setState(() => _selectedStickerOverlayId = null);
    await _commitMultitrackProject(_project.copyWith(stickerOverlays: items));
  }

  Future<void> _addVideoOverlay() async {
    if (_importingMedia ||
        _saving ||
        _projectOperationInProgress ||
        _exportingNavigation ||
        _configuring ||
        !_hasVisualTrack ||
        _durationMs <= 0) {
      return;
    }
    setState(() {
      _importingMedia = true;
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      final picked = await NativeBridge.pickMedia();
      if (!mounted || picked.isEmpty) return;
      final visualAssets = picked
          .where(
            (asset) =>
                asset.kind == MediaKind.video || asset.kind == MediaKind.image,
          )
          .toList(growable: false);
      if (visualAssets.isEmpty) {
        setState(() => _error = 'اختر فيديو أو صورة لإضافتها كطبقة مرئية.');
        return;
      }

      const maxSafeMs = 9007199254740991;
      final assets = List<MediaAsset>.of(_project.assets);
      final assetsByUri = <String, MediaAsset>{
        for (final asset in assets) asset.uri: asset,
      };
      final overlayTracks = List<VideoOverlayTrack>.of(
        _project.videoOverlayTracks,
      );
      final usedIds = <String>{
        ..._project.videoTrack.map((clip) => clip.id),
        ..._project.audioTrack.map((clip) => clip.id),
        ...overlayTracks.map((track) => track.id),
        for (final track in overlayTracks)
          ...track.clips.map((clip) => clip.id),
      };
      String uniqueId() {
        var id = newLocalId();
        while (!usedIds.add(id)) {
          id = newLocalId();
        }
        return id;
      }

      final outputStartMs = _positionMs.clamp(0, _durationMs - 1).toInt();
      final sourceStartMs = outputTimelineMsToProjectMs(
        _project.videoTrack,
        outputStartMs,
        transitions: _project.videoTransitions,
      );
      String? firstAddedClipId;
      for (final candidate in visualAssets) {
        _validateImportAsset(candidate);
        final existing = assetsByUri[candidate.uri];
        if (existing != null && existing.kind != candidate.kind) {
          throw FormatException(
            'نوع الوسيط المحدد لا يطابق الأصل «${candidate.name}».',
          );
        }
        final source = existing ?? candidate;
        var assetId = source.id.trim();
        if (existing == null && assets.any((asset) => asset.id == assetId)) {
          do {
            assetId = newLocalId();
          } while (assets.any((asset) => asset.id == assetId));
        }
        final asset =
            existing ??
            MediaAsset(
              id: assetId,
              uri: source.uri,
              name: source.name,
              mimeType: source.mimeType,
              kind: source.kind,
              durationMs: source.durationMs,
              width: source.width,
              height: source.height,
              sizeBytes: source.sizeBytes,
            );
        if (existing == null) {
          assets.add(asset);
          assetsByUri[asset.uri] = asset;
        }
        if (asset.durationMs <= 0 || asset.durationMs > maxSafeMs) {
          throw FormatException('مدة «${asset.name}» غير صالحة للطبقة.');
        }
        final durationMs = math
            .min(asset.durationMs, _durationMs - outputStartMs)
            .toInt();
        if (durationMs <= 0) continue;
        final overlayClip = VideoOverlayClip(
          id: uniqueId(),
          assetId: asset.id,
          trimStartMs: 0,
          trimEndMs: durationMs,
          timelineStartMs: sourceStartMs,
        );
        firstAddedClipId ??= overlayClip.id;
        overlayTracks.insert(
          0,
          VideoOverlayTrack(
            id: uniqueId(),
            name: asset.name,
            clips: [overlayClip],
          ),
        );
      }
      if (firstAddedClipId == null) {
        setState(() => _error = 'تعذّر إنشاء طبقة ضمن مدة الفيديو الحالية.');
        return;
      }
      final updatedProject = _project.copyWith(
        assets: assets,
        videoOverlayTracks: overlayTracks,
      );
      await _commitMultitrackProject(
        updatedProject,
        selectedOverlayClipId: firstAddedClipId,
      );
    } catch (error) {
      if (mounted) {
        setState(
          () => _error = _mediaPickerFailure(error, 'تعذّرت إضافة الطبقة: '),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _importingMedia = false;
          _projectOperationInProgress = false;
        });
      }
    }
  }

  Future<void> _togglePlayback() async {
    if (!_configured) return;
    try {
      if (_playing) {
        await NativeBridge.pausePreview();
        if (mounted) setState(() => _playing = false);
      } else {
        if (_positionMs >= _durationMs && _durationMs > 0) {
          await _seekTo(0);
        }
        await NativeBridge.playPreview();
        if (mounted) setState(() => _playing = true);
      }
      if (mounted) setState(() => _error = null);
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر التحكم في التشغيل: $error');
    }
  }

  Future<void> _importMedia() async {
    if (_importingMedia ||
        _saving ||
        _projectOperationInProgress ||
        _exportingNavigation) {
      return;
    }
    setState(() {
      _importingMedia = true;
      _projectOperationInProgress = true;
      _error = null;
    });

    try {
      final pickedAssets = await NativeBridge.pickMedia();
      if (!mounted || pickedAssets.isEmpty) return;

      // Construct and validate the complete next project before committing any
      // state, so one bad picker result cannot leave a partially imported batch.
      final updatedProject = _projectWithImportedMedia(pickedAssets);
      final updatedDurationMs = visualTimelineDurationMs(
        updatedProject.videoTrack,
        transitions: updatedProject.videoTransitions,
      );
      final audioExceedsVisualDuration = updatedProject.audioTrack.any(
        (clip) =>
            clip.timelineStartMs + clip.effectiveDurationMs > updatedDurationMs,
      );
      final updatedPositionMs = _positionMs.clamp(0, updatedDurationMs).toInt();

      _history.record(updatedProject);
      setState(() {
        _project = updatedProject;
        _durationMs = updatedDurationMs;
        _positionMs = updatedPositionMs;
        _isScrubbing = false;
      });

      final saveSucceeded = await _saveEditedProject(updatedProject);
      if (!saveSucceeded && mounted) {
        // Keep the imported project in editor state and expose the save retry.
        setState(() => _hasUnsavedChanges = true);
      }
      await _reconfigurePreviewAfterProjectChange();
      if (mounted && audioExceedsVisualDuration) {
        final warning = updatedDurationMs == 0
            ? 'تنبيه: لا يوجد مسار مرئي؛ قد لا تشمل المعاينة والتصدير الحاليان الصوت كاملًا.'
            : 'تنبيه: يتجاوز مقطع صوتي مدة الخط الزمني المرئي؛ قد لا تشمل المعاينة والتصدير الحاليان الجزء الأخير من الصوت.';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(warning),
            duration: const Duration(seconds: 6),
          ),
        );
      }
    } on FormatException catch (error) {
      if (mounted) {
        setState(() => _error = 'لم تُستورد الوسائط: ${error.message}');
      }
    } catch (error) {
      if (mounted) {
        setState(
          () => _error = _mediaPickerFailure(error, 'تعذّر استيراد الوسائط: '),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _importingMedia = false;
          _projectOperationInProgress = false;
        });
      }
    }
  }

  VeloraProject _projectWithImportedMedia(List<MediaAsset> pickedAssets) {
    const maxSafeMilliseconds = 9007199254740991;
    final assets = List<MediaAsset>.of(_project.assets);
    final assetsByUri = <String, MediaAsset>{
      for (final asset in assets) asset.uri: asset,
    };
    final videoTrack = List<TimelineClip>.of(_project.videoTrack);
    final audioTrack = List<TimelineClip>.of(_project.audioTrack);
    final usedClipIds = <String>{
      ...videoTrack.map((clip) => clip.id),
      ...audioTrack.map((clip) => clip.id),
    };

    String newClipId() {
      var id = newLocalId();
      while (!usedClipIds.add(id)) {
        id = newLocalId();
      }
      return id;
    }

    for (final picked in pickedAssets) {
      _validateImportAsset(picked);
      final existingAsset = assetsByUri[picked.uri];
      final asset = existingAsset ?? picked;
      if (existingAsset != null) {
        _validateImportAsset(existingAsset);
        if (existingAsset.kind != picked.kind) {
          throw FormatException(
            'نوع الوسيط المحدد لا يطابق الأصل المحفوظ «${picked.name}».',
          );
        }
      }

      var assetId = asset.id.trim();
      if (existingAsset == null && assets.any((item) => item.id == assetId)) {
        do {
          assetId = newLocalId();
        } while (assets.any((item) => item.id == assetId));
      }
      final projectAsset =
          existingAsset ??
          MediaAsset(
            id: assetId,
            uri: asset.uri,
            name: asset.name,
            mimeType: asset.mimeType,
            kind: asset.kind,
            durationMs: asset.durationMs,
            width: asset.width,
            height: asset.height,
            sizeBytes: asset.sizeBytes,
          );
      if (existingAsset == null) {
        assets.add(projectAsset);
        assetsByUri[projectAsset.uri] = projectAsset;
      }

      switch (projectAsset.kind) {
        case MediaKind.video:
        case MediaKind.image:
          videoTrack.add(
            TimelineClip(
              id: newClipId(),
              assetId: projectAsset.id,
              trimStartMs: 0,
              trimEndMs: projectAsset.durationMs,
            ),
          );
          break;
        case MediaKind.audio:
          audioTrack.add(
            TimelineClip(
              id: newClipId(),
              assetId: projectAsset.id,
              trimStartMs: 0,
              trimEndMs: projectAsset.durationMs,
              timelineStartMs: 0,
            ),
          );
          break;
        case MediaKind.unsupported:
          throw FormatException('نوع الوسيط «${projectAsset.name}» غير مدعوم.');
      }
    }

    final updatedProject = _project.copyWith(
      assets: assets,
      videoTrack: videoTrack,
      audioTrack: audioTrack,
    );
    final durationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    if (durationMs < 0 || durationMs > maxSafeMilliseconds) {
      throw const FormatException('مدة المسار المرئي الناتجة غير صالحة.');
    }
    return updatedProject;
  }

  void _validateImportAsset(MediaAsset asset) {
    final name = asset.name.trim();
    final uriText = asset.uri.trim();
    final mimeType = asset.mimeType.trim().toLowerCase();
    if (asset.id.trim().isEmpty ||
        name.isEmpty ||
        mimeType.isEmpty ||
        uriText.isEmpty) {
      throw FormatException('بيانات أحد الملفات المختارة ناقصة.');
    }
    final parsedUri = Uri.tryParse(uriText);
    if (parsedUri == null ||
        (parsedUri.scheme != 'content' && parsedUri.scheme != 'file') ||
        (parsedUri.scheme == 'content' && parsedUri.authority.isEmpty) ||
        (parsedUri.scheme == 'file' && parsedUri.path.isEmpty)) {
      throw FormatException('رابط الوصول إلى «$name» غير صالح.');
    }
    if (!const {
      MediaKind.video,
      MediaKind.image,
      MediaKind.audio,
    }.contains(asset.kind)) {
      throw FormatException(
        'نوع «$name» غير مدعوم؛ اختر فيديو أو صورة أو صوتًا.',
      );
    }
    final mimeFamily = mimeType.startsWith('video/')
        ? MediaKind.video
        : mimeType.startsWith('image/')
        ? MediaKind.image
        : mimeType.startsWith('audio/')
        ? MediaKind.audio
        : null;
    if (mimeFamily != null && mimeFamily != asset.kind) {
      throw FormatException('نوع الملف المعلن لا يطابق «$name».');
    }
    if (asset.durationMs <= 0 || asset.durationMs > 9007199254740991) {
      throw FormatException('تعذّر تحديد مدة صالحة للوسيط «$name».');
    }
    if (asset.width < 0 || asset.height < 0 || asset.sizeBytes < 0) {
      throw FormatException('بيانات الوسيط «$name» غير صالحة.');
    }
  }

  Future<void> _saveProjectAsTemplate() async {
    if (_saving || _projectOperationInProgress || _exportingNavigation) return;
    final controller = TextEditingController(text: '${_project.name} — قالب');
    final name = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حفظ المشروع كقالب'),
        content: TextField(
          key: const ValueKey('save-template-name'),
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'اسم القالب',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('حفظ القالب'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.trim().isEmpty || !mounted) return;
    setState(() => _projectOperationInProgress = true);
    try {
      final template = ProjectTemplate.fromProject(
        _project,
        id: newLocalId(),
        name: name.trim(),
        description: 'قالب قابل لإعادة الاستخدام أُنشئ من مشروع VELORA.',
      );
      await NativeBridge.saveTemplate(template);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم حفظ نسخة القالب دون تغيير المشروع.'),
          ),
        );
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر حفظ القالب: $error');
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Future<void> _saveProject() async {
    if (_saving || _projectOperationInProgress || _exportingNavigation) return;
    final projectToSave = _project;
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await NativeBridge.saveProject(projectToSave);
      if (mounted) {
        setState(() => _hasUnsavedChanges = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تم حفظ المشروع.')));
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر حفظ المشروع: $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _openExport() async {
    if (_exportingNavigation || _saving || _projectOperationInProgress) return;
    final projectToExport = _project;
    setState(() => _exportingNavigation = true);
    try {
      await NativeBridge.saveProject(projectToExport);
      if (mounted) setState(() => _hasUnsavedChanges = false);
      await NativeBridge.pausePreview();
      if (!mounted) return;
      setState(() => _playing = false);
      final mediaAccessLost = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(
          builder: (_) => ExportScreen(project: projectToExport),
        ),
      );
      if (mediaAccessLost == true && mounted && _isAndroid) {
        final position = timelinePositionAt(
          _project.videoTrack,
          _positionMs,
          transitions: _project.videoTransitions,
        );
        await _configurePreview(preferredPosition: position);
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر فتح شاشة التصدير: $error');
    } finally {
      if (mounted) setState(() => _exportingNavigation = false);
    }
  }

  Future<void> _releasePreview() async {
    try {
      await NativeBridge.pausePreview();
    } catch (_) {
      // The native view/channel may already have been detached.
    }
    try {
      await NativeBridge.clearPreview();
    } catch (_) {
      // Disposal must not surface a platform-channel error to the user.
    }
  }

  @override
  void dispose() {
    _stateTimer?.cancel();
    _overlayTextController.dispose();
    _keyframeTimeController.dispose();
    unawaited(_releasePreview());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasDuration = _durationMs > 0;
    final safePosition = _positionMs.clamp(0, _durationMs).toInt();
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _project.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            tooltip: 'تراجع',
            onPressed:
                !_history.canUndo ||
                    _saving ||
                    _exportingNavigation ||
                    _projectOperationInProgress
                ? null
                : _undoProject,
            icon: const Icon(Icons.undo_rounded),
          ),
          IconButton(
            tooltip: 'إعادة',
            onPressed:
                !_history.canRedo ||
                    _saving ||
                    _exportingNavigation ||
                    _projectOperationInProgress
                ? null
                : _redoProject,
            icon: const Icon(Icons.redo_rounded),
          ),
          IconButton(
            tooltip: 'حفظ المشروع',
            onPressed:
                _saving || _projectOperationInProgress || _exportingNavigation
                ? null
                : _saveProject,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
          ),
          IconButton(
            key: const ValueKey('save-project-as-template'),
            tooltip: 'حفظ كقالب',
            onPressed:
                _saving || _projectOperationInProgress || _exportingNavigation
                ? null
                : _saveProjectAsTemplate,
            icon: const Icon(Icons.bookmark_add_outlined),
          ),
          IconButton(
            tooltip: 'تصدير الفيديو',
            onPressed:
                _exportingNavigation || _saving || _projectOperationInProgress
                ? null
                : _openExport,
            icon: const Icon(Icons.file_upload_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          key: const ValueKey('editor-screen-scroll'),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed:
                    _importingMedia ||
                        _saving ||
                        _projectOperationInProgress ||
                        _exportingNavigation
                    ? null
                    : _importMedia,
                icon: _importingMedia
                    ? const SizedBox.square(
                        dimension: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.add_photo_alternate_outlined),
                label: const Text('استيراد وسائط'),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                key: const ValueKey('add-video-overlay-button'),
                onPressed:
                    !_hasVisualTrack ||
                        _importingMedia ||
                        _saving ||
                        _projectOperationInProgress ||
                        _exportingNavigation ||
                        _configuring
                    ? null
                    : _addVideoOverlay,
                icon: const Icon(Icons.layers_outlined),
                label: const Text('إضافة طبقة فيديو أو صورة'),
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 4,
              children: [
                OutlinedButton.icon(
                  key: const ValueKey('add-text-overlay-button'),
                  onPressed:
                      !_hasVisualTrack ||
                          _projectOperationInProgress ||
                          _saving ||
                          _importingMedia ||
                          _exportingNavigation ||
                          _configuring
                      ? null
                      : _addTextOverlay,
                  icon: const Icon(Icons.title_rounded),
                  label: const Text('نص'),
                ),
                OutlinedButton.icon(
                  key: const ValueKey('import-subtitle-button'),
                  onPressed:
                      !_hasVisualTrack ||
                          _projectOperationInProgress ||
                          _saving ||
                          _importingMedia ||
                          _exportingNavigation ||
                          _configuring
                      ? null
                      : _importSubtitleFile,
                  icon: const Icon(Icons.subtitles_outlined),
                  label: const Text('استيراد SRT'),
                ),
                OutlinedButton.icon(
                  key: const ValueKey('add-subtitle-cue-button'),
                  onPressed:
                      !_hasVisualTrack ||
                          _projectOperationInProgress ||
                          _saving ||
                          _importingMedia ||
                          _exportingNavigation ||
                          _configuring
                      ? null
                      : _addSubtitleCue,
                  icon: const Icon(Icons.closed_caption_outlined),
                  label: const Text('ترجمة يدوية'),
                ),
                OutlinedButton.icon(
                  key: const ValueKey('add-emoji-overlay-button'),
                  onPressed:
                      !_hasVisualTrack ||
                          _projectOperationInProgress ||
                          _saving ||
                          _importingMedia ||
                          _exportingNavigation ||
                          _configuring
                      ? null
                      : _chooseEmoji,
                  icon: const Icon(Icons.emoji_emotions_outlined),
                  label: const Text('إيموجي'),
                ),
                OutlinedButton.icon(
                  key: const ValueKey('add-sticker-overlay-button'),
                  onPressed:
                      !_hasVisualTrack ||
                          _projectOperationInProgress ||
                          _saving ||
                          _importingMedia ||
                          _exportingNavigation ||
                          _configuring
                      ? null
                      : _addStickerOverlay,
                  icon: const Icon(Icons.sticky_note_2_outlined),
                  label: const Text('ملصق من الصور'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              clipBehavior: Clip.antiAlias,
              child: AspectRatio(aspectRatio: 16 / 9, child: _buildPreview()),
            ),
            const SizedBox(height: 12),
            EditorTimeline(
              project: _project,
              playheadPositionMs: safePosition,
              selectedVideoClipId: _selectedTimelineClipId,
              onVideoClipTap: _selectTimelineVideoClip,
              selectedVideoOverlayClipId: _selectedVideoOverlayClipId,
              selectedAudioClipId: _selectedAudioClipId,
              selectedTextOverlayId: _selectedTextOverlayId,
              selectedSubtitleCueId: _selectedSubtitleCueId,
              selectedStickerOverlayId: _selectedStickerOverlayId,
              onTextOverlayTap: _selectTextOverlay,
              onTextOverlayMove:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _moveTextOverlayOnTimeline
                  : null,
              onSubtitleCueTap: _selectSubtitleCue,
              onSubtitleCueMove:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _moveSubtitleCue
                  : null,
              onStickerOverlayTap: _selectStickerOverlay,
              onStickerOverlayMove:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _moveStickerOnTimeline
                  : null,
              onVideoOverlayTap: _selectVideoOverlayClip,
              onVideoOverlayMove:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _moveVideoOverlayOnTimeline
                  : null,
              onAudioClipTap: _selectAudioClip,
              onAudioClipMove:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _moveAudioClipOnTimeline
                  : null,
              onVideoClipReorder: _reorderVideoClip,
              onVideoClipTrim:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? _applyTimelineTrimById
                  : null,
              onVideoTransitionTap:
                  !_projectOperationInProgress &&
                      !_saving &&
                      !_exportingNavigation &&
                      !_configuring
                  ? (boundaryIndex) =>
                        unawaited(_editTransitionBoundary(boundaryIndex))
                  : null,
              allowVideoReorder:
                  !_projectOperationInProgress &&
                  !_saving &&
                  !_exportingNavigation &&
                  !_configuring,
            ),
            if (_selectedVideoOverlayClipId != null)
              _buildVideoOverlayControls(),
            if (_selectedAudioClipId != null) _buildAudioClipControls(),
            if (_selectedTextOverlayId != null) _buildTextOverlayControls(),
            if (_selectedSubtitleCueId != null) _buildSubtitleCueControls(),
            if (_selectedStickerOverlayId != null) _buildStickerControls(),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(_formatDuration(safePosition)),
                        const Spacer(),
                        Text(_formatDuration(_durationMs)),
                      ],
                    ),
                    Slider(
                      key: const ValueKey('preview-position-slider'),
                      min: 0,
                      max: hasDuration ? _durationMs.toDouble() : 1,
                      value: hasDuration ? safePosition.toDouble() : 0,
                      onChangeStart: _configured && hasDuration
                          ? (_) => setState(() => _isScrubbing = true)
                          : null,
                      onChanged: _configured && hasDuration
                          ? (value) =>
                                setState(() => _positionMs = value.round())
                          : null,
                      onChangeEnd: _configured && hasDuration
                          ? (value) {
                              setState(() => _isScrubbing = false);
                              unawaited(_seekTo(value.round()));
                            }
                          : null,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton.filledTonal(
                          tooltip: _playing ? 'إيقاف مؤقت' : 'تشغيل',
                          onPressed: _configured ? _togglePlayback : null,
                          icon: Icon(
                            _playing
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(_playing ? 'قيد التشغيل' : 'متوقف'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            _buildTrimControls(),
            if (_configuring) ...[
              const SizedBox(height: 10),
              const LinearProgressIndicator(),
              const SizedBox(height: 6),
              const Text(
                'جارٍ إعداد معاينة الخط الزمني…',
                textAlign: TextAlign.center,
              ),
            ],
            if (_mediaAccessIssue != null) ...[
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFF493A20),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'تعذّر الوصول إلى «${_mediaAccessIssue!.name}». لم يُحذف المشروع ولم تُغيّر بياناته. أعد اختيار الملف لإصلاح الرابط المحفوظ.',
                        style: const TextStyle(color: Color(0xFFFFE3A3)),
                      ),
                      const SizedBox(height: 8),
                      FilledButton.icon(
                        onPressed:
                            _importingMedia || _projectOperationInProgress
                            ? null
                            : _reselectUnavailableMedia,
                        icon: const Icon(Icons.folder_open_rounded),
                        label: const Text('إعادة اختيار الملف'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFF3A2023),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Color(0xFFFFD5D5)),
                  ),
                ),
              ),
            ],
            if (_hasUnsavedChanges) ...[
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFF493A20),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'غير محفوظ: التعديلات موجودة في المحرر، لكن تعذّر حفظها على الجهاز.',
                        style: TextStyle(color: Color(0xFFFFE3A3)),
                      ),
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed:
                            _saving ||
                                _projectOperationInProgress ||
                                _exportingNavigation
                            ? null
                            : _retrySaveEditedProject,
                        icon: _saving
                            ? const SizedBox.square(
                                dimension: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.refresh_rounded),
                        label: const Text('إعادة محاولة الحفظ'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 10),
            Text(
              '${_project.videoTrack.length} مقطع أساسي · '
              '${_project.videoOverlayTracks.fold<int>(0, (count, track) => count + track.clips.length)} طبقة فيديو · '
              '${_project.textOverlays.length} نص · ${_project.subtitleTrack.length} ترجمة · ${_project.stickerOverlays.length} ملصق · '
              '${_project.audioTrack.length} مقطع صوتي',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFFAFBAC5)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrimControls() {
    if (_project.videoTrack.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'قص المقاطع المرئية',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed:
                    _projectOperationInProgress ||
                        _saving ||
                        _exportingNavigation ||
                        _configuring ||
                        _splitPositionAtPlayhead() == null
                    ? null
                    : _splitAtPlayhead,
                icon: const Icon(Icons.content_cut),
                label: const Text('تقسيم عند المؤشر'),
              ),
            ),
            for (var index = 0; index < _project.videoTrack.length; index++)
              _buildClipTrimRow(_project.videoTrack[index], index),
          ],
        ),
      ),
    );
  }

  Widget _buildClipTrimRow(TimelineClip clip, int index) {
    final clipAsset = _project.assetById(clip.assetId);
    final assetName = clipAsset?.name ?? clip.id;
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring;
    return Padding(
      key: ValueKey('trim-controls-${clip.id}'),
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${index + 1}. $assetName',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          Row(
            children: [
              const SizedBox(width: 48, child: Text('البداية')),
              IconButton(
                tooltip: 'تقليل 100 مللي ثانية',
                onPressed: disabled
                    ? null
                    : () => _nudgeTrimBoundary(
                        clip,
                        moveStart: true,
                        deltaMs: -100,
                      ),
                icon: const Icon(Icons.remove_circle_outline),
              ),
              TextButton(
                onPressed: disabled
                    ? null
                    : () => _editTrimBoundary(clip, moveStart: true),
                child: Text(_formatDuration(clip.trimStartMs)),
              ),
              IconButton(
                tooltip: 'زيادة 100 مللي ثانية في البداية',
                onPressed: disabled
                    ? null
                    : () => _nudgeTrimBoundary(
                        clip,
                        moveStart: true,
                        deltaMs: 100,
                      ),
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
          Row(
            children: [
              const SizedBox(width: 48, child: Text('النهاية')),
              IconButton(
                tooltip: 'تقليل 100 مللي ثانية من النهاية',
                onPressed: disabled
                    ? null
                    : () => _nudgeTrimBoundary(
                        clip,
                        moveStart: false,
                        deltaMs: -100,
                      ),
                icon: const Icon(Icons.remove_circle_outline),
              ),
              TextButton(
                onPressed: disabled
                    ? null
                    : () => _editTrimBoundary(clip, moveStart: false),
                child: Text(_formatDuration(clip.trimEndMs)),
              ),
              IconButton(
                tooltip: 'زيادة 100 مللي ثانية في النهاية',
                onPressed: disabled
                    ? null
                    : () => _nudgeTrimBoundary(
                        clip,
                        moveStart: false,
                        deltaMs: 100,
                      ),
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
          ),
          if (clip.id == _selectedTimelineClipId)
            _buildClipSpeedControls(clip, disabled),
          if (clip.id == _selectedTimelineClipId)
            _buildClipTransformKeyframeControls(clip, disabled),
          if (clip.id == _selectedTimelineClipId)
            _buildClipColorControls(clip, disabled),
          if (clip.id == _selectedTimelineClipId &&
              clipAsset?.kind == MediaKind.video)
            _buildEmbeddedAudioControls(clip, disabled),
          if (clip.id == _selectedTimelineClipId &&
              clipAsset?.kind == MediaKind.video) ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                key: ValueKey('extract-video-audio-${clip.id}'),
                onPressed: disabled || _extractingAudioClipId != null
                    ? null
                    : () => unawaited(_extractAudioFromVideoClip(clip.id)),
                icon: _extractingAudioClipId == clip.id
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.music_note_rounded),
                label: Text(
                  _extractingAudioClipId == clip.id
                      ? 'جارٍ استخراج الصوت…'
                      : 'استخراج صوت الفيديو كمقطع مستقل',
                ),
              ),
            ),
            const Text(
              'تُطبّق سرعة المقطع الحالية عند الاستخراج؛ لا يتبع الصوت تغييرات السرعة اللاحقة.',
              style: TextStyle(fontSize: 12),
            ),
          ],
          if (index < _project.videoTrack.length - 1) const Divider(height: 8),
        ],
      ),
    );
  }

  VideoOverlayClip? _selectedOverlayClip() {
    final id = _selectedVideoOverlayClipId;
    if (id == null) return null;
    for (final track in _project.videoOverlayTracks) {
      for (final clip in track.clips) {
        if (clip.id == id) return clip;
      }
    }
    return null;
  }

  Widget _buildSubtitleCueControls() {
    final id = _selectedSubtitleCueId;
    final cueIndex = id == null
        ? -1
        : _project.subtitleTrack.indexWhere((item) => item.id == id);
    final cue = cueIndex < 0 ? null : _project.subtitleTrack[cueIndex];
    if (cue == null) return const SizedBox.shrink();
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring;
    final start = _overlayProjectToOutput(cue.startMs);
    final end = _overlayProjectToOutput(cue.endMs);
    return Card(
      key: const ValueKey('subtitle-cue-controls'),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'مقطع ترجمة',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  tooltip: 'تحرير الترجمة',
                  onPressed: disabled ? null : () => _editSubtitleCue(cue.id),
                  icon: const Icon(Icons.edit_outlined),
                ),
                IconButton(
                  tooltip: 'حذف الترجمة',
                  onPressed: disabled ? null : () => _deleteSubtitleCue(cue.id),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            Text(cue.text, maxLines: 3, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(
              '${_formatDuration(start)} – ${_formatDuration(end)} · اسحب المقطع في الخط الزمني لضبط موضعه',
              style: const TextStyle(color: Color(0xFFAFBAC5), fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextOverlayControls() {
    final id = _selectedTextOverlayId;
    if (id == null) return const SizedBox.shrink();
    final index = _project.textOverlays.indexWhere((item) => item.id == id);
    if (index < 0) return const SizedBox.shrink();
    final saved = _project.textOverlays[index];
    final item = _textStyleDraft ?? saved;
    final mappedStart = _overlayProjectToOutput(saved.startMs);
    final mappedEnd = _overlayProjectToOutput(saved.endMs);
    final requestedDuration =
        _textDurationDraftMs ?? math.max(1, mappedEnd - mappedStart);
    final durationMs = requestedDuration
        .clamp(1, math.max(1, _durationMs))
        .toInt();
    final maximumStart = math.max(0, _durationMs - durationMs).toInt();
    final startMs = (_textStartDraftMs ?? mappedStart)
        .clamp(0, maximumStart)
        .toInt();
    final maximumDuration = math.max(1, _durationMs - startMs).toInt();
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _configuring ||
        _exportingNavigation;

    void commitDraft() =>
        unawaited(_saveTextOverlaySettings(id, style: _textStyleDraft));
    Future<void> updateStyle(TextOverlay next) =>
        _saveTextOverlaySettings(id, style: next);

    const swatches = <int>[
      0xFFFFFFFF,
      0xFF111820,
      0xFFFFD166,
      0xFFFF5E68,
      0xFF67D6A3,
      0xFF6EB5FF,
      0xFFFF8AC6,
    ];
    return Card(
      key: ValueKey('text-overlay-controls-$id'),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'تحرير النص',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  tooltip: 'حذف النص',
                  onPressed: disabled ? null : () => _deleteTextOverlay(id),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            Text(item.text, maxLines: 2, overflow: TextOverflow.ellipsis),
            Wrap(
              spacing: 8,
              children: [
                TextButton.icon(
                  key: ValueKey('edit-overlay-text-$id'),
                  onPressed: disabled ? null : () => _editTextOverlay(id),
                  icon: const Icon(Icons.edit_outlined),
                  label: const Text('تعديل النص'),
                ),
              ],
            ),
            DropdownButtonFormField<String>(
              key: ValueKey('overlay-template-$id'),
              value: item.templateId,
              decoration: const InputDecoration(labelText: 'قالب النص'),
              items: const ['classic', 'banner', 'outline', 'subtitle', 'emoji']
                  .map(
                    (template) => DropdownMenuItem(
                      value: template,
                      child: Text(overlayTemplateName(template)),
                    ),
                  )
                  .toList(),
              onChanged: disabled
                  ? null
                  : (template) {
                      if (template != null) {
                        unawaited(
                          updateStyle(applyTextTemplate(item, template)),
                        );
                      }
                    },
            ),
            DropdownButtonFormField<String>(
              key: ValueKey('overlay-font-$id'),
              value: overlayFontFamilies.contains(item.fontFamily)
                  ? item.fontFamily
                  : overlayFontFamilies.first,
              decoration: const InputDecoration(labelText: 'الخط'),
              items: const [
                DropdownMenuItem(value: 'sans-serif', child: Text('Sans')),
                DropdownMenuItem(value: 'serif', child: Text('Serif')),
                DropdownMenuItem(value: 'monospace', child: Text('Monospace')),
                DropdownMenuItem(
                  value: 'sans-serif-condensed',
                  child: Text('Condensed'),
                ),
              ],
              onChanged: disabled || item.templateId == 'emoji'
                  ? null
                  : (font) {
                      if (font != null)
                        unawaited(updateStyle(item.copyWith(fontFamily: font)));
                    },
            ),
            Text(
              'حجم النص: ${(item.fontSizeScale * 100).round()}٪ من ارتفاع الإطار',
            ),
            Slider(
              key: ValueKey('overlay-font-size-$id'),
              min: 0.02,
              max: 0.15,
              divisions: 26,
              value: item.fontSizeScale.clamp(0.02, 0.15).toDouble(),
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () =>
                          _textStyleDraft = item.copyWith(fontSizeScale: value),
                    ),
              onChangeEnd: disabled ? null : (_) => commitDraft(),
            ),
            const Text('لون النص'),
            Wrap(
              spacing: 2,
              children: swatches
                  .map(
                    (color) => IconButton(
                      tooltip: 'اختيار لون النص',
                      onPressed: disabled
                          ? null
                          : () => unawaited(
                              updateStyle(item.copyWith(colorArgb: color)),
                            ),
                      icon: Icon(Icons.circle, color: Color(color), size: 22),
                    ),
                  )
                  .toList(),
            ),
            const Text('المحاذاة'),
            Wrap(
              spacing: 8,
              children: OverlayTextAlignment.values
                  .map(
                    (alignment) => ChoiceChip(
                      label: Text(switch (alignment) {
                        OverlayTextAlignment.start => 'بداية',
                        OverlayTextAlignment.center => 'وسط',
                        OverlayTextAlignment.end => 'نهاية',
                      }),
                      selected: item.alignment == alignment,
                      onSelected: disabled
                          ? null
                          : (_) => unawaited(
                              updateStyle(item.copyWith(alignment: alignment)),
                            ),
                    ),
                  )
                  .toList(),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('ظل النص'),
              value: item.shadow,
              onChanged: disabled
                  ? null
                  : (value) =>
                        unawaited(updateStyle(item.copyWith(shadow: value))),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('خلفية للنص'),
              value: item.backgroundArgb != null,
              onChanged: disabled
                  ? null
                  : (value) => unawaited(
                      updateStyle(
                        item.copyWith(
                          backgroundArgb: value ? 0xB8000000 : null,
                          clearBackground: !value,
                        ),
                      ),
                    ),
            ),
            if (item.backgroundArgb != null)
              Wrap(
                spacing: 2,
                children: [0xB8000000, 0xB8204268, 0xB86B263C]
                    .map(
                      (color) => IconButton(
                        tooltip: 'اختيار لون الخلفية',
                        onPressed: disabled
                            ? null
                            : () => unawaited(
                                updateStyle(
                                  item.copyWith(backgroundArgb: color),
                                ),
                              ),
                        icon: Icon(Icons.circle, color: Color(color), size: 22),
                      ),
                    )
                    .toList(),
              ),
            Text('سُمك الحد: ${(item.outlineWidthScale * 1000).round()}‰'),
            Slider(
              key: ValueKey('overlay-outline-$id'),
              min: 0,
              max: 0.02,
              divisions: 20,
              value: item.outlineWidthScale.clamp(0, 0.02).toDouble(),
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _textStyleDraft = item.copyWith(
                        outlineWidthScale: value,
                      ),
                    ),
              onChangeEnd: disabled ? null : (_) => commitDraft(),
            ),
            Wrap(
              spacing: 2,
              children: swatches
                  .map(
                    (color) => IconButton(
                      tooltip: 'لون الحد',
                      onPressed: disabled
                          ? null
                          : () => unawaited(
                              updateStyle(item.copyWith(outlineArgb: color)),
                            ),
                      icon: Icon(
                        Icons.circle_outlined,
                        color: Color(color),
                        size: 22,
                      ),
                    ),
                  )
                  .toList(),
            ),
            Text('موضع البداية: ${_formatDuration(startMs)}'),
            Slider(
              key: ValueKey('text-overlay-start-$id'),
              min: 0,
              max: math.max(1, maximumStart).toDouble(),
              divisions: maximumStart > 1
                  ? math.min(100, maximumStart).toInt()
                  : null,
              value: startMs.clamp(0, maximumStart).toDouble(),
              onChanged: disabled || maximumStart == 0
                  ? null
                  : (value) =>
                        setState(() => _textStartDraftMs = value.round()),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_saveTextOverlaySettings(id)),
            ),
            Text('المدة: ${_formatDuration(durationMs)}'),
            Slider(
              key: ValueKey('text-overlay-duration-$id'),
              min: 1,
              max: maximumDuration.toDouble(),
              divisions: maximumDuration > 1
                  ? math.min(100, maximumDuration - 1).toInt()
                  : null,
              value: durationMs.toDouble(),
              onChanged: disabled || maximumDuration <= 1
                  ? null
                  : (value) =>
                        setState(() => _textDurationDraftMs = value.round()),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_saveTextOverlaySettings(id)),
            ),
            Text('الموضع الأفقي: ${(item.positionX * 100).round()}٪'),
            Slider(
              key: ValueKey('text-overlay-x-$id'),
              min: 0,
              max: 1,
              divisions: 100,
              value: item.positionX,
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _textStyleDraft = item.copyWith(positionX: value),
                    ),
              onChangeEnd: disabled ? null : (_) => commitDraft(),
            ),
            Text('الموضع العمودي: ${(item.positionY * 100).round()}٪'),
            Slider(
              key: ValueKey('text-overlay-y-$id'),
              min: 0,
              max: 1,
              divisions: 100,
              value: item.positionY,
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _textStyleDraft = item.copyWith(positionY: value),
                    ),
              onChangeEnd: disabled ? null : (_) => commitDraft(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStickerControls() {
    final id = _selectedStickerOverlayId;
    if (id == null) return const SizedBox.shrink();
    final index = _project.stickerOverlays.indexWhere((item) => item.id == id);
    if (index < 0) return const SizedBox.shrink();
    final saved = _project.stickerOverlays[index];
    final sticker = _stickerDraft ?? saved;
    final mappedStart = _overlayProjectToOutput(saved.startMs);
    final mappedEnd = _overlayProjectToOutput(saved.endMs);
    final requestedDuration =
        _stickerDurationDraftMs ?? math.max(1, mappedEnd - mappedStart);
    final durationMs = requestedDuration
        .clamp(1, math.max(1, _durationMs))
        .toInt();
    final maxStart = math.max(0, _durationMs - durationMs).toInt();
    final startMs = (_stickerStartDraftMs ?? mappedStart)
        .clamp(0, maxStart)
        .toInt();
    final maxDuration = math.max(1, _durationMs - startMs).toInt();
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _configuring ||
        _exportingNavigation;
    void commitSticker() =>
        unawaited(_saveStickerSettings(id, draft: _stickerDraft));

    return Card(
      key: ValueKey('sticker-controls-$id'),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'ملصق: ${sticker.name}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  tooltip: 'حذف الملصق',
                  onPressed: disabled ? null : () => _deleteStickerOverlay(id),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            Text('موضع البداية: ${_formatDuration(startMs)}'),
            Slider(
              key: ValueKey('sticker-start-$id'),
              min: 0,
              max: math.max(1, maxStart).toDouble(),
              divisions: maxStart > 1 ? math.min(100, maxStart).toInt() : null,
              value: startMs.clamp(0, maxStart).toDouble(),
              onChanged: disabled || maxStart == 0
                  ? null
                  : (value) =>
                        setState(() => _stickerStartDraftMs = value.round()),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_saveStickerSettings(id)),
            ),
            Text('المدة: ${_formatDuration(durationMs)}'),
            Slider(
              key: ValueKey('sticker-duration-$id'),
              min: 1,
              max: maxDuration.toDouble(),
              divisions: maxDuration > 1
                  ? math.min(100, maxDuration - 1).toInt()
                  : null,
              value: durationMs.toDouble(),
              onChanged: disabled || maxDuration <= 1
                  ? null
                  : (value) =>
                        setState(() => _stickerDurationDraftMs = value.round()),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_saveStickerSettings(id)),
            ),
            Text('الموضع الأفقي: ${(sticker.positionX * 100).round()}٪'),
            Slider(
              key: ValueKey('sticker-x-$id'),
              min: 0,
              max: 1,
              divisions: 100,
              value: sticker.positionX,
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _stickerDraft = sticker.copyWith(positionX: value),
                    ),
              onChangeEnd: disabled ? null : (_) => commitSticker(),
            ),
            Text('الموضع العمودي: ${(sticker.positionY * 100).round()}٪'),
            Slider(
              key: ValueKey('sticker-y-$id'),
              min: 0,
              max: 1,
              divisions: 100,
              value: sticker.positionY,
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _stickerDraft = sticker.copyWith(positionY: value),
                    ),
              onChangeEnd: disabled ? null : (_) => commitSticker(),
            ),
            Text(
              'الحجم: ${(sticker.widthFraction * 100).round()}٪ من عرض الإطار',
            ),
            Slider(
              key: ValueKey('sticker-size-$id'),
              min: 0.03,
              max: 0.8,
              divisions: 77,
              value: sticker.widthFraction.clamp(0.03, 0.8).toDouble(),
              onChanged: disabled
                  ? null
                  : (value) => setState(
                      () => _stickerDraft = sticker.copyWith(
                        widthFraction: value,
                      ),
                    ),
              onChangeEnd: disabled ? null : (_) => commitSticker(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoOverlayControls() {
    final clip = _selectedOverlayClip();
    if (clip == null) return const SizedBox.shrink();
    final asset = _project.assetById(clip.assetId);
    if (asset == null) return const SizedBox.shrink();
    final mappedStart = _project.videoTrack.isEmpty
        ? clip.timelineStartMs
        : projectTimelineMsToOutputMs(
            _project.videoTrack,
            clip.timelineStartMs,
            transitions: _project.videoTransitions,
          );
    final startMs = (_videoOverlayStartDraftMs ?? mappedStart)
        .clamp(0, math.max(0, _durationMs - 1))
        .toInt();
    final durationMs = (_videoOverlayDurationDraftMs ?? clip.durationMs)
        .clamp(1, math.max(1, asset.durationMs - clip.trimStartMs))
        .toInt();
    final maximumStart = math.max(0, _durationMs - durationMs).toInt();
    final maximumDuration = math
        .max(
          1,
          math.min(asset.durationMs - clip.trimStartMs, _durationMs - startMs),
        )
        .toInt();
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring;
    return Card(
      key: ValueKey('video-overlay-controls-${clip.id}'),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'طبقة الفيديو: ${asset.name}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            Text('البداية في الخط الزمني: ${_formatDuration(startMs)}'),
            Slider(
              key: ValueKey('video-overlay-start-${clip.id}'),
              min: 0,
              max: math.max(1, maximumStart).toDouble(),
              divisions: maximumStart > 1
                  ? math.min(100, maximumStart).toInt()
                  : null,
              value: startMs.clamp(0, maximumStart).toDouble(),
              onChanged: disabled || maximumStart == 0
                  ? null
                  : (value) => setState(
                      () => _videoOverlayStartDraftMs = value.round(),
                    ),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(
                      _saveVideoOverlaySettings(
                        clip.id,
                        outputStartMs: _videoOverlayStartDraftMs,
                      ),
                    ),
            ),
            Text('المدة: ${_formatDuration(durationMs)}'),
            Slider(
              key: ValueKey('video-overlay-duration-${clip.id}'),
              min: 1,
              max: maximumDuration.toDouble(),
              divisions: maximumDuration > 1
                  ? math.min(100, maximumDuration - 1).toInt()
                  : null,
              value: durationMs.clamp(1, maximumDuration).toDouble(),
              onChanged: disabled || maximumDuration <= 1
                  ? null
                  : (value) => setState(
                      () => _videoOverlayDurationDraftMs = value.round(),
                    ),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(
                      _saveVideoOverlaySettings(
                        clip.id,
                        durationMs: _videoOverlayDurationDraftMs,
                      ),
                    ),
            ),
            const Text(
              'تُعرض الطبقة في المعاينة والتصدير، ويُكتم صوت الفيديو الثانوي.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAudioClipControls() {
    final id = _selectedAudioClipId;
    if (id == null) return const SizedBox.shrink();
    final matches = _project.audioTrack.where((clip) => clip.id == id);
    if (matches.length != 1) return const SizedBox.shrink();
    final clip = matches.single;
    final asset = _project.assetById(clip.assetId);
    if (asset == null) return const SizedBox.shrink();
    final mappedStart = _project.videoTrack.isEmpty
        ? clip.timelineStartMs
        : projectTimelineMsToOutputMs(
            _project.videoTrack,
            clip.timelineStartMs,
            transitions: _project.videoTransitions,
          );
    final sourceStartMs = (_audioSourceStartDraftMs ?? clip.trimStartMs)
        .clamp(0, math.max(0, asset.durationMs - 1))
        .toInt();
    final maximumTimelineStart = _durationMs > 0
        ? math.max(0, _durationMs - 1).toInt()
        : 1 << 53;
    var startMs = (_audioStartDraftMs ?? mappedStart)
        .clamp(0, maximumTimelineStart)
        .toInt();
    final availableSourceDuration = math
        .max(1, asset.durationMs - sourceStartMs)
        .toInt();
    var maximumDuration = _durationMs > 0
        ? math
              .max(1, math.min(availableSourceDuration, _durationMs - startMs))
              .toInt()
        : availableSourceDuration;
    var durationMs = (_audioDurationDraftMs ?? clip.durationMs)
        .clamp(1, maximumDuration)
        .toInt();
    final maximumStart = _durationMs > 0
        ? math.max(0, _durationMs - durationMs).toInt()
        : 1 << 53;
    startMs = startMs.clamp(0, maximumStart).toInt();
    maximumDuration = _durationMs > 0
        ? math
              .max(1, math.min(availableSourceDuration, _durationMs - startMs))
              .toInt()
        : availableSourceDuration;
    durationMs = durationMs.clamp(1, maximumDuration).toInt();
    final maximumSourceStart = math
        .max(0, asset.durationMs - durationMs)
        .toInt();
    final volume = (_audioVolumeDraft ?? clip.volume)
        .clamp(0.0, 1.0)
        .toDouble();
    final fadeInMs = (_audioFadeInDraftMs ?? clip.fadeInMs)
        .clamp(0, durationMs)
        .toInt();
    final fadeOutMs = (_audioFadeOutDraftMs ?? clip.fadeOutMs)
        .clamp(0, durationMs)
        .toInt();
    final disabled =
        _projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring;

    void commitAudio() => unawaited(_commitAudioDraft(clip));

    return Card(
      key: ValueKey('audio-clip-controls-${clip.id}'),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تحرير الصوت: ${asset.name}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            Text('موضع البداية: ${_formatDuration(startMs)}'),
            Slider(
              key: ValueKey('audio-timeline-start-${clip.id}'),
              min: 0,
              max: math.max(1, maximumStart).toDouble(),
              divisions: maximumStart > 1
                  ? math.min(100, maximumStart).toInt()
                  : null,
              value: startMs.clamp(0, maximumStart).toDouble(),
              onChanged: disabled || maximumStart == 0
                  ? null
                  : (value) =>
                        setState(() => _audioStartDraftMs = value.round()),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
            Text('بداية المصدر: ${_formatDuration(sourceStartMs)}'),
            Slider(
              key: ValueKey('audio-source-start-${clip.id}'),
              min: 0,
              max: math.max(1, maximumSourceStart).toDouble(),
              divisions: maximumSourceStart > 1
                  ? math.min(100, maximumSourceStart).toInt()
                  : null,
              value: sourceStartMs.clamp(0, maximumSourceStart).toDouble(),
              onChanged: disabled || maximumSourceStart == 0
                  ? null
                  : (value) => setState(
                      () => _audioSourceStartDraftMs = value.round(),
                    ),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
            Text('المدة المصدرية: ${_formatDuration(durationMs)}'),
            Slider(
              key: ValueKey('audio-duration-${clip.id}'),
              min: 1,
              max: maximumDuration.toDouble(),
              divisions: maximumDuration > 1
                  ? math.min(100, maximumDuration - 1).toInt()
                  : null,
              value: durationMs.toDouble(),
              onChanged: disabled || maximumDuration <= 1
                  ? null
                  : (value) =>
                        setState(() => _audioDurationDraftMs = value.round()),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
            Text('مستوى الصوت: ${(volume * 100).round()}٪'),
            Slider(
              key: ValueKey('audio-volume-${clip.id}'),
              min: 0,
              max: 1,
              divisions: 100,
              value: volume,
              onChanged: disabled
                  ? null
                  : (value) => setState(() => _audioVolumeDraft = value),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
            Text('تلاشي تدريجي عند البداية: ${_formatDuration(fadeInMs)}'),
            Slider(
              key: ValueKey('audio-fade-in-${clip.id}'),
              min: 0,
              max: math.max(1, durationMs).toDouble(),
              divisions: durationMs > 1
                  ? math.min(100, durationMs).toInt()
                  : null,
              value: fadeInMs.toDouble(),
              onChanged: disabled || durationMs <= 0
                  ? null
                  : (value) =>
                        setState(() => _audioFadeInDraftMs = value.round()),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
            Text('تلاشي تدريجي عند النهاية: ${_formatDuration(fadeOutMs)}'),
            Slider(
              key: ValueKey('audio-fade-out-${clip.id}'),
              min: 0,
              max: math.max(1, durationMs).toDouble(),
              divisions: durationMs > 1
                  ? math.min(100, durationMs).toInt()
                  : null,
              value: fadeOutMs.toDouble(),
              onChanged: disabled || durationMs <= 0
                  ? null
                  : (value) =>
                        setState(() => _audioFadeOutDraftMs = value.round()),
              onChangeEnd: disabled ? null : (_) => commitAudio(),
            ),
          ],
        ),
      ),
    );
  }

  List<SpeedRampPoint> _displaySpeedRampPoints(TimelineClip clip) {
    if (_speedDraftClipId == clip.id && _speedDraftPoints != null) {
      return _speedDraftPoints!;
    }
    return clip.speedRampPoints;
  }

  List<SpeedRampPoint> _visibleSpeedCurvePoints(
    TimelineClip clip,
    List<SpeedRampPoint> points,
  ) {
    final normalized = speedRampPointsForSourceDuration(
      points,
      clip.durationMs,
    );
    return [
      SpeedRampPoint(
        timeMs: clip.trimStartMs,
        speed: speedAtSourceTime(normalized, clip.trimStartMs),
      ),
      ...normalized.where(
        (point) =>
            point.timeMs > clip.trimStartMs && point.timeMs < clip.trimEndMs,
      ),
      SpeedRampPoint(
        timeMs: clip.trimEndMs,
        speed: speedAtSourceTime(normalized, clip.trimEndMs),
      ),
    ];
  }

  List<SpeedRampPoint> _mergeVisibleSpeedCurve(
    TimelineClip clip,
    List<SpeedRampPoint> basePoints,
    List<SpeedRampPoint> visiblePoints,
  ) {
    final outside = normalizeSpeedRampPoints(basePoints).where(
      (point) =>
          point.timeMs < clip.trimStartMs || point.timeMs > clip.trimEndMs,
    );
    return normalizeSpeedRampPoints([...outside, ...visiblePoints]);
  }

  String _speedProfile(List<SpeedRampPoint> visiblePoints) {
    final normalized = normalizeSpeedRampPoints(visiblePoints);
    if (normalized.isEmpty || normalized.every((point) => point.speed == 1)) {
      return 'normal';
    }
    if (normalized.every((point) => point.speed == normalized.first.speed)) {
      return 'constant';
    }
    final preset = speedPresetForPoints(normalized);
    return const {'accelerate', 'decelerate', 'slow_fast_slow'}.contains(preset)
        ? preset
        : 'custom';
  }

  TimelinePosition? _playheadPositionForClip(TimelineClip clip) {
    final position = timelinePositionAt(
      _project.videoTrack,
      _positionMs,
      transitions: _project.videoTransitions,
    );
    return position?.clipId == clip.id ? position : null;
  }

  List<ClipTransformKeyframe> _visibleTransformKeyframes(TimelineClip clip) =>
      normalizeTransformKeyframes(clip.transformKeyframes)
          .where(
            (frame) =>
                frame.timeMs >= clip.trimStartMs &&
                frame.timeMs <= clip.trimEndMs,
          )
          .toList(growable: false);

  ClipTransformKeyframe? _selectedTransformKeyframe(TimelineClip clip) {
    final frames = _visibleTransformKeyframes(clip);
    for (final frame in frames) {
      if (frame.timeMs == _selectedTransformKeyframeTimeMs) return frame;
    }
    return frames.isEmpty ? null : frames.first;
  }

  Future<void> _addTransformKeyframeAtPlayhead(TimelineClip clip) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final position = _playheadPositionForClip(clip);
    if (position == null) return;
    final frames = normalizeTransformKeyframes(clip.transformKeyframes);
    final existing = frames.where(
      (frame) => frame.timeMs == position.sourcePositionMs,
    );
    if (existing.isNotEmpty) {
      setState(() {
        _selectedTransformKeyframeTimeMs = position.sourcePositionMs;
        _transformKeyframeDraft = null;
      });
      return;
    }
    final value = evaluateTransformKeyframes(frames, position.sourcePositionMs);
    final added = ClipTransformKeyframe(
      timeMs: position.sourcePositionMs,
      positionX: value.positionX,
      positionY: value.positionY,
      scale: value.scale,
      rotationDegrees: value.rotationDegrees,
      opacity: value.opacity,
      interpolation: MotionInterpolation.smooth,
    );
    final updatedFrames = normalizeTransformKeyframes([...frames, added]);
    final videoTrack = List<TimelineClip>.of(_project.videoTrack);
    final index = videoTrack.indexWhere((item) => item.id == clip.id);
    if (index < 0) return;
    videoTrack[index] = clip.copyWith(transformKeyframes: updatedFrames);
    setState(() {
      _selectedTransformKeyframeTimeMs = added.timeMs;
      _transformKeyframeDraft = null;
    });
    await _commitMultitrackProject(_project.copyWith(videoTrack: videoTrack));
  }

  void _selectTransformKeyframe(int? timeMs) {
    setState(() {
      _selectedTransformKeyframeTimeMs = timeMs;
      _transformKeyframeDraft = null;
    });
  }

  Future<void> _replaceTransformKeyframe(
    TimelineClip clip,
    int originalTimeMs,
    ClipTransformKeyframe replacement,
  ) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final frames = normalizeTransformKeyframes(clip.transformKeyframes);
    final index = frames.indexWhere((frame) => frame.timeMs == originalTimeMs);
    if (index < 0) return;
    if (frames.asMap().entries.any(
      (entry) => entry.key != index && entry.value.timeMs == replacement.timeMs,
    )) {
      return;
    }
    final updatedFrames = List<ClipTransformKeyframe>.of(frames)
      ..[index] = replacement;
    final videoTrack = List<TimelineClip>.of(_project.videoTrack);
    final clipIndex = videoTrack.indexWhere((item) => item.id == clip.id);
    if (clipIndex < 0) return;
    videoTrack[clipIndex] = clip.copyWith(
      transformKeyframes: normalizeTransformKeyframes(updatedFrames),
    );
    setState(() {
      _selectedTransformKeyframeTimeMs = replacement.timeMs;
      _transformKeyframeDraft = null;
    });
    await _commitMultitrackProject(_project.copyWith(videoTrack: videoTrack));
  }

  Future<void> _editTransformKeyframeTime(
    TimelineClip clip,
    ClipTransformKeyframe frame,
  ) async {
    final controller = _keyframeTimeController..text = frame.timeMs.toString();
    String? validationMessage;
    final nextTimeMs = await showDialog<int>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: const Text('تعديل موضع الإطار المفتاحي'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('أدخل زمن المصدر بالمللي ثانية ضمن حدود المقطع.'),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                autofocus: true,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'زمن المصدر (مللي ثانية)',
                  errorText: validationMessage,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                final value = int.tryParse(controller.text.trim());
                if (value == null ||
                    value < clip.trimStartMs ||
                    value > clip.trimEndMs) {
                  setDialogState(
                    () => validationMessage =
                        'أدخل وقتًا بين ${clip.trimStartMs} و${clip.trimEndMs} مللي ثانية.',
                  );
                  return;
                }
                final collision =
                    normalizeTransformKeyframes(clip.transformKeyframes).any(
                      (other) =>
                          other.timeMs == value && other.timeMs != frame.timeMs,
                    );
                if (collision) {
                  setDialogState(
                    () => validationMessage =
                        'يوجد إطار مفتاحي آخر عند هذا الوقت.',
                  );
                  return;
                }
                Navigator.pop(dialogContext, value);
              },
              child: const Text('تطبيق'),
            ),
          ],
        ),
      ),
    );
    if (!mounted || nextTimeMs == null || nextTimeMs == frame.timeMs) return;
    await _replaceTransformKeyframe(
      clip,
      frame.timeMs,
      frame.copyWith(timeMs: nextTimeMs),
    );
  }

  Future<void> _deleteTransformKeyframe(
    TimelineClip clip,
    ClipTransformKeyframe frame,
  ) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final frames = List<ClipTransformKeyframe>.of(
      normalizeTransformKeyframes(clip.transformKeyframes),
    )..removeWhere((item) => item.timeMs == frame.timeMs);
    final remainingVisibleFrames = frames
        .where(
          (item) =>
              item.timeMs >= clip.trimStartMs && item.timeMs <= clip.trimEndMs,
        )
        .toList(growable: false);
    final videoTrack = List<TimelineClip>.of(_project.videoTrack);
    final index = videoTrack.indexWhere((item) => item.id == clip.id);
    if (index < 0) return;
    videoTrack[index] = clip.copyWith(transformKeyframes: frames);
    setState(() {
      _selectedTransformKeyframeTimeMs = remainingVisibleFrames.isEmpty
          ? null
          : remainingVisibleFrames.first.timeMs;
      _transformKeyframeDraft = null;
    });
    await _commitMultitrackProject(_project.copyWith(videoTrack: videoTrack));
  }

  Widget _buildTransformKeyframeSlider({
    required String key,
    required String label,
    required String valueLabel,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required bool disabled,
    required ValueChanged<double> onChanged,
    required ValueChanged<double> onChangeEnd,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Expanded(child: Text(label)),
          Text(valueLabel, textDirection: TextDirection.ltr),
        ],
      ),
      Slider(
        key: ValueKey(key),
        min: min,
        max: max,
        divisions: divisions,
        value: value.clamp(min, max).toDouble(),
        onChanged: disabled ? null : onChanged,
        onChangeEnd: disabled ? null : onChangeEnd,
      ),
    ],
  );

  Widget _buildClipTransformKeyframeControls(TimelineClip clip, bool disabled) {
    final frames = _visibleTransformKeyframes(clip);
    final frame = _selectedTransformKeyframe(clip);
    final draft =
        frame != null && _transformKeyframeDraft?.timeMs == frame.timeMs
        ? _transformKeyframeDraft!
        : frame;
    final playheadPosition = _playheadPositionForClip(clip);
    final canEdit =
        !disabled &&
        !_projectOperationInProgress &&
        !_saving &&
        !_exportingNavigation &&
        !_configuring;

    Widget editSlider({
      required String name,
      required String label,
      required double value,
      required double min,
      required double max,
      required int divisions,
      required String formatted,
      required ClipTransformKeyframe Function(double) update,
    }) => _buildTransformKeyframeSlider(
      key: 'transform-keyframe-$name-${clip.id}-${frame!.timeMs}',
      label: label,
      valueLabel: formatted,
      value: value,
      min: min,
      max: max,
      divisions: divisions,
      disabled: !canEdit,
      onChanged: (next) =>
          setState(() => _transformKeyframeDraft = update(next)),
      onChangeEnd: (next) => unawaited(
        _replaceTransformKeyframe(clip, frame.timeMs, update(next)),
      ),
    );

    return Container(
      key: ValueKey('clip-transform-keyframes-${clip.id}'),
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.key, size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'الإطارات المفتاحية للتحويل',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            playheadPosition == null
                ? 'حرّك موضع التشغيل إلى المقطع المحدد لإضافة إطار عند زمن المصدر.'
                : 'موضع التشغيل في المصدر: ${_formatDuration(playheadPosition.sourcePositionMs)}',
          ),
          const SizedBox(height: 6),
          OutlinedButton.icon(
            key: ValueKey('add-transform-keyframe-${clip.id}'),
            onPressed: canEdit && playheadPosition != null
                ? () => unawaited(_addTransformKeyframeAtPlayhead(clip))
                : null,
            icon: const Icon(Icons.add),
            label: const Text('إضافة إطار عند موضع التشغيل'),
          ),
          if (frames.isEmpty)
            const Text(
              'لا توجد إطارات؛ أضف إطارًا ثم غيّر موضعًا أو حجمًا أو دورانًا.',
            ),
          if (frame != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButton<int>(
                    key: ValueKey('transform-keyframe-select-${clip.id}'),
                    isExpanded: true,
                    value: frame.timeMs,
                    items: frames
                        .map(
                          (item) => DropdownMenuItem<int>(
                            value: item.timeMs,
                            child: Text(
                              'إطار · ${_formatDuration(item.timeMs)} من المصدر',
                            ),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: canEdit ? _selectTransformKeyframe : null,
                  ),
                ),
                IconButton(
                  key: ValueKey('edit-transform-keyframe-time-${clip.id}'),
                  tooltip: 'تعديل موضع الإطار المفتاحي',
                  onPressed: canEdit
                      ? () => _editTransformKeyframeTime(clip, frame)
                      : null,
                  icon: const Icon(Icons.schedule),
                ),
                IconButton(
                  key: ValueKey('delete-transform-keyframe-${clip.id}'),
                  tooltip: 'حذف الإطار المفتاحي',
                  onPressed: canEdit
                      ? () => _deleteTransformKeyframe(clip, frame)
                      : null,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            const Text(
              'الموضع نسبي إلى إطار الفيديو؛ 0 في الوسط و±1 حتى الحافة.',
            ),
            editSlider(
              name: 'x',
              label: 'الموضع الأفقي',
              value: draft!.positionX,
              min: -1,
              max: 1,
              divisions: 200,
              formatted: draft!.positionX.toStringAsFixed(2),
              update: (value) => frame.copyWith(positionX: value),
            ),
            editSlider(
              name: 'y',
              label: 'الموضع العمودي',
              value: draft!.positionY,
              min: -1,
              max: 1,
              divisions: 200,
              formatted: draft!.positionY.toStringAsFixed(2),
              update: (value) => frame.copyWith(positionY: value),
            ),
            editSlider(
              name: 'scale',
              label: 'الحجم',
              value: draft!.scale,
              min: 0.05,
              max: 10,
              divisions: 199,
              formatted: '${draft!.scale.toStringAsFixed(2)}×',
              update: (value) => frame.copyWith(scale: value),
            ),
            editSlider(
              name: 'rotation',
              label: 'الدوران',
              value: draft!.rotationDegrees,
              min: -3600,
              max: 3600,
              divisions: 7200,
              formatted: '${draft!.rotationDegrees.toStringAsFixed(0)}°',
              update: (value) => frame.copyWith(rotationDegrees: value),
            ),
            editSlider(
              name: 'opacity',
              label: 'العتامة',
              value: draft!.opacity,
              min: 0,
              max: 1,
              divisions: 100,
              formatted: '${(draft!.opacity * 100).round()}٪',
              update: (value) => frame.copyWith(opacity: value),
            ),
            DropdownButton<MotionInterpolation>(
              key: ValueKey('transform-keyframe-interpolation-${clip.id}'),
              isExpanded: true,
              value: frame.interpolation,
              items: const [
                DropdownMenuItem(
                  value: MotionInterpolation.smooth,
                  child: Text('استيفاء ناعم'),
                ),
                DropdownMenuItem(
                  value: MotionInterpolation.linear,
                  child: Text('استيفاء خطي'),
                ),
              ],
              onChanged: !canEdit || frame == null
                  ? null
                  : (value) {
                      if (value != null) {
                        unawaited(
                          _replaceTransformKeyframe(
                            clip,
                            frame.timeMs,
                            frame.copyWith(interpolation: value),
                          ),
                        );
                      }
                    },
            ),
          ],
        ],
      ),
    );
  }

  double _maximumSpeedForClip(TimelineClip clip) =>
      maxSpeedMultiplierForSourceDurationMs(clip.durationMs);

  int _speedSliderDivisionsForClip(TimelineClip clip) =>
      ((_maximumSpeedForClip(clip) - minSpeedMultiplier) * 10)
          .round()
          .clamp(1, 999)
          .toInt();

  double _constantClipSpeed(TimelineClip clip, List<SpeedRampPoint> points) =>
      speedAtSourceTime(
        points,
        clip.trimStartMs,
      ).clamp(minSpeedMultiplier, _maximumSpeedForClip(clip)).toDouble();

  Widget _buildClipSpeedControls(TimelineClip clip, bool disabled) {
    final allPoints = _displaySpeedRampPoints(clip);
    final visiblePoints = _visibleSpeedCurvePoints(clip, allPoints);
    final detectedProfile = _speedProfile(visiblePoints);
    final profile = _expandedSpeedCurveClipId == clip.id
        ? 'custom'
        : _constantSpeedControlClipId == clip.id
        ? 'constant'
        : detectedProfile;
    final speedDraftActive =
        _speedDraftClipId == clip.id && _speedDraftPoints != null;
    final curveDraftActive = speedDraftActive && _speedDraftIsCurve;
    final constantDraftActive = speedDraftActive && !_speedDraftIsCurve;
    final showCurveEditor =
        (profile != 'normal' && profile != 'constant') || curveDraftActive;
    final showConstantSlider =
        (profile == 'constant' && !showCurveEditor) || constantDraftActive;
    final constantSpeed = _constantClipSpeed(clip, allPoints);
    final effectiveDurationMs = speedAdjustedDurationMs(
      clip.trimStartMs,
      clip.trimEndMs,
      allPoints,
    );
    const profiles = <String, String>{
      'normal': 'عادي · 1×',
      'constant': 'ثابتة',
      'accelerate': 'تسارع · 0.5× إلى 2×',
      'decelerate': 'تباطؤ · 2× إلى 0.5×',
      'slow_fast_slow': 'بطيء إلى سريع إلى بطيء',
      'custom': 'منحنى مخصص',
    };

    return Container(
      key: ValueKey('clip-speed-controls-${clip.id}'),
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.speed, size: 20),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'السرعة ومنحناها',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          DropdownButton<String>(
            key: ValueKey('clip-speed-mode-${clip.id}'),
            value: profile,
            isExpanded: true,
            items: profiles.entries
                .map(
                  (entry) => DropdownMenuItem<String>(
                    value: entry.key,
                    child: Text(entry.value),
                  ),
                )
                .toList(growable: false),
            onChanged: disabled
                ? null
                : (value) {
                    if (value != null) {
                      unawaited(_applySpeedProfile(clip, value));
                    }
                  },
          ),
          if (showConstantSlider) ...[
            Text('السرعة الثابتة: ${constantSpeed.toStringAsFixed(1)}×'),
            Slider(
              key: ValueKey('clip-speed-constant-${clip.id}'),
              min: minSpeedMultiplier,
              max: _maximumSpeedForClip(clip),
              divisions: _speedSliderDivisionsForClip(clip),
              value: constantSpeed,
              onChanged: disabled
                  ? null
                  : (value) => _updateConstantSpeedDraft(clip, value),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_commitSpeedDraft(clip)),
            ),
          ],
          if (showCurveEditor) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                const Expanded(child: Text('نقاط المنحنى')),
                IconButton(
                  key: ValueKey('clip-speed-add-point-${clip.id}'),
                  tooltip: 'إضافة نقطة للمنحنى',
                  onPressed: disabled
                      ? null
                      : () => unawaited(_addSpeedCurvePoint(clip)),
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
            for (var index = 0; index < visiblePoints.length; index++)
              _buildSpeedCurvePointControl(
                clip,
                visiblePoints,
                index,
                disabled,
              ),
          ],
          Text(
            'المدة بعد السرعة: ${_formatDuration(effectiveDurationMs)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          Text(
            'النطاق: 0.1× إلى ${_maximumSpeedForClip(clip).toStringAsFixed(1)}×؛ يُخفض الحد تلقائيًا للمقاطع القصيرة لضمان مدة قابلة للتمثيل.',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildSpeedCurvePointControl(
    TimelineClip clip,
    List<SpeedRampPoint> visiblePoints,
    int index,
    bool disabled,
  ) {
    final point = visiblePoints[index];
    final isEndpoint = index == 0 || index == visiblePoints.length - 1;
    final left = index > 0 ? visiblePoints[index - 1] : point;
    final right = index < visiblePoints.length - 1
        ? visiblePoints[index + 1]
        : point;
    final canMove = !isEndpoint && right.timeMs - left.timeMs > 2;
    return Padding(
      key: ValueKey('clip-speed-point-${clip.id}-$index'),
      padding: const EdgeInsets.only(bottom: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${isEndpoint ? 'حد المقطع' : 'نقطة'} · ${_formatDuration(point.timeMs)} · ${point.speed.toStringAsFixed(2)}×',
                ),
              ),
              if (!isEndpoint)
                IconButton(
                  key: ValueKey('clip-speed-remove-point-${clip.id}-$index'),
                  tooltip: 'حذف نقطة المنحنى',
                  visualDensity: VisualDensity.compact,
                  onPressed: disabled
                      ? null
                      : () => unawaited(
                          _removeSpeedCurvePoint(clip, visiblePoints, index),
                        ),
                  icon: const Icon(Icons.remove_circle_outline, size: 20),
                ),
            ],
          ),
          if (canMove)
            Slider(
              key: ValueKey('clip-speed-point-time-${clip.id}-$index'),
              min: (left.timeMs + 1).toDouble(),
              max: (right.timeMs - 1).toDouble(),
              divisions: (right.timeMs - left.timeMs - 2).clamp(1, 100).toInt(),
              value: point.timeMs.toDouble(),
              label: _formatDuration(point.timeMs),
              onChanged: disabled
                  ? null
                  : (value) => _updateSpeedCurvePoint(
                      clip,
                      visiblePoints,
                      index,
                      timeMs: value.round(),
                    ),
              onChangeEnd: disabled
                  ? null
                  : (_) => unawaited(_commitSpeedDraft(clip)),
            ),
          Text('السرعة عند النقطة: ${point.speed.toStringAsFixed(2)}×'),
          Slider(
            key: ValueKey('clip-speed-point-speed-${clip.id}-$index'),
            min: minSpeedMultiplier,
            max: _maximumSpeedForClip(clip),
            divisions: _speedSliderDivisionsForClip(clip),
            value: point.speed
                .clamp(minSpeedMultiplier, _maximumSpeedForClip(clip))
                .toDouble(),
            onChanged: disabled
                ? null
                : (value) => _updateSpeedCurvePoint(
                    clip,
                    visiblePoints,
                    index,
                    speed: value,
                  ),
            onChangeEnd: disabled
                ? null
                : (_) => unawaited(_commitSpeedDraft(clip)),
          ),
        ],
      ),
    );
  }

  void _updateConstantSpeedDraft(TimelineClip clip, double speed) {
    final requested = speed
        .clamp(minSpeedMultiplier, _maximumSpeedForClip(clip))
        .toDouble();
    _setSpeedDraft(
      clip,
      (requested - 1).abs() < 0.000001
          ? const []
          : [SpeedRampPoint(timeMs: clip.trimStartMs, speed: requested)],
      isCurve: false,
    );
  }

  void _updateSpeedCurvePoint(
    TimelineClip clip,
    List<SpeedRampPoint> visiblePoints,
    int index, {
    int? timeMs,
    double? speed,
  }) {
    final updatedVisible = List<SpeedRampPoint>.of(visiblePoints);
    updatedVisible[index] = updatedVisible[index].copyWith(
      timeMs: timeMs,
      speed: speed == null
          ? null
          : speed
                .clamp(minSpeedMultiplier, _maximumSpeedForClip(clip))
                .toDouble(),
    );
    _setSpeedDraft(clip, updatedVisible);
  }

  void _setSpeedDraft(
    TimelineClip clip,
    List<SpeedRampPoint> visiblePoints, {
    bool isCurve = true,
  }) {
    final base = _displaySpeedRampPoints(clip);
    final merged = _mergeVisibleSpeedCurve(clip, base, visiblePoints);
    setState(() {
      _speedDraftClipId = clip.id;
      _speedDraftPoints = merged;
      _speedDraftIsCurve = isCurve;
    });
  }

  Future<void> _commitSpeedDraft(TimelineClip clip) async {
    if (_speedDraftClipId != clip.id || _speedDraftPoints == null) return;
    await _saveClipSpeedRamp(clip, _speedDraftPoints!);
  }

  Future<void> _applySpeedProfile(TimelineClip clip, String profile) async {
    final current = _displaySpeedRampPoints(clip);
    final visible = _visibleSpeedCurvePoints(clip, current);
    List<SpeedRampPoint> requested;
    switch (profile) {
      case 'normal':
        requested = const [];
        break;
      case 'constant':
        final speed = _constantClipSpeed(clip, current);
        requested = (speed - 1).abs() < 0.000001
            ? const []
            : [SpeedRampPoint(timeMs: clip.trimStartMs, speed: speed)];
        break;
      case 'accelerate':
      case 'decelerate':
      case 'slow_fast_slow':
        requested = speedPresetPoints(
          clip.trimStartMs,
          clip.trimEndMs,
          profile,
        );
        break;
      case 'custom':
        requested = _mergeVisibleSpeedCurve(clip, current, visible);
        break;
      default:
        return;
    }
    setState(() {
      _expandedSpeedCurveClipId = profile == 'custom' ? clip.id : null;
      _constantSpeedControlClipId = profile == 'constant' ? clip.id : null;
    });
    await _saveClipSpeedRamp(clip, requested);
  }

  Future<void> _addSpeedCurvePoint(TimelineClip clip) async {
    final base = _displaySpeedRampPoints(clip);
    final visible = _visibleSpeedCurvePoints(clip, base);
    var widestIndex = -1;
    var widestGap = 1;
    for (var index = 0; index < visible.length - 1; index++) {
      final gap = visible[index + 1].timeMs - visible[index].timeMs;
      if (gap > widestGap) {
        widestGap = gap;
        widestIndex = index;
      }
    }
    if (widestIndex < 0) return;
    final left = visible[widestIndex];
    final right = visible[widestIndex + 1];
    final timeMs = left.timeMs + (right.timeMs - left.timeMs) ~/ 2;
    final updatedVisible = [...visible]
      ..insert(
        widestIndex + 1,
        SpeedRampPoint(
          timeMs: timeMs,
          speed: speedAtSourceTime(visible, timeMs),
        ),
      );
    await _saveClipSpeedRamp(
      clip,
      _mergeVisibleSpeedCurve(clip, base, updatedVisible),
    );
  }

  Future<void> _removeSpeedCurvePoint(
    TimelineClip clip,
    List<SpeedRampPoint> visible,
    int index,
  ) async {
    if (index <= 0 || index >= visible.length - 1) return;
    final updatedVisible = [...visible]..removeAt(index);
    final base = _displaySpeedRampPoints(clip);
    await _saveClipSpeedRamp(
      clip,
      _mergeVisibleSpeedCurve(clip, base, updatedVisible),
    );
  }

  Future<void> _saveClipSpeedRamp(
    TimelineClip clip,
    List<SpeedRampPoint> requestedPoints,
  ) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final result = updateVideoClipSpeedRampSafely(
      videoTrack: _project.videoTrack,
      transitions: _project.videoTransitions,
      clipId: clip.id,
      speedRampPoints: requestedPoints,
    );
    if (!result.accepted) {
      setState(() {
        _speedDraftClipId = null;
        _speedDraftPoints = null;
        _speedDraftIsCurve = false;
        _error = result.rejectionReason ?? 'رُفض تعديل منحنى السرعة.';
      });
      return;
    }
    if (!result.changed) {
      setState(() {
        _speedDraftClipId = null;
        _speedDraftPoints = null;
        _speedDraftIsCurve = false;
      });
      return;
    }

    final updatedProject = _project.copyWith(videoTrack: result.track!);
    final updatedDurationMs = visualTimelineDurationMs(
      updatedProject.videoTrack,
      transitions: updatedProject.videoTransitions,
    );
    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _speedDraftClipId = null;
      _speedDraftPoints = null;
      _speedDraftIsCurve = false;
      _durationMs = updatedDurationMs;
      _positionMs = _positionMs.clamp(0, updatedDurationMs).toInt();
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange();
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  VideoColorSettings _displayColorSettings(TimelineClip clip) {
    if (_colorDraftClipId == clip.id && _colorDraftSettings != null) {
      return _colorDraftSettings!;
    }
    return clip.effectiveColorSettings(_project.colorSettings);
  }

  void _updateColorDraft(TimelineClip clip, VideoColorSettings settings) {
    setState(() {
      _colorDraftClipId = clip.id;
      _colorDraftSettings = settings;
    });
  }

  Future<void> _commitColorDraft(TimelineClip clip) async {
    if (_colorDraftClipId != clip.id || _colorDraftSettings == null) return;
    await _saveClipColorOverride(clip, _colorDraftSettings);
  }

  Future<void> _resetClipColorOverride(TimelineClip clip) async {
    await _saveClipColorOverride(clip, null);
  }

  Future<void> _saveClipColorOverride(
    TimelineClip clip,
    VideoColorSettings? requestedSettings,
  ) async {
    if (_projectOperationInProgress ||
        _saving ||
        _exportingNavigation ||
        _configuring) {
      return;
    }
    final clipIndex = _project.videoTrack.indexWhere(
      (item) => item.id == clip.id,
    );
    if (clipIndex < 0) return;
    final currentClip = _project.videoTrack[clipIndex];
    final nextOverride =
        requestedSettings == null || requestedSettings == _project.colorSettings
        ? null
        : requestedSettings;
    if (currentClip.colorSettingsOverride == nextOverride) {
      setState(() {
        _colorDraftClipId = null;
        _colorDraftSettings = null;
      });
      return;
    }

    final updatedClip = nextOverride == null
        ? currentClip.copyWith(clearColorSettingsOverride: true)
        : currentClip.copyWith(colorSettingsOverride: nextOverride);
    final updatedTrack = List<TimelineClip>.of(_project.videoTrack)
      ..[clipIndex] = updatedClip;
    final updatedProject = _project.copyWith(videoTrack: updatedTrack);
    final updatedDurationMs = visualTimelineDurationMs(
      updatedTrack,
      transitions: updatedProject.videoTransitions,
    );

    _history.record(updatedProject);
    setState(() {
      _project = updatedProject;
      _colorDraftClipId = null;
      _colorDraftSettings = null;
      _durationMs = updatedDurationMs;
      _positionMs = _positionMs.clamp(0, updatedDurationMs).toInt();
      _projectOperationInProgress = true;
      _error = null;
    });
    try {
      await _saveEditedProject(updatedProject);
      await _reconfigurePreviewAfterProjectChange();
    } finally {
      if (mounted) setState(() => _projectOperationInProgress = false);
    }
  }

  Widget _buildClipColorControls(TimelineClip clip, bool disabled) {
    final settings = _displayColorSettings(clip);
    final hasOverride =
        clip.colorSettingsOverride != null ||
        (_colorDraftClipId == clip.id && _colorDraftSettings != null);
    return Padding(
      key: ValueKey('clip-color-controls-${clip.id}'),
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'تصحيح الألوان',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              TextButton(
                key: ValueKey('clip-color-reset-${clip.id}'),
                onPressed: disabled || !hasOverride
                    ? null
                    : () => unawaited(_resetClipColorOverride(clip)),
                child: const Text('إعادة ضبط'),
              ),
            ],
          ),
          if (clip.colorSettingsOverride == null &&
              _colorDraftClipId != clip.id)
            const Text(
              'تُستخدم إعدادات اللون العامة للمشروع.',
              style: TextStyle(fontSize: 12, color: Color(0xFFAFBAC5)),
            ),
          const SizedBox(height: 8),
          const Text(
            'فلاتر جاهزة · قابلة للتعديل',
            style: TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 4),
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              for (final preset in videoFilterPresets)
                ChoiceChip(
                  key: ValueKey('video-filter-${preset.id}-${clip.id}'),
                  label: Text(preset.name),
                  tooltip: preset.description,
                  selected: settings == preset.settings,
                  onSelected: disabled
                      ? null
                      : (selected) {
                          if (selected) {
                            unawaited(
                              _saveClipColorOverride(clip, preset.settings),
                            );
                          }
                        },
                ),
            ],
          ),
          _buildColorSlider(
            clip: clip,
            disabled: disabled,
            keyName: 'brightness',
            label: 'السطوع',
            value: settings.brightness,
            minimum: -1,
            maximum: 1,
            divisions: 100,
            valueText: settings.brightness.toStringAsFixed(2),
            update: (value) => settings.copyWith(brightness: value),
          ),
          _buildColorSlider(
            clip: clip,
            disabled: disabled,
            keyName: 'contrast',
            label: 'التباين',
            value: settings.contrast,
            minimum: -1,
            maximum: 1,
            divisions: 100,
            valueText: settings.contrast.toStringAsFixed(2),
            update: (value) => settings.copyWith(contrast: value),
          ),
          _buildColorSlider(
            clip: clip,
            disabled: disabled,
            keyName: 'saturation',
            label: 'التشبّع',
            value: settings.saturation,
            minimum: -100,
            maximum: 100,
            divisions: 200,
            valueText: settings.saturation.toStringAsFixed(0),
            update: (value) => settings.copyWith(saturation: value),
          ),
          _buildColorSlider(
            clip: clip,
            disabled: disabled,
            keyName: 'warmth',
            label: 'دفء اللون',
            value: settings.warmth,
            minimum: -1,
            maximum: 1,
            divisions: 100,
            valueText: settings.warmth.toStringAsFixed(2),
            update: (value) => settings.copyWith(warmth: value),
          ),
        ],
      ),
    );
  }

  Widget _buildColorSlider({
    required TimelineClip clip,
    required bool disabled,
    required String keyName,
    required String label,
    required double value,
    required double minimum,
    required double maximum,
    required int divisions,
    required String valueText,
    required VideoColorSettings Function(double value) update,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Expanded(child: Text(label)),
          Text(
            valueText,
            key: ValueKey('clip-color-value-$keyName-${clip.id}'),
          ),
        ],
      ),
      Slider(
        key: ValueKey('clip-color-slider-$keyName-${clip.id}'),
        min: minimum,
        max: maximum,
        divisions: divisions,
        value: value.clamp(minimum, maximum).toDouble(),
        onChanged: disabled
            ? null
            : (nextValue) => _updateColorDraft(clip, update(nextValue)),
        onChangeEnd: disabled
            ? null
            : (_) => unawaited(_commitColorDraft(clip)),
      ),
    ],
  );

  String _formatSecondsInput(int milliseconds) {
    final safeMs = milliseconds.clamp(0, 1 << 53).toInt();
    return '${safeMs ~/ 1000}.${(safeMs % 1000).toString().padLeft(3, '0')}';
  }

  Widget _buildPreview() {
    if (!_isAndroid) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('معاينة الخط الزمني متاحة حاليًا على Android فقط.'),
        ),
      );
    }
    if (!_hasVisualTrack) {
      return const Center(child: Text('أضف مقطعًا مرئيًا لعرض المعاينة.'));
    }
    return const AndroidView(
      viewType: 'velora/preview',
      creationParams: <String, Object>{'timelineMode': true},
      creationParamsCodec: StandardMessageCodec(),
    );
  }
}

String _formatDuration(int milliseconds) {
  final safeMs = milliseconds.clamp(0, 1 << 53).toInt();
  final totalSeconds = safeMs ~/ 1000;
  final minutes = totalSeconds ~/ 60;
  final seconds = totalSeconds % 60;
  final millisecondPart = safeMs % 1000;
  return '${minutes.toString().padLeft(2, '0')}:'
      '${seconds.toString().padLeft(2, '0')}.'
      '${millisecondPart.toString().padLeft(3, '0')}';
}
