package com.velora.app

import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import java.util.UUID

@UnstableApi
internal data class TimedVideoLayer(
    val id: String,
    val asset: Map<String, Any?>,
    val sourceStartMs: Long,
    val sourceEndMs: Long,
    val timelineStartMs: Long,
    val timelineEndMs: Long,
    val positionX: Float,
    val positionY: Float,
    val widthFraction: Float,
    val heightFraction: Float,
) {
    val durationMs: Long get() = timelineEndMs - timelineStartMs

    fun overlaySettings(timeUs: Long): OverlaySettings {
        val timeMs = timeUs.coerceAtLeast(0L) / 1_000L
        if (timeMs < timelineStartMs || timeMs >= timelineEndMs) {
            return StaticOverlaySettings.Builder().setAlphaScale(0f).build()
        }
        return StaticOverlaySettings.Builder()
            .setScale(widthFraction, heightFraction)
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(positionX * 2f - 1f, 1f - positionY * 2f)
            .build()
    }
}

@UnstableApi
internal data class VideoLayerSequence(
    val trackId: String,
    val clips: List<TimedVideoLayer>,
    val sequence: EditedMediaItemSequence,
)

@UnstableApi
internal data class ProjectVideoLayerPlan(
    /** PIP sequences must precede the main sequence in Media3's compositor input order. */
    val overlaySequences: List<VideoLayerSequence>,
    val mainVideoInputId: Int,
    val compositorSettings: VideoCompositorSettings?,
) {
    fun settingsForInput(inputId: Int, timeUs: Long): OverlaySettings {
        if (inputId == mainVideoInputId) return StaticOverlaySettings.Builder().build()
        return overlaySequences.getOrNull(inputId)?.clips
            ?.firstOrNull { timeUs >= it.timelineStartMs * 1_000L && timeUs < it.timelineEndMs * 1_000L }
            ?.overlaySettings(timeUs)
            ?: StaticOverlaySettings.Builder().setAlphaScale(0f).build()
    }
}

@UnstableApi
internal object ProjectVideoLayers {
    /** Creates one silent video sequence per non-overlapping interval lane. */
    fun create(
        project: Map<*, *>,
        assets: Map<String, Map<String, Any?>>,
        totalDurationMs: Long,
        frameSettings: ProjectFrameSettings,
        outputHeight: Int,
        colorSettings: ProjectColorSettings = ProjectColorSettings(),
        sourceTimelineDurationMs: Long = totalDurationMs,
        timelineMapper: (Long) -> Long = { it },
    ): ProjectVideoLayerPlan {
        if (totalDurationMs <= 0L) {
            return ProjectVideoLayerPlan(emptyList(), 0, null)
        }

        val sequences = mutableListOf<VideoLayerSequence>()
        val tracks = project["videoOverlayTracks"] as? List<*> ?: emptyList<Any?>()
        for (trackIndex in tracks.indices) {
            val track = tracks[trackIndex] as? Map<*, *> ?: continue
            val trackId = track["id"]?.toString() ?: "overlay-track-$trackIndex"
            val clipRows = track["clips"] as? List<*> ?: emptyList<Any?>()
            val parsed = clipRows.mapNotNull { raw ->
                val row = raw as? Map<*, *> ?: return@mapNotNull null
                val assetId = row["assetId"]?.toString().orEmpty()
                val asset = assets[assetId] ?: return@mapNotNull null
                val kind = asset["kind"]?.toString()
                if (kind != "video" && kind != "image") return@mapNotNull null
                val sourceStart = (row["trimStartMs"] as? Number)?.toLong() ?: return@mapNotNull null
                val sourceEnd = (row["trimEndMs"] as? Number)?.toLong() ?: return@mapNotNull null
                val originalTimelineStart = (row["timelineStartMs"] as? Number)?.toLong() ?: 0L
                if (sourceStart < 0L || sourceEnd <= sourceStart || originalTimelineStart < 0L || originalTimelineStart >= sourceTimelineDurationMs) {
                    return@mapNotNull null
                }
                val originalSourceDuration = sourceEnd - sourceStart
                // PIP is an independent media clip: map its placement to the composition
                // clock, but preserve its playback duration across main-track overlaps.
                val timelineStart = timelineMapper(originalTimelineStart).coerceAtLeast(0L)
                if (timelineStart >= totalDurationMs) return@mapNotNull null
                val duration = minOf(originalSourceDuration, totalDurationMs - timelineStart)
                if (duration <= 0L) return@mapNotNull null
                val assetDuration = (asset["durationMs"] as? Number)?.toLong() ?: 0L
                if (kind == "video" && assetDuration > 0L && sourceEnd > assetDuration) {
                    throw IllegalArgumentException("PIP clip ${row["id"] ?: ""} exceeds its source duration")
                }
                val rawX = (row["positionX"] as? Number)?.toFloat() ?: 0.78f
                val rawY = (row["positionY"] as? Number)?.toFloat() ?: 0.22f
                val rawWidth = (row["widthFraction"] as? Number)?.toFloat() ?: 0.28f
                val rawHeight = (row["heightFraction"] as? Number)?.toFloat() ?: 0.28f
                TimedVideoLayer(
                    id = row["id"]?.toString() ?: UUID.randomUUID().toString(),
                    asset = asset,
                    sourceStartMs = sourceStart,
                    sourceEndMs = sourceStart + duration,
                    timelineStartMs = timelineStart,
                    timelineEndMs = timelineStart + duration,
                    positionX = if (rawX.isFinite()) rawX.coerceIn(0f, 1f) else 0.78f,
                    positionY = if (rawY.isFinite()) rawY.coerceIn(0f, 1f) else 0.22f,
                    widthFraction = if (rawWidth.isFinite()) rawWidth.coerceIn(0.05f, 1f) else 0.28f,
                    heightFraction = if (rawHeight.isFinite()) rawHeight.coerceIn(0.05f, 1f) else 0.28f,
                )
            }.sortedWith(compareBy<TimedVideoLayer> { it.timelineStartMs }.thenBy { it.id })

            // Greedy interval partitioning: clips that overlap occupy separate video
            // sequences, while non-overlapping clips in this track share one sequence.
            val laneClips = mutableListOf<MutableList<TimedVideoLayer>>()
            val laneEnds = mutableListOf<Long>()
            for (clip in parsed) {
                val laneIndex = laneEnds.indexOfFirst { it <= clip.timelineStartMs }
                    .let { if (it < 0) laneEnds.size else it }
                if (laneIndex == laneClips.size) {
                    laneClips += mutableListOf()
                    laneEnds += clip.timelineEndMs
                } else {
                    laneEnds[laneIndex] = clip.timelineEndMs
                }
                laneClips[laneIndex] += clip
            }

            for (lane in laneClips) {
                val builder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                var cursorMs = 0L
                for (clip in lane) {
                    if (clip.timelineStartMs > cursorMs) {
                        builder.addGap((clip.timelineStartMs - cursorMs) * 1_000L)
                    }
                    builder.addItem(createEditedOverlayItem(clip, frameSettings, colorSettings, outputHeight))
                    cursorMs = clip.timelineEndMs
                }
                sequences += VideoLayerSequence(trackId, lane, builder.build())
            }
        }

        val mainInputId = sequences.size
        val compositor: VideoCompositorSettings? = if (sequences.isEmpty()) null else object : VideoCompositorSettings {
            override fun getOutputSize(inputSizes: List<Size>): Size {
                require(inputSizes.size > mainInputId) { "The main video sequence is missing from the compositor" }
                return inputSizes[mainInputId]
            }

            override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings =
                when {
                    inputId == mainInputId -> StaticOverlaySettings.Builder().build()
                    inputId in sequences.indices -> sequences[inputId].clips
                        .firstOrNull { presentationTimeUs >= it.timelineStartMs * 1_000L && presentationTimeUs < it.timelineEndMs * 1_000L }
                        ?.overlaySettings(presentationTimeUs)
                        ?: StaticOverlaySettings.Builder().setAlphaScale(0f).build()
                    else -> StaticOverlaySettings.Builder().setAlphaScale(0f).build()
                }
        }
        return ProjectVideoLayerPlan(sequences, mainInputId, compositor)
    }

    private fun createEditedOverlayItem(
        clip: TimedVideoLayer,
        frameSettings: ProjectFrameSettings,
        colorSettings: ProjectColorSettings,
        outputHeight: Int,
    ): EditedMediaItem {
        val kind = clip.asset["kind"]?.toString()
        val uri = clip.asset["uri"]?.toString()
            ?: throw IllegalArgumentException("PIP media URI is missing")
        val durationMs = clip.durationMs
        val mediaItemBuilder = MediaItem.Builder().setUri(android.net.Uri.parse(uri))
        if (kind == "image") {
            mediaItemBuilder.setImageDurationMs(durationMs)
        } else {
            mediaItemBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.sourceStartMs)
                    .setEndPositionMs(clip.sourceEndMs)
                    .build(),
            )
        }
        val effects = ProjectFrameEffects.createOverlay(frameSettings, outputHeight) +
            ProjectColorEffects.create(colorSettings)
        val builder = EditedMediaItem.Builder(mediaItemBuilder.build())
            .setRemoveAudio(true)
            .setDurationUs(durationMs * 1_000L)
            .setEffects(Effects(emptyList(), effects))
        if (kind == "image") builder.setFrameRate(30)
        return builder.build()
    }
}
