import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_support/target_platform.dart';

import 'package:velora/src/models/project.dart';
import 'package:velora/src/screens/editor_screen.dart';
import 'package:velora/src/screens/export_screen.dart';

const _nativeChannel = MethodChannel('velora/native');

const _project = VeloraProject(
  id: 'editor-basic-test',
  name: 'مشروع اختبار المحرر',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [
    MediaAsset(
      id: 'asset-1',
      uri: 'content://media/video/1',
      name: 'clip.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 5000,
      width: 1920,
      height: 1080,
      sizeBytes: 100,
    ),
  ],
  videoTrack: [
    TimelineClip(
      id: 'clip-1',
      assetId: 'asset-1',
      trimStartMs: 0,
      trimEndMs: 5000,
    ),
  ],
  audioTrack: [],
);

const _emptyVisualProject = VeloraProject(
  id: 'editor-empty-test',
  name: 'مشروع بلا مقطع مرئي',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [],
  videoTrack: [],
  audioTrack: [],
);

class _StrictNativeChannelRecorder {
  final List<MethodCall> calls = [];
  final List<Map<String, dynamic>> savedProjects = [];

  void install() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          calls.add(call);
          switch (call.method) {
            case 'saveProject':
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
              return null;
            case 'pausePreview':
            case 'clearPreview':
              return null;
            default:
              throw StateError(
                'Unexpected velora/native method in this test: ${call.method}',
              );
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );
  }
}

Future<void> _disposeScreen(WidgetTester tester) async {
  await tester.pumpWidget(const SizedBox.shrink());
  await tester.pump();
  await tester.pump();
}

List<String> _methodNames(_StrictNativeChannelRecorder recorder) =>
    recorder.calls.map((call) => call.method).toList();

List<Object?> _callArguments(_StrictNativeChannelRecorder recorder) =>
    recorder.calls.map((call) => call.arguments).toList();

void main() {
  testWidgetsOnPlatform(
    'creates EditorScreen with a populated project',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _StrictNativeChannelRecorder()..install();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _project)),
      );
      await tester.pump();

      expect(find.text(_project.name), findsOneWidget);
      expect(
        find.text(
          '1 مقطع أساسي · 0 طبقة فيديو · 0 نص · 0 ترجمة · 0 ملصق · 0 مقطع صوتي',
        ),
        findsOneWidget,
      );
      expect(
        find.text('معاينة الخط الزمني متاحة حاليًا على Android فقط.'),
        findsOneWidget,
      );
      expect(recorder.calls, isEmpty);

      await _disposeScreen(tester);
      expect(_methodNames(recorder), ['pausePreview', 'clearPreview']);
      expect(_callArguments(recorder), [null, null]);
    },
  );

  testWidgetsOnPlatform(
    'shows the empty visual-track state without configuring preview',
    TargetPlatform.android,
    (tester) async {
      final recorder = _StrictNativeChannelRecorder()..install();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _emptyVisualProject)),
      );
      await tester.pump();

      expect(find.text('أضف مقطعًا مرئيًا لعرض المعاينة.'), findsOneWidget);
      expect(tester.widget<Slider>(find.byType(Slider)).onChanged, isNull);
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تشغيل')).onPressed,
        isNull,
      );
      expect(recorder.calls, isEmpty);

      await _disposeScreen(tester);
      expect(_methodNames(recorder), ['pausePreview', 'clearPreview']);
      expect(_callArguments(recorder), [null, null]);
    },
  );

  testWidgetsOnPlatform(
    'saves the exact project map through velora/native',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _StrictNativeChannelRecorder()..install();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _project)),
      );
      await tester.pump();
      await tester.tap(find.byTooltip('حفظ المشروع'));
      await tester.pumpAndSettle();

      expect(_methodNames(recorder), ['saveProject']);
      expect(_callArguments(recorder), [_project.toMap()]);
      expect(recorder.savedProjects, [_project.toMap()]);

      await _disposeScreen(tester);
      expect(_methodNames(recorder), [
        'saveProject',
        'pausePreview',
        'clearPreview',
      ]);
      expect(_callArguments(recorder), [_project.toMap(), null, null]);
    },
  );

  testWidgetsOnPlatform(
    'opens ExportScreen with the same project after saving it',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _StrictNativeChannelRecorder()..install();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _project)),
      );
      await tester.pump();
      await tester.tap(find.byTooltip('تصدير الفيديو'));
      await tester.pumpAndSettle();

      expect(find.byType(ExportScreen), findsOneWidget);
      final exportScreen = tester.widget<ExportScreen>(
        find.byType(ExportScreen),
      );
      expect(exportScreen.project, same(_project));
      expect(_methodNames(recorder), ['saveProject', 'pausePreview']);
      expect(_callArguments(recorder), [_project.toMap(), null]);
      expect(recorder.savedProjects, [_project.toMap()]);

      await _disposeScreen(tester);
      expect(_methodNames(recorder), [
        'saveProject',
        'pausePreview',
        'pausePreview',
        'clearPreview',
      ]);
      expect(_callArguments(recorder), [_project.toMap(), null, null, null]);
    },
  );
}
