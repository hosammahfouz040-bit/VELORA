import 'dart:math' as math;
import 'dart:typed_data' as typed_data;

import 'video_transitions.dart';

enum MotionInterpolation { linear, smooth }

class ClipTransformKeyframe {
  const ClipTransformKeyframe({
    required this.timeMs,
    this.positionX = 0,
    this.positionY = 0,
    this.scale = 1,
    this.rotationDegrees = 0,
    this.opacity = 1,
    this.interpolation = MotionInterpolation.smooth,
  });

  final int
  timeMs; // absolute source-media timestamp, so trims/splits remain stable
  final double positionX;
  final double positionY;
  final double scale;
  final double rotationDegrees;
  final double opacity;
  final MotionInterpolation interpolation;

  ClipTransformKeyframe copyWith({
    int? timeMs,
    double? positionX,
    double? positionY,
    double? scale,
    double? rotationDegrees,
    double? opacity,
    MotionInterpolation? interpolation,
  }) => ClipTransformKeyframe(
    timeMs: (timeMs ?? this.timeMs).clamp(0, 1 << 53).toInt(),
    positionX: _finiteClamp(positionX ?? this.positionX, -1, 1, 0),
    positionY: _finiteClamp(positionY ?? this.positionY, -1, 1, 0),
    scale: _finiteClamp(scale ?? this.scale, 0.05, 10, 1),
    rotationDegrees: _finiteClamp(
      rotationDegrees ?? this.rotationDegrees,
      -3600,
      3600,
      0,
    ),
    opacity: _finiteClamp(opacity ?? this.opacity, 0, 1, 1),
    interpolation: interpolation ?? this.interpolation,
  );

  factory ClipTransformKeyframe.fromMap(
    Map<String, dynamic> map,
  ) => ClipTransformKeyframe(
    timeMs: ((map['timeMs'] as num?)?.toInt() ?? 0).clamp(0, 1 << 53).toInt(),
    positionX: _finiteClamp(
      (map['positionX'] as num?)?.toDouble() ?? 0,
      -1,
      1,
      0,
    ),
    positionY: _finiteClamp(
      (map['positionY'] as num?)?.toDouble() ?? 0,
      -1,
      1,
      0,
    ),
    scale: _finiteClamp((map['scale'] as num?)?.toDouble() ?? 1, 0.05, 10, 1),
    rotationDegrees: _finiteClamp(
      (map['rotationDegrees'] as num?)?.toDouble() ?? 0,
      -3600,
      3600,
      0,
    ),
    opacity: _finiteClamp((map['opacity'] as num?)?.toDouble() ?? 1, 0, 1, 1),
    interpolation: MotionInterpolation.values.firstWhere(
      (value) => value.name == map['interpolation'],
      orElse: () => MotionInterpolation.smooth,
    ),
  );

  Map<String, Object> toMap() => {
    'timeMs': timeMs,
    'positionX': positionX,
    'positionY': positionY,
    'scale': scale,
    'rotationDegrees': rotationDegrees,
    'opacity': opacity,
    'interpolation': interpolation.name,
  };
}

const double minSpeedMultiplier = 0.1;
// Keep the advertised cap at Media3's presently verified safe boundary.
// Higher values remain clamped until high-speed runtime behavior is validated.
const double maxSpeedMultiplier = 8.0;

/// Keep every positive source clip representable on the editor's millisecond clock.
/// Faster rates are available for longer trims, up to the verified 8× ceiling.
double maxSpeedMultiplierForSourceDurationMs(int sourceDurationMs) =>
    sourceDurationMs <= 0
    ? maxSpeedMultiplier
    : math.min(maxSpeedMultiplier, sourceDurationMs.toDouble()).toDouble();

class SpeedRampPoint {
  const SpeedRampPoint({required this.timeMs, required this.speed});

  final int timeMs; // absolute source-media timestamp
  final double speed;

  SpeedRampPoint copyWith({int? timeMs, double? speed}) => SpeedRampPoint(
    timeMs: (timeMs ?? this.timeMs).clamp(0, 1 << 53).toInt(),
    speed: _finiteClamp(
      speed ?? this.speed,
      minSpeedMultiplier,
      maxSpeedMultiplier,
      1,
    ),
  );

  factory SpeedRampPoint.fromMap(Map<String, dynamic> map) => SpeedRampPoint(
    timeMs: ((map['timeMs'] as num?)?.toInt() ?? 0).clamp(0, 1 << 53).toInt(),
    speed: _finiteClamp(
      (map['speed'] as num?)?.toDouble() ?? 1,
      minSpeedMultiplier,
      maxSpeedMultiplier,
      1,
    ),
  );

  Map<String, Object> toMap() {
    final safe = copyWith();
    return {'timeMs': safe.timeMs, 'speed': safe.speed};
  }
}

class ClipTransformValue {
  const ClipTransformValue({
    this.positionX = 0,
    this.positionY = 0,
    this.scale = 1,
    this.rotationDegrees = 0,
    this.opacity = 1,
  });

  final double positionX;
  final double positionY;
  final double scale;
  final double rotationDegrees;
  final double opacity;
}

const int speedRampSampleStepMs = 50;

// Media3's SpeedProvider exposes Float rates. Quantize only the sampled rate
// used by the project clock; saved ramp points remain unchanged doubles.
final typed_data.ByteData _media3SpeedBuffer = typed_data.ByteData(4);

double _media3SpeedFloat(double speed) {
  _media3SpeedBuffer.setFloat32(0, speed, typed_data.Endian.little);
  return _media3SpeedBuffer.getFloat32(0, typed_data.Endian.little);
}

List<ClipTransformKeyframe> normalizeTransformKeyframes(
  Iterable<ClipTransformKeyframe> points,
) {
  final sorted = points.map((point) => point.copyWith()).toList()
    ..sort((a, b) => a.timeMs.compareTo(b.timeMs));
  final byTime = <int, ClipTransformKeyframe>{};
  for (final point in sorted) {
    byTime[point.timeMs] = point;
  }
  return byTime.values.toList(growable: false);
}

List<SpeedRampPoint> normalizeSpeedRampPoints(Iterable<SpeedRampPoint> points) {
  final sorted = points.map((point) => point.copyWith()).toList()
    ..sort((a, b) => a.timeMs.compareTo(b.timeMs));
  final byTime = <int, SpeedRampPoint>{};
  for (final point in sorted) {
    byTime[point.timeMs] = point;
  }
  return byTime.values.toList(growable: false);
}

List<SpeedRampPoint> speedRampPointsForSourceDuration(
  Iterable<SpeedRampPoint> points,
  int sourceDurationMs,
) {
  final maxSpeed = maxSpeedMultiplierForSourceDurationMs(sourceDurationMs);
  return normalizeSpeedRampPoints(points)
      .map(
        (point) => point.copyWith(
          speed: point.speed.clamp(minSpeedMultiplier, maxSpeed).toDouble(),
        ),
      )
      .toList(growable: false);
}

ClipTransformValue evaluateTransformKeyframes(
  Iterable<ClipTransformKeyframe> points,
  int sourceTimeMs,
) {
  final frames = normalizeTransformKeyframes(points);
  if (frames.isEmpty) return const ClipTransformValue();
  if (sourceTimeMs <= frames.first.timeMs) return _valueOf(frames.first);
  if (sourceTimeMs >= frames.last.timeMs) return _valueOf(frames.last);
  var rightIndex = frames.indexWhere((point) => point.timeMs >= sourceTimeMs);
  if (rightIndex <= 0) return _valueOf(frames.first);
  final left = frames[rightIndex - 1];
  final right = frames[rightIndex];
  final span = right.timeMs - left.timeMs;
  if (span <= 0) return _valueOf(right);
  var t = (sourceTimeMs - left.timeMs) / span;
  if (left.interpolation == MotionInterpolation.smooth) {
    t = t * t * (3 - 2 * t);
  }
  return ClipTransformValue(
    positionX: _lerp(left.positionX, right.positionX, t),
    positionY: _lerp(left.positionY, right.positionY, t),
    scale: _lerp(left.scale, right.scale, t),
    rotationDegrees: _lerp(left.rotationDegrees, right.rotationDegrees, t),
    opacity: _lerp(left.opacity, right.opacity, t),
  );
}

double speedAtSourceTime(Iterable<SpeedRampPoint> points, int sourceTimeMs) =>
    _speedAtNormalized(normalizeSpeedRampPoints(points), sourceTimeMs);

double _speedAtNormalized(List<SpeedRampPoint> ramp, int sourceTimeMs) {
  if (ramp.isEmpty) return 1;
  if (sourceTimeMs <= ramp.first.timeMs) return ramp.first.speed;
  if (sourceTimeMs >= ramp.last.timeMs) return ramp.last.speed;
  final rightIndex = ramp.indexWhere((point) => point.timeMs >= sourceTimeMs);
  final left = ramp[rightIndex - 1];
  final right = ramp[rightIndex];
  final span = right.timeMs - left.timeMs;
  if (span <= 0) return right.speed;
  final t = (sourceTimeMs - left.timeMs) / span;
  return _lerp(left.speed, right.speed, t);
}

int speedAdjustedDurationMs(
  int sourceStartMs,
  int sourceEndMs,
  Iterable<SpeedRampPoint> points,
) {
  final sourceDurationMs = (sourceEndMs - sourceStartMs)
      .clamp(0, 1 << 53)
      .toInt();
  final ramp = normalizeSpeedRampPoints(points);
  // A split fragment keeps the original absolute ramp points. Use their full
  // span when applying the representable-duration speed cap, otherwise a tiny
  // tail fragment can be capped differently and make a split non-additive.
  final rampSpanMs = ramp.length > 1 ? ramp.last.timeMs - ramp.first.timeMs : 0;
  final speedCapDurationMs = math.max(sourceDurationMs, rampSpanMs);
  return sourceOffsetToOutputMs(
    sourceDurationMs,
    sourceStartMs,
    speedRampPointsForSourceDuration(ramp, speedCapDurationMs),
  );
}

/// Maps a source-clock span to output time using a cumulative absolute clock.
/// The 50 ms sampling grid is anchored to absolute source time, with additional
/// boundaries at ramp points. Rounding the cumulative clock at each endpoint
/// makes adjacent spans additive instead of rounding each fragment separately.
int sourceOffsetToOutputMs(
  int sourceOffsetMs,
  int sourceStartMs,
  Iterable<SpeedRampPoint> points,
) {
  final totalSourceMs = sourceOffsetMs.clamp(0, 1 << 53).toInt();
  if (totalSourceMs == 0) return 0;
  final sourceEndMs = sourceStartMs + totalSourceMs;
  final clock = _SpeedRampOutputClock(points, throughSourceTimeMs: sourceEndMs);
  return (clock.at(sourceEndMs) - clock.at(sourceStartMs))
      .clamp(0, 1 << 53)
      .toInt();
}

/// Inverts the same cumulative source/output clock used for durations.
/// Since output time is quantized to milliseconds, the returned source offset
/// is the closest integer-millisecond point; ties choose the earlier point.
int outputOffsetToSourceMs(
  int outputOffsetMs,
  int sourceStartMs,
  int sourceEndMs,
  Iterable<SpeedRampPoint> points,
) {
  final outputTarget = outputOffsetMs.clamp(0, 1 << 53).toInt();
  final sourceDuration = (sourceEndMs - sourceStartMs)
      .clamp(0, 1 << 53)
      .toInt();
  if (outputTarget == 0 || sourceDuration == 0) return 0;

  final sourceEndMsForClock = sourceStartMs + sourceDuration;
  final clock = _SpeedRampOutputClock(
    points,
    throughSourceTimeMs: sourceEndMsForClock,
  );
  final sourceStartClock = clock.at(sourceStartMs);
  final outputDuration = (clock.at(sourceEndMsForClock) - sourceStartClock)
      .clamp(0, 1 << 53)
      .toInt();
  if (outputTarget >= outputDuration) return sourceDuration;

  final boundedTarget = outputTarget.clamp(0, outputDuration).toInt();
  var low = 0;
  var high = sourceDuration;
  while (low < high) {
    final middle = (low + high) ~/ 2;
    final outputAtMiddle = clock.at(sourceStartMs + middle) - sourceStartClock;
    if (outputAtMiddle < boundedTarget) {
      low = middle + 1;
    } else {
      high = middle;
    }
  }

  final upperOffset = low;
  final lowerOffset = (upperOffset - 1).clamp(0, sourceDuration).toInt();
  final upperError =
      (clock.at(sourceStartMs + upperOffset) - sourceStartClock - boundedTarget)
          .abs();
  final lowerError =
      (clock.at(sourceStartMs + lowerOffset) - sourceStartClock - boundedTarget)
          .abs();
  return lowerError <= upperError ? lowerOffset : upperOffset;
}

/// A rounded cumulative output-time clock over absolute source timestamps.
/// Within ramp ranges, cells are split at absolute 50 ms boundaries and at
/// speed-ramp points; the speed at each cell's start is held for that cell.
/// This retains the existing sampled-speed approximation while ensuring that
/// splitting a range cannot change the sum of its rounded durations.
class _SpeedRampOutputClock {
  _SpeedRampOutputClock(
    Iterable<SpeedRampPoint> points, {
    required int throughSourceTimeMs,
  }) : _ramp = normalizeSpeedRampPoints(points),
       _throughSourceTimeMs = throughSourceTimeMs {
    if (_ramp.length < 2 || throughSourceTimeMs <= _ramp.first.timeMs) return;

    _breakpoints.add(_ramp.first.timeMs);
    _prefixOutputMs.add(0);
    var cursor = _ramp.first.timeMs;
    var nextRampPointIndex = 1;
    final integrationEndMs = math
        .min(_ramp.last.timeMs, throughSourceTimeMs)
        .toInt();
    while (cursor < integrationEndMs) {
      final nextGridBoundary =
          (cursor ~/ speedRampSampleStepMs + 1) * speedRampSampleStepMs;
      final nextRampPoint = _ramp[nextRampPointIndex].timeMs;
      final next = math
          .min(math.min(nextGridBoundary, nextRampPoint), integrationEndMs)
          .toInt();
      final speed = _media3SpeedFloat(_speedAtNormalized(_ramp, cursor));
      _intervalSpeeds.add(speed);
      _prefixOutputMs.add(_prefixOutputMs.last + (next - cursor) / speed);
      _breakpoints.add(next);
      cursor = next;
      if (cursor == nextRampPoint) nextRampPointIndex++;
    }
  }

  final List<SpeedRampPoint> _ramp;
  final int _throughSourceTimeMs;
  final List<int> _breakpoints = [];
  final List<double> _prefixOutputMs = [];
  final List<double> _intervalSpeeds = [];

  int at(int sourceTimeMs) {
    final rawOutputMs = _rawAt(sourceTimeMs);
    return rawOutputMs.round().clamp(-(1 << 53), 1 << 53).toInt();
  }

  double _rawAt(int sourceTimeMs) {
    if (_ramp.isEmpty) return sourceTimeMs.toDouble();
    final first = _ramp.first;
    final last = _ramp.last;
    final firstSpeed = _media3SpeedFloat(first.speed);
    final lastSpeed = _media3SpeedFloat(last.speed);
    if (sourceTimeMs <= first.timeMs) {
      return sourceTimeMs / firstSpeed;
    }

    final outputBeforeRamp = first.timeMs / firstSpeed;
    if (_ramp.length == 1 || sourceTimeMs >= last.timeMs) {
      final rampOutput = _ramp.length == 1 ? 0 : _prefixOutputMs.last;
      return outputBeforeRamp +
          rampOutput +
          (sourceTimeMs - last.timeMs) / lastSpeed;
    }
    if (_breakpoints.isNotEmpty &&
        sourceTimeMs >= _breakpoints.last &&
        sourceTimeMs <= _throughSourceTimeMs) {
      return outputBeforeRamp + _prefixOutputMs.last;
    }

    var low = 0;
    var high = _breakpoints.length - 1;
    while (low < high) {
      final middle = (low + high) ~/ 2;
      if (_breakpoints[middle + 1] <= sourceTimeMs) {
        low = middle + 1;
      } else {
        high = middle;
      }
    }
    return outputBeforeRamp +
        _prefixOutputMs[low] +
        (sourceTimeMs - _breakpoints[low]) / _intervalSpeeds[low];
  }
}

List<SpeedRampPoint> speedPresetPoints(
  int sourceStartMs,
  int sourceEndMs,
  String preset, {
  double constantSpeed = 1,
}) {
  final duration = (sourceEndMs - sourceStartMs).clamp(1, 1 << 53).toInt();
  final mid = sourceStartMs + duration ~/ 2;
  switch (preset) {
    case 'constant_slow':
      return [SpeedRampPoint(timeMs: sourceStartMs, speed: 0.5)];
    case 'constant_normal':
      return const [];
    case 'constant_fast':
      return [SpeedRampPoint(timeMs: sourceStartMs, speed: 2)];
    case 'accelerate':
      return [
        SpeedRampPoint(timeMs: sourceStartMs, speed: 0.5),
        SpeedRampPoint(timeMs: sourceEndMs, speed: 2),
      ];
    case 'decelerate':
      return [
        SpeedRampPoint(timeMs: sourceStartMs, speed: 2),
        SpeedRampPoint(timeMs: sourceEndMs, speed: 0.5),
      ];
    case 'slow_fast_slow':
      return [
        SpeedRampPoint(timeMs: sourceStartMs, speed: 0.5),
        SpeedRampPoint(timeMs: mid, speed: 2),
        SpeedRampPoint(timeMs: sourceEndMs, speed: 0.5),
      ];
    case 'custom':
      return [
        SpeedRampPoint(
          timeMs: sourceStartMs,
          speed: _finiteClamp(
            constantSpeed,
            minSpeedMultiplier,
            maxSpeedMultiplier,
            1,
          ),
        ),
        SpeedRampPoint(
          timeMs: sourceEndMs,
          speed: _finiteClamp(
            constantSpeed,
            minSpeedMultiplier,
            maxSpeedMultiplier,
            1,
          ),
        ),
      ];
    default:
      return const [];
  }
}

String speedPresetForPoints(List<SpeedRampPoint> points) {
  if (points.isEmpty) return 'constant_normal';
  if (points.length == 1 ||
      points.every((point) => point.speed == points.first.speed)) {
    if (points.first.speed < 0.99) return 'constant_slow';
    if (points.first.speed > 1.01) return 'constant_fast';
    return 'constant_normal';
  }
  if (points.first.speed < points.last.speed) return 'accelerate';
  if (points.first.speed > points.last.speed) return 'decelerate';
  return 'slow_fast_slow';
}

ClipTransformValue _valueOf(ClipTransformKeyframe frame) => ClipTransformValue(
  positionX: frame.positionX,
  positionY: frame.positionY,
  scale: frame.scale,
  rotationDegrees: frame.rotationDegrees,
  opacity: frame.opacity,
);

double _lerp(double a, double b, double t) => a + (b - a) * t;

double _finiteClamp(double value, double min, double max, double fallback) =>
    value.isFinite ? value.clamp(min, max).toDouble() : fallback;
