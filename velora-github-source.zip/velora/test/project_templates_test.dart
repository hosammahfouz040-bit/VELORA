import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_templates.dart';
import 'package:velora/src/models/video_transitions.dart';

MediaAsset _asset({
  required String id,
  required String uri,
  required MediaKind kind,
  required int durationMs,
  String name = 'وسيط',
}) => MediaAsset(
  id: id,
  uri: uri,
  name: name,
  mimeType: switch (kind) {
    MediaKind.video => 'video/mp4',
    MediaKind.image => 'image/jpeg',
    MediaKind.audio => 'audio/mpeg',
    MediaKind.unsupported => 'application/octet-stream',
  },
  kind: kind,
  durationMs: durationMs,
  width: 1080,
  height: 1920,
  sizeBytes: 10,
);

void main() {
  group('Project templates', () {
    test('ships four original starter templates with media-independent slots', () {
      final templates = builtInProjectTemplates();
      expect(templates, hasLength(4));
      expect(templates.map((template) => template.name), containsAll([
        'مقدمة عصرية',
        'فيديو قصير',
        'اقتباس وترجمة',
        'مونتاج متعدد المقاطع',
      ]));
      for (final template in templates) {
        expect(template.isBuiltIn, isTrue);
        expect(template.mediaSlots, isNotEmpty);
        expect(
          template.project.assets.every((asset) => asset.uri.startsWith('template://')),
          isTrue,
        );
      }
    });

    test('captures a project without retaining source media URIs and round-trips', () {
      final source = VeloraProject(
        id: 'original-project',
        name: 'المشروع الأصلي',
        createdAt: '2026-10-01T10:00:00Z',
        assets: [
          _asset(
            id: 'source-video',
            uri: 'content://media/private/video-1',
            kind: MediaKind.video,
            durationMs: 8_000,
          ),
        ],
        videoTrack: const [
          TimelineClip(
            id: 'clip-1',
            assetId: 'source-video',
            trimStartMs: 1_000,
            trimEndMs: 5_000,
            speedRampPoints: [
              SpeedRampPoint(timeMs: 1_000, speed: 1),
              SpeedRampPoint(timeMs: 4_000, speed: 1.5),
            ],
          ),
        ],
        audioTrack: const [],
        subtitleTrack: const [
          SubtitleCue(id: 'subtitle', text: 'ترجمة', startMs: 0, endMs: 5_000),
        ],
        stickerOverlays: const [
          StickerOverlay(
            id: 'sticker',
            uri: 'content://media/private/sticker-1',
            name: 'ملصق أصلي',
            mimeType: 'image/png',
            startMs: 500,
            endMs: 4_500,
          ),
        ],
      );

      final template = ProjectTemplate.fromProject(
        source,
        id: 'custom_template_1',
        name: 'نسخة قابلة لإعادة الاستخدام',
      );
      final encoded = template.toMap();
      final roundTripped = ProjectTemplate.fromMap(encoded);

      expect(template.mediaSlots, hasLength(2));
      expect(template.project.assets.single.uri, startsWith('template://'));
      expect(template.project.stickerOverlays.single.uri, startsWith('template://'));
      expect(template.project.assets.single.uri, isNot(contains('private')));
      expect(source.assets.single.uri, 'content://media/private/video-1');
      expect(source.stickerOverlays.single.uri, 'content://media/private/sticker-1');
      expect(roundTripped.name, template.name);
      expect(roundTripped.project.videoTrack.single.speedRampPoints, hasLength(2));
      expect(roundTripped.isBuiltIn, isFalse);
    });

    test('creates an independent project and safely fits short media and overlays', () {
      final source = VeloraProject(
        id: 'original-project',
        name: 'المشروع الأصلي',
        createdAt: '2026-10-01T10:00:00Z',
        assets: [
          _asset(
            id: 'source-video',
            uri: 'content://media/private/video-1',
            kind: MediaKind.video,
            durationMs: 8_000,
          ),
        ],
        videoTrack: const [
          TimelineClip(
            id: 'clip-1',
            assetId: 'source-video',
            trimStartMs: 1_000,
            trimEndMs: 5_000,
            speedRampPoints: [
              SpeedRampPoint(timeMs: 1_000, speed: 1),
              SpeedRampPoint(timeMs: 4_000, speed: 1.5),
            ],
          ),
        ],
        audioTrack: const [],
        subtitleTrack: const [
          SubtitleCue(id: 'subtitle', text: 'ترجمة', startMs: 0, endMs: 5_000),
        ],
        stickerOverlays: const [
          StickerOverlay(
            id: 'sticker',
            uri: 'content://media/private/sticker-1',
            name: 'ملصق أصلي',
            mimeType: 'image/png',
            startMs: 500,
            endMs: 4_500,
          ),
        ],
      );
      final template = ProjectTemplate.fromProject(
        source,
        id: 'custom_template_2',
        name: 'قالب تجريبي',
      );
      final videoSlot = template.mediaSlots.singleWhere((slot) => slot.assetId != null);
      final stickerSlot = template.mediaSlots.singleWhere((slot) => slot.stickerOverlayIds.isNotEmpty);
      final selectedVideo = _asset(
        id: 'picked-video',
        uri: 'content://picked/video-2',
        kind: MediaKind.video,
        durationMs: 2_500,
        name: 'فيديو قصير',
      );
      final selectedImage = _asset(
        id: 'picked-sticker',
        uri: 'content://picked/sticker-2',
        kind: MediaKind.image,
        durationMs: 0,
        name: 'ملصق جديد',
      );

      final result = instantiateProjectTemplate(
        template: template,
        projectName: 'مشروع جديد مستقل',
        assignments: {
          videoSlot.id: selectedVideo,
          stickerSlot.id: selectedImage,
        },
      );

      expect(result.project.id, isNot(source.id));
      expect(result.project.name, 'مشروع جديد مستقل');
      expect(result.project.assets.single.uri, selectedVideo.uri);
      expect(result.project.videoTrack.single.trimStartMs, 1_000);
      expect(result.project.videoTrack.single.trimEndMs, 2_500);
      expect(result.project.videoTrack.single.speedRampPoints, hasLength(1));
      expect(result.project.subtitleTrack.single.endMs, 1_500);
      expect(result.project.stickerOverlays.single.uri, selectedImage.uri);
      expect(result.project.stickerOverlays.single.endMs, 1_500);
      expect(result.adjustments, isNotEmpty);
      expect(source.videoTrack.single.trimEndMs, 5_000);
      expect(source.assets.single.uri, 'content://media/private/video-1');
      expect(template.project.assets.single.uri, startsWith('template://'));
    });

    test('rejects unsupported media URIs instead of creating a broken project', () {
      final template = builtInProjectTemplates().first;
      final slot = template.mediaSlots.single;
      expect(
        () => instantiateProjectTemplate(
          template: template,
          projectName: 'اختبار',
          assignments: {
            slot.id: _asset(
              id: 'bad',
              uri: 'https://example.invalid/video.mp4',
              kind: MediaKind.video,
              durationMs: 8_000,
            ),
          },
        ),
        throwsFormatException,
      );
    });

    test('short clips reduce transitions while keeping a valid positive timeline', () {
      final template = builtInProjectTemplates().singleWhere((item) => item.id == 'builtin:short');
      final selected = <String, MediaAsset>{};
      for (var index = 0; index < template.mediaSlots.length; index++) {
        final slot = template.mediaSlots[index];
        selected[slot.id] = _asset(
          id: 'picked-$index',
          uri: 'content://picked/video-$index',
          kind: MediaKind.video,
          durationMs: 600,
        );
      }
      final result = instantiateProjectTemplate(
        template: template,
        projectName: 'قصير جدًا',
        assignments: selected,
      );
      final transition = result.project.videoTransitions.single;
      final layout = layoutVideoTransitions(
        result.project.videoTrack.map((clip) => clip.id).toList(),
        result.project.videoTrack.map((clip) => clip.effectiveDurationMs).toList(),
        result.project.videoTransitions,
      );
      expect(transition.durationMs, lessThanOrEqualTo(300));
      expect(layout.totalDurationMs, greaterThan(0));
      expect(result.adjustments, isNotEmpty);
    });
  });
}
