import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/services/native_bridge.dart';

void main() {
  test('project serialization preserves assets and track ranges', () {
    const project = VeloraProject(
      id: 'project-1',
      name: 'اختبار',
      createdAt: '2026-10-27T00:00:00.000Z',
      assets: [
        MediaAsset(
          id: 'asset-1',
          uri: 'content://media/video/1',
          name: 'clip.mp4',
          mimeType: 'video/mp4',
          kind: MediaKind.video,
          durationMs: 9000,
          width: 1920,
          height: 1080,
          sizeBytes: 100,
        ),
      ],
      videoTrack: [
        TimelineClip(
          id: 'clip-1',
          assetId: 'asset-1',
          trimStartMs: 1000,
          trimEndMs: 7000,
        ),
      ],
      audioTrack: [],
    );

    final restored = VeloraProject.fromMap(project.toMap());
    expect(restored.name, 'اختبار');
    expect(restored.assets.single.kind, MediaKind.video);
    expect(restored.videoTrack.single.trimStartMs, 1000);
    expect(restored.videoTrack.single.trimEndMs, 7000);
  });

  test(
    'splitting creates adjacent source ranges without changing duration',
    () {
      const track = [
        TimelineClip(
          id: 'clip-1',
          assetId: 'asset-1',
          trimStartMs: 1000,
          trimEndMs: 9000,
        ),
      ];
      final split = splitClipAtMidpoint(
        track,
        'clip-1',
        secondClipId: 'clip-2',
      );

      expect(split, isNotNull);
      expect(split!.length, 2);
      expect(split[0].trimStartMs, 1000);
      expect(split[0].trimEndMs, split[1].trimStartMs);
      expect(split[1].trimEndMs, 9000);
      expect(split.fold<int>(0, (sum, clip) => sum + clip.durationMs), 8000);
    },
  );

  test('clips shorter than one second are not split', () {
    const track = [
      TimelineClip(
        id: 'clip-1',
        assetId: 'asset-1',
        trimStartMs: 0,
        trimEndMs: 999,
      ),
    ];
    expect(
      splitClipAtMidpoint(track, 'clip-1', secondClipId: 'clip-2'),
      isNull,
    );
  });

  group('visual timeline position', () {
    const track = [
      TimelineClip(
        id: 'clip-1',
        assetId: 'asset-1',
        trimStartMs: 1000,
        trimEndMs: 4000,
      ),
      TimelineClip(
        id: 'clip-2',
        assetId: 'asset-2',
        trimStartMs: 5000,
        trimEndMs: 9000,
      ),
    ];

    test('maps timeline positions into source ranges in list order', () {
      expect(visualTimelineDurationMs(track), 7000);

      final first = timelinePositionAt(track, 1500)!;
      expect(first.clipId, 'clip-1');
      expect(first.assetId, 'asset-1');
      expect(first.clipIndex, 0);
      expect(first.sourcePositionMs, 2500);

      final second = timelinePositionAt(track, 4000)!;
      expect(second.clipId, 'clip-2');
      expect(second.sourcePositionMs, 6000);
    });

    test(
      'uses the next clip at an internal boundary and clamps at track end',
      () {
        final boundary = timelinePositionAt(track, 3000)!;
        expect(boundary.clipId, 'clip-2');
        expect(boundary.sourcePositionMs, 5000);

        final beforeStart = timelinePositionAt(track, -100)!;
        expect(beforeStart.clipId, 'clip-1');
        expect(beforeStart.sourcePositionMs, 1000);

        final afterEnd = timelinePositionAt(track, 9000)!;
        expect(afterEnd.clipId, 'clip-2');
        expect(afterEnd.sourcePositionMs, 9000);
      },
    );

    test('maps a player item position back to timeline and source time', () {
      final position = timelinePositionForClipOffset(
        track,
        clipIndex: 1,
        clipPositionMs: 1250,
      )!;
      expect(position.clipId, 'clip-2');
      expect(position.clipIndex, 1);
      expect(position.clipPositionMs, 1250);
      expect(position.timelinePositionMs, 4250);
      expect(position.sourcePositionMs, 6250);

      final clamped = timelinePositionForClipOffset(
        track,
        clipIndex: 1,
        clipPositionMs: 9000,
      )!;
      expect(clamped.clipPositionMs, 4000);
      expect(clamped.timelinePositionMs, 7000);
      expect(clamped.sourcePositionMs, 9000);

      final beforeClip = timelinePositionForClipOffset(
        track,
        clipIndex: 1,
        clipPositionMs: -50,
      )!;
      expect(beforeClip.clipPositionMs, 0);
      expect(beforeClip.timelinePositionMs, 3000);
      expect(beforeClip.sourcePositionMs, 5000);
      expect(
        timelinePositionForClipOffset(track, clipIndex: 9, clipPositionMs: 0),
        isNull,
      );
    });

    test('maps fixed-duration still-image clips like other visual items', () {
      const imageTrack = [
        TimelineClip(
          id: 'image-clip',
          assetId: 'image-asset',
          trimStartMs: 0,
          trimEndMs: 5000,
        ),
      ];
      final position = timelinePositionForClipOffset(
        imageTrack,
        clipIndex: 0,
        clipPositionMs: 2750,
      )!;
      expect(position.timelinePositionMs, 2750);
      expect(position.clipPositionMs, 2750);
      expect(position.sourcePositionMs, 2750);
    });

    test('ignores invalid ranges and returns null for an empty timeline', () {
      const invalid = [
        TimelineClip(
          id: 'invalid',
          assetId: 'asset-x',
          trimStartMs: 10,
          trimEndMs: 10,
        ),
        TimelineClip(
          id: 'valid',
          assetId: 'asset-1',
          trimStartMs: 100,
          trimEndMs: 600,
        ),
      ];
      expect(visualTimelineDurationMs(invalid), 500);
      expect(timelinePositionAt(invalid, 200)?.clipId, 'valid');
      expect(visualTimelineDurationMs(const []), 0);
      expect(timelinePositionAt(const [], 0), isNull);
    });
  });

  test('video-image-video timeline maps trims and seek boundaries', () {
    const assets = [
      MediaAsset(
        id: 'video-1',
        uri: 'content://media/video/1',
        name: 'first.mp4',
        mimeType: 'video/mp4',
        kind: MediaKind.video,
        durationMs: 7000,
        width: 1920,
        height: 1080,
        sizeBytes: 100,
      ),
      MediaAsset(
        id: 'image-1',
        uri: 'content://media/image/1',
        name: 'still.png',
        mimeType: 'image/png',
        kind: MediaKind.image,
        durationMs: 5000,
        width: 1200,
        height: 800,
        sizeBytes: 100,
      ),
      MediaAsset(
        id: 'video-2',
        uri: 'content://media/video/2',
        name: 'last.mp4',
        mimeType: 'video/mp4',
        kind: MediaKind.video,
        durationMs: 10000,
        width: 1920,
        height: 1080,
        sizeBytes: 100,
      ),
    ];
    const track = [
      TimelineClip(
        id: 'clip-1',
        assetId: 'video-1',
        trimStartMs: 1000,
        trimEndMs: 4000,
      ),
      TimelineClip(
        id: 'clip-image',
        assetId: 'image-1',
        trimStartMs: 0,
        trimEndMs: 2000,
      ),
      TimelineClip(
        id: 'clip-2',
        assetId: 'video-2',
        trimStartMs: 5000,
        trimEndMs: 9000,
      ),
    ];

    expect(visualTimelineDurationMs(track), 9000);
    expect(
      track
          .map(
            (clip) =>
                assets.singleWhere((asset) => asset.id == clip.assetId).kind,
          )
          .toList(),
      [MediaKind.video, MediaKind.image, MediaKind.video],
    );

    final firstClipEnd = timelinePositionAt(track, 2999)!;
    expect(firstClipEnd.clipIndex, 0);
    expect(firstClipEnd.sourcePositionMs, 3999);

    final imageBoundary = timelinePositionAt(track, 3000)!;
    expect(imageBoundary.clipId, 'clip-image');
    expect(imageBoundary.clipPositionMs, 0);
    expect(imageBoundary.sourcePositionMs, 0);

    final imageScrub = timelinePositionAt(track, 4500)!;
    expect(imageScrub.clipIndex, 1);
    expect(imageScrub.sourcePositionMs, 1500);

    final lastVideoBoundary = timelinePositionAt(track, 5000)!;
    expect(lastVideoBoundary.clipId, 'clip-2');
    expect(lastVideoBoundary.sourcePositionMs, 5000);

    final seekBackToVideo = timelinePositionAt(track, 2500)!;
    expect(seekBackToVideo.clipId, 'clip-1');
    expect(seekBackToVideo.sourcePositionMs, 3500);

    final playerPosition = timelinePositionForClipOffset(
      track,
      clipIndex: 2,
      clipPositionMs: 2500,
    )!;
    expect(playerPosition.timelinePositionMs, 7500);
    expect(playerPosition.sourcePositionMs, 7500);

    final trackEnd = timelinePositionAt(track, 12000)!;
    expect(trackEnd.clipId, 'clip-2');
    expect(trackEnd.clipPositionMs, 4000);
    expect(trackEnd.sourcePositionMs, 9000);
  });

  test('new project is saved and restored through the native bridge', () async {
    TestWidgetsFlutterBinding.ensureInitialized();
    const channel = MethodChannel('velora/native');
    final savedProjects = <Map<String, dynamic>>[];
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          if (call.method == 'saveProject') {
            savedProjects.add(Map<String, dynamic>.from(call.arguments as Map));
            return null;
          }
          if (call.method == 'listProjects') return savedProjects;
          return null;
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, null),
    );

    final created = VeloraProject.empty(id: 'home-create-test', name: 'مشروعي');
    await NativeBridge.saveProject(created);
    final restored = await NativeBridge.listProjects();

    expect(restored, hasLength(1));
    expect(restored.single.id, created.id);
    expect(restored.single.name, created.name);
    expect(restored.single.createdAt, created.createdAt);
    expect(restored.single.assets, isEmpty);
    expect(restored.single.videoTrack, isEmpty);
    expect(restored.single.audioTrack, isEmpty);
  });

  test(
    'native bridge sends preview controls and export cancellation in order',
    () async {
      TestWidgetsFlutterBinding.ensureInitialized();
      const channel = MethodChannel('velora/native');
      final calls = <MethodCall>[];
      var cancelRequests = 0;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            calls.add(call);
            if (call.method == 'cancelExport') return ++cancelRequests == 1;
            return null;
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      await NativeBridge.seekPreviewTo(mediaItemIndex: 1, clipPositionMs: 450);
      await NativeBridge.pausePreview();
      await NativeBridge.playPreview();
      expect(await NativeBridge.cancelExport(), isTrue);
      expect(await NativeBridge.cancelExport(), isFalse);

      expect(calls.map((call) => call.method), [
        'seekPreview',
        'pausePreview',
        'playPreview',
        'cancelExport',
        'cancelExport',
      ]);
      expect(calls.first.arguments, {
        'mediaItemIndex': 1,
        'clipPositionMs': 450,
      });
    },
  );
}
