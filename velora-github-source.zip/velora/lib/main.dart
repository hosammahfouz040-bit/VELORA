import 'package:flutter/material.dart';

import 'src/screens/home_screen.dart';
import 'src/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VeloraApp());
}

class VeloraApp extends StatelessWidget {
  const VeloraApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VELORA — فيلورا',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: veloraCanvas,
      colorScheme: ColorScheme.fromSeed(
        seedColor: veloraGold,
        brightness: Brightness.dark,
        surface: veloraPanel,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: veloraCanvas,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: veloraPanel,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFF293744)),
        ),
      ),
      useMaterial3: true,
    ),
    builder: (context, child) => Directionality(
      textDirection: TextDirection.rtl,
      child: child ?? const SizedBox.shrink(),
    ),
    home: const HomeScreen(),
  );
}
