import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';
import '../models/project.dart';
import '../services/native_bridge.dart';

class ExportScreen extends StatefulWidget {
  const ExportScreen({super.key, required this.project});

  final VeloraProject project;

  @override
  State<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends State<ExportScreen> {
  int _height = 720;
  bool _exporting = false;
  Map<String, dynamic>? _completed;
  String? _error;

  Future<void> _cancelExport() async {
    try {
      await NativeBridge.cancelExport();
    } on PlatformException catch (error) {
      if (mounted) {
        setState(() => _error = error.message ?? 'تعذّر إلغاء التصدير.');
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر إلغاء التصدير: $error');
    }
  }

  Future<void> _export() async {
    setState(() {
      _exporting = true;
      _completed = null;
      _error = null;
    });
    try {
      final result = await NativeBridge.exportProject(widget.project, _height);
      if (mounted) setState(() => _completed = result);
    } on PlatformException catch (error) {
      if (mounted) {
        setState(() {
          _error = error.code == 'export_cancelled'
              ? 'تم إلغاء التصدير.'
              : error.message ?? 'تعذّر إكمال التصدير.';
        });
      }
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر إكمال التصدير: $error');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visualCount = widget.project.videoTrack.length;
    final audioCount = widget.project.audioTrack.length;
    return Scaffold(
      appBar: AppBar(title: const Text('تصدير الفيديو')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ملخص المشروع',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.project.name,
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 4),
                  Text('$visualCount مقطع مرئي · $audioCount مقطع صوتي إضافي'),
                  const SizedBox(height: 10),
                  const Text(
                    'سيتم ترتيب المقاطع بقطع مباشر. معاينة النصوص والمؤثرات والانتقالات غير متاحة في هذه المرحلة.',
                    style: TextStyle(color: Color(0xFFAFBAC5), height: 1.45),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'دقة الإخراج',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          AbsorbPointer(
            absorbing: _exporting,
            child: RadioGroup<int>(
              groupValue: _height,
              onChanged: (value) {
                if (value != null) setState(() => _height = value);
              },
              child: const Card(
                child: Column(
                  children: [
                    RadioListTile<int>(
                      value: 720,
                      title: Text('720p'),
                      subtitle: Text('ارتفاع 720 بكسل · H.264 / AAC'),
                      activeColor: veloraGold,
                    ),
                    Divider(height: 1),
                    RadioListTile<int>(
                      value: 1080,
                      title: Text('1080p'),
                      subtitle: Text('ارتفاع 1080 بكسل · H.264 / AAC'),
                      activeColor: veloraGold,
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (_exporting)
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    const SizedBox.square(
                      dimension: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(child: Text('يجري إنشاء ملف MP4 على الجهاز…')),
                    TextButton.icon(
                      onPressed: _cancelExport,
                      icon: const Icon(Icons.cancel_outlined),
                      label: const Text('إلغاء'),
                    ),
                  ],
                ),
              ),
            ),
          if (_error != null)
            Card(
              color: const Color(0xFF3A2023),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  _error!,
                  style: const TextStyle(color: Color(0xFFFFD5D5)),
                ),
              ),
            ),
          if (_completed != null)
            Card(
              color: const Color(0xFF183228),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.check_circle_outline,
                          color: Color(0xFF91D9AF),
                        ),
                        SizedBox(width: 8),
                        Text(
                          'اكتمل التصدير',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    SelectableText(
                      (_completed!['path'] ?? _completed!['uri'] ?? '')
                          .toString(),
                      textDirection: TextDirection.ltr,
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'تحقق من تشغيل الملف وبياناته على جهاز Android قبل اعتماد النتيجة.',
                      style: TextStyle(fontSize: 12, color: Color(0xFFB9D5C4)),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _exporting ? null : _export,
            icon: _exporting
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.file_upload_outlined),
            label: Text(_exporting ? 'جارٍ التصدير…' : 'تصدير MP4'),
            style: FilledButton.styleFrom(
              backgroundColor: veloraGold,
              foregroundColor: veloraInk,
              padding: const EdgeInsets.symmetric(vertical: 15),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'التصدير يعتمد على ترميزات الجهاز؛ لا تغلق التطبيق حتى ينتهي. على Android 10 فأحدث يُحفظ الناتج في Movies/VELORA، وعلى الإصدارات الأقدم في مجلد التطبيق.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF9EABB7),
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}
