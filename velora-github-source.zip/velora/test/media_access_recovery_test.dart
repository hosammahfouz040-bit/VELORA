import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/services/media_access_recovery.dart';
import 'package:velora/src/services/native_bridge.dart';

const _nativeChannel = MethodChannel('velora/native');

MediaAsset _asset({
  String id = 'asset-1',
  String uri = 'content://provider/original',
  String name = 'source.mp4',
  MediaKind kind = MediaKind.video,
  int durationMs = 10000,
  String mimeType = 'video/mp4',
}) => MediaAsset(
  id: id,
  uri: uri,
  name: name,
  mimeType: mimeType,
  kind: kind,
  durationMs: durationMs,
  width: 1920,
  height: 1080,
  sizeBytes: 1234,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('turns a native access error into a reselectable reference', () {
    final issue = MediaAccessIssue.fromPlatformException(
      PlatformException(
        code: 'media_access_lost',
        details: {'assetId': 'asset-1', 'name': 'source.mp4', 'kind': 'video'},
      ),
    );

    expect(issue?.assetId, 'asset-1');
    expect(issue?.kind, MediaKind.video);
    expect(issue?.name, 'source.mp4');
    expect(issue?.isSticker, isFalse);
    expect(
      MediaAccessIssue.fromPlatformException(
        PlatformException(code: 'media_metadata_failed'),
      ),
      isNull,
    );
  });

  test('rebinds the same asset ID without changing trims or project identity', () {
    final project = VeloraProject(
      id: 'project-1',
      name: 'Keep this project',
      createdAt: '2026-01-01T00:00:00Z',
      assets: [_asset()],
      videoTrack: const [
        TimelineClip(
          id: 'clip-1',
          assetId: 'asset-1',
          trimStartMs: 1000,
          trimEndMs: 5000,
        ),
      ],
      audioTrack: const [],
    );
    final updated = replaceProjectAssetReference(
      project,
      assetId: 'asset-1',
      replacement: _asset(
        id: 'new-picker-id',
        uri: 'content://provider/replacement',
        name: 'replacement.mp4',
        durationMs: 8000,
      ),
    );

    expect(updated.id, project.id);
    expect(updated.name, project.name);
    expect(updated.assets, hasLength(1));
    expect(updated.assets.single.id, 'asset-1');
    expect(updated.assets.single.uri, 'content://provider/replacement');
    expect(updated.videoTrack.single.id, 'clip-1');
    expect(updated.videoTrack.single.assetId, 'asset-1');
    expect(updated.videoTrack.single.trimStartMs, 1000);
    expect(updated.videoTrack.single.trimEndMs, 5000);
    expect(project.assets.single.uri, 'content://provider/original');
  });

  test('rejects a shorter or wrong-kind replacement without mutating project', () {
    final project = VeloraProject(
      id: 'project-1',
      name: 'Project',
      createdAt: '',
      assets: [_asset()],
      videoTrack: const [
        TimelineClip(
          id: 'clip-1',
          assetId: 'asset-1',
          trimStartMs: 0,
          trimEndMs: 5000,
        ),
      ],
      audioTrack: const [],
    );

    expect(
      () => replaceProjectAssetReference(
        project,
        assetId: 'asset-1',
        replacement: _asset(durationMs: 4000),
      ),
      throwsFormatException,
    );
    expect(
      () => replaceProjectAssetReference(
        project,
        assetId: 'asset-1',
        replacement: _asset(kind: MediaKind.audio, mimeType: 'audio/mpeg'),
      ),
      throwsFormatException,
    );
    expect(project.assets.single.uri, 'content://provider/original');
  });

  test('replaces sticker URI while retaining sticker layout and timing', () {
    final sticker = StickerOverlay(
      id: 'sticker-1',
      uri: 'content://provider/lost.png',
      name: 'old.png',
      mimeType: 'image/png',
      startMs: 300,
      endMs: 2300,
      positionX: 0.2,
      positionY: 0.8,
      widthFraction: 0.4,
    );
    final project = VeloraProject.empty(id: 'project-1', name: 'Project')
        .copyWith(stickerOverlays: [sticker]);
    final updated = replaceProjectStickerReference(
      project,
      stickerId: 'sticker-1',
      replacement: _asset(
        id: 'picked-sticker',
        uri: 'content://provider/new.png',
        name: 'new.png',
        kind: MediaKind.image,
        mimeType: 'image/png',
      ),
    );

    final result = updated.stickerOverlays.single;
    expect(result.id, sticker.id);
    expect(result.uri, 'content://provider/new.png');
    expect(result.startMs, sticker.startMs);
    expect(result.endMs, sticker.endMs);
    expect(result.positionX, sticker.positionX);
    expect(result.positionY, sticker.positionY);
    expect(result.widthFraction, sticker.widthFraction);
    expect(project.stickerOverlays.single.uri, 'content://provider/lost.png');
  });

  test('replacement picker uses requested kind and decodes the chosen asset', () async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          expect(call.method, 'pickReplacementMedia');
          expect(call.arguments, {'kind': 'audio'});
          return _asset(
            id: 'picked',
            uri: 'content://provider/audio',
            name: 'voice.m4a',
            kind: MediaKind.audio,
            mimeType: 'audio/mp4',
          ).toMap();
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );

    final replacement = await NativeBridge.pickReplacementMedia(MediaKind.audio);
    expect(replacement?.kind, MediaKind.audio);
    expect(replacement?.uri, 'content://provider/audio');
  });
}
