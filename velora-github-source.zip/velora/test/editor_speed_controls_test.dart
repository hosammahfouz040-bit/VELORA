import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_support/target_platform.dart';

import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/screens/editor_screen.dart';

const _nativeChannel = MethodChannel('velora/native');

class _NativeRecorder {
  final savedProjects = <Map<String, dynamic>>[];

  void install() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          switch (call.method) {
            case 'saveProject':
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
              return null;
            case 'pausePreview':
            case 'clearPreview':
              return null;
            default:
              throw StateError('Unexpected native call: ${call.method}');
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );
  }
}

VeloraProject _project() => VeloraProject(
  id: 'speed-controls',
  name: 'Speed controls',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: const [
    MediaAsset(
      id: 'asset-1',
      uri: 'content://media/video/1',
      name: 'one.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 4_000,
      width: 640,
      height: 360,
      sizeBytes: 100,
    ),
    MediaAsset(
      id: 'asset-2',
      uri: 'content://media/video/2',
      name: 'two.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 4_000,
      width: 640,
      height: 360,
      sizeBytes: 100,
    ),
  ],
  videoTrack: const [
    TimelineClip(
      id: 'clip-1',
      assetId: 'asset-1',
      trimStartMs: 0,
      trimEndMs: 4_000,
    ),
    TimelineClip(
      id: 'clip-2',
      assetId: 'asset-2',
      trimStartMs: 0,
      trimEndMs: 4_000,
      speedRampPoints: [SpeedRampPoint(timeMs: 0, speed: 1.5)],
    ),
  ],
  audioTrack: const [],
);

void main() {
  testWidgetsOnPlatform(
    'edits the selected clip curve and supports undo and redo',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _NativeRecorder()..install();

      await tester.pumpWidget(
        MaterialApp(home: EditorScreen(project: _project())),
      );
      await tester.pump();
      final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip-1'));
      await tester.ensureVisible(clipTap);
      await tester.tap(clipTap);
      await tester.pumpAndSettle();

      expect(
        find.byKey(const ValueKey('clip-speed-controls-clip-1')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('clip-speed-controls-clip-2')),
        findsNothing,
      );
      final modeKey = const ValueKey('clip-speed-mode-clip-1');
      expect(
        tester.widget<DropdownButton<String>>(find.byKey(modeKey)).value,
        'normal',
      );

      tester.widget<DropdownButton<String>>(find.byKey(modeKey)).onChanged!(
        'accelerate',
      );
      await tester.pumpAndSettle();

      final firstSpeedKey = const ValueKey('clip-speed-point-speed-clip-1-0');
      var firstSpeed = tester.widget<Slider>(find.byKey(firstSpeedKey));
      expect(firstSpeed.min, 0.1);
      expect(firstSpeed.max, 8);
      expect(firstSpeed.divisions, 79);
      firstSpeed.onChanged!(0.8);
      await tester.pump();
      firstSpeed = tester.widget<Slider>(find.byKey(firstSpeedKey));
      firstSpeed.onChangeEnd!(0.8);
      await tester.pumpAndSettle();

      Map<String, dynamic> savedClip(int index) {
        final track = recorder.savedProjects.last['videoTrack'] as List;
        return Map<String, dynamic>.from(track[index] as Map);
      }

      List<Map<String, dynamic>> rampFor(int index) =>
          (savedClip(index)['speedRampPoints'] as List)
              .map((point) => Map<String, dynamic>.from(point as Map))
              .toList();

      expect(rampFor(0), [
        {'timeMs': 0, 'speed': 0.8},
        {'timeMs': 4_000, 'speed': 2.0},
      ]);
      expect(rampFor(1), [
        {'timeMs': 0, 'speed': 1.5},
      ]);
      expect(
        tester.widget<DropdownButton<String>>(find.byKey(modeKey)).value,
        'accelerate',
      );
      expect(find.textContaining('المدة بعد السرعة: 00:03.'), findsOneWidget);

      // Choosing a profile and then moving a curve point are separate edits.
      // One undo restores the profile defaults; the next restores normal speed.
      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(rampFor(0), [
        {'timeMs': 0, 'speed': 0.5},
        {'timeMs': 4_000, 'speed': 2.0},
      ]);
      expect(rampFor(1), [
        {'timeMs': 0, 'speed': 1.5},
      ]);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(rampFor(0), isEmpty);

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pumpAndSettle();
      expect(rampFor(0).first['speed'], 0.5);
      await tester.tap(find.byTooltip('إعادة'));
      await tester.pumpAndSettle();
      expect(rampFor(0).first['speed'], 0.8);
      expect(rampFor(1).single['speed'], 1.5);
    },
  );

  testWidgetsOnPlatform(
    'short trims cap their speed slider to a representable duration',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _NativeRecorder()..install();
      final source = _project();
      final shortProject = source.copyWith(
        videoTrack: [source.videoTrack.first.copyWith(trimEndMs: 5)],
      );

      await tester.pumpWidget(
        MaterialApp(home: EditorScreen(project: shortProject)),
      );
      await tester.pump();
      final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip-1'));
      await tester.ensureVisible(clipTap);
      await tester.tap(clipTap);
      await tester.pumpAndSettle();

      final modeKey = const ValueKey('clip-speed-mode-clip-1');
      tester.widget<DropdownButton<String>>(find.byKey(modeKey)).onChanged!(
        'constant',
      );
      await tester.pumpAndSettle();
      final slider = tester.widget<Slider>(
        find.byKey(const ValueKey('clip-speed-constant-clip-1')),
      );
      expect(slider.min, 0.1);
      expect(slider.max, 5);
      expect(slider.divisions, 49);
      expect(recorder.savedProjects, isEmpty);
    },
  );

  testWidgetsOnPlatform(
    'normal clip can open and save a constant speed slider',
    TargetPlatform.linux,
    (tester) async {
      final recorder = _NativeRecorder()..install();

      await tester.pumpWidget(
        MaterialApp(home: EditorScreen(project: _project())),
      );
      await tester.pump();
      final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip-1'));
      await tester.ensureVisible(clipTap);
      await tester.tap(clipTap);
      await tester.pumpAndSettle();

      final modeKey = const ValueKey('clip-speed-mode-clip-1');
      tester.widget<DropdownButton<String>>(find.byKey(modeKey)).onChanged!(
        'constant',
      );
      await tester.pumpAndSettle();
      final sliderKey = const ValueKey('clip-speed-constant-clip-1');
      var slider = tester.widget<Slider>(find.byKey(sliderKey));
      expect(slider.value, 1);
      expect(slider.min, 0.1);
      expect(slider.max, 8);
      expect(slider.divisions, 79);
      slider.onChanged!(100.0);
      await tester.pump();
      slider = tester.widget<Slider>(find.byKey(sliderKey));
      slider.onChangeEnd!(100.0);
      await tester.pumpAndSettle();

      final track = recorder.savedProjects.last['videoTrack'] as List;
      final first = Map<String, dynamic>.from(track.first as Map);
      final second = Map<String, dynamic>.from(track[1] as Map);
      final ramp = (first['speedRampPoints'] as List).single as Map;
      expect(ramp['speed'], 8.0);
      expect((second['speedRampPoints'] as List).single['speed'], 1.5);
    },
  );
}
