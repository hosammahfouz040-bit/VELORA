import 'project.dart';

/// A real, editable grade composed only from the Media3 color controls VELORA uses.
class VideoFilterPreset {
  const VideoFilterPreset({
    required this.id,
    required this.name,
    required this.description,
    required this.brightness,
    required this.contrast,
    required this.saturation,
    required this.warmth,
  });

  final String id;
  final String name;
  final String description;
  final double brightness;
  final double contrast;
  final double saturation;
  final double warmth;

  VideoColorSettings get settings => VideoColorSettings(
    brightness: brightness,
    contrast: contrast,
    saturation: saturation,
    warmth: warmth,
  );
}

/// Presets are starting points: the selected clip's sliders remain editable.
const videoFilterPresets = <VideoFilterPreset>[
  VideoFilterPreset(
    id: 'natural',
    name: 'طبيعي',
    description: 'تباين وتشبع خفيفان مع إبقاء توازن اللون محايدًا.',
    brightness: 0,
    contrast: 0.04,
    saturation: 6,
    warmth: 0,
  ),
  VideoFilterPreset(
    id: 'warm',
    name: 'دافئ',
    description: 'يرفع الأحمر ويخفض الأزرق قليلًا مع تشبع معتدل.',
    brightness: 0.015,
    contrast: 0.07,
    saturation: 10,
    warmth: 0.35,
  ),
  VideoFilterPreset(
    id: 'cool',
    name: 'بارد',
    description: 'يخفض الأحمر ويرفع الأزرق قليلًا مع تباين لطيف.',
    brightness: 0.01,
    contrast: 0.08,
    saturation: 6,
    warmth: -0.35,
  ),
  VideoFilterPreset(
    id: 'monochrome',
    name: 'أبيض وأسود',
    description: 'تشبع صفري فعليًا مع تباين مضبوط.',
    brightness: 0.015,
    contrast: 0.12,
    saturation: -100,
    warmth: 0,
  ),
  VideoFilterPreset(
    id: 'cinematic',
    name: 'سينمائي',
    description: 'تباين أعلى وتشبع أقل ولمسة دافئة؛ بلا حبيبات أو تعتيم حواف.',
    brightness: -0.015,
    contrast: 0.16,
    saturation: -18,
    warmth: 0.1,
  ),
];
