import 'dart:math' as math;

enum OverlayTextAlignment { start, center, end }

const overlayTextTemplateIds = <String>[
  'classic',
  'banner',
  'outline',
  'subtitle',
  'emoji',
];

const overlayFontFamilies = <String>[
  'sans-serif',
  'serif',
  'monospace',
  'sans-serif-condensed',
];

/// A template is a starting point only; every generated style remains editable.
String overlayTemplateName(String id) => switch (id) {
  'banner' => 'شريط',
  'outline' => 'حدّ وظل',
  'subtitle' => 'ترجمة سفلية',
  'emoji' => 'إيموجي',
  _ => 'كلاسيكي',
};

class TextOverlay {
  const TextOverlay({
    required this.id,
    required this.text,
    required this.startMs,
    required this.endMs,
    this.templateId = 'classic',
    this.fontFamily = 'sans-serif',
    this.fontSizeScale = 0.055,
    this.colorArgb = 0xFFFFFFFF,
    this.backgroundArgb,
    this.alignment = OverlayTextAlignment.center,
    this.shadow = true,
    this.outlineWidthScale = 0,
    this.outlineArgb = 0xFF000000,
    this.positionX = 0.5,
    this.positionY = 0.5,
  });

  final String id;
  final String text;
  final int startMs;
  final int endMs;
  final String templateId;
  final String fontFamily;
  /// Font size as a fraction of the output frame height.
  final double fontSizeScale;
  final int colorArgb;
  final int? backgroundArgb;
  final OverlayTextAlignment alignment;
  final bool shadow;
  /// Outline width as a fraction of the output frame height.
  final double outlineWidthScale;
  final int outlineArgb;
  /// Normalized center position, 0..1 from left/top.
  final double positionX;
  final double positionY;

  bool isVisibleAt(int positionMs) => positionMs >= startMs && positionMs < endMs;

  TextOverlay copyWith({
    String? text,
    int? startMs,
    int? endMs,
    String? templateId,
    String? fontFamily,
    double? fontSizeScale,
    int? colorArgb,
    int? backgroundArgb,
    bool clearBackground = false,
    OverlayTextAlignment? alignment,
    bool? shadow,
    double? outlineWidthScale,
    int? outlineArgb,
    double? positionX,
    double? positionY,
  }) => TextOverlay(
    id: id,
    text: text ?? this.text,
    startMs: (startMs ?? this.startMs).clamp(0, 1 << 53).toInt(),
    endMs: (endMs ?? this.endMs).clamp(0, 1 << 53).toInt(),
    templateId: overlayTextTemplateIds.contains(templateId)
        ? templateId!
        : this.templateId,
    fontFamily: overlayFontFamilies.contains(fontFamily)
        ? fontFamily!
        : this.fontFamily,
    fontSizeScale: (fontSizeScale ?? this.fontSizeScale).clamp(0.02, 0.15).toDouble(),
    colorArgb: colorArgb ?? this.colorArgb,
    backgroundArgb: clearBackground
        ? null
        : backgroundArgb ?? this.backgroundArgb,
    alignment: alignment ?? this.alignment,
    shadow: shadow ?? this.shadow,
    outlineWidthScale: (outlineWidthScale ?? this.outlineWidthScale)
        .clamp(0, 0.02)
        .toDouble(),
    outlineArgb: outlineArgb ?? this.outlineArgb,
    positionX: _unit(positionX ?? this.positionX),
    positionY: _unit(positionY ?? this.positionY),
  );

  factory TextOverlay.fromMap(Map<String, dynamic> map) => TextOverlay(
    id: map['id'] as String? ?? _overlayId(),
    text: map['text'] as String? ?? '',
    startMs: _nonNegativeInt(map['startMs']),
    endMs: _nonNegativeInt(map['endMs']),
    templateId: overlayTextTemplateIds.contains(map['templateId'])
        ? map['templateId'] as String
        : 'classic',
    fontFamily: overlayFontFamilies.contains(map['fontFamily'])
        ? map['fontFamily'] as String
        : 'sans-serif',
    fontSizeScale: _boundedDouble(map['fontSizeScale'], 0.055, 0.02, 0.15),
    colorArgb: (map['colorArgb'] as num?)?.toInt() ?? 0xFFFFFFFF,
    backgroundArgb: (map['backgroundArgb'] as num?)?.toInt(),
    alignment: OverlayTextAlignment.values.firstWhere(
      (value) => value.name == map['alignment'],
      orElse: () => OverlayTextAlignment.center,
    ),
    shadow: map['shadow'] as bool? ?? true,
    outlineWidthScale: _boundedDouble(map['outlineWidthScale'], 0, 0, 0.02),
    outlineArgb: (map['outlineArgb'] as num?)?.toInt() ?? 0xFF000000,
    positionX: _boundedDouble(map['positionX'], 0.5, 0, 1),
    positionY: _boundedDouble(map['positionY'], 0.5, 0, 1),
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'text': text,
    'startMs': startMs,
    'endMs': endMs,
    'templateId': templateId,
    'fontFamily': fontFamily,
    'fontSizeScale': fontSizeScale,
    'colorArgb': colorArgb,
    'backgroundArgb': backgroundArgb,
    'alignment': alignment.name,
    'shadow': shadow,
    'outlineWidthScale': outlineWidthScale,
    'outlineArgb': outlineArgb,
    'positionX': positionX,
    'positionY': positionY,
  };
}

TextOverlay applyTextTemplate(TextOverlay item, String templateId) {
  final base = item.copyWith(templateId: templateId);
  return switch (templateId) {
    'banner' => base.copyWith(
      fontSizeScale: 0.052,
      colorArgb: 0xFFFFFFFF,
      backgroundArgb: 0xB8000000,
      alignment: OverlayTextAlignment.center,
      shadow: false,
      outlineWidthScale: 0,
    ),
    'outline' => base.copyWith(
      fontSizeScale: 0.07,
      colorArgb: 0xFFFFD166,
      clearBackground: true,
      shadow: true,
      outlineWidthScale: 0.004,
      outlineArgb: 0xFF111820,
    ),
    'emoji' => base.copyWith(
      fontSizeScale: 0.14,
      colorArgb: 0xFFFFFFFF,
      clearBackground: true,
      shadow: false,
      outlineWidthScale: 0,
      alignment: OverlayTextAlignment.center,
    ),
    'subtitle' => base.copyWith(
      fontSizeScale: 0.045,
      colorArgb: 0xFFFFFFFF,
      backgroundArgb: 0xAA000000,
      alignment: OverlayTextAlignment.center,
      shadow: true,
      outlineWidthScale: 0,
      positionY: 0.88,
    ),
    _ => base.copyWith(
      fontSizeScale: 0.055,
      colorArgb: 0xFFFFFFFF,
      clearBackground: true,
      alignment: OverlayTextAlignment.center,
      shadow: true,
      outlineWidthScale: 0,
    ),
  };
}

/// One timestamped result emitted by an ASR engine, in the project clock.
/// The engine adapter must map media-local timestamps before creating this value.
class TimedSpeechSegment {
  const TimedSpeechSegment({
    required this.text,
    required this.startMs,
    required this.endMs,
  });

  final String text;
  final int startMs;
  final int endMs;
}

class SubtitleCue {
  const SubtitleCue({
    required this.id,
    required this.text,
    required this.startMs,
    required this.endMs,
  });

  final String id;
  final String text;
  final int startMs;
  final int endMs;

  bool isVisibleAt(int positionMs) => positionMs >= startMs && positionMs < endMs;

  SubtitleCue copyWith({String? text, int? startMs, int? endMs}) => SubtitleCue(
    id: id,
    text: text ?? this.text,
    startMs: (startMs ?? this.startMs).clamp(0, 1 << 53).toInt(),
    endMs: (endMs ?? this.endMs).clamp(0, 1 << 53).toInt(),
  );

  factory SubtitleCue.fromMap(Map<String, dynamic> map) => SubtitleCue(
    id: map['id'] as String? ?? _overlayId(),
    text: map['text'] as String? ?? '',
    startMs: _nonNegativeInt(map['startMs']),
    endMs: _nonNegativeInt(map['endMs']),
  );

  Map<String, Object> toMap() => {
    'id': id,
    'text': text,
    'startMs': startMs,
    'endMs': endMs,
  };

  /// Serialize valid cues in sorted SRT order. Cue ids are intentionally not exported.
  static String toSrt(Iterable<SubtitleCue> source) {
    final cues = source
        .where((cue) =>
            cue.startMs >= 0 &&
            cue.endMs > cue.startMs &&
            cue.endMs <= (1 << 53) &&
            cue.text.trim().isNotEmpty)
        .toList()
      ..sort((a, b) {
        final byStart = a.startMs.compareTo(b.startMs);
        return byStart != 0 ? byStart : a.endMs.compareTo(b.endMs);
      });
    if (cues.isEmpty) return '';
    final blocks = <String>[];
    for (var index = 0; index < cues.length; index++) {
      final cue = cues[index];
      final text = cue.text
          .replaceAll('\r\n', '\n')
          .replaceAll('\r', '\n')
          .trim();
      blocks.add(
        '${index + 1}\n'
        '${_formatSrtTime(cue.startMs)} --> ${_formatSrtTime(cue.endMs)}\n'
        '$text',
      );
    }
    return '${blocks.join('\n\n')}\n';
  }

  static List<SubtitleCue> parseSrt(String source) {
    final normalized = source.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final blocks = normalized.split(RegExp(r'\n\s*\n+'));
    final cues = <SubtitleCue>[];
    final timePattern = RegExp(
      r'(\d+:)?\d{2}:\d{2}[,.]\d{3}\s*-->\s*(\d+:)?\d{2}:\d{2}[,.]\d{3}',
    );
    for (final block in blocks) {
      final lines = block.split('\n');
      final timeIndex = lines.indexWhere((line) => timePattern.hasMatch(line));
      if (timeIndex < 0) continue;
      final pieces = lines[timeIndex].split('-->');
      if (pieces.length != 2) continue;
      final start = _parseSrtTime(pieces[0].trim());
      final end = _parseSrtTime(pieces[1].trim().split(RegExp(r'\s+')).first);
      final body = lines.skip(timeIndex + 1).join('\n').trim();
      if (start == null || end == null || end <= start || body.isEmpty) continue;
      final cleanText = body
          .replaceAll(RegExp(r'<[^>]*>'), '')
          .replaceAll(RegExp(r'\{\\[^}]*\}'), '')
          .trim();
      if (cleanText.isEmpty) continue;
      cues.add(SubtitleCue(
        id: _overlayId(),
        text: cleanText,
        startMs: start,
        endMs: end,
      ));
    }
    cues.sort((a, b) => a.startMs.compareTo(b.startMs));
    return cues;
  }
}

/// Convert ASR output into editable subtitle cues without inventing word timing.
/// Timestamps are clamped to [durationMs]; empty/reversed segments and spans
/// wholly outside the project are discarded. The caller submits these cues as one project
/// edit so the existing project history keeps generation undoable.
List<SubtitleCue> subtitleCuesFromSpeechSegments(
  Iterable<TimedSpeechSegment> segments, {
  required int durationMs,
}) {
  final safeDurationMs = durationMs.clamp(0, 1 << 53).toInt();
  if (safeDurationMs == 0) return const [];
  final cues = <SubtitleCue>[];
  for (final segment in segments) {
    final text = segment.text.trim();
    if (text.isEmpty) continue;
    final startMs = segment.startMs.clamp(0, safeDurationMs).toInt();
    final endMs = segment.endMs.clamp(0, safeDurationMs).toInt();
    if (endMs <= startMs) continue;
    cues.add(SubtitleCue(
      id: _overlayId(),
      text: text,
      startMs: startMs,
      endMs: endMs,
    ));
  }
  cues.sort((a, b) {
    final byStart = a.startMs.compareTo(b.startMs);
    return byStart != 0 ? byStart : a.endMs.compareTo(b.endMs);
  });
  return cues;
}

class StickerOverlay {
  const StickerOverlay({
    required this.id,
    required this.uri,
    required this.name,
    required this.mimeType,
    required this.startMs,
    required this.endMs,
    this.positionX = 0.5,
    this.positionY = 0.5,
    this.widthFraction = 0.22,
  });

  final String id;
  final String uri;
  final String name;
  final String mimeType;
  final int startMs;
  final int endMs;
  final double positionX;
  final double positionY;
  /// Sticker width relative to the output frame width.
  final double widthFraction;

  bool isVisibleAt(int positionMs) => positionMs >= startMs && positionMs < endMs;

  StickerOverlay copyWith({
    int? startMs,
    int? endMs,
    double? positionX,
    double? positionY,
    double? widthFraction,
  }) => StickerOverlay(
    id: id,
    uri: uri,
    name: name,
    mimeType: mimeType,
    startMs: (startMs ?? this.startMs).clamp(0, 1 << 53).toInt(),
    endMs: (endMs ?? this.endMs).clamp(0, 1 << 53).toInt(),
    positionX: _unit(positionX ?? this.positionX),
    positionY: _unit(positionY ?? this.positionY),
    widthFraction: (widthFraction ?? this.widthFraction).clamp(0.03, 0.8).toDouble(),
  );

  factory StickerOverlay.fromMap(Map<String, dynamic> map) => StickerOverlay(
    id: map['id'] as String? ?? _overlayId(),
    uri: map['uri'] as String? ?? '',
    name: map['name'] as String? ?? 'ملصق',
    mimeType: map['mimeType'] as String? ?? 'image/png',
    startMs: _nonNegativeInt(map['startMs']),
    endMs: _nonNegativeInt(map['endMs']),
    positionX: _boundedDouble(map['positionX'], 0.5, 0, 1),
    positionY: _boundedDouble(map['positionY'], 0.5, 0, 1),
    widthFraction: _boundedDouble(map['widthFraction'], 0.22, 0.03, 0.8),
  );

  Map<String, Object> toMap() => {
    'id': id,
    'uri': uri,
    'name': name,
    'mimeType': mimeType,
    'startMs': startMs,
    'endMs': endMs,
    'positionX': positionX,
    'positionY': positionY,
    'widthFraction': widthFraction,
  };
}

String _formatSrtTime(int timeMs) {
  String padded(int value, int width) => value.toString().padLeft(width, '0');

  final hours = timeMs ~/ 3600000;
  final minutes = (timeMs ~/ 60000) % 60;
  final seconds = (timeMs ~/ 1000) % 60;
  final millis = timeMs % 1000;
  return '${padded(hours, 2)}:'
      '${padded(minutes, 2)}:'
      '${padded(seconds, 2)},'
      '${padded(millis, 3)}';
}

int? _parseSrtTime(String raw) {
  final match = RegExp(r'^(?:(\d+):)?(\d{2}):(\d{2})[,.](\d{3})$').firstMatch(raw);
  if (match == null) return null;
  final hours = int.tryParse(match.group(1) ?? '0') ?? 0;
  final minutes = int.tryParse(match.group(2)!) ?? 0;
  final seconds = int.tryParse(match.group(3)!) ?? 0;
  final millis = int.tryParse(match.group(4)!) ?? 0;
  if (minutes > 59 || seconds > 59) return null;
  return (((hours * 60 + minutes) * 60 + seconds) * 1000) + millis;
}

String _overlayId() => 'overlay_${DateTime.now().microsecondsSinceEpoch}_${math.Random().nextInt(1 << 20)}';

int _nonNegativeInt(Object? value) => ((value as num?)?.toInt() ?? 0).clamp(0, 1 << 53).toInt();

double _boundedDouble(Object? value, double fallback, double min, double max) {
  final number = (value as num?)?.toDouble() ?? fallback;
  return number.isFinite ? number.clamp(min, max).toDouble() : fallback;
}

double _unit(double value) => value.isFinite ? value.clamp(0, 1).toDouble() : 0.5;
