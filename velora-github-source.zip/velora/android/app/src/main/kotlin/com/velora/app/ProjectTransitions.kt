package com.velora.app

import androidx.media3.common.C
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence

@UnstableApi
internal data class TransitionClipWindow(
    val id: String,
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val motion: ProjectClipTiming,
) {
    val durationMs: Long get() = endMs - startMs
}

@UnstableApi
internal data class TransitionSpec(
    val type: String,
    val durationMs: Long,
    val direction: String,
    val intensity: Float,
)

@UnstableApi
internal data class TransitionWindow(
    val boundaryIndex: Int,
    val startMs: Long,
    val endMs: Long,
    val spec: TransitionSpec,
) {
    val durationMs: Long get() = endMs - startMs
}

/**
 * Native composition schedule shared by CompositionPlayer preview and Transformer export.
 * Media3 has no first-class transition object in Composition; each clip is a video-only
 * sequence and time-varying OverlaySettings implement transitions and clip transforms.
 */
@UnstableApi
internal class ProjectTransitionPlan private constructor(
    val clipWindows: List<TransitionClipWindow>,
    val transitionWindows: Map<Int, TransitionWindow>,
    val primaryVideoSequence: EditedMediaItemSequence,
    val videoSequences: List<EditedMediaItemSequence>,
    val totalDurationMs: Long,
) {
    val hasTransitions: Boolean get() = transitionWindows.isNotEmpty()
    val mainVideoInputCount: Int get() = clipWindows.size

    /** Input ids are local: clips are registered newest-first (topmost first). */
    fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
        if (inputId !in 0 until clipWindows.size) return hiddenSettings()
        val clipIndex = clipWindows.lastIndex - inputId
        val clip = clipWindows[clipIndex]
        val timeMs = presentationTimeUs.coerceAtLeast(0L) / 1_000L
        if (timeMs < clip.startMs || timeMs >= clip.endMs) return hiddenSettings()

        val incoming = transitionWindows[clipIndex - 1]
            ?.takeIf { timeMs >= it.startMs && timeMs < it.endMs }
        val outgoing = transitionWindows[clipIndex]
            ?.takeIf { timeMs >= it.startMs && timeMs < it.endMs }
        val active = incoming ?: outgoing
        val transitionTransform = if (active == null) {
            TransitionFrameTransform()
        } else {
            val progress = ((timeMs - active.startMs).toFloat() / active.durationMs.coerceAtLeast(1L))
                .coerceIn(0f, 1f)
            transitionFrameTransform(
                type = active.spec.type,
                isIncoming = incoming != null,
                progress = progress,
                direction = active.spec.direction,
                intensity = active.spec.intensity,
            ) ?: TransitionFrameTransform()
        }
        val localOutputMs = (timeMs - clip.startMs).coerceIn(0L, clip.durationMs)
        val localSourceMs = clip.motion.trimStartMs + clip.motion.sourceOffsetAtOutputMs(localOutputMs)
        val keyframe = evaluateTransformKeyframes(clip.motion.transformKeyframes, localSourceMs)
        return StaticOverlaySettings.Builder()
            .setAlphaScale((transitionTransform.alpha * keyframe.opacity).coerceIn(0f, 1f))
            .setScale(
                transitionTransform.scaleX * keyframe.scale,
                transitionTransform.scaleY * keyframe.scale,
            )
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(
                (transitionTransform.anchorX + keyframe.x).coerceIn(-1f, 1f),
                (transitionTransform.anchorY - keyframe.y).coerceIn(-1f, 1f),
            )
            .setRotationDegrees(transitionTransform.rotationDegrees - keyframe.rotationDegrees)
            .build()
    }

    /**
     * Maps project-time overlays to the shortened composition clock. A 2D window around a
     * cut maps to the D-ms overlap. The transform is monotone and keeps overlay endpoints aligned.
     */
    fun mapOriginalTimeMs(originalTimeMs: Long, originalDurationsMs: List<Long>): Long {
        var originalCutMs = 0L
        var compressedBeforeMs = 0L
        for (boundary in 0 until clipWindows.lastIndex) {
            originalCutMs += originalDurationsMs.getOrElse(boundary) { 0L }.coerceAtLeast(0L)
            val transition = transitionWindows[boundary] ?: continue
            val overlap = transition.durationMs
            val start = originalCutMs - overlap
            val end = originalCutMs + overlap
            if (originalTimeMs <= start) break
            if (originalTimeMs < end) {
                val progress = originalTimeMs - start
                return (start - compressedBeforeMs + progress / 2L)
                    .coerceIn(0L, totalDurationMs)
            }
            compressedBeforeMs += overlap
        }
        return (originalTimeMs - compressedBeforeMs).coerceIn(0L, totalDurationMs)
    }

    companion object {
        private val supportedTypes = setOf("fade", "dissolve", "slide", "zoom", "spin")

        fun create(
            visualClips: List<Map<String, Any?>>,
            visualItems: List<EditedMediaItem>,
            transitionRows: List<Map<String, Any?>>,
            adjustedClipDurationsMs: List<Long> = visualClips.map { row ->
                ((row["trimEndMs"] as? Number)?.toLong() ?: 0L) -
                    ((row["trimStartMs"] as? Number)?.toLong() ?: 0L)
            },
            clockItemFactory: (Long) -> EditedMediaItem,
        ): ProjectTransitionPlan? {
            if (visualClips.isEmpty() || visualItems.size != visualClips.size) return null
            val hasTransformKeyframes = visualClips.any { clip ->
                !(clip["transformKeyframes"] as? List<*>).isNullOrEmpty()
            }
            // Keep the legacy one-clip path unchanged unless that clip actually needs
            // transform animation. Keyframes must not depend on a second clip/transition.
            if (visualClips.size < 2 && !hasTransformKeyframes) return null
            require(adjustedClipDurationsMs.size == visualClips.size) {
                "Adjusted visual clip durations do not match the visual track"
            }
            val durations = adjustedClipDurationsMs.map { it.coerceAtLeast(0L) }
            val timings = visualClips.map { ProjectClipMotion.timingFromMap(it) }
            val hasClipMotion = visualClips.any { ProjectClipMotion.hasMotion(it) }
            val byBoundary = mutableMapOf<Int, TransitionSpec>()
            val occupied = MutableList(durations.size) { 0L }
            for (boundary in 0 until visualClips.lastIndex) {
                val fromId = visualClips[boundary]["id"]?.toString().orEmpty()
                val toId = visualClips[boundary + 1]["id"]?.toString().orEmpty()
                val row = transitionRows.firstOrNull {
                    it["fromClipId"]?.toString() == fromId && it["toClipId"]?.toString() == toId
                } ?: continue
                val type = row["type"]?.toString().orEmpty()
                if (type !in supportedTypes) continue
                val duration = (row["durationMs"] as? Number)?.toLong() ?: 0L
                // Match the Dart planner: malformed durations are ignored, not silently
                // shortened, so preview, editor clock and export cannot disagree.
                if (duration <= 0L || duration > durations[boundary] || duration > durations[boundary + 1]) continue
                if (occupied[boundary] + duration > durations[boundary] ||
                    occupied[boundary + 1] + duration > durations[boundary + 1]
                ) continue
                occupied[boundary] += duration
                occupied[boundary + 1] += duration
                byBoundary[boundary] = TransitionSpec(
                    type = type,
                    durationMs = duration,
                    direction = row["direction"]?.toString()?.takeIf {
                        it in setOf("left", "right", "up", "down")
                    } ?: "right",
                    intensity = ((row["intensity"] as? Number)?.toFloat() ?: 1f)
                        .let { if (it.isFinite()) it.coerceIn(0f, 1f) else 1f },
                )
            }
            if (byBoundary.isEmpty() && !hasClipMotion) return null

            val windows = mutableListOf<TransitionClipWindow>()
            val transitionWindows = mutableMapOf<Int, TransitionWindow>()
            var cursorMs = 0L
            for (index in visualClips.indices) {
                val id = visualClips[index]["id"]?.toString() ?: "clip-$index"
                val duration = durations[index].coerceAtLeast(0L)
                windows += TransitionClipWindow(
                    id = id,
                    index = index,
                    startMs = cursorMs,
                    endMs = cursorMs + duration,
                    motion = timings[index],
                )
                cursorMs += duration
                val spec = byBoundary[index]
                if (spec != null) {
                    cursorMs -= spec.durationMs
                    transitionWindows[index] = TransitionWindow(
                        boundaryIndex = index,
                        startMs = cursorMs,
                        endMs = cursorMs + spec.durationMs,
                        spec = spec,
                    )
                }
            }

            val totalDurationMs = cursorMs
            // A hidden primary stream anchors composition timestamps. The compositor clears
            // its output to black, so a separate 4x4 "matte" layer would not cover the frame.
            val primarySequence = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                .addItem(clockItemFactory(totalDurationMs))
                .build()
            val sequences = mutableListOf<EditedMediaItemSequence>()
            // Media3 draws the first registered input on top, so later clips are ordered first.
            for (clipIndex in visualItems.indices.reversed()) {
                val window = windows[clipIndex]
                val builder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                if (window.startMs > 0L) builder.addGap(window.startMs * 1_000L)
                builder.addItem(visualItems[clipIndex])
                sequences += builder.build()
            }
            return ProjectTransitionPlan(
                windows,
                transitionWindows,
                primarySequence,
                sequences,
                totalDurationMs,
            )
        }

        private fun neutralSettings(): OverlaySettings = StaticOverlaySettings.Builder().build()
        private fun hiddenSettings(): OverlaySettings = StaticOverlaySettings.Builder().setAlphaScale(0f).build()

    }
}
