import 'project.dart';

/// Session-scoped, bounded undo/redo history for complete project snapshots.
/// Snapshots are serialized through the existing model map so later edits to
/// mutable collection instances cannot alter earlier history entries.
class ProjectHistory {
  ProjectHistory(
    VeloraProject initialProject, {
    this.maxEntries = 50,
  }) : assert(maxEntries >= 2),
       _snapshots = [_snapshot(initialProject)];

  final int maxEntries;
  final List<VeloraProject> _snapshots;
  int _currentIndex = 0;

  bool get canUndo => _currentIndex > 0;
  bool get canRedo => _currentIndex < _snapshots.length - 1;

  void record(VeloraProject project) {
    if (canRedo) {
      _snapshots.removeRange(_currentIndex + 1, _snapshots.length);
    }
    _snapshots.add(_snapshot(project));
    if (_snapshots.length > maxEntries) {
      _snapshots.removeAt(0);
    }
    _currentIndex = _snapshots.length - 1;
  }

  VeloraProject? undo() {
    if (!canUndo) return null;
    _currentIndex--;
    return _snapshot(_snapshots[_currentIndex]);
  }

  VeloraProject? redo() {
    if (!canRedo) return null;
    _currentIndex++;
    return _snapshot(_snapshots[_currentIndex]);
  }

  static VeloraProject _snapshot(VeloraProject project) =>
      VeloraProject.fromMap(project.toMap());
}
