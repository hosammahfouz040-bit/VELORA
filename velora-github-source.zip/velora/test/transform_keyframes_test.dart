import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_position.dart';

VeloraProject _project({List<TimelineClip>? clips}) => VeloraProject(
  id: 'keyframe-project',
  name: 'Keyframe project',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: const [
    MediaAsset(
      id: 'asset',
      uri: 'content://media/video/1',
      name: 'clip.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 6000,
      width: 1920,
      height: 1080,
      sizeBytes: 10,
    ),
  ],
  videoTrack: clips ?? const [],
  audioTrack: const [],
);

void main() {
  group('clip transform keyframes', () {
    test('normalizes by absolute source time and keeps the last duplicate', () {
      final frames = normalizeTransformKeyframes([
        const ClipTransformKeyframe(timeMs: 2000, positionX: 0.7),
        const ClipTransformKeyframe(timeMs: 1000, positionX: -0.5),
        const ClipTransformKeyframe(timeMs: 2000, positionX: 0.3),
        const ClipTransformKeyframe(timeMs: 3000, scale: 99, opacity: -1),
      ]);

      expect(frames.map((frame) => frame.timeMs), [1000, 2000, 3000]);
      expect(frames[1].positionX, 0.3);
      expect(frames[2].scale, 10);
      expect(frames[2].opacity, 0);
    });

    test('evaluates position, uniform scale, rotation and opacity between source times', () {
      const frames = [
        ClipTransformKeyframe(
          timeMs: 1000,
          positionX: -0.5,
          positionY: 0.2,
          scale: 1,
          rotationDegrees: -30,
          opacity: 0.4,
          interpolation: MotionInterpolation.linear,
        ),
        ClipTransformKeyframe(
          timeMs: 3000,
          positionX: 0.5,
          positionY: 0.8,
          scale: 3,
          rotationDegrees: 90,
          opacity: 1,
        ),
      ];

      final middle = evaluateTransformKeyframes(frames, 2000);
      expect(middle.positionX, 0);
      expect(middle.positionY, 0.5);
      expect(middle.scale, 2);
      expect(middle.rotationDegrees, 30);
      expect(middle.opacity, 0.7);
      expect(evaluateTransformKeyframes(frames, 0).positionX, -0.5);
      expect(evaluateTransformKeyframes(frames, 4000).scale, 3);
    });

    test('project serialization preserves keyframes and old projects default to none', () {
      final clip = const TimelineClip(
        id: 'clip',
        assetId: 'asset',
        trimStartMs: 1000,
        trimEndMs: 5000,
        transformKeyframes: [
          ClipTransformKeyframe(
            timeMs: 1200,
            positionX: 0.25,
            positionY: -0.2,
            scale: 1.5,
            rotationDegrees: 45,
            opacity: 0.8,
            interpolation: MotionInterpolation.linear,
          ),
        ],
      );
      final project = _project(clips: [clip]);
      final restored = VeloraProject.fromMap(project.toMap());
      final restoredFrame = restored.videoTrack.single.transformKeyframes.single;

      expect(restoredFrame.toMap(), clip.transformKeyframes.single.toMap());

      final oldClipMap = clip.toMap()..remove('transformKeyframes');
      final oldProjectMap = project.toMap()
        ..['videoTrack'] = [oldClipMap];
      final oldRestored = VeloraProject.fromMap(oldProjectMap);
      expect(oldRestored.videoTrack.single.transformKeyframes, isEmpty);
    });

    test('playhead source timestamp follows the same speed clock as keyframes', () {
      final clip = const TimelineClip(
        id: 'clip',
        assetId: 'asset',
        trimStartMs: 1000,
        trimEndMs: 5000,
        speedRampPoints: [
          SpeedRampPoint(timeMs: 1000, speed: 1),
          SpeedRampPoint(timeMs: 5000, speed: 2),
        ],
        transformKeyframes: [
          ClipTransformKeyframe(timeMs: 1000),
          ClipTransformKeyframe(timeMs: 5000, positionX: 1),
        ],
      );
      final position = timelinePositionAt([clip], 1000)!;

      expect(position.clipId, 'clip');
      expect(position.sourcePositionMs, outputOffsetToSourceMs(
        1000, 1000, 5000, clip.speedRampPoints,
      ) + clip.trimStartMs);
      expect(position.sourcePositionMs, greaterThan(1000));
      expect(position.sourcePositionMs, lessThan(5000));
    });

    test('playhead at double speed evaluates a keyframe at the matching source time', () {
      const clip = TimelineClip(
        id: 'clip',
        assetId: 'asset',
        trimStartMs: 1000,
        trimEndMs: 5000,
        speedRampPoints: [SpeedRampPoint(timeMs: 1000, speed: 2)],
        transformKeyframes: [
          ClipTransformKeyframe(
            timeMs: 1000,
            positionX: 0,
            interpolation: MotionInterpolation.linear,
          ),
          ClipTransformKeyframe(
            timeMs: 5000,
            positionX: 1,
            interpolation: MotionInterpolation.linear,
          ),
        ],
      );
      final playhead = timelinePositionAt([clip], 1000)!;

      // Integer output milliseconds can represent adjacent source milliseconds;
      // the inverse clock resolves that quantization to the earlier source time.
      expect(playhead.sourcePositionMs, 2999);
      expect(
        evaluateTransformKeyframes(clip.transformKeyframes, playhead.sourcePositionMs).positionX,
        closeTo(0.5, 0.0003),
      );
    });

    test('history undo and redo retain edited keyframe values and timing', () {
      const initialClip = TimelineClip(
        id: 'clip',
        assetId: 'asset',
        trimStartMs: 0,
        trimEndMs: 5000,
      );
      const initial = ClipTransformKeyframe(timeMs: 1000, positionX: 0);
      const edited = ClipTransformKeyframe(
        timeMs: 1250,
        positionX: 0.75,
        scale: 2,
        rotationDegrees: 45,
      );
      final history = ProjectHistory(_project(clips: [initialClip]));
      history.record(_project(clips: [initialClip.copyWith(transformKeyframes: [initial])]));
      history.record(_project(clips: [initialClip.copyWith(transformKeyframes: [edited])]));

      expect(history.undo()!.videoTrack.single.transformKeyframes.single.timeMs, 1000);
      final redone = history.redo()!.videoTrack.single.transformKeyframes.single;
      expect(redone.timeMs, 1250);
      expect(redone.positionX, 0.75);
      expect(redone.scale, 2);
      expect(redone.rotationDegrees, 45);
    });
  });
}
