import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_support/target_platform.dart';

import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_overlays.dart';
import 'package:velora/src/models/video_transitions.dart';
import 'package:velora/src/screens/editor_screen.dart';
import 'package:velora/src/widgets/editor_timeline.dart';

const _timelineProject = VeloraProject(
  id: 'timeline-widget-test',
  name: 'اختبار الخط الزمني',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [
    MediaAsset(
      id: 'video-asset-1',
      uri: 'content://media/video/1',
      name: 'الأول.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1000,
      width: 1920,
      height: 1080,
      sizeBytes: 100,
    ),
    MediaAsset(
      id: 'video-asset-2',
      uri: 'content://media/video/2',
      name: 'الثاني.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 2000,
      width: 1920,
      height: 1080,
      sizeBytes: 120,
    ),
    MediaAsset(
      id: 'audio-asset-1',
      uri: 'content://media/audio/1',
      name: 'موسيقى.m4a',
      mimeType: 'audio/mp4',
      kind: MediaKind.audio,
      durationMs: 3000,
      width: 0,
      height: 0,
      sizeBytes: 80,
    ),
    MediaAsset(
      id: 'audio-asset-2',
      uri: 'content://media/audio/2',
      name: 'مؤثر.m4a',
      mimeType: 'audio/mp4',
      kind: MediaKind.audio,
      durationMs: 800,
      width: 0,
      height: 0,
      sizeBytes: 40,
    ),
  ],
  videoTrack: [
    TimelineClip(
      id: 'video-clip-1',
      assetId: 'video-asset-1',
      trimStartMs: 0,
      trimEndMs: 1000,
    ),
    TimelineClip(
      id: 'video-clip-2',
      assetId: 'video-asset-2',
      trimStartMs: 0,
      trimEndMs: 2000,
      speedRampPoints: [
        SpeedRampPoint(timeMs: 0, speed: 1),
        SpeedRampPoint(timeMs: 2000, speed: 2),
      ],
    ),
  ],
  audioTrack: [
    TimelineClip(
      id: 'audio-clip-1',
      assetId: 'audio-asset-1',
      trimStartMs: 0,
      trimEndMs: 3000,
      timelineStartMs: 750,
    ),
    TimelineClip(
      id: 'audio-clip-2',
      assetId: 'audio-asset-2',
      trimStartMs: 0,
      trimEndMs: 800,
      timelineStartMs: 1100,
    ),
  ],
  videoTransitions: [
    VideoTransition(
      id: 'transition-1-2',
      fromClipId: 'video-clip-1',
      toClipId: 'video-clip-2',
      type: VideoTransitionType.fade,
      durationMs: 200,
    ),
  ],
);

double _timelineScrollOffset(WidgetTester tester) {
  final scrollable = find
      .descendant(
        of: find.byKey(const ValueKey('timeline-scroll-view')),
        matching: find.byType(Scrollable),
      )
      .first;
  return tester.state<ScrollableState>(scrollable).position.pixels;
}

void main() {
  testWidgets(
    'shows project clips at their real timeline positions and durations',
    (tester) async {
      TimelineClip? selected;
      const playheadMs = 900;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: playheadMs,
                  selectedVideoClipId: null,
                  onVideoClipTap: (clip) => selected = clip,
                ),
              ),
            ),
          ),
        ),
      );

      expect(find.text('الخط الزمني'), findsOneWidget);
      expect(find.text('المؤشر 0.90ث'), findsOneWidget);
      expect(find.byKey(const ValueKey('timeline-playhead')), findsOneWidget);
      expect(
        find.byKey(const ValueKey('timeline-video-video-clip-1')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('timeline-video-video-clip-2')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('timeline-audio-audio-clip-2')),
        findsOneWidget,
      );

      final videoLayout = layoutVideoTransitions(
        _timelineProject.videoTrack.map((clip) => clip.id).toList(),
        _timelineProject.videoTrack
            .map((clip) => clip.effectiveDurationMs)
            .toList(),
        _timelineProject.videoTransitions,
      );
      final secondVideoBlock = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-video-video-clip-2')),
      );
      expect(
        secondVideoBlock.left,
        68 + videoLayout.startOfClip(1) * EditorTimeline.pixelsPerMillisecond,
      );
      expect(
        secondVideoBlock.width,
        _timelineProject.videoTrack[1].effectiveDurationMs *
            EditorTimeline.pixelsPerMillisecond,
      );

      final firstAudioBlock = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
      );
      final secondAudioBlock = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-audio-audio-clip-2')),
      );
      expect(
        firstAudioBlock.left,
        68 + 750 * EditorTimeline.pixelsPerMillisecond,
      );
      expect(firstAudioBlock.width, 3000 * EditorTimeline.pixelsPerMillisecond);
      expect(
        secondAudioBlock.left,
        68 +
            projectTimelineMsToOutputMs(
                  _timelineProject.videoTrack,
                  1100,
                  transitions: _timelineProject.videoTransitions,
                ) *
                EditorTimeline.pixelsPerMillisecond,
      );
      expect(firstAudioBlock.top, isNot(secondAudioBlock.top));

      await tester.tap(
        find.byKey(const ValueKey('timeline-video-tap-video-clip-2')),
      );
      expect(selected?.id, 'video-clip-2');
    },
  );

  testWidgets(
    'selects and drags overlay and audio blocks in composition time',
    (tester) async {
      const overlay = VideoOverlayClip(
        id: 'pip-clip-1',
        assetId: 'video-asset-2',
        trimStartMs: 0,
        trimEndMs: 1_500,
        timelineStartMs: 0,
      );
      final project = _timelineProject.copyWith(
        videoOverlayTracks: const [
          VideoOverlayTrack(
            id: 'pip-track-1',
            name: 'طبقة تجريبية',
            clips: [overlay],
          ),
        ],
      );
      String? selectedOverlay;
      String? selectedAudio;
      final overlayMoves = <int>[];
      final audioMoves = <int>[];

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: project,
                playheadPositionMs: 0,
                selectedVideoClipId: null,
                selectedVideoOverlayClipId: null,
                selectedAudioClipId: null,
                onVideoClipTap: (_) {},
                onVideoOverlayTap: (id) => selectedOverlay = id,
                onVideoOverlayMove: (_, requested) =>
                    overlayMoves.add(requested),
                onAudioClipTap: (id) => selectedAudio = id,
                onAudioClipMove: (_, requested) => audioMoves.add(requested),
              ),
            ),
          ),
        ),
      );

      final overlayBlock = find.byKey(
        const ValueKey('timeline-overlay-pip-clip-1'),
      );
      expect(overlayBlock, findsOneWidget);
      await tester.tap(overlayBlock);
      expect(selectedOverlay, 'pip-clip-1');
      await tester.drag(overlayBlock, const Offset(60, 0));
      await tester.pumpAndSettle();
      expect(overlayMoves, [1_000]);

      final audioBlock = find.byKey(
        const ValueKey('timeline-audio-audio-clip-1'),
      );
      await tester.tap(audioBlock);
      expect(selectedAudio, 'audio-clip-1');
      await tester.drag(audioBlock, const Offset(30, 0));
      await tester.pumpAndSettle();
      expect(audioMoves, [1_250]);
    },
  );

  testWidgets(
    'two-finger pinch zoom anchors timeline time and leaves editing state untouched',
    (tester) async {
      var selectedClipCount = 0;
      var trimCommitCount = 0;
      var reorderCommitCount = 0;
      const playheadMs = 900;
      final projectBefore = _timelineProject.toMap();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: playheadMs,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) => selectedClipCount++,
                  onVideoClipTrim:
                      (_, {required moveStart, required requestedMs}) async {
                        trimCommitCount++;
                      },
                  onVideoClipReorder: (_, __, ___) => reorderCommitCount++,
                ),
              ),
            ),
          ),
        ),
      );

      final startHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-1-start'),
      );
      final endHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-1-end'),
      );
      final startPoint = tester.getCenter(startHandle);
      final endPoint = tester.getCenter(endHandle);
      final viewportLeft = tester
          .getTopLeft(find.byKey(const ValueKey('timeline-scroll-viewport')))
          .dx;
      final anchorViewportX =
          ((startPoint.dx + endPoint.dx) / 2) - viewportLeft;
      final initialScrollOffset = _timelineScrollOffset(tester);
      final initialWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width!;
      final initialScale = EditorTimeline.pixelsPerMillisecond;
      final anchorTimeMs =
          (initialScrollOffset + anchorViewportX - 68) / initialScale;
      final initialAudioWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
          )
          .width!;

      final firstFinger = await tester.startGesture(startPoint, pointer: 31);
      final secondFinger = await tester.startGesture(endPoint, pointer: 32);
      await tester.pump();
      await firstFinger.moveBy(const Offset(-12, 0));
      await secondFinger.moveBy(const Offset(12, 0));
      await tester.pump();
      await firstFinger.moveBy(const Offset(-12, 0));
      await secondFinger.moveBy(const Offset(12, 0));
      await tester.pump();

      final zoomedVideoWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width!;
      final zoomedAudioWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
          )
          .width!;
      expect(zoomedVideoWidth, greaterThan(initialWidth));
      expect(zoomedAudioWidth, greaterThan(initialAudioWidth));
      final zoomedScale = zoomedVideoWidth / 1000;
      final zoomedScrollOffset = _timelineScrollOffset(tester);
      final zoomedAnchorTimeMs =
          (zoomedScrollOffset + anchorViewportX - 68) / zoomedScale;
      expect(zoomedAnchorTimeMs, closeTo(anchorTimeMs, 2));
      expect(find.text('المؤشر 0.90ث'), findsOneWidget);
      expect(selectedClipCount, 0);
      expect(trimCommitCount, 0);
      expect(reorderCommitCount, 0);

      await firstFinger.up();
      await secondFinger.up();
      await tester.pump();

      final zoomedStartPoint = tester.getCenter(startHandle);
      final zoomedEndPoint = tester.getCenter(endHandle);
      final zoomOutFirstFinger = await tester.startGesture(
        zoomedStartPoint,
        pointer: 33,
      );
      final zoomOutSecondFinger = await tester.startGesture(
        zoomedEndPoint,
        pointer: 34,
      );
      await tester.pump();
      await zoomOutFirstFinger.moveBy(const Offset(6, 0));
      await zoomOutSecondFinger.moveBy(const Offset(-6, 0));
      await tester.pump();
      await zoomOutFirstFinger.moveBy(const Offset(6, 0));
      await zoomOutSecondFinger.moveBy(const Offset(-6, 0));
      await tester.pump();
      await zoomOutFirstFinger.moveBy(const Offset(6, 0));
      await zoomOutSecondFinger.moveBy(const Offset(-6, 0));
      await tester.pump();
      final zoomedOutWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width!;
      expect(zoomedOutWidth, lessThan(zoomedVideoWidth));
      expect(zoomedOutWidth, greaterThanOrEqualTo(12.0));
      expect(selectedClipCount, 0);
      expect(trimCommitCount, 0);
      expect(reorderCommitCount, 0);
      expect(_timelineProject.toMap(), projectBefore);

      await zoomOutFirstFinger.up();
      await zoomOutSecondFinger.up();
      await tester.pump();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets('a second pointer alone does not steal a clip tap', (
    tester,
  ) async {
    TimelineClip? selected;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: _timelineProject,
                playheadPositionMs: 0,
                selectedVideoClipId: null,
                onVideoClipTap: (clip) => selected = clip,
              ),
            ),
          ),
        ),
      ),
    );

    final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
    final clip = find.byKey(const ValueKey('timeline-video-tap-video-clip-1'));
    final first = await tester.startGesture(
      tester.getCenter(clip),
      pointer: 51,
    );
    final viewportTopLeft = tester.getTopLeft(viewport);
    final second = await tester.startGesture(
      viewportTopLeft + const Offset(300, 10),
      pointer: 52,
    );
    await tester.pump();
    await second.up();
    await tester.pump();
    await first.up();
    await tester.pump();

    expect(selected?.id, 'video-clip-1');
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets('a won trim drag is not taken over by a later pinch', (
    tester,
  ) async {
    int? trimmedEndMs;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: _timelineProject,
                playheadPositionMs: 900,
                selectedVideoClipId: null,
                onVideoClipTap: (_) {},
                onVideoClipTrim:
                    (clipId, {required moveStart, required requestedMs}) async {
                      expect(clipId, 'video-clip-1');
                      trimmedEndMs = requestedMs;
                    },
              ),
            ),
          ),
        ),
      ),
    );

    final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
    final origin = tester.getTopLeft(viewport);
    final audioFinder = find.byKey(
      const ValueKey('timeline-audio-audio-clip-1'),
    );
    final initialAudioWidth = tester.widget<Positioned>(audioFinder).width!;
    final endHandle = find.byKey(
      const ValueKey('timeline-trim-video-clip-1-end'),
    );
    final endHandleRect = tester.getRect(endHandle);
    // At a transition cut the two trim handles overlap; use the exposed edge
    // of clip 1's end handle rather than the upper clip's start handle.
    final first = await tester.startGesture(
      Offset(endHandleRect.left + 1, endHandleRect.center.dy),
      pointer: 141,
    );
    await first.moveBy(const Offset(-24, 0));
    await first.moveBy(const Offset(-12, 0));
    await tester.pump();

    final second = await tester.startGesture(
      origin + Offset(210, tester.getCenter(endHandle).dy - origin.dy),
      pointer: 142,
    );
    await tester.pump();
    await second.moveBy(const Offset(0, 80));
    await tester.pump();
    expect(
      tester.widget<Positioned>(audioFinder).width,
      closeTo(initialAudioWidth, 0.1),
    );

    await first.up();
    await tester.pumpAndSettle();
    expect(trimmedEndMs, isNotNull);
    expect(trimmedEndMs, lessThan(1000));
    expect(
      tester.widget<Positioned>(audioFinder).width,
      closeTo(initialAudioWidth, 0.1),
    );
    await second.up();
    await tester.pump();

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets(
    'a won long-press reorder drag is not taken over by a later pinch',
    (tester) async {
      var reorderCount = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoClipReorder: (_, __, ___) => reorderCount++,
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final viewportSize = tester.getSize(viewport);
      final viewportRect = Rect.fromLTWH(
        origin.dx,
        origin.dy,
        viewportSize.width,
        viewportSize.height,
      );
      final clip = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-1'),
      );
      final audio = find.byKey(const ValueKey('timeline-audio-audio-clip-1'));
      final initialAudioWidth = tester.widget<Positioned>(audio).width!;
      final clipCenter = tester.getCenter(clip);
      final secondPoint =
          origin +
          Offset(clipCenter.dx - origin.dx + 60, clipCenter.dy - origin.dy);
      expect(viewportRect.contains(clipCenter), isTrue);
      expect(viewportRect.contains(secondPoint), isTrue);

      final first = await tester.startGesture(clipCenter, pointer: 151);
      await tester.pump(const Duration(milliseconds: 600));
      // The draggable's exact asset-name feedback exists only after its long press wins.
      expect(find.text('الأول.mp4'), findsOneWidget);
      final second = await tester.startGesture(secondPoint, pointer: 152);
      await tester.pump();
      await second.moveBy(const Offset(0, 80));
      await tester.pump();

      expect(
        tester.widget<Positioned>(audio).width,
        closeTo(initialAudioWidth, 0.1),
      );
      expect(reorderCount, 0);
      await second.up();
      await first.up();
      await tester.pumpAndSettle();

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'PointerCancel and repeated pair changes rebase cleanly for the next pinch',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final y = tester
          .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
          .dy;
      final first = await tester.startGesture(
        origin + Offset(120, y - origin.dy),
        pointer: 161,
      );
      final second = await tester.startGesture(
        origin + Offset(200, y - origin.dy),
        pointer: 162,
      );
      await tester.pump();
      await first.moveBy(const Offset(-12, 0));
      await second.moveBy(const Offset(12, 0));
      await tester.pump();
      await first.moveBy(const Offset(-12, 0));
      await second.moveBy(const Offset(12, 0));
      await tester.pump();
      final scaledWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width!;
      final scaledOffset = _timelineScrollOffset(tester);

      final third = await tester.startGesture(
        origin + Offset(160, y - origin.dy),
        pointer: 163,
      );
      await tester.pump();
      await first.cancel();
      await tester.pump();
      expect(
        tester
            .widget<Positioned>(
              find.byKey(const ValueKey('timeline-video-video-clip-1')),
            )
            .width,
        closeTo(scaledWidth, 0.1),
      );
      expect(_timelineScrollOffset(tester), closeTo(scaledOffset, 0.1));

      final fourth = await tester.startGesture(
        origin + Offset(240, y - origin.dy),
        pointer: 164,
      );
      await tester.pump();
      await second.cancel();
      await tester.pump();
      expect(
        tester
            .widget<Positioned>(
              find.byKey(const ValueKey('timeline-video-video-clip-1')),
            )
            .width,
        closeTo(scaledWidth, 0.1),
      );
      expect(_timelineScrollOffset(tester), closeTo(scaledOffset, 0.1));

      await third.cancel();
      await fourth.cancel();
      await tester.pump();

      final freshFirst = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(120, y - origin.dy),
        pointer: 165,
      );
      final freshSecond = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(180, y - origin.dy),
        pointer: 166,
      );
      await tester.pump();
      await freshFirst.moveBy(const Offset(-12, 0));
      await freshSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      await freshFirst.moveBy(const Offset(-12, 0));
      await freshSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      expect(
        tester
            .widget<Positioned>(
              find.byKey(const ValueKey('timeline-video-video-clip-1')),
            )
            .width,
        greaterThan(scaledWidth),
      );
      await freshFirst.up();
      await freshSecond.up();
      await tester.pump();

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'a new pinch before the pending scroll frame uses the latest anchor',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final y = tester
          .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
          .dy;
      final first = await tester.startGesture(
        origin + Offset(90, y - origin.dy),
        pointer: 171,
      );
      final second = await tester.startGesture(
        origin + Offset(170, y - origin.dy),
        pointer: 172,
      );
      await first.moveBy(const Offset(-12, 0));
      await second.moveBy(const Offset(12, 0));
      await first.moveBy(const Offset(-12, 0));
      await second.moveBy(const Offset(12, 0));
      await first.up();
      await second.up();

      const firstFocalX = 130.0;
      const initialScale = EditorTimeline.pixelsPerMillisecond;
      final firstAnchorMs = (firstFocalX - 68) / initialScale;
      final firstScale = initialScale * (128 / 104);
      final firstPendingOffset = 68 + firstAnchorMs * firstScale - firstFocalX;
      const secondFocalX = 210.0;
      final secondAnchorMs =
          (firstPendingOffset + secondFocalX - 68) / firstScale;

      final freshFirst = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(180, y - origin.dy),
        pointer: 173,
      );
      final freshSecond = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(240, y - origin.dy),
        pointer: 174,
      );
      await freshFirst.moveBy(const Offset(-12, 0));
      await freshSecond.moveBy(const Offset(12, 0));
      await freshFirst.moveBy(const Offset(-12, 0));
      await freshSecond.moveBy(const Offset(12, 0));
      await freshFirst.up();
      await freshSecond.up();

      // The recognizer starts from the second pair's initial span (60 px),
      // so both staged movements contribute to the pinch scale.
      const expectedScale = 0.06 * (128 / 104) * (108 / 60);
      final expectedOffset = 68 + secondAnchorMs * expectedScale - secondFocalX;
      await tester.pump();
      final actualScale =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      expect(actualScale, closeTo(expectedScale, 0.001));
      expect(_timelineScrollOffset(tester), closeTo(expectedOffset, 1));
      expect(
        (_timelineScrollOffset(tester) + secondFocalX - 68) / actualScale,
        closeTo(secondAnchorMs, 10),
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets('three-finger changes rebase without a scale or scroll jump', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: _timelineProject,
                playheadPositionMs: 900,
                selectedVideoClipId: null,
                onVideoClipTap: (_) {},
              ),
            ),
          ),
        ),
      ),
    );

    final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
    final origin = tester.getTopLeft(viewport);
    final y = tester
        .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
        .dy;
    final first = await tester.startGesture(
      origin + Offset(120, y - origin.dy),
      pointer: 61,
    );
    final second = await tester.startGesture(
      origin + Offset(200, y - origin.dy),
      pointer: 62,
    );
    await tester.pump();
    await first.moveBy(const Offset(-12, 0));
    await second.moveBy(const Offset(12, 0));
    await tester.pump();
    await first.moveBy(const Offset(-12, 0));
    await second.moveBy(const Offset(12, 0));
    await tester.pump();

    final widthBeforeCountChange = tester
        .widget<Positioned>(
          find.byKey(const ValueKey('timeline-video-video-clip-1')),
        )
        .width!;
    final offsetBeforeCountChange = _timelineScrollOffset(tester);
    final third = await tester.startGesture(
      origin + Offset(160, y - origin.dy),
      pointer: 63,
    );
    await tester.pump();
    expect(
      tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width,
      closeTo(widthBeforeCountChange, 0.1),
    );
    expect(
      _timelineScrollOffset(tester),
      closeTo(offsetBeforeCountChange, 0.1),
    );

    await first.up();
    await tester.pump();
    expect(
      tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width,
      closeTo(widthBeforeCountChange, 0.1),
    );
    expect(
      _timelineScrollOffset(tester),
      closeTo(offsetBeforeCountChange, 0.1),
    );

    await second.moveBy(const Offset(6, 0));
    await third.moveBy(const Offset(-6, 0));
    await tester.pump();
    expect(
      tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width,
      greaterThan(widthBeforeCountChange),
    );

    await second.up();
    await third.up();
    await tester.pump();
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets(
    'pinch at the start and end stays within scroll bounds, including after fit',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final viewportWidth = tester.getSize(viewport).width;
      final y = tester
          .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
          .dy;
      await tester.tap(find.byKey(const ValueKey('timeline-fit-button')));
      await tester.pump();
      await tester.pump();

      // The focal point is exactly the timeline origin; it cannot move before 0.
      final startFirst = await tester.startGesture(
        origin + Offset(52, y - origin.dy),
        pointer: 71,
      );
      final startSecond = await tester.startGesture(
        origin + Offset(84, y - origin.dy),
        pointer: 72,
      );
      await tester.pump();
      await startFirst.moveBy(const Offset(-10, 0));
      await startSecond.moveBy(const Offset(10, 0));
      await tester.pump();
      await startFirst.moveBy(const Offset(-10, 0));
      await startSecond.moveBy(const Offset(10, 0));
      await tester.pump();
      expect(_timelineScrollOffset(tester), closeTo(0, 0.1));
      final startScale =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      final startTimeAtFocal =
          (_timelineScrollOffset(tester) + 68 - 68) / startScale;
      expect(startTimeAtFocal, closeTo(0, 0.1));
      await startFirst.up();
      await startSecond.up();
      await tester.pump();

      // Fit, then verify an anchor near the far end remains stable while zooming in.
      await tester.tap(find.byKey(const ValueKey('timeline-fit-button')));
      await tester.pump();
      await tester.pump();
      final fitScale =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      final endFocalX = viewportWidth - 30;
      final endAnchorMs = (endFocalX - 68) / fitScale;
      final endFitFirst = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(viewportWidth - 50, y - origin.dy),
        pointer: 721,
      );
      final endFitSecond = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(viewportWidth - 10, y - origin.dy),
        pointer: 722,
      );
      await tester.pump();
      await endFitFirst.moveBy(const Offset(-12, 0));
      await endFitSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      await endFitFirst.moveBy(const Offset(-12, 0));
      await endFitSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      final scaleAfterFit =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      expect(
        (_timelineScrollOffset(tester) + endFocalX - 68) / scaleAfterFit,
        closeTo(endAnchorMs, 2),
      );
      await endFitFirst.up();
      await endFitSecond.up();
      await tester.pump();

      // Grow the content, scroll to its far end, then zoom out at that boundary.
      final afterStartZoomOrigin = tester.getTopLeft(viewport);
      final zoomFirst = await tester.startGesture(
        afterStartZoomOrigin + Offset(180, y - origin.dy),
        pointer: 73,
      );
      final zoomSecond = await tester.startGesture(
        afterStartZoomOrigin + Offset(240, y - origin.dy),
        pointer: 74,
      );
      await tester.pump();
      await zoomFirst.moveBy(const Offset(-20, 0));
      await zoomSecond.moveBy(const Offset(20, 0));
      await tester.pump();
      await zoomFirst.moveBy(const Offset(-20, 0));
      await zoomSecond.moveBy(const Offset(20, 0));
      await tester.pump();
      await zoomFirst.up();
      await zoomSecond.up();
      await tester.pump();
      await tester.drag(viewport, const Offset(-1000, 0));
      await tester.pumpAndSettle();

      final scrollable = find
          .descendant(
            of: find.byKey(const ValueKey('timeline-scroll-view')),
            matching: find.byType(Scrollable),
          )
          .first;
      final position = tester.state<ScrollableState>(scrollable).position;
      expect(
        _timelineScrollOffset(tester),
        closeTo(position.maxScrollExtent, 0.1),
      );
      final endFirst = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(viewportWidth - 55, y - origin.dy),
        pointer: 75,
      );
      final endSecond = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(viewportWidth - 5, y - origin.dy),
        pointer: 76,
      );
      await tester.pump();
      await endFirst.moveBy(const Offset(10, 0));
      await endSecond.moveBy(const Offset(-10, 0));
      await tester.pump();
      await endFirst.moveBy(const Offset(10, 0));
      await endSecond.moveBy(const Offset(-10, 0));
      await tester.pump();
      expect(
        _timelineScrollOffset(tester),
        lessThanOrEqualTo(position.maxScrollExtent),
      );
      expect(_timelineScrollOffset(tester), greaterThanOrEqualTo(0));
      await endFirst.up();
      await endSecond.up();
      await tester.pump();

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'zooming out at the far edge measures anchor drift caused by scroll clamping',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final y = tester
          .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
          .dy;
      final zoomFirst = await tester.startGesture(
        origin + Offset(140, y - origin.dy),
        pointer: 181,
      );
      final zoomSecond = await tester.startGesture(
        origin + Offset(200, y - origin.dy),
        pointer: 182,
      );
      await tester.pump();
      await zoomFirst.moveBy(const Offset(-12, 0));
      await zoomSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      await zoomFirst.moveBy(const Offset(-24, 0));
      await zoomSecond.moveBy(const Offset(24, 0));
      await tester.pump();
      await zoomFirst.moveBy(const Offset(-12, 0));
      await zoomSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      await zoomFirst.up();
      await zoomSecond.up();
      await tester.pump();

      final scaleBeforeEdgePinch =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      expect(scaleBeforeEdgePinch, greaterThan(0.1));
      await tester.drag(viewport, const Offset(-1000, 0));
      await tester.pumpAndSettle();

      final scrollable = find
          .descendant(
            of: find.byKey(const ValueKey('timeline-scroll-view')),
            matching: find.byType(Scrollable),
          )
          .first;
      final position = tester.state<ScrollableState>(scrollable).position;
      final oldOffset = _timelineScrollOffset(tester);
      expect(oldOffset, closeTo(position.maxScrollExtent, 0.1));
      const focalX = 290.0;
      final originalAnchorMs = (oldOffset + focalX - 68) / scaleBeforeEdgePinch;

      final edgeFirst = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(focalX - 20, y - origin.dy),
        pointer: 183,
      );
      final edgeSecond = await tester.startGesture(
        tester.getTopLeft(viewport) + Offset(focalX + 20, y - origin.dy),
        pointer: 184,
      );
      await tester.pump();
      await edgeFirst.moveBy(const Offset(10, 0));
      await edgeSecond.moveBy(const Offset(-10, 0));
      await tester.pump();
      await edgeFirst.moveBy(const Offset(2, 0));
      await edgeSecond.moveBy(const Offset(-2, 0));
      await tester.pump();

      final scaleAfterEdgePinch =
          tester
              .widget<Positioned>(
                find.byKey(const ValueKey('timeline-video-video-clip-1')),
              )
              .width! /
          1000;
      final newOffset = _timelineScrollOffset(tester);
      final newMaxOffset = tester
          .state<ScrollableState>(scrollable)
          .position
          .maxScrollExtent;
      final targetWithoutClamping =
          68 + originalAnchorMs * scaleAfterEdgePinch - focalX;
      final actualAnchorMs = (newOffset + focalX - 68) / scaleAfterEdgePinch;
      final clampedAnchorMs =
          (newMaxOffset + focalX - 68) / scaleAfterEdgePinch;

      expect(scaleAfterEdgePinch, lessThan(scaleBeforeEdgePinch));
      expect(targetWithoutClamping, greaterThan(newMaxOffset));
      expect(newOffset, closeTo(newMaxOffset, 0.1));
      expect(actualAnchorMs, closeTo(clampedAnchorMs, 1));
      expect((actualAnchorMs - originalAnchorMs).abs(), greaterThan(10));

      await edgeFirst.up();
      await edgeSecond.up();
      await tester.pump();
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'all timeline geometry stays aligned after zoom; trim and transition remain usable',
    (tester) async {
      int? openedBoundary;
      (String, bool, int)? trimmed;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 900,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoClipTrim:
                      (
                        clipId, {
                        required moveStart,
                        required requestedMs,
                      }) async {
                        trimmed = (clipId, moveStart, requestedMs);
                      },
                  onVideoClipReorder: (_, __, ___) {},
                  onVideoTransitionTap: (boundary) => openedBoundary = boundary,
                ),
              ),
            ),
          ),
        ),
      );

      final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
      final origin = tester.getTopLeft(viewport);
      final videoCenter = tester.getCenter(
        find.byKey(const ValueKey('timeline-video-video-clip-1')),
      );
      final first = await tester.startGesture(
        Offset(origin.dx + 120, videoCenter.dy),
        pointer: 81,
      );
      final second = await tester.startGesture(
        Offset(origin.dx + 200, videoCenter.dy),
        pointer: 82,
      );
      await tester.pump();
      await first.moveBy(const Offset(-12, 0));
      await second.moveBy(const Offset(12, 0));
      await tester.pump();
      await first.moveBy(const Offset(-24, 0));
      await second.moveBy(const Offset(24, 0));
      await tester.pump();
      await first.up();
      await second.up();
      await tester.pump();

      final videoLayout = layoutVideoTransitions(
        _timelineProject.videoTrack.map((clip) => clip.id).toList(),
        _timelineProject.videoTrack
            .map((clip) => clip.effectiveDurationMs)
            .toList(),
        _timelineProject.videoTransitions,
      );
      final clip1 = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-video-video-clip-1')),
      );
      final scale = clip1.width! / 1000;
      final clip2 = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-video-video-clip-2')),
      );
      expect(clip1.left, closeTo(68, 0.1));
      expect(clip2.left, closeTo(68 + videoLayout.startOfClip(1) * scale, 0.1));

      final audio = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
      );
      expect(audio.left, closeTo(68 + 750 * scale, 0.1));
      expect(audio.width, closeTo(3000 * scale, 0.1));
      final rulerTickFinder = find.byWidgetPredicate((widget) {
        final key = widget.key;
        return widget is Positioned &&
            key is ValueKey<String> &&
            key.value.startsWith('timeline-ruler-tick-');
      });
      final rulerTick = tester.widget<Positioned>(rulerTickFinder.first);
      final rulerTickKey = rulerTick.key as ValueKey<String>;
      final rulerTickMs = int.parse(
        rulerTickKey.value.substring('timeline-ruler-tick-'.length),
      );
      expect(rulerTick.left, closeTo(68 + rulerTickMs * scale, 0.1));
      final playhead = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-playhead')),
      );
      expect(playhead.left, closeTo(68 + 900 * scale, 0.1));
      final transition = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-transition-boundary-0')),
      );
      final transitionTimeMs = videoLayout.startOfClip(1) + 100;
      expect(
        transition.left! + transition.width! / 2,
        closeTo(68 + transitionTimeMs * scale, 0.2),
      );

      final clipBoxFinder = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-1'),
      );
      final startHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-1-start'),
      );
      final endHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-1-end'),
      );
      final clipTopLeft = tester.getTopLeft(clipBoxFinder);
      final clipWidth = tester.getSize(clipBoxFinder).width;
      expect(tester.getTopLeft(startHandle).dx, closeTo(clipTopLeft.dx, 0.1));
      expect(
        tester.getTopLeft(endHandle).dx,
        closeTo(clipTopLeft.dx + clipWidth - 14, 0.1),
      );

      final transitionMarker = find.byKey(
        const ValueKey('timeline-transition-edit-0'),
      );
      await tester.ensureVisible(transitionMarker);
      await tester.tap(transitionMarker);
      expect(openedBoundary, 0);
      final trimHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-2-end'),
      );
      await tester.ensureVisible(trimHandle);
      final trimGesture = await tester.startGesture(
        tester.getCenter(trimHandle),
      );
      await trimGesture.moveBy(const Offset(-38, 0));
      await tester.pump();
      await trimGesture.up();
      await tester.pumpAndSettle();
      expect(trimmed, isNotNull);
      expect(trimmed!.$1, 'video-clip-2');
      expect(trimmed!.$2, isFalse);
      expect(trimmed!.$3, isNot(2000));

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets('video reorder still works after changing timeline scale', (
    tester,
  ) async {
    final project = _timelineProject.copyWith(videoTransitions: const []);
    (String, String, bool)? receivedDrop;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: project,
                playheadPositionMs: 900,
                selectedVideoClipId: null,
                onVideoClipTap: (_) {},
                onVideoClipReorder: (dragged, target, after) {
                  receivedDrop = (dragged, target, after);
                },
              ),
            ),
          ),
        ),
      ),
    );

    final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
    final origin = tester.getTopLeft(viewport);
    final clipCenter = tester.getCenter(
      find.byKey(const ValueKey('timeline-video-video-clip-1')),
    );
    final first = await tester.startGesture(
      Offset(origin.dx + 125, clipCenter.dy),
      pointer: 91,
    );
    final second = await tester.startGesture(
      Offset(origin.dx + 205, clipCenter.dy),
      pointer: 92,
    );
    await tester.pump();
    await first.moveBy(const Offset(-12, 0));
    await second.moveBy(const Offset(12, 0));
    await tester.pump();
    await first.moveBy(const Offset(-12, 0));
    await second.moveBy(const Offset(12, 0));
    await tester.pump();
    await first.up();
    await second.up();
    await tester.pump();
    expect(
      tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width,
      greaterThan(60),
    );

    final source = find.byKey(
      const ValueKey('timeline-video-tap-video-clip-1'),
    );
    final target = find.byKey(
      const ValueKey('timeline-video-tap-video-clip-2'),
    );
    final targetCenter = tester.getCenter(target);
    final reorder = await tester.startGesture(tester.getCenter(source));
    await tester.pump(const Duration(milliseconds: 600));
    await reorder.moveTo(targetCenter + const Offset(12, 0));
    await tester.pump(const Duration(milliseconds: 50));
    expect(find.textContaining('معاينة: ترتيب مقترح'), findsOneWidget);
    await reorder.up();
    await tester.pump();
    expect(receivedDrop, isNotNull);
    expect(receivedDrop!.$1, 'video-clip-1');
    expect(receivedDrop!.$2, 'video-clip-2');

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets('pinch zoom obeys scale bounds and fit resets a bounded zoom', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: _timelineProject,
                playheadPositionMs: 900,
                selectedVideoClipId: null,
                onVideoClipTap: (_) {},
              ),
            ),
          ),
        ),
      ),
    );

    final viewport = find.byKey(const ValueKey('timeline-scroll-viewport'));
    final viewportOrigin = tester.getTopLeft(viewport);
    final videoCenterY = tester
        .getCenter(find.byKey(const ValueKey('timeline-video-video-clip-1')))
        .dy;
    final beforeWidth = tester
        .widget<Positioned>(
          find.byKey(const ValueKey('timeline-video-video-clip-1')),
        )
        .width!;

    final localVideoCenterY = videoCenterY - viewportOrigin.dy;
    final zoomInFirst = await tester.startGesture(
      viewportOrigin + Offset(140, localVideoCenterY),
      pointer: 41,
    );
    final zoomInSecond = await tester.startGesture(
      viewportOrigin + Offset(200, localVideoCenterY),
      pointer: 42,
    );
    await tester.pump();
    for (var step = 0; step < 5; step++) {
      await zoomInFirst.moveBy(const Offset(-120, 0));
      await zoomInSecond.moveBy(const Offset(120, 0));
      await tester.pump();
    }
    final maximumWidth = tester
        .widget<Positioned>(
          find.byKey(const ValueKey('timeline-video-video-clip-1')),
        )
        .width!;
    expect(maximumWidth, closeTo(240, 0.1));
    await zoomInFirst.up();
    await zoomInSecond.up();
    await tester.pump();

    final afterZoomViewportOrigin = tester.getTopLeft(viewport);
    final zoomOutFirst = await tester.startGesture(
      afterZoomViewportOrigin + const Offset(100, 55),
      pointer: 43,
    );
    final zoomOutSecond = await tester.startGesture(
      afterZoomViewportOrigin + const Offset(240, 55),
      pointer: 44,
    );
    await tester.pump();
    for (var step = 0; step < 7; step++) {
      await zoomOutFirst.moveBy(const Offset(10, 0));
      await zoomOutSecond.moveBy(const Offset(-10, 0));
      await tester.pump();
    }
    final minimumWidth = tester
        .widget<Positioned>(
          find.byKey(const ValueKey('timeline-video-video-clip-1')),
        )
        .width!;
    expect(minimumWidth, closeTo(12, 0.1));
    expect(minimumWidth, lessThan(maximumWidth));
    await zoomOutFirst.up();
    await zoomOutSecond.up();
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('timeline-fit-button')));
    await tester.pump();
    expect(
      tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width,
      greaterThan(minimumWidth),
    );
    expect(beforeWidth, closeTo(60, 0.1));

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets(
    'fit button fits the full audio extent without seeking or mutating the project',
    (tester) async {
      const playheadMs = 900;
      var selectedClipCount = 0;
      final projectBefore = _timelineProject.toMap();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: playheadMs,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) => selectedClipCount++,
                ),
              ),
            ),
          ),
        ),
      );

      final originalVideoWidth = tester
          .widget<Positioned>(
            find.byKey(const ValueKey('timeline-video-video-clip-1')),
          )
          .width!;
      await tester.tap(find.byKey(const ValueKey('timeline-fit-button')));
      await tester.pump();
      await tester.pump();

      final viewportWidth = tester
          .getSize(find.byKey(const ValueKey('timeline-scroll-viewport')))
          .width;
      final audioBlock = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-audio-audio-clip-1')),
      );
      final audioEndX = audioBlock.left! + audioBlock.width!;
      final videoBlock = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-video-video-clip-2')),
      );
      final videoLayout = layoutVideoTransitions(
        _timelineProject.videoTrack.map((clip) => clip.id).toList(),
        _timelineProject.videoTrack
            .map((clip) => clip.effectiveDurationMs)
            .toList(),
        _timelineProject.videoTransitions,
      );
      final videoEndX = videoBlock.left! + videoBlock.width!;
      final playhead = tester.widget<Positioned>(
        find.byKey(const ValueKey('timeline-playhead')),
      );

      expect(audioEndX, closeTo(viewportWidth, 1));
      expect(videoEndX, lessThanOrEqualTo(viewportWidth));
      expect(playhead.left!, lessThan(viewportWidth));
      expect(videoLayout.totalDurationMs, lessThan(3750));
      expect(_timelineScrollOffset(tester), closeTo(0, 0.1));
      expect(
        tester
            .widget<Positioned>(
              find.byKey(const ValueKey('timeline-video-video-clip-1')),
            )
            .width,
        greaterThan(originalVideoWidth),
      );
      expect(find.text('المؤشر 0.90ث'), findsOneWidget);
      expect(selectedClipCount, 0);
      expect(_timelineProject.toMap(), projectBefore);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'video clip selection seeks preview to its transition-aware start',
    TargetPlatform.android,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const nativeChannel = MethodChannel('velora/native');
      const platformViewsChannel = MethodChannel('flutter/platform_views');
      final previewConfigurations = <Map<String, dynamic>>[];
      final previewSeeks = <Map<String, dynamic>>[];
      var previewPositionMs = 0;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(nativeChannel, (call) async {
            switch (call.method) {
              case 'configurePreviewTimeline':
                final args = Map<String, dynamic>.from(call.arguments as Map);
                previewConfigurations.add(args);
                previewPositionMs = (args['timelinePositionMs'] as num).toInt();
                return null;
              case 'seekPreview':
                final args = Map<String, dynamic>.from(call.arguments as Map);
                previewSeeks.add(args);
                previewPositionMs = (args['timelinePositionMs'] as num).toInt();
                return null;
              case 'getPreviewState':
                return <String, Object?>{
                  'timelinePositionMs': previewPositionMs,
                  'isPlaying': false,
                };
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(platformViewsChannel, (call) async {
            if (call.method == 'create') return 77;
            return null;
          });
      addTearDown(() {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(nativeChannel, null);
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(platformViewsChannel, null);
      });

      await tester.pumpWidget(
        MaterialApp(home: EditorScreen(project: _timelineProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 1));
      expect(previewConfigurations, hasLength(1));

      final videoLayout = layoutVideoTransitions(
        _timelineProject.videoTrack.map((clip) => clip.id).toList(),
        _timelineProject.videoTrack
            .map((clip) => clip.effectiveDurationMs)
            .toList(),
        _timelineProject.videoTransitions,
      );
      final expectedStartMs = videoLayout.startOfClip(1);
      final clipFinder = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-2'),
      );
      await tester.ensureVisible(clipFinder);
      await tester.tap(clipFinder);
      await tester.pump();

      expect(previewSeeks, hasLength(1));
      expect(previewSeeks.single['mediaItemIndex'], 1);
      expect(previewSeeks.single['clipPositionMs'], 0);
      expect(previewSeeks.single['timelinePositionMs'], expectedStartMs);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'shows the stored transition at the cut and opens its boundary editor',
    (tester) async {
      int? openedBoundary;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 0,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoTransitionTap: (boundaryIndex) =>
                      openedBoundary = boundaryIndex,
                ),
              ),
            ),
          ),
        ),
      );

      expect(
        find.byKey(const ValueKey('timeline-transition-boundary-0')),
        findsOneWidget,
      );
      expect(find.textContaining('تلاشي ·'), findsOneWidget);
      await tester.tap(
        find.byKey(const ValueKey('timeline-transition-edit-0')),
      );
      expect(openedBoundary, 0);
    },
  );

  testWidgets(
    'dragging a visual clip previews and emits its real reorder target',
    (tester) async {
      final project = _timelineProject.copyWith(videoTransitions: const []);
      (String, String, bool)? receivedDrop;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: project,
                  playheadPositionMs: 0,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoClipReorder: (dragged, target, after) {
                    receivedDrop = (dragged, target, after);
                  },
                ),
              ),
            ),
          ),
        ),
      );

      final source = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-1'),
      );
      final target = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-2'),
      );
      final gesture = await tester.startGesture(tester.getCenter(source));
      await tester.pump(const Duration(milliseconds: 600));
      await gesture.moveTo(tester.getCenter(target) + const Offset(12, 0));
      await tester.pump(const Duration(milliseconds: 50));

      expect(find.textContaining('معاينة: ترتيب مقترح'), findsOneWidget);
      await gesture.up();
      await tester.pump();

      expect(receivedDrop, ('video-clip-1', 'video-clip-2', true));
    },
  );

  testWidgets(
    'trims a speed-ramped clip on release and emits one source boundary',
    (tester) async {
      final clip = _timelineProject.videoTrack[1];
      final draggedOutputMs = (38 / EditorTimeline.pixelsPerMillisecond)
          .round();
      final expectedSourceEnd =
          clip.trimStartMs +
          outputOffsetToSourceMs(
            clip.effectiveDurationMs - draggedOutputMs,
            clip.trimStartMs,
            clip.trimEndMs,
            clip.speedRampPoints,
          );
      int? committedSourceEnd;
      var commitCount = 0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 0,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoClipTrim:
                      (
                        clipId, {
                        required moveStart,
                        required requestedMs,
                      }) async {
                        expect(clipId, 'video-clip-2');
                        expect(moveStart, isFalse);
                        committedSourceEnd = requestedMs;
                        commitCount++;
                      },
                ),
              ),
            ),
          ),
        ),
      );

      final endHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-2-end'),
      );
      await tester.ensureVisible(endHandle);
      final gesture = await tester.startGesture(tester.getCenter(endHandle));
      await gesture.moveBy(const Offset(-38, 0));
      await tester.pump();
      expect(committedSourceEnd, isNull);
      expect(find.textContaining('المدة:'), findsOneWidget);
      await gesture.up();
      await tester.pumpAndSettle();

      expect(commitCount, 1);
      expect(committedSourceEnd, expectedSourceEnd);
    },
  );

  testWidgets(
    'start trim maps the dragged output time through the speed curve',
    (tester) async {
      final clip = _timelineProject.videoTrack[1];
      final outputClockAtSourceStart = sourceOffsetToOutputMs(
        clip.trimStartMs,
        0,
        clip.speedRampPoints,
      );
      final expectedSourceStart = outputOffsetToSourceMs(
        outputClockAtSourceStart +
            (38 / EditorTimeline.pixelsPerMillisecond).round(),
        0,
        2000,
        clip.speedRampPoints,
      );
      int? committedSourceStart;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: SizedBox(
                width: 360,
                child: EditorTimeline(
                  project: _timelineProject,
                  playheadPositionMs: 0,
                  selectedVideoClipId: null,
                  onVideoClipTap: (_) {},
                  onVideoClipTrim:
                      (
                        clipId, {
                        required moveStart,
                        required requestedMs,
                      }) async {
                        expect(clipId, 'video-clip-2');
                        expect(moveStart, isTrue);
                        committedSourceStart = requestedMs;
                      },
                ),
              ),
            ),
          ),
        ),
      );

      final startHandle = find.byKey(
        const ValueKey('timeline-trim-video-clip-2-start'),
      );
      await tester.ensureVisible(startHandle);
      final gesture = await tester.startGesture(tester.getCenter(startHandle));
      await gesture.moveBy(const Offset(38, 0));
      await tester.pump();
      await gesture.up();
      await tester.pumpAndSettle();

      expect(committedSourceStart, expectedSourceStart);
    },
  );

  testWidgetsOnPlatform(
    'rejecting a transition-breaking reorder leaves the project, history, and storage unchanged',
    TargetPlatform.linux,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const channel = MethodChannel('velora/native');
      var saveCalls = 0;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            switch (call.method) {
              case 'saveProject':
                saveCalls++;
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _timelineProject)),
      );
      await tester.pump();

      final clipAKey = const ValueKey('timeline-video-video-clip-1');
      final clipBKey = const ValueKey('timeline-video-video-clip-2');
      final clipABefore = tester.widget<Positioned>(find.byKey(clipAKey)).left;
      final clipBBefore = tester.widget<Positioned>(find.byKey(clipBKey)).left;
      final source = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-1'),
      );
      final target = find.byKey(
        const ValueKey('timeline-video-tap-video-clip-2'),
      );
      final targetRect = tester.getRect(target);
      final gesture = await tester.startGesture(tester.getCenter(source));
      await tester.pump(const Duration(milliseconds: 600));
      await gesture.moveTo(Offset(targetRect.right - 20, targetRect.center.dy));
      await tester.pump(const Duration(milliseconds: 50));
      await gesture.up();
      await tester.pumpAndSettle();

      expect(find.textContaining('رُفض الترتيب'), findsWidgets);
      expect(tester.widget<Positioned>(find.byKey(clipAKey)).left, clipABefore);
      expect(tester.widget<Positioned>(find.byKey(clipBKey)).left, clipBBefore);
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('إعادة')).onPressed,
        isNull,
      );
      expect(saveCalls, 0);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'commits a safe video reorder and persists undo and redo',
    TargetPlatform.linux,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const channel = MethodChannel('velora/native');
      final savedProjects = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            switch (call.method) {
              case 'saveProject':
                savedProjects.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'editor-video-reorder',
        name: 'إعادة ترتيب الفيديو',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'asset-a',
            uri: 'content://video/a',
            name: 'a.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'asset-b',
            uri: 'content://video/b',
            name: 'b.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'asset-c',
            uri: 'content://video/c',
            name: 'c.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'audio-asset',
            uri: 'content://audio/a',
            name: 'music.m4a',
            mimeType: 'audio/mp4',
            kind: MediaKind.audio,
            durationMs: 3000,
            width: 0,
            height: 0,
            sizeBytes: 60,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'a',
            assetId: 'asset-a',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'b',
            assetId: 'asset-b',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'c',
            assetId: 'asset-c',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
        ],
        audioTrack: [
          TimelineClip(
            id: 'audio-clip',
            assetId: 'audio-asset',
            trimStartMs: 200,
            trimEndMs: 1800,
            timelineStartMs: 650,
            volume: 0.42,
            fadeInMs: 120,
            fadeOutMs: 250,
          ),
        ],
        videoTransitions: [
          VideoTransition(
            id: 'transition-a-b',
            fromClipId: 'a',
            toClipId: 'b',
            type: VideoTransitionType.dissolve,
            durationMs: 200,
          ),
        ],
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();

      final clipA = find.byKey(const ValueKey('timeline-video-a'));
      final clipB = find.byKey(const ValueKey('timeline-video-b'));
      final initialClipAWidth = tester.widget<Positioned>(clipA).width!;
      final firstClipCenter = tester.getCenter(clipA);
      final secondClipCenter = tester.getCenter(clipB);
      final pinchFirst = await tester.startGesture(
        Offset(firstClipCenter.dx, firstClipCenter.dy),
        pointer: 131,
      );
      final pinchSecond = await tester.startGesture(
        Offset(secondClipCenter.dx, secondClipCenter.dy),
        pointer: 132,
      );
      await tester.pump();
      await pinchFirst.moveBy(const Offset(-12, 0));
      await pinchSecond.moveBy(const Offset(12, 0));
      await tester.pump();
      await pinchFirst.moveBy(const Offset(-20, 0));
      await pinchSecond.moveBy(const Offset(20, 0));
      await tester.pump();
      await pinchFirst.up();
      await pinchSecond.up();
      await tester.pump();
      expect(
        tester.widget<Positioned>(clipA).width,
        greaterThan(initialClipAWidth),
      );
      expect(savedProjects, isEmpty);

      final transitionMarker = find.byKey(
        const ValueKey('timeline-transition-edit-0'),
      );
      await tester.tap(transitionMarker);
      await tester.pumpAndSettle();
      expect(find.text('إعداد الانتقال'), findsOneWidget);
      await tester.tap(find.text('إلغاء'));
      await tester.pumpAndSettle();
      expect(savedProjects, isEmpty);

      final trimmedEndHandle = find.byKey(
        const ValueKey('timeline-trim-c-end'),
      );
      final trimGesture = await tester.startGesture(
        tester.getCenter(trimmedEndHandle),
        pointer: 133,
      );
      await trimGesture.moveBy(const Offset(-20, 0));
      await tester.pump();
      await trimGesture.up();
      await tester.pumpAndSettle();
      expect(savedProjects, hasLength(1));
      final trimmedTrack = savedProjects.single['videoTrack'] as List;
      final trimmedClipC = trimmedTrack.cast<Map>().singleWhere(
        (clip) => clip['id'] == 'c',
      );
      final savedTrimEndMs = (trimmedClipC['trimEndMs'] as num).toInt();
      int persistedClipCEnd(Map<String, dynamic> savedProject) {
        final track = (savedProject['videoTrack'] as List).cast<Map>();
        final clip = track.singleWhere((item) => item['id'] == 'c');
        return (clip['trimEndMs'] as num).toInt();
      }

      expect(savedTrimEndMs, lessThan(1000));
      expect(
        savedProjects.single['videoTransitions'],
        project.toMap()['videoTransitions'],
      );
      expect(savedProjects.single['audioTrack'], project.toMap()['audioTrack']);
      savedProjects.clear();

      final source = find.byKey(const ValueKey('timeline-video-tap-c'));
      final target = find.byKey(const ValueKey('timeline-video-tap-a'));
      await tester.ensureVisible(source);
      await tester.ensureVisible(target);
      final gesture = await tester.startGesture(tester.getCenter(source));
      await tester.pump(const Duration(milliseconds: 600));
      await gesture.moveTo(tester.getCenter(target) - const Offset(10, 0));
      await tester.pump(const Duration(milliseconds: 50));
      expect(find.textContaining('معاينة: ترتيب مقترح'), findsOneWidget);
      await gesture.up();
      await tester.pumpAndSettle();

      expect(savedProjects, hasLength(1));
      expect(
        (savedProjects.single['videoTrack'] as List).map(
          (clip) => (clip as Map)['id'],
        ),
        ['c', 'a', 'b'],
      );
      expect(persistedClipCEnd(savedProjects.single), savedTrimEndMs);
      expect(
        savedProjects.single['videoTransitions'],
        project.toMap()['videoTransitions'],
      );
      expect(savedProjects.single['audioTrack'], project.toMap()['audioTrack']);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(
        (savedProjects.last['videoTrack'] as List).map(
          (clip) => (clip as Map)['id'],
        ),
        ['a', 'b', 'c'],
      );
      expect(persistedClipCEnd(savedProjects.last), savedTrimEndMs);
      expect(savedProjects.last['audioTrack'], project.toMap()['audioTrack']);

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pumpAndSettle();
      expect(
        (savedProjects.last['videoTrack'] as List).map(
          (clip) => (clip as Map)['id'],
        ),
        ['c', 'a', 'b'],
      );
      expect(persistedClipCEnd(savedProjects.last), savedTrimEndMs);
      expect(
        savedProjects.last['videoTransitions'],
        project.toMap()['videoTransitions'],
      );
      expect(savedProjects.last['audioTrack'], project.toMap()['audioTrack']);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgets(
    'shows selectable text and sticker lanes and reports composition-time drags',
    (tester) async {
      final project = _timelineProject.copyWith(
        textOverlays: const [
          TextOverlay(
            id: 'title-lane',
            text: 'عنوان',
            startMs: 500,
            endMs: 1500,
          ),
        ],
        subtitleTrack: const [
          SubtitleCue(
            id: 'subtitle-lane',
            text: 'سطر ترجمة',
            startMs: 750,
            endMs: 1750,
          ),
        ],
        stickerOverlays: const [
          StickerOverlay(
            id: 'star-lane',
            uri: 'content://stickers/star.png',
            name: 'star.png',
            mimeType: 'image/png',
            startMs: 250,
            endMs: 750,
          ),
        ],
      );
      String? selectedText;
      String? selectedSubtitle;
      String? selectedSticker;
      final textMoves = <int>[];
      final subtitleMoves = <int>[];
      final stickerMoves = <int>[];
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SizedBox(
              width: 360,
              child: EditorTimeline(
                project: project,
                playheadPositionMs: 0,
                selectedVideoClipId: null,
                onVideoClipTap: (_) {},
                onTextOverlayTap: (id) => selectedText = id,
                onTextOverlayMove: (_, position) => textMoves.add(position),
                onSubtitleCueTap: (id) => selectedSubtitle = id,
                onSubtitleCueMove: (_, position) => subtitleMoves.add(position),
                onStickerOverlayTap: (id) => selectedSticker = id,
                onStickerOverlayMove: (_, position) =>
                    stickerMoves.add(position),
              ),
            ),
          ),
        ),
      );
      final textBlock = find.byKey(const ValueKey('timeline-text-title-lane'));
      final stickerBlock = find.byKey(
        const ValueKey('timeline-sticker-star-lane'),
      );
      final subtitleBlock = find.byKey(
        const ValueKey('timeline-subtitle-subtitle-lane'),
      );
      expect(textBlock, findsOneWidget);
      expect(stickerBlock, findsOneWidget);
      expect(subtitleBlock, findsOneWidget);
      final positionedText = tester.widget<Positioned>(textBlock);
      expect(
        positionedText.left,
        68 +
            projectTimelineMsToOutputMs(
                  project.videoTrack,
                  500,
                  transitions: project.videoTransitions,
                ) *
                EditorTimeline.pixelsPerMillisecond,
      );
      await tester.tap(textBlock);
      expect(selectedText, 'title-lane');
      await tester.tap(subtitleBlock);
      expect(selectedSubtitle, 'subtitle-lane');
      await tester.drag(subtitleBlock, const Offset(30, 0));
      await tester.pumpAndSettle();
      expect(subtitleMoves, isNotEmpty);
      await tester.tap(stickerBlock);
      expect(selectedSticker, 'star-lane');
      await tester.drag(textBlock, const Offset(30, 0));
      await tester.pumpAndSettle();
      expect(textMoves, isNotEmpty);
      expect(textMoves.last, 1000);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
}
