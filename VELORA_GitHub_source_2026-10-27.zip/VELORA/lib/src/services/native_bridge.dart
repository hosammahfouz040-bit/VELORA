import 'package:flutter/services.dart';

import '../models/project.dart';

class NativeBridge {
  NativeBridge._();

  static const MethodChannel _channel = MethodChannel('velora/native');

  static Future<List<MediaAsset>> pickMedia() async {
    final rows = await _channel.invokeListMethod<Object?>('pickMedia') ?? [];
    return rows
        .map(
          (row) => MediaAsset.fromMap(Map<String, dynamic>.from(row! as Map)),
        )
        .toList();
  }

  static Future<List<VeloraProject>> listProjects() async {
    final rows = await _channel.invokeListMethod<Object?>('listProjects') ?? [];
    return rows
        .map(
          (row) =>
              VeloraProject.fromMap(Map<String, dynamic>.from(row! as Map)),
        )
        .toList();
  }

  static Future<void> saveProject(VeloraProject project) async {
    await _channel.invokeMethod<void>('saveProject', project.toMap());
  }

  static Future<void> configurePreviewTimeline(
    VeloraProject project, {
    required int startIndex,
    required int clipPositionMs,
    required bool playWhenReady,
  }) async {
    await _channel.invokeMethod<void>('configurePreviewTimeline', {
      'project': project.toMap(),
      'startIndex': startIndex,
      'clipPositionMs': clipPositionMs,
      'playWhenReady': playWhenReady,
    });
  }

  static Future<void> setPreviewSource(
    MediaAsset asset, {
    int positionMs = 0,
  }) async {
    await _channel.invokeMethod<void>('setPreviewSource', {
      'uri': asset.uri,
      'kind': asset.kind.name,
      'positionMs': positionMs < 0 ? 0 : positionMs,
      'durationMs': asset.durationMs,
    });
  }

  static Future<void> seekPreviewTo({
    required int mediaItemIndex,
    required int clipPositionMs,
  }) async {
    await _channel.invokeMethod<void>('seekPreview', {
      'mediaItemIndex': mediaItemIndex,
      'clipPositionMs': clipPositionMs < 0 ? 0 : clipPositionMs,
    });
  }

  static Future<void> playPreview() async {
    await _channel.invokeMethod<void>('playPreview');
  }

  static Future<void> pausePreview() async {
    await _channel.invokeMethod<void>('pausePreview');
  }

  static Future<void> clearPreview() async {
    await _channel.invokeMethod<void>('clearPreview');
  }

  static Future<Map<String, dynamic>> getPreviewState() async {
    final state = await _channel.invokeMapMethod<Object?, Object?>(
      'getPreviewState',
    );
    if (state == null) throw PlatformException(code: 'empty_preview_state');
    return state.map((key, value) => MapEntry(key.toString(), value));
  }

  static Future<bool> cancelExport() async =>
      await _channel.invokeMethod<bool>('cancelExport') ?? false;

  static Future<Map<String, dynamic>> exportProject(
    VeloraProject project,
    int height,
  ) async {
    final result = await _channel.invokeMapMethod<Object?, Object?>(
      'exportProject',
      {'project': project.toMap(), 'height': height},
    );
    if (result == null) throw PlatformException(code: 'empty_export_result');
    return result.map((key, value) => MapEntry(key.toString(), value));
  }
}
