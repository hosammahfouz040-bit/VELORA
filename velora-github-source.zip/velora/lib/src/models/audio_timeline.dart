import 'project.dart';

/// A clipped placement of an audio clip within the visible project duration.
class AudioTimelineSpan {
  const AudioTimelineSpan({
    required this.clip,
    required this.startMs,
    required this.endMs,
    required this.lane,
  });

  final TimelineClip clip;
  final int startMs;
  final int endMs;
  final int lane;
}

/// Places clips on the fewest non-overlapping audio lanes, clipping any tail
/// beyond [projectDurationMs]. The list order remains untouched in the project;
/// this is only a chronological playback/mixing layout.
List<AudioTimelineSpan> layoutAudioTrack(
  List<TimelineClip> clips, {
  required int projectDurationMs,
}) {
  if (projectDurationMs <= 0) return const [];
  final ordered = clips
      .where((clip) => clip.timelineStartMs >= 0 && clip.durationMs > 0)
      .map((clip) => (
            clip: clip,
            start: clip.timelineStartMs,
            end: clip.timelineEndMs < projectDurationMs
                ? clip.timelineEndMs
                : projectDurationMs,
          ))
      .where((entry) => entry.start < entry.end)
      .toList()
    ..sort((a, b) {
      final byStart = a.start.compareTo(b.start);
      if (byStart != 0) return byStart;
      return a.clip.id.compareTo(b.clip.id);
    });

  final laneEnds = <int>[];
  final spans = <AudioTimelineSpan>[];
  for (final entry in ordered) {
    var lane = laneEnds.indexWhere((end) => end <= entry.start);
    if (lane < 0) {
      lane = laneEnds.length;
      laneEnds.add(entry.end);
    } else {
      laneEnds[lane] = entry.end;
    }
    spans.add(AudioTimelineSpan(
      clip: entry.clip,
      startMs: entry.start,
      endMs: entry.end,
      lane: lane,
    ));
  }
  return spans;
}

/// Moves an audio clip independently of the source trim range. The start is
/// bounded to the project duration, while the clip's tail may be clipped at
/// export time if the clip extends beyond the picture.
TimelineClip? moveAudioClipToPosition(
  TimelineClip clip, {
  required int requestedMs,
  required int projectDurationMs,
}) {
  if (clip.durationMs <= 0 || projectDurationMs < 0) return null;
  final positionMs = requestedMs.clamp(0, projectDurationMs).toInt();
  if (positionMs == clip.timelineStartMs) return null;
  return clip.copyWith(timelineStartMs: positionMs);
}

int audioTimelineDurationMs(List<TimelineClip> clips) {
  var duration = 0;
  for (final clip in clips) {
    if (clip.timelineStartMs >= 0 && clip.durationMs > 0 &&
        clip.timelineEndMs > duration) {
      duration = clip.timelineEndMs;
    }
  }
  return duration;
}
