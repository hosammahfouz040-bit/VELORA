package com.velora.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Effects
import kotlin.math.max

private data class OverlayTextItem(
    val id: String,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val fontFamily: String,
    val fontSizeScale: Float,
    val color: Int,
    val background: Int?,
    val alignment: String,
    val shadow: Boolean,
    val outlineWidthScale: Float,
    val outlineColor: Int,
    val x: Float,
    val y: Float,
)

private data class OverlayStickerItem(
    val id: String,
    val startMs: Long,
    val endMs: Long,
    val x: Float,
    val y: Float,
    val widthFraction: Float,
    val bitmap: Bitmap,
)

/** Composition-level effect: cue timestamps are project-timeline timestamps, after concatenation. */
@UnstableApi
internal object ProjectOverlayEffects {
    fun create(
        context: Context,
        project: Map<*, *>,
        timelineMapper: (Long) -> Long = { it },
    ): OverlayEffect? {
        val textItems = mutableListOf<OverlayTextItem>()
        for (row in mapRows(project["textOverlays"])) {
            val text = row["text"]?.toString().orEmpty()
            val originalStart = (row["startMs"] as? Number)?.toLong() ?: 0L
            val originalEnd = (row["endMs"] as? Number)?.toLong() ?: 0L
            val start = timelineMapper(originalStart)
            val end = timelineMapper(originalEnd)
            if (text.isBlank() || start < 0L || end <= start) continue
            textItems += OverlayTextItem(
                id = row["id"]?.toString() ?: "text-${textItems.size}",
                text = text,
                startMs = start,
                endMs = end,
                fontFamily = safeFontFamily(row["fontFamily"]),
                fontSizeScale = safeFloat(row["fontSizeScale"], 0.055f, 0.02f, 0.15f),
                color = (row["colorArgb"] as? Number)?.toInt() ?: Color.WHITE,
                background = (row["backgroundArgb"] as? Number)?.toInt(),
                alignment = row["alignment"]?.toString() ?: "center",
                shadow = row["shadow"] as? Boolean ?: true,
                outlineWidthScale = safeFloat(row["outlineWidthScale"], 0f, 0f, 0.02f),
                outlineColor = (row["outlineArgb"] as? Number)?.toInt() ?: Color.BLACK,
                x = safeFloat(row["positionX"], 0.5f, 0f, 1f),
                y = safeFloat(row["positionY"], 0.5f, 0f, 1f),
            )
        }
        for (row in mapRows(project["subtitleTrack"])) {
            val text = row["text"]?.toString().orEmpty()
            val originalStart = (row["startMs"] as? Number)?.toLong() ?: 0L
            val originalEnd = (row["endMs"] as? Number)?.toLong() ?: 0L
            val start = timelineMapper(originalStart)
            val end = timelineMapper(originalEnd)
            if (text.isBlank() || start < 0L || end <= start) continue
            textItems += OverlayTextItem(
                id = row["id"]?.toString() ?: "subtitle-${textItems.size}",
                text = text,
                startMs = start,
                endMs = end,
                fontFamily = "sans-serif",
                fontSizeScale = 0.045f,
                color = Color.WHITE,
                background = 0xB8000000.toInt(),
                alignment = "center",
                shadow = true,
                outlineWidthScale = 0f,
                outlineColor = Color.BLACK,
                x = 0.5f,
                y = 0.88f,
            )
        }

        val stickers = mapRows(project["stickerOverlays"]).mapNotNull { row ->
            val uriText = row["uri"]?.toString().orEmpty()
            val mime = row["mimeType"]?.toString().orEmpty()
            val originalStart = (row["startMs"] as? Number)?.toLong() ?: 0L
            val originalEnd = (row["endMs"] as? Number)?.toLong() ?: 0L
            val start = timelineMapper(originalStart)
            val end = timelineMapper(originalEnd)
            if (
                uriText.isBlank() ||
                (mime != "image/png" && mime != "image/webp") ||
                start < 0L || end <= start
            ) return@mapNotNull null
            val bitmap = decodeSticker(context, uriText)
                ?: throw IllegalArgumentException("تعذّر قراءة الملصق ${row["name"] ?: ""}")
            OverlayStickerItem(
                id = row["id"]?.toString() ?: "sticker-${stickersSizeFallback(row)}",
                startMs = start,
                endMs = end,
                x = safeFloat(row["positionX"], 0.5f, 0f, 1f),
                y = safeFloat(row["positionY"], 0.5f, 0f, 1f),
                widthFraction = safeFloat(row["widthFraction"], 0.22f, 0.03f, 0.8f),
                bitmap = bitmap,
            )
        }
        if (textItems.isEmpty() && stickers.isEmpty()) return null
        return OverlayEffect(listOf(ProjectTimelineBitmapOverlay(textItems, stickers)))
    }
}

@UnstableApi
private class ProjectTimelineBitmapOverlay(
    private val textItems: List<OverlayTextItem>,
    private val stickers: List<OverlayStickerItem>,
) : BitmapOverlay() {
    private var bitmap: Bitmap? = null
    private var canvasSize: Size? = null
    private var lastActiveSignature: String? = null

    override fun configure(videoSize: Size) {
        if (canvasSize == videoSize && bitmap != null) return
        canvasSize = videoSize
        bitmap = Bitmap.createBitmap(
            videoSize.width.coerceAtLeast(2),
            videoSize.height.coerceAtLeast(2),
            Bitmap.Config.ARGB_8888,
        )
        lastActiveSignature = null
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val current = bitmap ?: throw IllegalStateException("Overlay was not configured")
        val timeMs = (presentationTimeUs / 1_000L).coerceAtLeast(0L)
        val activeTexts = textItems.filter { timeMs >= it.startMs && timeMs < it.endMs }
        val activeStickers = stickers.filter { timeMs >= it.startMs && timeMs < it.endMs }
        val signature = buildString {
            activeTexts.forEach { append('T').append(it.id).append(';') }
            activeStickers.forEach { append('S').append(it.id).append(';') }
        }
        if (signature != lastActiveSignature) {
            current.eraseColor(Color.TRANSPARENT)
            val canvas = Canvas(current)
            activeTexts.forEach { drawTextItem(canvas, current.width, current.height, it) }
            activeStickers.forEach { drawSticker(canvas, current.width, current.height, it) }
            lastActiveSignature = signature
        }
        return current
    }

    private fun drawTextItem(canvas: Canvas, frameWidth: Int, frameHeight: Int, item: OverlayTextItem) {
        val fontSize = max(14f, frameHeight * item.fontSizeScale)
        val maxTextWidth = max(64, (frameWidth * 0.9f).toInt())
        val basePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            textSize = fontSize
            typeface = Typeface.create(item.fontFamily, Typeface.BOLD)
            color = item.color
            if (item.shadow) setShadowLayer(fontSize * 0.10f, fontSize * 0.035f, fontSize * 0.04f, 0xB0000000.toInt())
        }
        val alignment = when (item.alignment) {
            "start" -> Layout.Alignment.ALIGN_NORMAL
            "end" -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_CENTER
        }
        val content = SpannableString(item.text)
        val layout = StaticLayout.Builder.obtain(content, 0, content.length, basePaint, maxTextWidth)
            .setAlignment(alignment)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setIncludePad(true)
            .build()
        val blockWidth = maxTextWidth.toFloat()
        val padding = frameHeight * 0.012f
        val left = item.x * frameWidth - blockWidth / 2f
        val top = item.y * frameHeight - (layout.height + padding * 2f) / 2f
        if (item.background != null) {
            val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.background }
            val rect = RectF(left, top, left + blockWidth, top + layout.height + padding * 2f)
            canvas.drawRoundRect(rect, frameHeight * 0.008f, frameHeight * 0.008f, backgroundPaint)
        }
        canvas.save()
        canvas.translate(left, top + padding)
        if (item.outlineWidthScale > 0f) {
            val outlinePaint = TextPaint(basePaint).apply {
                style = Paint.Style.STROKE
                strokeJoin = Paint.Join.ROUND
                strokeWidth = frameHeight * item.outlineWidthScale
                color = item.outlineColor
                clearShadowLayer()
            }
            val outlineLayout = StaticLayout.Builder.obtain(content, 0, content.length, outlinePaint, maxTextWidth)
                .setAlignment(alignment)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                .setIncludePad(true)
                .build()
            outlineLayout.draw(canvas)
        }
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawSticker(canvas: Canvas, frameWidth: Int, frameHeight: Int, item: OverlayStickerItem) {
        val targetWidth = (frameWidth * item.widthFraction).coerceAtLeast(2f)
        val scale = targetWidth / item.bitmap.width
        val targetHeight = item.bitmap.height * scale
        val centerX = frameWidth * item.x
        val centerY = frameHeight * item.y
        val dst = RectF(
            centerX - targetWidth / 2f,
            centerY - targetHeight / 2f,
            centerX + targetWidth / 2f,
            centerY + targetHeight / 2f,
        )
        canvas.drawBitmap(item.bitmap, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }
}

private fun decodeSticker(context: Context, uriText: String): Bitmap? {
    val uri = android.net.Uri.parse(uriText)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 1024) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
}

private fun mapRows(raw: Any?): List<Map<*, *>> =
    (raw as? List<*>)?.mapNotNull { it as? Map<*, *> }.orEmpty()

private fun safeFontFamily(value: Any?): String = when (value?.toString()) {
    "serif", "monospace", "sans-serif-condensed" -> value.toString()
    else -> "sans-serif"
}

private fun safeFloat(value: Any?, fallback: Float, minimum: Float, maximum: Float): Float {
    val number = (value as? Number)?.toFloat() ?: fallback
    return if (number.isFinite()) number.coerceIn(minimum, maximum) else fallback
}

private fun stickersSizeFallback(row: Map<*, *>): Int =
    (row["startMs"] as? Number)?.toInt() ?: 0
