import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_support/target_platform.dart';

import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_overlays.dart';
import 'package:velora/src/models/video_transitions.dart';
import 'package:velora/src/models/video_filter_presets.dart';
import 'package:velora/src/screens/editor_screen.dart';
import 'package:velora/src/screens/export_screen.dart';

const _rampTransitionProject = VeloraProject(
  id: 'ramp-transition-integration',
  name: 'اختبار Ramp والانتقال',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [
    MediaAsset(
      id: 'a-asset',
      uri: 'content://video/a',
      name: 'a.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1000,
      width: 1920,
      height: 1080,
      sizeBytes: 100,
    ),
    MediaAsset(
      id: 'b-asset',
      uri: 'content://video/b',
      name: 'b.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1000,
      width: 1920,
      height: 1080,
      sizeBytes: 110,
    ),
    MediaAsset(
      id: 'audio-asset',
      uri: 'content://audio/music',
      name: 'music.m4a',
      mimeType: 'audio/mp4',
      kind: MediaKind.audio,
      durationMs: 5000,
      width: 0,
      height: 0,
      sizeBytes: 80,
    ),
  ],
  videoTrack: [
    TimelineClip(id: 'a', assetId: 'a-asset', trimStartMs: 0, trimEndMs: 1000),
    TimelineClip(
      id: 'b',
      assetId: 'b-asset',
      trimStartMs: 0,
      trimEndMs: 1000,
      volume: 0.45,
      fadeInMs: 120,
      fadeOutMs: 130,
      transformKeyframes: [
        ClipTransformKeyframe(timeMs: 300, positionX: 0.2, opacity: 0.8),
      ],
      speedRampPoints: [
        SpeedRampPoint(timeMs: 0, speed: 1),
        SpeedRampPoint(timeMs: 1000, speed: 2),
      ],
    ),
  ],
  audioTrack: [
    TimelineClip(
      id: 'music',
      assetId: 'audio-asset',
      trimStartMs: 200,
      trimEndMs: 4200,
      timelineStartMs: 350,
      volume: 0.65,
      fadeInMs: 250,
      fadeOutMs: 400,
    ),
  ],
  frameSettings: VideoFrameSettings(
    aspectRatio: '9:16',
    fitMode: FrameFitMode.fill,
    positionX: 0.2,
    rotationQuarterTurns: 1,
    flipHorizontal: true,
  ),
  videoTransitions: [
    VideoTransition(
      id: 'a-b',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.fade,
      durationMs: 200,
    ),
  ],
  textOverlays: [
    TextOverlay(id: 'title', text: 'عنوان', startMs: 100, endMs: 600),
  ],
  subtitleTrack: [
    SubtitleCue(id: 'subtitle', text: 'ترجمة', startMs: 200, endMs: 500),
  ],
  stickerOverlays: [
    StickerOverlay(
      id: 'sticker',
      uri: 'content://sticker',
      name: 'sticker.png',
      mimeType: 'image/png',
      startMs: 250,
      endMs: 700,
    ),
  ],
  videoOverlayTracks: [
    VideoOverlayTrack(
      id: 'pip-track',
      name: 'PIP',
      clips: [
        VideoOverlayClip(
          id: 'pip',
          assetId: 'b-asset',
          trimStartMs: 100,
          trimEndMs: 700,
          timelineStartMs: 500,
        ),
      ],
    ),
  ],
);

const _outOfRangeTransitionProject = VeloraProject(
  id: 'out-of-range-transition-edit',
  name: 'اختبار مدة انتقال خارج النطاق',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: [
    MediaAsset(
      id: 'safe-a-asset',
      uri: 'content://video/safe-a',
      name: 'a.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1200,
      width: 1920,
      height: 1080,
      sizeBytes: 100,
    ),
    MediaAsset(
      id: 'safe-b-asset',
      uri: 'content://video/safe-b',
      name: 'b.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1200,
      width: 1920,
      height: 1080,
      sizeBytes: 110,
    ),
    MediaAsset(
      id: 'safe-c-asset',
      uri: 'content://video/safe-c',
      name: 'c.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 1100,
      width: 1920,
      height: 1080,
      sizeBytes: 120,
    ),
    MediaAsset(
      id: 'safe-audio-asset',
      uri: 'content://audio/safe-music',
      name: 'music.m4a',
      mimeType: 'audio/mp4',
      kind: MediaKind.audio,
      durationMs: 5000,
      width: 0,
      height: 0,
      sizeBytes: 80,
    ),
  ],
  videoTrack: [
    TimelineClip(
      id: 'safe-a',
      assetId: 'safe-a-asset',
      trimStartMs: 100,
      trimEndMs: 1100,
    ),
    TimelineClip(
      id: 'safe-b',
      assetId: 'safe-b-asset',
      trimStartMs: 100,
      trimEndMs: 1100,
    ),
    TimelineClip(
      id: 'safe-c',
      assetId: 'safe-c-asset',
      trimStartMs: 50,
      trimEndMs: 1050,
    ),
  ],
  audioTrack: [
    TimelineClip(
      id: 'safe-music',
      assetId: 'safe-audio-asset',
      trimStartMs: 200,
      trimEndMs: 4200,
      timelineStartMs: 350,
      volume: 0.65,
      fadeInMs: 250,
      fadeOutMs: 400,
    ),
  ],
  videoTransitions: [
    VideoTransition(
      id: 'safe-a-b',
      fromClipId: 'safe-a',
      toClipId: 'safe-b',
      type: VideoTransitionType.fade,
      durationMs: 600,
    ),
    VideoTransition(
      id: 'safe-b-c',
      fromClipId: 'safe-b',
      toClipId: 'safe-c',
      type: VideoTransitionType.spin,
      durationMs: 500,
    ),
  ],
);

class _RampSafeSplitPoint {
  const _RampSafeSplitPoint({required this.playheadMs, required this.position});

  final int playheadMs;
  final TimelinePosition position;
}

_RampSafeSplitPoint _calculateSafeRampSplitPoint() {
  final clip = _rampTransitionProject.videoTrack[1];
  final incoming = _rampTransitionProject.videoTransitions.single;
  final layout = layoutVideoTransitions(
    _rampTransitionProject.videoTrack.map((item) => item.id).toList(),
    _rampTransitionProject.videoTrack
        .map((item) => item.effectiveDurationMs)
        .toList(),
    _rampTransitionProject.videoTransitions,
  );
  final requestedOutputOffsetMs = incoming.durationMs + 1;
  final sourceOffsetMs = outputOffsetToSourceMs(
    requestedOutputOffsetMs,
    clip.trimStartMs,
    clip.trimEndMs,
    clip.speedRampPoints,
  );
  final actualOutputOffsetMs = sourceOffsetToOutputMs(
    sourceOffsetMs - clip.trimStartMs,
    clip.trimStartMs,
    clip.speedRampPoints,
  );
  expect(actualOutputOffsetMs, greaterThanOrEqualTo(incoming.durationMs));
  expect(
    speedAdjustedDurationMs(
      clip.trimStartMs,
      sourceOffsetMs,
      clip.speedRampPoints,
    ),
    actualOutputOffsetMs,
  );
  final playheadMs = layout.startOfClip(1) + actualOutputOffsetMs;
  final position = timelinePositionAt(
    _rampTransitionProject.videoTrack,
    playheadMs,
    transitions: _rampTransitionProject.videoTransitions,
  );
  expect(position, isNotNull);
  final resolvedPosition = position!;
  expect(resolvedPosition.clipId, 'b');
  expect(resolvedPosition.clipPositionMs, actualOutputOffsetMs);
  expect(resolvedPosition.sourcePositionMs, sourceOffsetMs);
  return _RampSafeSplitPoint(
    playheadMs: playheadMs,
    position: resolvedPosition,
  );
}

VeloraProject _expectedSafeRampSplit(
  _RampSafeSplitPoint point,
  String secondClipId,
) {
  final splitTrack = splitClipAtPosition(
    _rampTransitionProject.videoTrack,
    'b',
    playheadMs: point.playheadMs,
    secondClipId: secondClipId,
    sourceDurationMs: 1000,
    sourceSplitPositionMs: point.position.sourcePositionMs,
  )!;
  final transitions = transitionsAfterClipSplit(
    _rampTransitionProject.videoTransitions,
    originalClipId: 'b',
    secondClipId: secondClipId,
    firstSegmentDurationMs: splitTrack[1].effectiveDurationMs,
    secondSegmentDurationMs: splitTrack[2].effectiveDurationMs,
  );
  return _rampTransitionProject.copyWith(
    videoTrack: splitTrack,
    videoTransitions: transitions,
  );
}

class _RampSplitRecorder {
  _RampSplitRecorder({
    required this.previewPositionMs,
    required this.failReconfigurations,
    required this.failPausePreview,
    required this.failSaves,
  });

  int previewPositionMs;
  final bool failReconfigurations;
  final bool failPausePreview;
  final bool failSaves;
  int configurationCount = 0;
  int pausePreviewCalls = 0;
  final savedProjects = <Map<String, dynamic>>[];
  final previewConfigurations = <Map<String, dynamic>>[];
}

_RampSplitRecorder _installRampSplitMocks(
  int initialPositionMs, {
  bool failReconfigurations = false,
  bool failPausePreview = false,
  bool failSaves = false,
}) {
  const nativeChannel = MethodChannel('velora/native');
  const platformViewsChannel = MethodChannel('flutter/platform_views');
  final recorder = _RampSplitRecorder(
    previewPositionMs: initialPositionMs,
    failReconfigurations: failReconfigurations,
    failPausePreview: failPausePreview,
    failSaves: failSaves,
  );
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  messenger.setMockMethodCallHandler(nativeChannel, (call) async {
    switch (call.method) {
      case 'configurePreviewTimeline':
        final args = Map<String, dynamic>.from(call.arguments as Map);
        recorder.previewConfigurations.add(args);
        recorder.configurationCount++;
        if (recorder.failReconfigurations && recorder.configurationCount > 1) {
          throw PlatformException(
            code: 'preview-reconfigure-failure',
            message: 'original preview reconfiguration failure',
          );
        }
        if (recorder.configurationCount > 1) {
          recorder.previewPositionMs = (args['timelinePositionMs'] as num)
              .toInt();
        }
        return null;
      case 'seekPreview':
        recorder.previewPositionMs =
            ((call.arguments as Map)['timelinePositionMs'] as num?)?.toInt() ??
            recorder.previewPositionMs;
        return null;
      case 'getPreviewState':
        return <String, Object?>{
          'timelinePositionMs': recorder.previewPositionMs,
          'isPlaying': false,
        };
      case 'saveProject':
        recorder.savedProjects.add(
          Map<String, dynamic>.from(call.arguments as Map),
        );
        if (recorder.failSaves) {
          throw PlatformException(code: 'save-failure', message: 'save failed');
        }
        return null;
      case 'pausePreview':
        recorder.pausePreviewCalls++;
        if (recorder.failPausePreview) {
          throw PlatformException(
            code: 'pause-preview-failure',
            message: 'secondary pause preview failure',
          );
        }
        return null;
      case 'clearPreview':
        return null;
      default:
        throw StateError('Unexpected native method: ${call.method}');
    }
  });
  messenger.setMockMethodCallHandler(platformViewsChannel, (call) async {
    if (call.method == 'create') return 77;
    return null;
  });
  addTearDown(() {
    messenger.setMockMethodCallHandler(nativeChannel, null);
    messenger.setMockMethodCallHandler(platformViewsChannel, null);
  });
  return recorder;
}

void _setUpAndroidEditorViewport(WidgetTester tester) {
  tester.view.physicalSize = const Size(1200, 2200);
  tester.view.devicePixelRatio = 1;
  addTearDown(() {
    tester.view.resetPhysicalSize();
    tester.view.resetDevicePixelRatio();
  });
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgetsOnPlatform(
    'out-of-range saved transition is disclosed and cancel is side-effect free',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0);

      await tester.pumpWidget(
        const MaterialApp(
          home: EditorScreen(project: _outOfRangeTransitionProject),
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      final initialConfigurationCount = recorder.configurationCount;

      final boundaryEditor = find.byKey(
        const ValueKey('timeline-transition-edit-1'),
      );
      await tester.ensureVisible(boundaryEditor);
      await tester.tap(boundaryEditor);
      await tester.pump();

      expect(find.text('المدة المحفوظة: 500 مللي ثانية.'), findsOneWidget);
      expect(
        find.textContaining('المدة الآمنة المقترحة: 400 مللي ثانية.'),
        findsOneWidget,
      );
      expect(
        tester.widget<TextField>(find.byType(TextField).last).controller!.text,
        isEmpty,
      );
      final applyButton = tester.widget<FilledButton>(
        find.byKey(const ValueKey('transition-apply-button')),
      );
      expect(applyButton.onPressed, isNull);
      expect(recorder.savedProjects, isEmpty);

      await tester.tap(find.widgetWithText(TextButton, 'إلغاء'));
      await tester.pump();

      expect(recorder.savedProjects, isEmpty);
      expect(recorder.configurationCount, initialConfigurationCount);
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('إعادة')).onPressed,
        isNull,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'out-of-range transition requires an explicit valid duration and preserves project history',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0);

      await tester.pumpWidget(
        const MaterialApp(
          home: EditorScreen(project: _outOfRangeTransitionProject),
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      final boundaryEditor = find.byKey(
        const ValueKey('timeline-transition-edit-1'),
      );
      await tester.ensureVisible(boundaryEditor);
      await tester.tap(boundaryEditor);
      await tester.pump();

      final durationField = find.byType(TextField).last;
      await tester.enterText(durationField, '401');
      await tester.pump();
      expect(
        tester
            .widget<FilledButton>(
              find.byKey(const ValueKey('transition-apply-button')),
            )
            .onPressed,
        isNull,
      );
      expect(recorder.savedProjects, isEmpty);
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('إعادة')).onPressed,
        isNull,
      );

      await tester.enterText(durationField, '350');
      await tester.pump();
      expect(
        tester
            .widget<FilledButton>(
              find.byKey(const ValueKey('transition-apply-button')),
            )
            .onPressed,
        isNotNull,
      );
      await tester.tap(find.byKey(const ValueKey('transition-apply-button')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(recorder.savedProjects, hasLength(1));
      final changedProject = recorder.savedProjects.single;
      final changedTransitions = (changedProject['videoTransitions'] as List)
          .cast<Map>();
      expect(
        changedTransitions.singleWhere(
          (item) => item['id'] == 'safe-a-b',
        )['durationMs'],
        600,
      );
      expect(
        changedTransitions.singleWhere(
          (item) => item['id'] == 'safe-b-c',
        )['durationMs'],
        350,
      );
      expect(
        changedProject['videoTrack'],
        _outOfRangeTransitionProject.toMap()['videoTrack'],
      );
      expect(
        changedProject['audioTrack'],
        _outOfRangeTransitionProject.toMap()['audioTrack'],
      );

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, _outOfRangeTransitionProject.toMap());

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        recorder.savedProjects.last['videoTrack'],
        changedProject['videoTrack'],
      );
      expect(
        recorder.savedProjects.last['audioTrack'],
        changedProject['audioTrack'],
      );
      final redoneTransitions =
          (recorder.savedProjects.last['videoTransitions'] as List).cast<Map>();
      expect(
        redoneTransitions.singleWhere(
          (item) => item['id'] == 'safe-a-b',
        )['durationMs'],
        600,
      );
      expect(
        redoneTransitions.singleWhere(
          (item) => item['id'] == 'safe-b-c',
        )['durationMs'],
        350,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'filter preset rebuilds the Android preview with per-clip grade',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0);
      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final clipTap = find.byKey(const ValueKey('timeline-video-tap-a'));
      await tester.ensureVisible(clipTap);
      await tester.tap(clipTap);
      await tester.pump(const Duration(milliseconds: 30));
      final chip = find.byKey(const ValueKey('video-filter-cool-a'));
      await tester.ensureVisible(chip);
      await tester.tap(chip);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final preset = videoFilterPresets.singleWhere(
        (item) => item.id == 'cool',
      );
      final savedClip =
          ((recorder.savedProjects.last['videoTrack'] as List).first as Map);
      expect(savedClip['colorSettingsOverride'], preset.settings.toMap());
      expect(recorder.previewConfigurations.length, greaterThanOrEqualTo(2));
      final previewClip =
          ((recorder.previewConfigurations.last['project']['videoTrack']
                      as List)
                  .first
              as Map);
      expect(previewClip['colorSettingsOverride'], preset.settings.toMap());

      await tester.pumpWidget(const SizedBox.shrink());
    },
  );

  testWidgetsOnPlatform(
    'slide transition exposes and persists a supported direction',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0);
      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final boundaryEditor = find.byKey(
        const ValueKey('timeline-transition-edit-0'),
      );
      await tester.ensureVisible(boundaryEditor);
      await tester.tap(boundaryEditor);
      await tester.pump();
      await tester.tap(find.byType(DropdownButton<VideoTransitionType>));
      await tester.pump(const Duration(milliseconds: 250));
      await tester.tap(find.text('انزلاق').last);
      await tester.pump(const Duration(milliseconds: 250));

      expect(
        find.byKey(const ValueKey('transition-direction-dropdown')),
        findsOneWidget,
      );
      await tester.tap(
        find.byKey(const ValueKey('transition-direction-dropdown')),
      );
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('من الأعلى').last);
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.byKey(const ValueKey('transition-apply-button')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final saved = recorder.savedProjects.single;
      final transition = (saved['videoTransitions'] as List).first as Map;
      expect(transition['type'], 'slide');
      expect(transition['direction'], 'down');
      expect(recorder.previewConfigurations.length, greaterThanOrEqualTo(2));

      await tester.pumpWidget(const SizedBox.shrink());
    },
  );

  testWidgetsOnPlatform(
    'transition editor saves a previewable edit and supports undo and redo',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0);

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final boundaryEditor = find.byKey(
        const ValueKey('timeline-transition-edit-0'),
      );
      await tester.ensureVisible(boundaryEditor);
      await tester.tap(boundaryEditor);
      await tester.pump();
      expect(find.text('إعداد الانتقال'), findsOneWidget);
      expect(find.text('تلاشي عبر الأسود'), findsWidgets);

      await tester.tap(find.byType(DropdownButton<VideoTransitionType>));
      await tester.pump(const Duration(milliseconds: 250));
      await tester.tap(find.text('تكبير').last);
      await tester.pump(const Duration(milliseconds: 250));
      final intensitySlider = tester.widget<Slider>(
        find.byKey(const ValueKey('transition-intensity-slider')),
      );
      intensitySlider.onChanged!(0.5);
      await tester.pump();
      final dialogSlider = tester.widget<Slider>(
        find.byKey(const ValueKey('transition-duration-slider')),
      );
      expect(dialogSlider.max, greaterThan(250));
      dialogSlider.onChanged!(250);
      await tester.pump();
      await tester.tap(find.widgetWithText(FilledButton, 'تطبيق'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(recorder.savedProjects, hasLength(1));
      final changedProject = recorder.savedProjects.single;
      final changedTransition =
          (changedProject['videoTransitions'] as List).first as Map;
      expect(changedTransition['type'], 'zoom');
      expect(changedTransition['durationMs'], 250);
      expect(changedTransition['intensity'], 0.5);
      expect(
        changedProject['audioTrack'],
        _rampTransitionProject.toMap()['audioTrack'],
      );
      expect(recorder.previewConfigurations.length, greaterThanOrEqualTo(2));
      expect(
        recorder.previewConfigurations.last['project']['videoTransitions'],
        changedProject['videoTransitions'],
      );

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, _rampTransitionProject.toMap());

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        recorder.savedProjects.last['videoTransitions'],
        changedProject['videoTransitions'],
      );
      expect(
        recorder.savedProjects.last['audioTrack'],
        changedProject['audioTrack'],
      );
      expect(recorder.previewConfigurations.length, greaterThanOrEqualTo(4));

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'failed transition save keeps the local edit available to undo',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(0, failSaves: true);

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      await tester.tap(
        find.byKey(const ValueKey('timeline-transition-edit-0')),
      );
      await tester.pump();
      await tester.tap(find.byType(DropdownButton<VideoTransitionType>));
      await tester.pump(const Duration(milliseconds: 250));
      await tester.tap(find.text('تكبير').last);
      await tester.pump(const Duration(milliseconds: 250));
      await tester.tap(find.widgetWithText(FilledButton, 'تطبيق'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(
        (recorder.savedProjects.last['videoTransitions'] as List).first['type'],
        'zoom',
      );
      expect(find.textContaining('غير محفوظ'), findsOneWidget);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, _rampTransitionProject.toMap());
      expect(find.textContaining('تلاشي ·'), findsOneWidget);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'imports audio at zero, preserves existing clips, warns on overflow, and undoes as one step',
    TargetPlatform.linux,
    (tester) async {
      const channel = MethodChannel('velora/native');
      final savedProjects = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            switch (call.method) {
              case 'pickMedia':
                return <Map<String, Object?>>[
                  {
                    'id': 'picked-audio',
                    'uri': 'content://media/audio/new-import',
                    'name': 'long-track.m4a',
                    'mimeType': 'audio/mp4',
                    'kind': 'audio',
                    'durationMs': 2000,
                    'width': 0,
                    'height': 0,
                    'sizeBytes': 120,
                  },
                ];
              case 'saveProject':
                savedProjects.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'audio-import-zero-start',
        name: 'استيراد صوت',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'video-asset',
            uri: 'content://media/video/import-test',
            name: 'picture.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 4000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'existing-audio-asset',
            uri: 'content://media/audio/existing',
            name: 'existing.m4a',
            mimeType: 'audio/mp4',
            kind: MediaKind.audio,
            durationMs: 7000,
            width: 0,
            height: 0,
            sizeBytes: 80,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'video-clip',
            assetId: 'video-asset',
            trimStartMs: 0,
            trimEndMs: 4000,
          ),
        ],
        audioTrack: [
          TimelineClip(
            id: 'existing-audio-clip',
            assetId: 'existing-audio-asset',
            trimStartMs: 250,
            trimEndMs: 3250,
            timelineStartMs: 1200,
            volume: 0.37,
            fadeInMs: 111,
            fadeOutMs: 222,
          ),
        ],
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.tap(find.text('استيراد وسائط'));
      await tester.pumpAndSettle();

      expect(savedProjects, hasLength(1));
      final saved = savedProjects.single;
      final savedAudio = (saved['audioTrack'] as List).cast<Map>();
      expect(
        Map<String, dynamic>.from(savedAudio.first),
        project.audioTrack.single.toMap(),
      );
      expect(savedAudio, hasLength(2));
      expect(savedAudio[1]['timelineStartMs'], 0);
      expect(savedAudio[1]['trimStartMs'], 0);
      expect(savedAudio[1]['trimEndMs'], 2000);
      expect(savedAudio[1]['volume'], 1.0);
      expect(savedAudio[1]['fadeInMs'], 0);
      expect(savedAudio[1]['fadeOutMs'], 0);
      expect((saved['assets'] as List), hasLength(3));
      expect(
        find.text(
          'تنبيه: يتجاوز مقطع صوتي مدة الخط الزمني المرئي؛ قد لا تشمل المعاينة والتصدير الحاليان الجزء الأخير من الصوت.',
        ),
        findsOneWidget,
      );

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pumpAndSettle();
      expect(savedProjects.last, project.toMap());

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pumpAndSettle();
      expect((savedProjects.last['audioTrack'] as List), hasLength(2));
      expect(
        (savedProjects.last['audioTrack'] as List)[1]['timelineStartMs'],
        0,
      );
      expect((savedProjects.last['audioTrack'] as List)[1]['trimEndMs'], 2000);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'failed import save can be retried without picking media again',
    TargetPlatform.linux,
    (tester) async {
      const channel = MethodChannel('velora/native');
      var pickCalls = 0;
      var saveCalls = 0;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            switch (call.method) {
              case 'pickMedia':
                pickCalls++;
                return <Map<String, Object?>>[
                  {
                    'id': 'retry-audio',
                    'uri': 'content://media/audio/retry-test',
                    'name': 'retry.m4a',
                    'mimeType': 'audio/mp4',
                    'kind': 'audio',
                    'durationMs': 1500,
                    'width': 0,
                    'height': 0,
                    'sizeBytes': 50,
                  },
                ];
              case 'saveProject':
                saveCalls++;
                if (saveCalls == 1) {
                  throw PlatformException(code: 'write_failed');
                }
                return null;
              default:
                return null;
            }
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'save-retry',
        name: 'إعادة محاولة الحفظ',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'retry-video',
            uri: 'content://media/video/retry-test',
            name: 'video.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 4000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'retry-video-clip',
            assetId: 'retry-video',
            trimStartMs: 0,
            trimEndMs: 4000,
          ),
        ],
        audioTrack: [],
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.tap(find.text('استيراد وسائط'));
      await tester.pumpAndSettle();

      expect(pickCalls, 1);
      expect(saveCalls, 1);
      expect(find.textContaining('غير محفوظ:'), findsOneWidget);
      expect(
        find.widgetWithText(TextButton, 'إعادة محاولة الحفظ'),
        findsOneWidget,
      );

      await tester.tap(find.widgetWithText(TextButton, 'إعادة محاولة الحفظ'));
      await tester.pumpAndSettle();

      expect(pickCalls, 1);
      expect(saveCalls, 2);
      expect(find.textContaining('غير محفوظ:'), findsNothing);
      expect(
        find.text(
          '1 مقطع أساسي · 0 طبقة فيديو · 0 نص · 0 ترجمة · 0 ملصق · 1 مقطع صوتي',
        ),
        findsOneWidget,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'editor undo and redo persist the restored clip trim',
    TargetPlatform.linux,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const channel = MethodChannel('velora/native');
      final savedProjects = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            if (call.method == 'saveProject') {
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
            }
            return null;
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'editor-history',
        name: 'اختبار التراجع',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'asset-1',
            uri: 'content://media/video/1',
            name: 'clip.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 5000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'audio-1',
            uri: 'content://media/audio/1',
            name: 'music.m4a',
            mimeType: 'audio/mp4',
            kind: MediaKind.audio,
            durationMs: 9000,
            width: 0,
            height: 0,
            sizeBytes: 200,
          ),
        ],

        videoTrack: [
          TimelineClip(
            id: 'clip-1',
            assetId: 'asset-1',
            trimStartMs: 1000,
            trimEndMs: 4000,
          ),
        ],
        audioTrack: [
          TimelineClip(
            id: 'audio-clip-1',
            assetId: 'audio-1',
            trimStartMs: 500,
            trimEndMs: 8500,
            timelineStartMs: 750,
            volume: 0.7,
            fadeInMs: 600,
            fadeOutMs: 400,
          ),
        ],
      );

      Map<String, dynamic> expectedProjectWithStart(int trimStartMs) => project
          .copyWith(
            videoTrack: [
              project.videoTrack.single.copyWith(trimStartMs: trimStartMs),
            ],
          )
          .toMap();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));

      final trimButton = find.byTooltip('تقليل 100 مللي ثانية').first;
      await tester.ensureVisible(trimButton);
      await tester.tap(trimButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));

      expect(savedProjects, isNotEmpty);
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 900);
      expect(savedProjects.last, expectedProjectWithStart(900));

      final trimValue = find.text('00:00.900').first;
      await tester.tap(trimValue);
      await tester.pump();
      await tester.enterText(find.byType(TextField), '0.877');
      await tester.tap(find.text('تطبيق'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 877);
      expect(savedProjects.last, expectedProjectWithStart(877));

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 900);
      expect(savedProjects.last, expectedProjectWithStart(900));

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 1000);
      expect(savedProjects.last, expectedProjectWithStart(1000));

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 900);
      expect(savedProjects.last, expectedProjectWithStart(900));

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimStartMs'], 877);
      expect(savedProjects.last, expectedProjectWithStart(877));
      final expectedLatestProject = project.copyWith(
        videoTrack: [project.videoTrack.single.copyWith(trimStartMs: 877)],
      );
      expect(savedProjects.last, expectedLatestProject.toMap());
      await tester.tap(find.byTooltip('حفظ المشروع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last, expectedLatestProject.toMap());
      expect(savedProjects.last['audioTrack'][0]['trimStartMs'], 500);
      expect(savedProjects.last['audioTrack'][0]['trimEndMs'], 8500);
      expect(savedProjects.last['audioTrack'][0]['timelineStartMs'], 750);
      expect(savedProjects.last['audioTrack'][0]['volume'], 0.7);
      expect(savedProjects.last['audioTrack'][0]['fadeInMs'], 600);
      expect(savedProjects.last['audioTrack'][0]['fadeOutMs'], 400);

      final restored = VeloraProject.fromMap(savedProjects.last);
      expect(restored.id, project.id);
      expect(restored.name, project.name);
      expect(restored.assets, hasLength(2));
      expect(restored.assets.last.uri, 'content://media/audio/1');
      expect(restored.videoTrack.single.trimStartMs, 877);
      expect(restored.audioTrack.single.trimEndMs, 8500);
      expect(restored.audioTrack.single.timelineStartMs, 750);
      expect(restored.audioTrack.single.volume, 0.7);
      expect(restored.audioTrack.single.fadeInMs, 600);
      expect(restored.audioTrack.single.fadeOutMs, 400);

      await tester.tap(find.byTooltip('تصدير الفيديو'));
      await tester.pumpAndSettle();
      expect(find.byType(ExportScreen), findsOneWidget);
      final exportScreen = tester.widget<ExportScreen>(
        find.byType(ExportScreen),
      );
      expect(exportScreen.project.toMap(), expectedLatestProject.toMap());
      expect(savedProjects.last, expectedLatestProject.toMap());

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'split at the playhead uses mapped source time and fully undoes/redoes',
    TargetPlatform.android,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const nativeChannel = MethodChannel('velora/native');
      const platformViewsChannel = MethodChannel('flutter/platform_views');
      final savedProjects = <Map<String, dynamic>>[];
      final previewConfigurations = <Map<String, dynamic>>[];
      var previewPositionMs = 1100;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(nativeChannel, (call) async {
            switch (call.method) {
              case 'configurePreviewTimeline':
                final args = Map<String, dynamic>.from(call.arguments as Map);
                previewConfigurations.add(args);
                if (previewConfigurations.length > 1) {
                  previewPositionMs = (args['timelinePositionMs'] as num)
                      .toInt();
                }
                return null;
              case 'getPreviewState':
                return <String, Object?>{
                  'timelinePositionMs': previewPositionMs,
                  'isPlaying': false,
                };
              case 'saveProject':
                savedProjects.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(platformViewsChannel, (call) async {
            if (call.method == 'create') return 77;
            return null;
          });
      addTearDown(() {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(nativeChannel, null);
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(platformViewsChannel, null);
      });

      const project = VeloraProject(
        id: 'editor-split',
        name: 'اختبار التقسيم',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'a-asset',
            uri: 'content://video/a',
            name: 'a.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'b-asset',
            uri: 'content://video/b',
            name: 'b.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 110,
          ),
          MediaAsset(
            id: 'c-asset',
            uri: 'content://video/c',
            name: 'c.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 120,
          ),
          MediaAsset(
            id: 'audio-asset',
            uri: 'content://audio/music',
            name: 'music.m4a',
            mimeType: 'audio/mp4',
            kind: MediaKind.audio,
            durationMs: 5000,
            width: 0,
            height: 0,
            sizeBytes: 80,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'a',
            assetId: 'a-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'b',
            assetId: 'b-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
            volume: 0.45,
            fadeInMs: 120,
            fadeOutMs: 130,
            transformKeyframes: [
              ClipTransformKeyframe(timeMs: 300, positionX: 0.2, opacity: 0.8),
            ],
            speedRampPoints: [
              SpeedRampPoint(timeMs: 0, speed: 1),
              SpeedRampPoint(timeMs: 1000, speed: 2),
            ],
          ),
          TimelineClip(
            id: 'c',
            assetId: 'c-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
        ],
        audioTrack: [
          TimelineClip(
            id: 'music',
            assetId: 'audio-asset',
            trimStartMs: 200,
            trimEndMs: 4200,
            timelineStartMs: 350,
            volume: 0.65,
            fadeInMs: 250,
            fadeOutMs: 400,
          ),
        ],
        frameSettings: VideoFrameSettings(
          aspectRatio: '9:16',
          fitMode: FrameFitMode.fill,
          positionX: 0.2,
          rotationQuarterTurns: 1,
          flipHorizontal: true,
        ),
        videoTransitions: [
          VideoTransition(
            id: 'a-b',
            fromClipId: 'a',
            toClipId: 'b',
            type: VideoTransitionType.fade,
            durationMs: 100,
          ),
          VideoTransition(
            id: 'b-c',
            fromClipId: 'b',
            toClipId: 'c',
            type: VideoTransitionType.slide,
            durationMs: 100,
            direction: 'left',
            intensity: 0.7,
          ),
        ],
        textOverlays: [
          TextOverlay(id: 'title', text: 'عنوان', startMs: 100, endMs: 600),
        ],
        subtitleTrack: [
          SubtitleCue(id: 'subtitle', text: 'ترجمة', startMs: 200, endMs: 500),
        ],
        stickerOverlays: [
          StickerOverlay(
            id: 'sticker',
            uri: 'content://sticker',
            name: 'sticker.png',
            mimeType: 'image/png',
            startMs: 250,
            endMs: 700,
          ),
        ],
        videoOverlayTracks: [
          VideoOverlayTrack(
            id: 'pip-track',
            name: 'PIP',
            clips: [
              VideoOverlayClip(
                id: 'pip',
                assetId: 'b-asset',
                trimStartMs: 100,
                trimEndMs: 700,
                timelineStartMs: 500,
              ),
            ],
          ),
        ],
      );
      final sourcePosition = timelinePositionAt(
        project.videoTrack,
        1100,
        transitions: project.videoTransitions,
      )!;
      expect(sourcePosition.clipId, 'b');
      expect(sourcePosition.sourcePositionMs, 216);

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        1100,
      );

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(savedProjects, isNotEmpty);
      final splitMap = savedProjects.last;
      final splitTrackRows = splitMap['videoTrack'] as List<dynamic>;
      expect(splitTrackRows.map((row) => (row as Map)['id']), [
        'a',
        'b',
        splitTrackRows[2]['id'],
        'c',
      ]);
      final secondId = (splitTrackRows[2] as Map)['id'] as String;
      expect(splitTrackRows[1]['trimEndMs'], 216);
      expect(splitTrackRows[2]['trimStartMs'], 216);

      final expectedTrack = splitClipAtPosition(
        project.videoTrack,
        'b',
        playheadMs: 1100,
        secondClipId: secondId,
        sourceDurationMs: 1000,
        sourceSplitPositionMs: sourcePosition.sourcePositionMs,
      )!;
      final expectedTransitions = transitionsAfterClipSplit(
        project.videoTransitions,
        originalClipId: 'b',
        secondClipId: secondId,
        firstSegmentDurationMs: expectedTrack[1].effectiveDurationMs,
        secondSegmentDurationMs: expectedTrack[2].effectiveDurationMs,
      );
      final expectedProject = project.copyWith(
        videoTrack: expectedTrack,
        videoTransitions: expectedTransitions,
      );
      expect(splitMap, expectedProject.toMap());
      expect(splitTrackRows[1]['volume'], 0.45);
      expect(splitTrackRows[2]['volume'], 0.45);
      expect(splitTrackRows[2]['fadeInMs'], 120);
      expect(splitTrackRows[2]['fadeOutMs'], 130);
      expect((splitMap['audioTrack'] as List), project.toMap()['audioTrack']);
      expect(splitMap['frameSettings'], project.toMap()['frameSettings']);
      expect(splitMap['textOverlays'], project.toMap()['textOverlays']);
      expect(splitMap['subtitleTrack'], project.toMap()['subtitleTrack']);
      expect(splitMap['stickerOverlays'], project.toMap()['stickerOverlays']);
      expect(
        splitMap['videoOverlayTracks'],
        project.toMap()['videoOverlayTracks'],
      );

      expect(previewConfigurations, hasLength(2));
      expect(previewConfigurations.last['startIndex'], 2);
      expect(previewConfigurations.last['clipPositionMs'], 0);
      expect(previewConfigurations.last['timelinePositionMs'], 1100);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(savedProjects.last, project.toMap());

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(savedProjects.last, expectedProject.toMap());
      expect(previewConfigurations.last['startIndex'], 2);
      expect(previewConfigurations.last['clipPositionMs'], 0);
      expect(previewConfigurations.last['timelinePositionMs'], 1100);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'rejects a split that would tie clip starts by shortening a transition',
    TargetPlatform.android,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const nativeChannel = MethodChannel('velora/native');
      const platformViewsChannel = MethodChannel('flutter/platform_views');
      final savedProjects = <Map<String, dynamic>>[];
      final previewConfigurations = <Map<String, dynamic>>[];
      const previewPositionMs = 970;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(nativeChannel, (call) async {
            switch (call.method) {
              case 'configurePreviewTimeline':
                previewConfigurations.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'getPreviewState':
                return <String, Object?>{
                  'timelinePositionMs': previewPositionMs,
                  'isPlaying': false,
                };
              case 'saveProject':
                savedProjects.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(platformViewsChannel, (call) async {
            if (call.method == 'create') return 77;
            return null;
          });
      addTearDown(() {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(nativeChannel, null);
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(platformViewsChannel, null);
      });

      const project = VeloraProject(
        id: 'editor-split-tied-starts',
        name: 'تقسيم مع بدايتين متساويتين',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'a-asset',
            uri: 'content://video/a',
            name: 'a.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'b-asset',
            uri: 'content://video/b',
            name: 'b.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 150,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'c-asset',
            uri: 'content://video/c',
            name: 'c.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'a',
            assetId: 'a-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'b',
            assetId: 'b-asset',
            trimStartMs: 0,
            trimEndMs: 150,
          ),
          TimelineClip(
            id: 'c',
            assetId: 'c-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
        ],
        audioTrack: [],
        videoTransitions: [
          VideoTransition(
            id: 'a-b',
            fromClipId: 'a',
            toClipId: 'b',
            type: VideoTransitionType.fade,
            durationMs: 80,
          ),
          VideoTransition(
            id: 'b-c',
            fromClipId: 'b',
            toClipId: 'c',
            type: VideoTransitionType.slide,
            durationMs: 100,
          ),
        ],
      );

      final playheadPosition = timelinePositionAt(
        project.videoTrack,
        previewPositionMs,
        transitions: project.videoTransitions,
      )!;
      expect(playheadPosition.clipId, 'b');
      expect(playheadPosition.sourcePositionMs, 50);
      final hypotheticalTrack = splitClipAtPosition(
        project.videoTrack,
        'b',
        playheadMs: previewPositionMs,
        secondClipId: 'b-second',
        sourceDurationMs: 150,
        sourceSplitPositionMs: playheadPosition.sourcePositionMs,
      )!;
      final hypotheticalTransitions = transitionsAfterClipSplit(
        project.videoTransitions,
        originalClipId: 'b',
        secondClipId: 'b-second',
        firstSegmentDurationMs: hypotheticalTrack[1].effectiveDurationMs,
        secondSegmentDurationMs: hypotheticalTrack[2].effectiveDurationMs,
      );
      final hypotheticalLayout = layoutVideoTransitions(
        hypotheticalTrack.map((clip) => clip.id).toList(),
        hypotheticalTrack.map((clip) => clip.effectiveDurationMs).toList(),
        hypotheticalTransitions,
      );
      expect(
        hypotheticalLayout.startOfClip(2),
        hypotheticalLayout.startOfClip(3),
      );
      final originalDurationMs = visualTimelineDurationMs(
        project.videoTrack,
        transitions: project.videoTransitions,
      );
      final hypotheticalDurationMs = visualTimelineDurationMs(
        hypotheticalTrack,
        transitions: hypotheticalTransitions,
      );
      expect(
        splitPreservesTransitionSchedule(
          originalTransitions: project.videoTransitions,
          splitTransitions: hypotheticalTransitions,
          originalClipId: 'b',
          secondClipId: 'b-second',
          originalTimelineDurationMs: originalDurationMs,
          splitTimelineDurationMs: hypotheticalDurationMs,
        ),
        isFalse,
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        previewPositionMs,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();

      expect(
        find.textContaining('لا يمكن التقسيم عند هذا الموضع'),
        findsOneWidget,
      );
      expect(savedProjects, isEmpty);
      expect(previewConfigurations, hasLength(1));
      expect(
        find.text(
          '3 مقطع أساسي · 0 طبقة فيديو · 0 نص · 0 ترجمة · 0 ملصق · 0 مقطع صوتي',
        ),
        findsOneWidget,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'rejects a split that shortens an incoming transition without saving or history',
    TargetPlatform.android,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const nativeChannel = MethodChannel('velora/native');
      const platformViewsChannel = MethodChannel('flutter/platform_views');
      final savedProjects = <Map<String, dynamic>>[];
      final previewConfigurations = <Map<String, dynamic>>[];
      const previewPositionMs = 1950;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(nativeChannel, (call) async {
            switch (call.method) {
              case 'configurePreviewTimeline':
                previewConfigurations.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'getPreviewState':
                return <String, Object?>{
                  'timelinePositionMs': previewPositionMs,
                  'isPlaying': false,
                };
              case 'saveProject':
                savedProjects.add(
                  Map<String, dynamic>.from(call.arguments as Map),
                );
                return null;
              case 'pausePreview':
              case 'clearPreview':
                return null;
              default:
                throw StateError('Unexpected native method: ${call.method}');
            }
          });
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(platformViewsChannel, (call) async {
            if (call.method == 'create') return 77;
            return null;
          });
      addTearDown(() {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(nativeChannel, null);
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(platformViewsChannel, null);
      });

      const project = VeloraProject(
        id: 'editor-reject-transition-shortening',
        name: 'رفض تقصير انتقال',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'a-asset',
            uri: 'content://video/a',
            name: 'a.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'b-asset',
            uri: 'content://video/b',
            name: 'b.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'c-asset',
            uri: 'content://video/c',
            name: 'c.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'a',
            assetId: 'a-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'b',
            assetId: 'b-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
          TimelineClip(
            id: 'c',
            assetId: 'c-asset',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
        ],
        audioTrack: [],
        videoTransitions: [
          VideoTransition(
            id: 'b-c',
            fromClipId: 'b',
            toClipId: 'c',
            type: VideoTransitionType.fade,
            durationMs: 100,
          ),
        ],
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        previewPositionMs,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();

      expect(
        find.textContaining('لا يمكن التقسيم عند هذا الموضع'),
        findsOneWidget,
      );
      expect(savedProjects, isEmpty);
      expect(previewConfigurations, hasLength(1));
      expect(
        find.text(
          '3 مقطع أساسي · 0 طبقة فيديو · 0 نص · 0 ترجمة · 0 ملصق · 0 مقطع صوتي',
        ),
        findsOneWidget,
      );
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'trimming the end updates duration and is undoable and redoable',
    TargetPlatform.linux,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const channel = MethodChannel('velora/native');
      final savedProjects = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            if (call.method == 'saveProject') {
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
            }
            return null;
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'editor-trim-end',
        name: 'قص النهاية',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'asset-end',
            uri: 'content://media/video/end',
            name: 'end.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 5000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
          MediaAsset(
            id: 'audio-end',
            uri: 'content://media/audio/end',
            name: 'sound.m4a',
            mimeType: 'audio/mp4',
            kind: MediaKind.audio,
            durationMs: 6000,
            width: 0,
            height: 0,
            sizeBytes: 120,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'clip-end',
            assetId: 'asset-end',
            trimStartMs: 1000,
            trimEndMs: 4000,
          ),
          TimelineClip(
            id: 'clip-end-2',
            assetId: 'asset-end',
            trimStartMs: 0,
            trimEndMs: 2000,
          ),
        ],
        audioTrack: [
          TimelineClip(
            id: 'audio-clip-end',
            assetId: 'audio-end',
            trimStartMs: 200,
            trimEndMs: 5200,
            timelineStartMs: 350,
            volume: 0.6,
            fadeInMs: 300,
            fadeOutMs: 450,
          ),
        ],
        frameSettings: VideoFrameSettings(
          aspectRatio: '9:16',
          fitMode: FrameFitMode.fill,
          positionX: 0.2,
          rotationQuarterTurns: 1,
          flipHorizontal: true,
        ),
        videoTransitions: [
          VideoTransition(
            id: 'transition-end',
            fromClipId: 'clip-end',
            toClipId: 'clip-end-2',
            type: VideoTransitionType.dissolve,
            durationMs: 200,
          ),
        ],
        textOverlays: [
          TextOverlay(
            id: 'title-end',
            text: 'عنوان محفوظ',
            startMs: 100,
            endMs: 900,
            positionX: 0.3,
            positionY: 0.25,
          ),
        ],
        subtitleTrack: [
          SubtitleCue(
            id: 'subtitle-end',
            text: 'ترجمة محفوظة',
            startMs: 250,
            endMs: 750,
          ),
        ],
        stickerOverlays: [
          StickerOverlay(
            id: 'sticker-end',
            uri: 'content://sticker/end',
            name: 'sticker.png',
            mimeType: 'image/png',
            startMs: 300,
            endMs: 800,
            positionX: 0.8,
            positionY: 0.7,
          ),
        ],
        videoOverlayTracks: [
          VideoOverlayTrack(
            id: 'overlay-track-end',
            name: 'PIP',
            clips: [
              VideoOverlayClip(
                id: 'overlay-clip-end',
                assetId: 'asset-end',
                trimStartMs: 100,
                trimEndMs: 1100,
                timelineStartMs: 1250,
                positionX: 0.72,
                positionY: 0.24,
              ),
            ],
          ),
        ],
      );

      Map<String, dynamic> expectedProjectWithEnd(int trimEndMs) => project
          .copyWith(
            videoTrack: [
              project.videoTrack[0].copyWith(trimEndMs: trimEndMs),
              project.videoTrack[1],
            ],
          )
          .toMap();

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      expect(find.text('00:04.800'), findsOneWidget);

      final trimEndButton = find
          .byTooltip('تقليل 100 مللي ثانية من النهاية')
          .first;
      await tester.ensureVisible(trimEndButton);
      await tester.tap(trimEndButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimEndMs'], 3900);
      expect(savedProjects.last, expectedProjectWithEnd(3900));
      expect(find.text('00:04.700'), findsOneWidget);
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        0,
      );

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimEndMs'], 4000);
      expect(savedProjects.last, expectedProjectWithEnd(4000));
      expect(find.text('00:04.800'), findsOneWidget);

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));
      expect(savedProjects.last['videoTrack'][0]['trimEndMs'], 3900);
      expect(savedProjects.last, expectedProjectWithEnd(3900));
      expect(find.text('00:04.700'), findsOneWidget);
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        0,
      );

      await tester.tap(find.byTooltip('تصدير الفيديو'));
      await tester.pumpAndSettle();
      final exportScreen = tester.widget<ExportScreen>(
        find.byType(ExportScreen),
      );
      expect(exportScreen.project.toMap(), expectedProjectWithEnd(3900));
      expect(savedProjects.last, expectedProjectWithEnd(3900));

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'a trim request that changes no boundary creates no history entry',
    TargetPlatform.linux,
    (tester) async {
      tester.view.physicalSize = const Size(1200, 2200);
      tester.view.devicePixelRatio = 1;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      const channel = MethodChannel('velora/native');
      final savedProjects = <Map<String, dynamic>>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            if (call.method == 'saveProject') {
              savedProjects.add(
                Map<String, dynamic>.from(call.arguments as Map),
              );
            }
            return null;
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );

      const project = VeloraProject(
        id: 'editor-noop-trim',
        name: 'قص بلا تغيير',
        createdAt: '2026-10-28T00:00:00.000Z',
        assets: [
          MediaAsset(
            id: 'asset-noop',
            uri: 'content://media/video/noop',
            name: 'noop.mp4',
            mimeType: 'video/mp4',
            kind: MediaKind.video,
            durationMs: 1000,
            width: 1920,
            height: 1080,
            sizeBytes: 100,
          ),
        ],
        videoTrack: [
          TimelineClip(
            id: 'clip-noop',
            assetId: 'asset-noop',
            trimStartMs: 0,
            trimEndMs: 1000,
          ),
        ],
        audioTrack: [],
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: project)),
      );
      await tester.pump();
      final undoButton = tester.widget<IconButton>(
        iconButtonForTooltip('تراجع'),
      );
      expect(undoButton.onPressed, isNull);

      final trimStartButton = find.byTooltip('تقليل 100 مللي ثانية');
      await tester.ensureVisible(trimStartButton);
      await tester.tap(trimStartButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 20));

      expect(savedProjects, isEmpty);
      expect(find.text('00:00.000'), findsAtLeastNWidgets(1));
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'a ramped incoming-transition split at 950ms is rejected without save or history',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final recorder = _installRampSplitMocks(950);
      final position = timelinePositionAt(
        _rampTransitionProject.videoTrack,
        950,
        transitions: _rampTransitionProject.videoTransitions,
      )!;
      expect(position.clipId, 'b');
      expect(position.sourcePositionMs, 158);
      expect(
        outputOffsetToSourceMs(
          150,
          0,
          1000,
          _rampTransitionProject.videoTrack[1].speedRampPoints,
        ),
        158,
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        950,
      );
      expect(recorder.previewConfigurations, hasLength(1));

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(
        find.textContaining('لا يمكن التقسيم عند هذا الموضع'),
        findsOneWidget,
      );
      expect(recorder.savedProjects, isEmpty);
      expect(recorder.previewConfigurations, hasLength(1));
      expect(find.textContaining('مقطع أساسي'), findsOneWidget);
      expect(
        tester.widget<IconButton>(iconButtonForTooltip('تراجع')).onPressed,
        isNull,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'safe ramped incoming-transition split saves the mapped project and supports undo/redo',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final point = _calculateSafeRampSplitPoint();
      final recorder = _installRampSplitMocks(point.playheadMs);

      // The layout and cumulative clock derive the safe point; it is not a
      // guessed constant. The first split output duration must contain 200 ms.
      expect(
        layoutVideoTransitions(
          _rampTransitionProject.videoTrack.map((item) => item.id).toList(),
          _rampTransitionProject.videoTrack
              .map((item) => item.effectiveDurationMs)
              .toList(),
          _rampTransitionProject.videoTransitions,
        ).startOfClip(1),
        800,
      );
      expect(point.playheadMs, 1001);
      expect(point.position.sourcePositionMs, 217);

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(
        tester
            .widget<Slider>(
              find.byKey(const ValueKey('preview-position-slider')),
            )
            .value,
        point.playheadMs,
      );

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(recorder.savedProjects, hasLength(1));
      expect(recorder.previewConfigurations, hasLength(2));
      final splitMap = recorder.savedProjects.single;
      final splitRows = splitMap['videoTrack'] as List<dynamic>;
      final secondId = (splitRows[2] as Map)['id'] as String;
      final expectedProject = _expectedSafeRampSplit(point, secondId);
      final expectedTrack = expectedProject.videoTrack;
      expect(splitMap, expectedProject.toMap());
      expect(splitRows[1]['trimEndMs'], point.position.sourcePositionMs);
      expect(splitRows[2]['trimStartMs'], point.position.sourcePositionMs);
      expect(splitRows[1]['volume'], splitRows[2]['volume']);
      expect(splitRows[1]['fadeInMs'], splitRows[2]['fadeInMs']);
      expect(splitRows[1]['fadeOutMs'], splitRows[2]['fadeOutMs']);
      expect(
        splitRows[1]['transformKeyframes'],
        splitRows[2]['transformKeyframes'],
      );
      expect(splitRows[1]['speedRampPoints'], splitRows[2]['speedRampPoints']);
      expect(expectedProject.videoTransitions.single.durationMs, 200);
      expect(
        visualTimelineDurationMs(
          expectedProject.videoTrack,
          transitions: expectedProject.videoTransitions,
        ),
        visualTimelineDurationMs(
          _rampTransitionProject.videoTrack,
          transitions: _rampTransitionProject.videoTransitions,
        ),
      );
      expect(expectedTrack[1].effectiveDurationMs, greaterThanOrEqualTo(200));
      expect(
        splitMap['audioTrack'],
        _rampTransitionProject.toMap()['audioTrack'],
      );
      expect(
        splitMap['frameSettings'],
        _rampTransitionProject.toMap()['frameSettings'],
      );
      expect(
        splitMap['textOverlays'],
        _rampTransitionProject.toMap()['textOverlays'],
      );
      expect(
        splitMap['subtitleTrack'],
        _rampTransitionProject.toMap()['subtitleTrack'],
      );
      expect(
        splitMap['stickerOverlays'],
        _rampTransitionProject.toMap()['stickerOverlays'],
      );
      expect(
        splitMap['videoOverlayTracks'],
        _rampTransitionProject.toMap()['videoOverlayTracks'],
      );
      expect(recorder.previewConfigurations.last['startIndex'], 2);
      expect(recorder.previewConfigurations.last['clipPositionMs'], 0);
      expect(
        recorder.previewConfigurations.last['timelinePositionMs'],
        point.playheadMs,
      );

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, _rampTransitionProject.toMap());

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, expectedProject.toMap());

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
    },
  );

  testWidgetsOnPlatform(
    'ramped split remains saved and undoable when reconfiguration and preview stop fail',
    TargetPlatform.android,
    (tester) async {
      _setUpAndroidEditorViewport(tester);
      final point = _calculateSafeRampSplitPoint();
      final recorder = _installRampSplitMocks(
        point.playheadMs,
        failReconfigurations: true,
        failPausePreview: true,
      );

      await tester.pumpWidget(
        const MaterialApp(home: EditorScreen(project: _rampTransitionProject)),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      final splitButton = find.widgetWithText(FilledButton, 'تقسيم عند المؤشر');
      await tester.ensureVisible(splitButton);
      await tester.tap(splitButton);
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));

      expect(recorder.savedProjects, hasLength(1));
      expect(recorder.previewConfigurations, hasLength(2));
      expect(
        find.textContaining('original preview reconfiguration failure'),
        findsOneWidget,
      );
      expect(
        find.textContaining('secondary pause preview failure'),
        findsNothing,
      );
      final splitRows =
          recorder.savedProjects.single['videoTrack'] as List<dynamic>;
      final secondId = (splitRows[2] as Map)['id'] as String;
      final expectedProject = _expectedSafeRampSplit(point, secondId);
      expect(recorder.savedProjects.single, expectedProject.toMap());
      expect(find.textContaining('مقطع أساسي'), findsOneWidget);

      await tester.tap(find.byTooltip('تراجع'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, _rampTransitionProject.toMap());
      expect(find.textContaining('مقطع أساسي'), findsOneWidget);
      expect(
        find.textContaining('original preview reconfiguration failure'),
        findsOneWidget,
      );
      expect(
        find.textContaining('secondary pause preview failure'),
        findsNothing,
      );

      await tester.tap(find.byTooltip('إعادة'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      expect(recorder.savedProjects.last, expectedProject.toMap());
      expect(find.textContaining('مقطع أساسي'), findsOneWidget);
      expect(
        find.textContaining('original preview reconfiguration failure'),
        findsOneWidget,
      );
      expect(
        find.textContaining('secondary pause preview failure'),
        findsNothing,
      );

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      await tester.pump();
      expect(recorder.pausePreviewCalls, 1);
      expect(tester.takeException(), isNull);
    },
  );
}
