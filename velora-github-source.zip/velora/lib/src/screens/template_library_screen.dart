import 'package:flutter/material.dart';

import '../models/project.dart';
import '../models/project_templates.dart';
import '../services/native_bridge.dart';
import 'editor_screen.dart';
import 'template_media_replacement_screen.dart';

class TemplateLibraryScreen extends StatefulWidget {
  const TemplateLibraryScreen({super.key});

  @override
  State<TemplateLibraryScreen> createState() => _TemplateLibraryScreenState();
}

class _TemplateLibraryScreenState extends State<TemplateLibraryScreen> {
  List<ProjectTemplate> _savedTemplates = const [];
  bool _loading = true;
  bool _working = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadTemplates();
  }

  Future<void> _loadTemplates() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final templates = await NativeBridge.listTemplates();
      if (!mounted) return;
      setState(() {
        _savedTemplates = templates.where((item) => !item.isBuiltIn).toList();
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذّر تحميل القوالب المحفوظة: $error';
      });
    }
  }

  Future<void> _useTemplate(ProjectTemplate template) async {
    if (_working) return;
    final project = await Navigator.of(context).push<VeloraProject>(
      MaterialPageRoute(
        builder: (_) => TemplateMediaReplacementScreen(template: template),
      ),
    );
    if (project == null || !mounted) return;
    setState(() => _working = true);
    try {
      await NativeBridge.saveProject(project);
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute(builder: (_) => EditorScreen(project: project)),
      );
      if (mounted) await _loadTemplates();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر حفظ نسخة المشروع: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _deleteTemplate(ProjectTemplate template) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حذف القالب المحفوظ؟'),
        content: Text('سيُحذف «${template.name}» من مكتبتك فقط؛ لا تتغير المشاريع المنشأة منه.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('حذف القالب'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await NativeBridge.deleteTemplate(template.id);
      if (mounted) await _loadTemplates();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر حذف القالب: $error')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final builtIns = builtInProjectTemplates();
    return Scaffold(
      appBar: AppBar(title: const Text('مكتبة قوالب الفيديو')),
      body: RefreshIndicator(
        onRefresh: _loadTemplates,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: [
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'قوالب أصلية قابلة للتعديل. استبدل الوسائط بملفاتك، ثم تابع في المحرر نفسه للمعاينة والتصدير.',
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text('قوالب VELORA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            for (final template in builtIns) _templateCard(template),
            const SizedBox(height: 14),
            Row(
              children: [
                const Expanded(
                  child: Text('قوالبي المحفوظة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                ),
                IconButton(
                  tooltip: 'تحديث القوالب',
                  onPressed: _loading || _working ? null : _loadTemplates,
                  icon: const Icon(Icons.refresh_rounded),
                ),
              ],
            ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_savedTemplates.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('احفظ أي مشروع من المحرر كقالب ليظهر هنا.'),
                ),
              )
            else
              for (final template in _savedTemplates) _templateCard(template),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(_error!, style: const TextStyle(color: Color(0xFFFFC2C2))),
              ),
            if (_working)
              const Padding(
                padding: EdgeInsets.all(20),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }

  Widget _templateCard(ProjectTemplate template) => Card(
    child: ListTile(
      key: ValueKey('template:${template.id}'),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: CircleAvatar(
        backgroundColor: const Color(0xFF304050),
        child: Icon(_templateIcon(template.id)),
      ),
      title: Text(template.name, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 5),
        child: Text(
          '${template.description}\n${template.mediaSlots.length} فتحة وسيط · '
          '${template.project.videoTrack.length} مقطع · '
          '${template.project.videoTransitions.length} انتقال · '
          '${template.project.textOverlays.length} نص',
        ),
      ),
      isThreeLine: true,
      trailing: template.isBuiltIn
          ? const Icon(Icons.chevron_left_rounded)
          : PopupMenuButton<String>(
              tooltip: 'خيارات القالب',
              onSelected: (value) {
                if (value == 'delete') _deleteTemplate(template);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'delete', child: Text('حذف القالب')),
              ],
            ),
      onTap: _working ? null : () => _useTemplate(template),
    ),
  );

  IconData _templateIcon(String id) => switch (id) {
    'builtin:opening' => Icons.wb_sunny_outlined,
    'builtin:short' => Icons.smartphone_rounded,
    'builtin:quote' => Icons.format_quote_rounded,
    'builtin:montage' => Icons.video_library_outlined,
    _ => Icons.bookmark_outline_rounded,
  };
}
