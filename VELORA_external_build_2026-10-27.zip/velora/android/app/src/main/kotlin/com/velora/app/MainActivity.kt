package com.velora.app

import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.ToInt16PcmAudioProcessor
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.UUID
import java.util.concurrent.CancellationException
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : FlutterActivity() {
    private lateinit var methodChannel: MethodChannel
    private var pendingPickerResult: MethodChannel.Result? = null
    private var activeExport: ExportState? = null

    override fun onStop() {
        VeloraPreviewPlayerRegistry.pause()
        super.onStop()
    }

    override fun onDestroy() {
        cancelActiveExport("Activity destroyed before export completed")
        VeloraPreviewPlayerRegistry.clear()
        super.onDestroy()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "velora/preview",
            VeloraPreviewFactory(),
        )
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel.setMethodCallHandler(::handleMethodCall)
    }

    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "pickMedia" -> launchMediaPicker(result)
            "configurePreviewTimeline" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing preview configuration")
                    configurePreviewTimeline(args)
                    result.success(null)
                } catch (error: Exception) {
                    result.error("preview_timeline_setup_failed", error.message, null)
                }
            }
            "setPreviewSource" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing source preview")
                    val uriText = args["uri"]?.toString()
                        ?: throw IllegalArgumentException("Media URI is missing")
                    val kind = args["kind"]?.toString().orEmpty()
                    if (kind == "video") {
                        val positionMs = (args["positionMs"] as? Number)?.toLong() ?: 0L
                        VeloraPreviewPlayerRegistry.setSource(
                            MediaItem.fromUri(Uri.parse(uriText)),
                            positionMs,
                            (args["durationMs"] as? Number)?.toLong() ?: 0L,
                        )
                    } else {
                        VeloraPreviewPlayerRegistry.clear()
                    }
                    result.success(null)
                } catch (error: Exception) {
                    result.error("preview_source_failed", error.message, null)
                }
            }
            "seekPreview" -> {
                val args = call.arguments as? Map<*, *>
                val itemIndex = (args?.get("mediaItemIndex") as? Number)?.toInt()
                val clipPositionMs = (args?.get("clipPositionMs") as? Number)?.toLong()
                if (itemIndex == null || clipPositionMs == null) {
                    result.error("invalid_preview_position", "A timeline item and position are required", null)
                } else {
                    VeloraPreviewPlayerRegistry.seekTo(itemIndex, clipPositionMs)
                    result.success(null)
                }
            }
            "playPreview" -> {
                VeloraPreviewPlayerRegistry.play()
                result.success(null)
            }
            "pausePreview" -> {
                VeloraPreviewPlayerRegistry.pause()
                result.success(null)
            }
            "clearPreview" -> {
                VeloraPreviewPlayerRegistry.clear()
                result.success(null)
            }
            "getPreviewState" -> result.success(VeloraPreviewPlayerRegistry.state())
            "listProjects" -> {
                try {
                    result.success(readProjects())
                } catch (error: Exception) {
                    result.error("project_read_failed", error.message, null)
                }
            }
            "saveProject" -> {
                try {
                    val project = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing project map")
                    saveProject(project)
                    result.success(null)
                } catch (error: Exception) {
                    result.error("project_save_failed", error.message, null)
                }
            }
            "exportProject" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing export arguments")
                    val project = args["project"] as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing project data")
                    val height = (args["height"] as? Number)?.toInt() ?: 720
                    startExport(project, height, result)
                } catch (error: Exception) {
                    result.error("export_setup_failed", error.message, null)
                }
            }
            "cancelExport" -> result.success(cancelActiveExport("Export cancelled by user"))
            else -> result.notImplemented()
        }
    }

    @Deprecated("Uses Activity result API to retain compatibility with FlutterActivity")
    private fun launchMediaPicker(result: MethodChannel.Result) {
        if (pendingPickerResult != null) {
            result.error("picker_busy", "A media picker is already open", null)
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("video/*", "image/*", "audio/*"),
            )
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pendingPickerResult = result
        try {
            startActivityForResult(intent, PICK_MEDIA_REQUEST)
        } catch (error: Exception) {
            pendingPickerResult = null
            result.error("picker_unavailable", error.message, null)
        }
    }

    @Deprecated("Uses Activity result API to retain compatibility with FlutterActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_MEDIA_REQUEST) return
        val result = pendingPickerResult ?: return
        pendingPickerResult = null
        if (resultCode != RESULT_OK || data == null) {
            result.success(emptyList<Map<String, Any>>())
            return
        }

        try {
            val uris = mutableListOf<Uri>()
            val clipData = data.clipData
            if (clipData != null) {
                for (index in 0 until clipData.itemCount) {
                    clipData.getItemAt(index).uri?.let(uris::add)
                }
            } else {
                data.data?.let(uris::add)
            }
            val permissionFlags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            uris.distinctBy(Uri::toString).forEach { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, permissionFlags)
                } catch (_: SecurityException) {
                    // Some document providers do not offer persistable grants.
                }
            }
            result.success(uris.distinctBy(Uri::toString).map(::describeMedia))
        } catch (error: Exception) {
            result.error("media_metadata_failed", error.message, null)
        }
    }

    private fun describeMedia(uri: Uri): Map<String, Any> {
        val name = queryDisplayName(uri) ?: "وسيط-${UUID.randomUUID()}"
        val contentType = contentResolver.getType(uri)
        val lowerName = name.lowercase()
        val mime = contentType ?: when {
            lowerName.endsWith(".mp4") || lowerName.endsWith(".mov") || lowerName.endsWith(".mkv") -> "video/mp4"
            lowerName.endsWith(".png") -> "image/png"
            lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") -> "image/jpeg"
            lowerName.endsWith(".webp") -> "image/webp"
            lowerName.endsWith(".wav") -> "audio/wav"
            lowerName.endsWith(".m4a") -> "audio/mp4"
            lowerName.endsWith(".mp3") -> "audio/mpeg"
            else -> "application/octet-stream"
        }
        val kind = when {
            mime.startsWith("video/") -> "video"
            mime.startsWith("image/") -> "image"
            mime.startsWith("audio/") -> "audio"
            else -> when {
                lowerName.endsWith(".mp4") || lowerName.endsWith(".mov") || lowerName.endsWith(".mkv") -> "video"
                lowerName.endsWith(".png") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".webp") -> "image"
                lowerName.endsWith(".mp3") || lowerName.endsWith(".wav") || lowerName.endsWith(".m4a") || lowerName.endsWith(".aac") -> "audio"
                else -> "unsupported"
            }
        }
        var durationMs = if (kind == "image") 5_000L else 0L
        var width = 0
        var height = 0
        if (kind == "video" || kind == "audio") {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 0
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 0
            } catch (_: Exception) {
                // A zero duration is kept explicit; the editor will not silently invent a video duration.
            } finally {
                try {
                    retriever.release()
                } catch (_: Exception) {
                }
            }
        }
        return mapOf(
            "id" to UUID.randomUUID().toString(),
            "uri" to uri.toString(),
            "name" to name,
            "mimeType" to mime,
            "kind" to kind,
            "durationMs" to durationMs,
            "width" to width,
            "height" to height,
            "sizeBytes" to querySize(uri),
        )
    }

    private fun queryDisplayName(uri: Uri): String? = queryColumn(uri, OpenableColumns.DISPLAY_NAME)

    private fun querySize(uri: Uri): Long = queryColumn(uri, OpenableColumns.SIZE)?.toLongOrNull() ?: 0L

    private fun queryColumn(uri: Uri, column: String): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(column), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(column)
                if (index >= 0 && !cursor.isNull(index)) cursor.getString(index) else null
            } else {
                null
            }
        } finally {
            cursor?.close()
        }
    }

    private fun projectsDirectory(): File = File(filesDir, "velora/projects").apply { mkdirs() }

    private fun saveProject(project: Map<*, *>) {
        val id = project["id"]?.toString()?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("Project ID is missing")
        val json = JSONObject()
        project.forEach { (key, value) ->
            if (key != null) json.put(key.toString(), toJsonValue(value))
        }
        File(projectsDirectory(), "$id.json").writeText(json.toString(), Charsets.UTF_8)
    }

    private fun readProjects(): List<Map<String, Any?>> = projectsDirectory()
        .listFiles { file -> file.isFile && file.extension == "json" }
        .orEmpty()
        .sortedByDescending(File::lastModified)
        .map { file -> jsonObjectToMap(JSONObject(file.readText(Charsets.UTF_8))) }

    private fun toJsonValue(value: Any?): Any? = when (value) {
        null -> JSONObject.NULL
        is Map<*, *> -> JSONObject().also { json ->
            value.forEach { (key, nested) ->
                if (key != null) json.put(key.toString(), toJsonValue(nested))
            }
        }
        is Iterable<*> -> JSONArray().also { array -> value.forEach { array.put(toJsonValue(it)) } }
        is Array<*> -> JSONArray().also { array -> value.forEach { array.put(toJsonValue(it)) } }
        else -> value
    }

    private fun jsonObjectToMap(json: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = fromJsonValue(json.opt(key))
        }
        return output
    }

    private fun fromJsonValue(value: Any?): Any? = when (value) {
        JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { fromJsonValue(value.opt(it)) }
        else -> value
    }

    private fun configurePreviewTimeline(args: Map<*, *>) {
        val project = args["project"] as? Map<*, *>
            ?: throw IllegalArgumentException("Project data is missing")
        val assets = mapList(project["assets"]).associateBy { it["id"]?.toString().orEmpty() }
        val clips = mapList(project["videoTrack"])
        require(clips.isNotEmpty()) { "Add a visual clip before previewing the timeline" }

        val items = ArrayList<MediaItem>(clips.size)
        val durationsMs = ArrayList<Long>(clips.size)
        clips.forEachIndexed { index, clip ->
            val asset = assets[clip["assetId"]?.toString()]
                ?: throw IllegalArgumentException("Visual clip $index has no media asset")
            val kind = asset["kind"]?.toString().orEmpty()
            require(kind == "video" || kind == "image") {
                "Only videos and images can be previewed on the visual track"
            }
            val uriText = asset["uri"]?.toString()
                ?: throw IllegalArgumentException("Visual clip $index has no media URI")
            val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                ?: throw IllegalArgumentException("Visual clip $index has no trim start")
            val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                ?: throw IllegalArgumentException("Visual clip $index has no trim end")
            require(startMs >= 0L && endMs > startMs) {
                "Visual clip $index has an invalid trim range"
            }
            val durationMs = endMs - startMs
            val assetDurationMs = (asset["durationMs"] as? Number)?.toLong() ?: 0L
            if (kind == "video" && assetDurationMs > 0L) {
                require(endMs <= assetDurationMs) {
                    "Visual clip $index ends beyond the source video duration"
                }
            }

            val builder = MediaItem.Builder()
                .setMediaId(clip["id"]?.toString() ?: "visual-$index")
                .setUri(Uri.parse(uriText))
            if (kind == "image") {
                builder.setImageDurationMs(durationMs)
            } else {
                builder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build(),
                )
            }
            items += builder.build()
            durationsMs += durationMs
        }

        val startIndex = (args["startIndex"] as? Number)?.toInt() ?: 0
        require(startIndex in items.indices) { "Preview start item is out of range" }
        val startPositionMs = (args["clipPositionMs"] as? Number)?.toLong() ?: 0L
        val playWhenReady = args["playWhenReady"] as? Boolean ?: false
        VeloraPreviewPlayerRegistry.configureTimeline(
            items,
            durationsMs,
            startIndex,
            startPositionMs,
            playWhenReady,
        )
    }

    private fun startExport(project: Map<*, *>, height: Int, result: MethodChannel.Result) {
        if (activeExport != null) {
            result.error("export_busy", "An export is already running", null)
            return
        }
        if (height != 720 && height != 1080) {
            result.error("invalid_resolution", "Only 720p and 1080p are configured", null)
            return
        }

        val assets = mapList(project["assets"]).associateBy { it["id"]?.toString().orEmpty() }
        val visualClips = mapList(project["videoTrack"])
        val audioClips = mapList(project["audioTrack"])
        if (visualClips.isEmpty()) {
            result.error("empty_timeline", "Add at least one video or image before exporting", null)
            return
        }

        var tempFile: File? = null
        var exportState: ExportState? = null
        try {
            val visualItems = mutableListOf<EditedMediaItem>()
            val embeddedAudioSequences = mutableListOf<EditedMediaItemSequence>()
            var totalVisualDurationMs = 0L
            val audioInfoByAssetId = mutableMapOf<String, AudioTrackInfo>()

            for (clip in visualClips) {
                val asset = assets[clip["assetId"]?.toString()]
                    ?: throw IllegalArgumentException("A visual clip references a missing asset")
                val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("A visual clip start time is missing")
                val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("A visual clip end time is missing")
                require(startMs >= 0L && endMs > startMs) {
                    "Visual clip range must have a non-negative start and positive duration"
                }
                val durationMs = endMs - startMs
                visualItems += createEditedItem(asset, clip, height, isVisual = true)

                if (asset["kind"]?.toString() == "video") {
                    val assetId = asset["id"]?.toString().orEmpty()
                    val uriText = asset["uri"]?.toString()
                        ?: throw IllegalArgumentException("A video asset has no media URI")
                    val audioInfo = audioInfoByAssetId.getOrPut(assetId) {
                        inspectAudioTrack(uriText)
                    }
                    if (audioInfo.hasAudio) {
                        val channelCount = audioInfo.channelCount
                            ?: throw IllegalArgumentException(
                                "Could not determine the embedded audio channel count for $uriText",
                            )
                        require(channelCount in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                            "Embedded audio with $channelCount channels is unsupported; use a source with at most $MAX_NORMALIZED_AUDIO_CHANNELS channels"
                        }
                        val audioSequenceBuilder = EditedMediaItemSequence.Builder(
                            setOf(C.TRACK_TYPE_AUDIO),
                        )
                        if (totalVisualDurationMs > 0L) {
                            audioSequenceBuilder.addGap(totalVisualDurationMs * 1_000L)
                        }
                        audioSequenceBuilder.addItem(createSourceAudioItem(asset, clip))
                        embeddedAudioSequences += audioSequenceBuilder.build()
                    }
                }
                totalVisualDurationMs += durationMs
            }

            val audioItems = mutableListOf<EditedMediaItem>()
            var remainingVisualDurationMs = totalVisualDurationMs
            for (clip in audioClips) {
                if (remainingVisualDurationMs <= 0L) break
                val asset = assets[clip["assetId"]?.toString()]
                    ?: throw IllegalArgumentException("An audio clip references a missing asset")
                if (asset["kind"]?.toString() != "audio") {
                    throw IllegalArgumentException("The audio track contains a non-audio asset")
                }
                val assetId = asset["id"]?.toString().orEmpty()
                val uriText = asset["uri"]?.toString()
                    ?: throw IllegalArgumentException("An audio asset has no media URI")
                val audioInfo = audioInfoByAssetId.getOrPut(assetId) {
                    inspectAudioTrack(uriText)
                }
                require(audioInfo.hasAudio) { "The selected audio asset has no audio track" }
                val channelCount = audioInfo.channelCount
                    ?: throw IllegalArgumentException("Could not determine audio channel count for $uriText")
                require(channelCount in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                    "Audio with $channelCount channels is unsupported; use a source with at most $MAX_NORMALIZED_AUDIO_CHANNELS channels"
                }
                val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("An audio clip start time is missing")
                val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("An audio clip end time is missing")
                if (startMs < 0L || endMs <= startMs) {
                    throw IllegalArgumentException("Audio clip range must have a non-negative start and positive duration")
                }
                val usedDurationMs = minOf(endMs - startMs, remainingVisualDurationMs)
                val cappedClip = clip.toMutableMap().apply { put("trimEndMs", startMs + usedDurationMs) }
                audioItems += createEditedItem(asset, cappedClip, height, isVisual = false)
                remainingVisualDurationMs -= usedDurationMs
            }

            // Keep every sequence track-homogeneous: video/images form a video-only
            // sequence; source audio and added audio are separate audio-only sequences.
            val sequences = mutableListOf(EditedMediaItemSequence.withVideoFrom(visualItems))
            sequences.addAll(embeddedAudioSequences)
            if (audioItems.isNotEmpty()) {
                sequences += EditedMediaItemSequence.withAudioFrom(audioItems)
            }
            val composition = Composition.Builder(sequences).build()

            val outputFile = File(cacheDir, "velora-${UUID.randomUUID()}.mp4")
            tempFile = outputFile
            val state = ExportState(result, outputFile)
            exportState = state
            activeExport = state

            val transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (state.cancelled.get() || !state.publishStarted.compareAndSet(false, true)) {
                            outputFile.delete()
                            return
                        }
                        val publishingThread = Thread({
                            state.publishingThread = Thread.currentThread()
                            try {
                                ensureExportActive(state)
                                val saved = publishExport(outputFile, state)
                                outputFile.delete()
                                if (state.cancelled.get()) {
                                    cleanupPublishedExport(state)
                                    return@Thread
                                }
                                runOnUiThread {
                                    if (state.cancelled.get()) {
                                        cleanupPublishedExport(state)
                                        return@runOnUiThread
                                    }
                                    releasePublishedExportTracking(state)
                                    completeExport(state) { state.result.success(saved) }
                                }
                            } catch (error: Exception) {
                                outputFile.delete()
                                cleanupPublishedExport(state)
                                if (!state.cancelled.get()) {
                                    runOnUiThread {
                                        if (!state.cancelled.get()) {
                                            completeExport(state) {
                                                state.result.error("export_save_failed", error.message, null)
                                            }
                                        }
                                    }
                                }
                            } finally {
                                state.publishingThread = null
                            }
                        }, "VeloraExportPublisher")
                        state.publishingThread = publishingThread
                        publishingThread.start()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        outputFile.delete()
                        if (state.cancelled.get()) return
                        runOnUiThread {
                            if (!state.cancelled.get()) {
                                cleanupPublishedExport(state)
                                completeExport(state) {
                                    state.result.error("media3_export_failed", exportException.message, null)
                                }
                            }
                        }
                    }
                })
                .build()
            state.transformer = transformer
            transformer.start(composition, outputFile.absolutePath)
        } catch (error: Exception) {
            tempFile?.delete()
            val state = exportState
            if (state == null) {
                result.error("export_setup_failed", error.message, null)
            } else if (!state.cancelled.get()) {
                completeExport(state) {
                    state.result.error("export_setup_failed", error.message, null)
                }
            }
        }
    }

    private fun createEditedItem(
        asset: Map<String, Any?>,
        clip: Map<String, Any?>,
        outputHeight: Int,
        isVisual: Boolean,
    ): EditedMediaItem {
        val uriText = asset["uri"]?.toString()
            ?: throw IllegalArgumentException("Media URI is missing")
        val kind = asset["kind"]?.toString() ?: ""
        if (isVisual && kind != "video" && kind != "image") {
            throw IllegalArgumentException("Only video and image assets belong on the visual track")
        }
        if (!isVisual && kind != "audio") {
            throw IllegalArgumentException("Only audio assets belong on the audio track")
        }
        val startMs = (clip["trimStartMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Clip start time is missing")
        val endMs = (clip["trimEndMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Clip end time is missing")
        if (endMs <= startMs) throw IllegalArgumentException("Clip duration must be positive")

        val mediaBuilder = MediaItem.Builder().setUri(Uri.parse(uriText))
        if (kind == "image") {
            if (!isVisual) throw IllegalArgumentException("An image cannot be placed on the audio track")
            mediaBuilder.setImageDurationMs(endMs - startMs)
        } else {
            mediaBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build(),
            )
        }
        val effects = when {
            isVisual -> Effects(emptyList(), listOf(Presentation.createForHeight(outputHeight)))
            kind == "audio" -> createNormalizedAudioEffects()
            else -> Effects(emptyList(), emptyList())
        }
        val builder = EditedMediaItem.Builder(mediaBuilder.build()).setEffects(effects)
        if (kind == "image") builder.setFrameRate(30)
        return builder.build()
    }

    private fun createSourceAudioItem(
        asset: Map<String, Any?>,
        clip: Map<String, Any?>,
    ): EditedMediaItem {
        require(asset["kind"]?.toString() == "video") {
            "Only video assets can provide embedded source audio"
        }
        val uriText = asset["uri"]?.toString()
            ?: throw IllegalArgumentException("Video media URI is missing")
        val startMs = (clip["trimStartMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Video clip start time is missing")
        val endMs = (clip["trimEndMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Video clip end time is missing")
        require(startMs >= 0L && endMs > startMs) { "Video audio clip range is invalid" }

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(uriText))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build(),
            )
            .build()
        return EditedMediaItem.Builder(mediaItem)
            .setRemoveVideo(true)
            .setEffects(createNormalizedAudioEffects())
            .build()
    }

    private fun createNormalizedAudioEffects(): Effects {
        val channelMixer = ChannelMixingAudioProcessor()
        for (inputChannels in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
            channelMixer.putChannelMixingMatrix(
                ChannelMixingMatrix.createForConstantPower(inputChannels, OUTPUT_AUDIO_CHANNELS),
            )
        }
        return Effects(
            listOf(ToInt16PcmAudioProcessor(), channelMixer),
            emptyList(),
        )
    }

    private fun inspectAudioTrack(uriText: String): AudioTrackInfo {
        val extractor = MediaExtractor()
        val descriptor = try {
            contentResolver.openAssetFileDescriptor(Uri.parse(uriText), "r")
                ?: throw IllegalArgumentException("Could not open media descriptor for $uriText")
        } catch (error: Exception) {
            runCatching { extractor.release() }
            throw error
        }
        return try {
            val length = descriptor.length
            when {
                length > 0L -> extractor.setDataSource(
                    descriptor.fileDescriptor,
                    descriptor.startOffset,
                    length,
                )
                descriptor.startOffset == 0L -> extractor.setDataSource(descriptor.fileDescriptor)
                else -> throw IllegalArgumentException(
                    "Media provider did not expose a usable file length for $uriText",
                )
            }
            for (index in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(index)
                val mimeType = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mimeType.startsWith("audio/")) {
                    val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    } else {
                        null
                    }
                    return AudioTrackInfo(hasAudio = true, channelCount = channelCount)
                }
            }
            AudioTrackInfo(hasAudio = false, channelCount = null)
        } catch (error: Exception) {
            throw IllegalArgumentException(
                "Could not inspect audio tracks for $uriText",
                error,
            )
        } finally {
            runCatching { extractor.release() }
            runCatching { descriptor.close() }
        }
    }

    private data class AudioTrackInfo(
        val hasAudio: Boolean,
        val channelCount: Int?,
    )

    private fun mapList(value: Any?): List<Map<String, Any?>> =
        (value as? List<*>)?.mapNotNull { item ->
            val row = item as? Map<*, *> ?: return@mapNotNull null
            row.entries.associate { (key, nested) -> key.toString() to nested }
        } ?: emptyList()

    private fun publishExport(tempFile: File, state: ExportState): Map<String, String> {
        ensureExportActive(state)
        if (!tempFile.exists() || tempFile.length() == 0L) {
            throw IllegalStateException("Transformer produced no MP4 data")
        }
        val fileName = "VELORA_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            publishToMediaStore(tempFile, fileName, state)
        } else {
            val directory = File(
                getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir,
                "VELORA",
            ).apply { mkdirs() }
            val destination = File(directory, fileName)
            synchronized(state) { state.publishedFile = destination }
            try {
                tempFile.inputStream().use { input ->
                    destination.outputStream().use { output -> copyCancellable(input, output, state) }
                }
                ensureExportActive(state)
                mapOf(
                    "uri" to Uri.fromFile(destination).toString(),
                    "path" to destination.absolutePath,
                )
            } catch (error: Exception) {
                destination.delete()
                synchronized(state) {
                    if (state.publishedFile == destination) state.publishedFile = null
                }
                throw error
            }
        }
    }

    private fun publishToMediaStore(
        tempFile: File,
        fileName: String,
        state: ExportState,
    ): Map<String, String> {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/VELORA")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a MediaStore entry")
        synchronized(state) { state.publishedUri = uri }
        try {
            ensureExportActive(state)
            val output = contentResolver.openOutputStream(uri, "w")
                ?: throw IllegalStateException("Could not open the output destination")
            tempFile.inputStream().use { input -> output.use { copyCancellable(input, it, state) } }
            ensureExportActive(state)
            val completed = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            val updatedRows = contentResolver.update(uri, completed, null, null)
            if (updatedRows <= 0) {
                throw IllegalStateException("Could not finalize the MediaStore output")
            }
            ensureExportActive(state)
        } catch (error: Exception) {
            contentResolver.delete(uri, null, null)
            synchronized(state) {
                if (state.publishedUri == uri) state.publishedUri = null
            }
            throw error
        }
        return mapOf(
            "uri" to uri.toString(),
            "path" to "Movies/VELORA/$fileName",
        )
    }

    private fun copyCancellable(
        input: java.io.InputStream,
        output: java.io.OutputStream,
        state: ExportState,
    ) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            ensureExportActive(state)
            val count = input.read(buffer)
            if (count < 0) return
            output.write(buffer, 0, count)
        }
    }

    private fun ensureExportActive(state: ExportState) {
        if (state.cancelled.get() || Thread.currentThread().isInterrupted) {
            throw CancellationException("Export cancelled")
        }
    }

    private fun cancelActiveExport(message: String): Boolean {
        val state = activeExport ?: return false
        if (!state.cancelled.compareAndSet(false, true)) return false

        state.publishingThread?.interrupt()
        try {
            state.transformer?.cancel()
        } catch (_: Exception) {
            // Cancellation must still resolve the pending Flutter result.
        }
        state.temporaryOutput?.delete()
        cleanupPublishedExport(state)
        completeExport(state) {
            state.result.error("export_cancelled", message, null)
        }
        return true
    }

    private fun completeExport(state: ExportState, deliverResult: () -> Unit) {
        if (!state.resultSent.compareAndSet(false, true)) return
        if (activeExport === state) activeExport = null
        state.transformer = null
        state.temporaryOutput = null
        state.publishingThread = null
        deliverResult()
    }

    private fun cleanupPublishedExport(state: ExportState) {
        val output = synchronized(state) {
            val uri = state.publishedUri
            val file = state.publishedFile
            state.publishedUri = null
            state.publishedFile = null
            uri to file
        }
        output.first?.let { uri -> runCatching { contentResolver.delete(uri, null, null) } }
        output.second?.let { file -> runCatching { file.delete() } }
    }

    private fun releasePublishedExportTracking(state: ExportState) {
        synchronized(state) {
            state.publishedUri = null
            state.publishedFile = null
        }
    }

    private class ExportState(
        val result: MethodChannel.Result,
        @Volatile var temporaryOutput: File? = null,
    ) {
        val resultSent = AtomicBoolean(false)
        val cancelled = AtomicBoolean(false)
        val publishStarted = AtomicBoolean(false)

        @Volatile var transformer: Transformer? = null
        @Volatile var publishingThread: Thread? = null
        @Volatile var publishedUri: Uri? = null
        @Volatile var publishedFile: File? = null
    }

    companion object {
        private const val CHANNEL = "velora/native"
        private const val PICK_MEDIA_REQUEST = 7401
        private const val MAX_NORMALIZED_AUDIO_CHANNELS = 6
        private const val OUTPUT_AUDIO_CHANNELS = 2
    }
}
