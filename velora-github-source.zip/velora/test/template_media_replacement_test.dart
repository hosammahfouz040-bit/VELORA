import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_templates.dart';
import 'package:velora/src/screens/template_media_replacement_screen.dart';

const _channel = MethodChannel('velora/native');

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('selects only a compatible local medium for a required slot', (tester) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_channel, (call) async {
          if (call.method != 'pickMedia') {
            throw StateError('Unexpected native method ${call.method}');
          }
          return [
            {
              'id': 'picked-video',
              'uri': 'content://picked/video',
              'name': 'لقطة محلية',
              'mimeType': 'video/mp4',
              'kind': 'video',
              'durationMs': 8_000,
              'width': 1080,
              'height': 1920,
              'sizeBytes': 20,
            },
          ];
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_channel, null),
    );

    final template = builtInProjectTemplates().first;
    await tester.pumpWidget(MaterialApp(
      home: TemplateMediaReplacementScreen(template: template),
    ));
    expect(find.byKey(const ValueKey('create-project-from-template')), findsOneWidget);
    expect(
      tester.widget<FilledButton>(find.byKey(const ValueKey('create-project-from-template'))).onPressed,
      isNull,
    );

    await tester.tap(find.byKey(ValueKey('choose-template-media-${template.mediaSlots.single.id}')));
    await tester.pumpAndSettle();

    expect(find.text('المحدد: لقطة محلية · 00:08.000'), findsOneWidget);
    expect(
      tester.widget<FilledButton>(find.byKey(const ValueKey('create-project-from-template'))).onPressed,
      isNotNull,
    );
  });
}
