import 'clip_motion.dart';
import 'project.dart';
import 'video_transitions.dart';

int mapProjectSourceTimeToOutputMs(
  int sourceProjectMs,
  List<TimelineClip> clips,
  List<VideoTransition> transitions,
) {
  if (clips.isEmpty) return 0;
  final ids = clips.map((clip) => clip.id).toList();
  final sourceDurations = clips.map((clip) => clip.durationMs).toList();
  final outputDurations = clips.map((clip) => clip.effectiveDurationMs).toList();
  var sourceCursor = 0;
  var outputBeforeTransitions = 0;
  final sourceTime = sourceProjectMs.clamp(0, 1 << 53).toInt();
  for (var i = 0; i < clips.length; i++) {
    final clip = clips[i];
    final sourceDuration = sourceDurations[i].clamp(0, 1 << 53).toInt();
    final outputDuration = outputDurations[i].clamp(0, 1 << 53).toInt();
    if (sourceTime <= sourceCursor + sourceDuration || i == clips.length - 1) {
      final localSource = (sourceTime - sourceCursor).clamp(0, sourceDuration).toInt();
      final localOutput = sourceOffsetToOutputMs(
        localSource,
        clip.trimStartMs,
        clip.effectiveSpeedRampPoints,
      ).clamp(0, outputDuration).toInt();
      final preTransitionTime = outputBeforeTransitions + localOutput;
      return mapTransitionTimelineMs(
        preTransitionTime,
        ids,
        outputDurations,
        transitions,
      );
    }
    sourceCursor += sourceDuration;
    outputBeforeTransitions += outputDuration;
  }
  return 0;
}

int mapOutputMsToProjectSourceTime(
  int outputMs,
  List<TimelineClip> clips,
  List<VideoTransition> transitions,
) {
  if (clips.isEmpty) return 0;
  final ids = clips.map((clip) => clip.id).toList();
  final outputDurations = clips.map((clip) => clip.effectiveDurationMs).toList();
  final preTransition = unmapTransitionTimelineMs(
    outputMs,
    ids,
    outputDurations,
    transitions,
  );
  var outputCursor = 0;
  var sourceCursor = 0;
  for (var i = 0; i < clips.length; i++) {
    final clip = clips[i];
    final outputDuration = outputDurations[i].clamp(0, 1 << 53).toInt();
    final sourceDuration = clip.durationMs.clamp(0, 1 << 53).toInt();
    if (preTransition <= outputCursor + outputDuration || i == clips.length - 1) {
      final localOutput = (preTransition - outputCursor).clamp(0, outputDuration).toInt();
      final localSource = outputOffsetToSourceMs(
        localOutput,
        clip.trimStartMs,
        clip.trimEndMs,
        clip.effectiveSpeedRampPoints,
      );
      return sourceCursor + localSource.clamp(0, sourceDuration).toInt();
    }
    outputCursor += outputDuration;
    sourceCursor += sourceDuration;
  }
  return sourceCursor;
}
