import 'clip_motion.dart';
import 'project.dart';
import 'video_transitions.dart';

/// Position of a playhead in the sequential visual track.
///
/// [timelinePositionMs] is relative to the start of the whole track, while
/// [sourcePositionMs] is relative to the referenced media asset.
class TimelinePosition {
  const TimelinePosition({
    required this.clipId,
    required this.assetId,
    required this.clipIndex,
    required this.timelinePositionMs,
    required this.clipPositionMs,
    required this.sourcePositionMs,
  });

  final String clipId;
  final String assetId;
  final int clipIndex;
  final int timelinePositionMs;
  final int clipPositionMs;
  final int sourcePositionMs;
}

/// Total duration of positive-length clips on the visual track.
int visualTimelineDurationMs(
  List<TimelineClip> track, {
  List<VideoTransition> transitions = const [],
}) => transitions.isEmpty
    ? track.fold<int>(
        0,
        (total, clip) => total + (clip.effectiveDurationMs > 0 ? clip.effectiveDurationMs : 0),
      )
    : layoutVideoTransitions(
        track.map((clip) => clip.id).toList(),
        track.map((clip) => clip.effectiveDurationMs).toList(),
        transitions,
      ).totalDurationMs;

/// Maps a saved (pre-speed, pre-transition) project-time value to the visible
/// composition clock used by timeline controls and Media3 overlays/audio.
int projectTimelineMsToOutputMs(
  List<TimelineClip> track,
  int requestedProjectMs, {
  List<VideoTransition> transitions = const [],
}) {
  if (track.isEmpty) return 0;
  final ids = track.map((clip) => clip.id).toList();
  final durations = track.map((clip) => clip.effectiveDurationMs).toList();
  final safeProjectMs = requestedProjectMs.clamp(0, 1 << 53).toInt();
  var sourceCursor = 0;
  var outputCursor = 0;
  for (final clip in track) {
    final sourceDuration = clip.durationMs;
    final outputDuration = clip.effectiveDurationMs;
    if (sourceDuration <= 0 || outputDuration <= 0) continue;
    if (safeProjectMs <= sourceCursor + sourceDuration) {
      final localSourceMs = (safeProjectMs - sourceCursor)
          .clamp(0, sourceDuration)
          .toInt();
      final localOutputMs = sourceOffsetToOutputMs(
        localSourceMs,
        clip.trimStartMs,
        clip.effectiveSpeedRampPoints,
      ).clamp(0, outputDuration).toInt();
      return mapTransitionTimelineMs(
        outputCursor + localOutputMs,
        ids,
        durations,
        transitions,
      );
    }
    sourceCursor += sourceDuration;
    outputCursor += outputDuration;
  }
  return visualTimelineDurationMs(track, transitions: transitions);
}

/// Inverse of [projectTimelineMsToOutputMs] for moving overlay/audio clips by
/// dragging them in the visible timeline. The inverse follows the same
/// transition overlap and speed-adjusted clip clocks as preview/export.
int outputTimelineMsToProjectMs(
  List<TimelineClip> track,
  int requestedOutputMs, {
  List<VideoTransition> transitions = const [],
}) {
  if (track.isEmpty) return 0;
  final ids = track.map((clip) => clip.id).toList();
  final durations = track.map((clip) => clip.effectiveDurationMs).toList();
  final preTransitionMs = unmapTransitionTimelineMs(
    requestedOutputMs.clamp(0, visualTimelineDurationMs(track, transitions: transitions)).toInt(),
    ids,
    durations,
    transitions,
  );
  var sourceCursor = 0;
  var outputCursor = 0;
  for (final clip in track) {
    final sourceDuration = clip.durationMs;
    final outputDuration = clip.effectiveDurationMs;
    if (sourceDuration <= 0 || outputDuration <= 0) continue;
    if (preTransitionMs <= outputCursor + outputDuration) {
      final localOutputMs = (preTransitionMs - outputCursor)
          .clamp(0, outputDuration)
          .toInt();
      final localSourceMs = outputOffsetToSourceMs(
        localOutputMs,
        clip.trimStartMs,
        clip.trimEndMs,
        clip.effectiveSpeedRampPoints,
      );
      return sourceCursor + localSourceMs.clamp(0, sourceDuration).toInt();
    }
    sourceCursor += sourceDuration;
    outputCursor += outputDuration;
  }
  return sourceCursor;
}

/// Maps a timeline time to its clip and source-media time.
///
/// Clip ranges are laid out sequentially in list order. Exact internal clip
/// boundaries select the following clip; the track's final boundary selects
/// the end of the final valid clip. Invalid/zero-length ranges are ignored.
TimelinePosition? timelinePositionAt(
  List<TimelineClip> track,
  int requestedPositionMs, {
  List<VideoTransition> transitions = const [],
}) {
  final layout = layoutVideoTransitions(
    track.map((clip) => clip.id).toList(),
    track.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final totalDurationMs = layout.totalDurationMs;
  if (totalDurationMs <= 0) return null;
  final positionMs = requestedPositionMs.clamp(0, totalDurationMs).toInt();
  final lastValidIndex = track.lastIndexWhere((clip) => clip.effectiveDurationMs > 0);
  for (var index = track.length - 1; index >= 0; index--) {
    final clip = track[index];
    final durationMs = clip.effectiveDurationMs;
    if (durationMs <= 0) continue;
    final timelineStartMs = layout.startOfClip(index);
    final timelineEndMs = timelineStartMs + durationMs;
    final isFinalBoundary = positionMs == totalDurationMs && index == lastValidIndex;
    if ((positionMs >= timelineStartMs && positionMs < timelineEndMs) || isFinalBoundary) {
      final outputOffsetMs = (positionMs - timelineStartMs).clamp(0, durationMs).toInt();
      final sourceOffsetMs = outputOffsetToSourceMs(
        outputOffsetMs,
        clip.trimStartMs,
        clip.trimEndMs,
        clip.effectiveSpeedRampPoints,
      );
      return TimelinePosition(
        clipId: clip.id,
        assetId: clip.assetId,
        clipIndex: index,
        timelinePositionMs: positionMs,
        clipPositionMs: outputOffsetMs,
        sourcePositionMs: clip.trimStartMs + sourceOffsetMs,
      );
    }
  }
  return null;
}

/// Maps a player's current playlist item and item-relative position back to the
/// absolute visual timeline and the source-media timestamp.
TimelinePosition? timelinePositionForClipOffset(
  List<TimelineClip> track, {
  required int clipIndex,
  required int clipPositionMs,
  List<VideoTransition> transitions = const [],
}) {
  if (clipIndex < 0 || clipIndex >= track.length) return null;
  final clip = track[clipIndex];
  final durationMs = clip.effectiveDurationMs;
  if (durationMs <= 0) return null;

  final timelineStartMs = layoutVideoTransitions(
    track.map((item) => item.id).toList(),
    track.map((item) => item.effectiveDurationMs).toList(),
    transitions,
  ).startOfClip(clipIndex);
  final boundedOffsetMs = clipPositionMs.clamp(0, durationMs).toInt();
  final sourceOffsetMs = outputOffsetToSourceMs(
    boundedOffsetMs,
    clip.trimStartMs,
    clip.trimEndMs,
    clip.effectiveSpeedRampPoints,
  );
  return TimelinePosition(
    clipId: clip.id,
    assetId: clip.assetId,
    clipIndex: clipIndex,
    timelinePositionMs: timelineStartMs + boundedOffsetMs,
    clipPositionMs: boundedOffsetMs,
    sourcePositionMs: clip.trimStartMs + sourceOffsetMs,
  );
}
