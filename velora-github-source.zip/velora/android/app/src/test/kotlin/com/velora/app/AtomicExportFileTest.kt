package com.velora.app

import java.io.File
import java.io.IOException
import java.nio.file.Files
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class AtomicExportFileTest {
    private lateinit var directory: File

    @Before
    fun setUp() {
        directory = Files.createTempDirectory("velora-atomic-export-test").toFile()
    }

    @After
    fun tearDown() {
        directory.deleteRecursively()
    }

    @Test
    fun completedFileAppearsOnlyAtFinalPathAndNoStagingFileRemains() {
        val source = File(directory, "encoded.tmp").apply { writeBytes(ByteArray(8192) { it.toByte() }) }
        val destination = File(directory, "final.mp4")
        val tracked = mutableListOf<File?>()

        publishExportFileAtomically(source, destination, {}) { tracked.add(it) }

        assertTrue(destination.isFile)
        assertEquals(source.readBytes().toList(), destination.readBytes().toList())
        assertTrue(tracked.first()!!.name.endsWith(".partial"))
        assertEquals(destination, tracked.last())
        assertFalse(directory.listFiles().orEmpty().any { it.name.endsWith(".partial") })
    }

    @Test
    fun cancellationDuringCopyRemovesStagingAndNeverCreatesFinalMp4() {
        val source = File(directory, "encoded.tmp").apply { writeBytes(ByteArray(16_384) { 7 }) }
        val destination = File(directory, "cancelled.mp4")
        var checks = 0

        try {
            publishExportFileAtomically(source, destination, {
                checks++
                if (checks == 3) throw java.util.concurrent.CancellationException("cancelled")
            }) {}
            throw AssertionError("Expected cancellation")
        } catch (_: java.util.concurrent.CancellationException) {
            // Expected: no completed destination is made visible.
        }

        assertFalse(destination.exists())
        assertFalse(directory.listFiles().orEmpty().any { it.name.endsWith(".partial") })
    }

    @Test
    fun copyFailureRemovesStagingWithoutCreatingTheFinalPath() {
        val source = File(directory, "missing-encoded.tmp")
        val destination = File(directory, "failed-copy.mp4")

        try {
            publishExportFileAtomically(source, destination, {}, {})
            throw AssertionError("Expected source read failure")
        } catch (_: java.io.FileNotFoundException) {
            // Expected: cleanup leaves no user-visible final output.
        }

        assertFalse(destination.exists())
        assertFalse(directory.listFiles().orEmpty().any { it.name.endsWith(".partial") })
    }

    @Test
    fun existingDestinationIsNeverDeletedWhenPublishingIsRejected() {
        val source = File(directory, "encoded.tmp").apply { writeText("new output") }
        val destination = File(directory, "existing.mp4").apply { writeText("keep existing") }

        try {
            publishExportFileAtomically(source, destination, {}, {})
            throw AssertionError("Expected destination collision")
        } catch (_: IOException) {
            // Expected: the name is already occupied.
        }

        assertEquals("keep existing", destination.readText())
        assertFalse(directory.listFiles().orEmpty().any { it.name.endsWith(".partial") })
    }
}
