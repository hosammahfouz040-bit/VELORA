import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_ops.dart';

void main() {
  const clipId = 'visual-clip';
  const assetId = 'asset';
  final perClipOverride = VideoColorSettings(
    brightness: 0.35,
    contrast: -0.2,
    saturation: 28,
    warmth: 0.4,
  );

  TimelineClip clipWithOverride() => TimelineClip(
        id: clipId,
        assetId: assetId,
        trimStartMs: 0,
        trimEndMs: 4_000,
        colorSettingsOverride: perClipOverride,
      );

  test('legacy clip maps omit override and inherit project settings', () {
    final legacyClip = TimelineClip.fromMap({
      'id': clipId,
      'assetId': assetId,
      'trimStartMs': 0,
      'trimEndMs': 4_000,
    });
    final projectSettings = VideoColorSettings(brightness: -0.15, saturation: 12);

    expect(legacyClip.colorSettingsOverride, isNull);
    expect(legacyClip.effectiveColorSettings(projectSettings), projectSettings);
    expect(legacyClip.toMap().containsKey('colorSettingsOverride'), isFalse);
  });

  test('clip color override round-trips through its map', () {
    final clip = clipWithOverride();
    final reopened = TimelineClip.fromMap(clip.toMap());

    expect(reopened.colorSettingsOverride, perClipOverride);
  });

  test('copyWith preserves, replaces, and explicitly clears the override', () {
    final clip = clipWithOverride();
    final trimmed = clip.copyWith(trimStartMs: 250);
    final replacement = VideoColorSettings(brightness: -0.4);
    final replaced = clip.copyWith(colorSettingsOverride: replacement);
    final cleared = clip.copyWith(clearColorSettingsOverride: true);

    expect(trimmed.colorSettingsOverride, perClipOverride);
    expect(replaced.colorSettingsOverride, replacement);
    expect(cleared.colorSettingsOverride, isNull);
  });

  test('both clip-splitting paths preserve override on each segment', () {
    final clip = clipWithOverride();
    final byPlayhead = splitClipAtPosition(
      [clip],
      clipId,
      playheadMs: 1_500,
      secondClipId: 'split-playhead',
      sourceDurationMs: 4_000,
    )!;
    final byMidpoint = splitClipAtMidpoint(
      [clip],
      clipId,
      secondClipId: 'split-midpoint',
    )!;

    expect(
      byPlayhead.map((item) => item.colorSettingsOverride),
      [perClipOverride, perClipOverride],
    );
    expect(
      byMidpoint.map((item) => item.colorSettingsOverride),
      [perClipOverride, perClipOverride],
    );
  });

  test('safe reorder moves clips without detaching their settings', () {
    final first = clipWithOverride();
    final second = TimelineClip(
      id: 'second',
      assetId: assetId,
      trimStartMs: 0,
      trimEndMs: 4_000,
      colorSettingsOverride: VideoColorSettings(saturation: -40),
    );
    final result = reorderVideoClipSafely(
      videoTrack: [first, second],
      transitions: const [],
      draggedClipId: clipId,
      targetClipId: 'second',
      insertAfterTarget: true,
    );

    expect(result.accepted, isTrue);
    expect(result.track!.map((item) => item.id), ['second', clipId]);
    expect(result.track![0].colorSettingsOverride, second.colorSettingsOverride);
    expect(result.track![1].colorSettingsOverride, perClipOverride);
  });

  test('project persistence and undo/redo retain per-clip overrides', () {
    final initial = VeloraProject.empty(id: 'p', name: 'Per-clip color')
        .copyWith(videoTrack: [clipWithOverride()]);
    final reopened = VeloraProject.fromMap(initial.toMap());
    final history = ProjectHistory(initial);
    final changedClip = initial.videoTrack.single.copyWith(
      colorSettingsOverride: VideoColorSettings(contrast: 0.5),
    );
    final changed = initial.copyWith(videoTrack: [changedClip]);
    history.record(changed);

    expect(reopened.videoTrack.single.colorSettingsOverride, perClipOverride);
    expect(history.undo()!.videoTrack.single.colorSettingsOverride, perClipOverride);
    expect(history.redo()!.videoTrack.single.colorSettingsOverride, changedClip.colorSettingsOverride);
  });
}
