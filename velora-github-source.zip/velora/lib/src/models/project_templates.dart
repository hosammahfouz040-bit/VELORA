import 'clip_motion.dart';
import 'overlays.dart';
import 'project.dart';
import 'timeline_ops.dart';
import 'timeline_position.dart';
import 'video_overlays.dart';
import 'video_transitions.dart';

/// A reusable, media-independent project snapshot. It wraps the existing
/// [VeloraProject] model rather than changing the editor or Media3 composition.
class ProjectTemplate {
  const ProjectTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.project,
    required this.mediaSlots,
    this.createdAt = '',
    this.isBuiltIn = false,
  });

  final String id;
  final String name;
  final String description;
  final String createdAt;
  final VeloraProject project;
  final List<TemplateMediaSlot> mediaSlots;
  final bool isBuiltIn;

  factory ProjectTemplate.fromMap(Map<String, dynamic> map) => ProjectTemplate(
    id: map['id'] as String,
    name: map['name'] as String? ?? 'قالب بلا اسم',
    description: map['description'] as String? ?? '',
    createdAt: map['createdAt'] as String? ?? '',
    project: VeloraProject.fromMap(
      Map<String, dynamic>.from(map['project'] as Map),
    ),
    mediaSlots: ((map['mediaSlots'] as List<dynamic>?) ?? const [])
        .map((item) => TemplateMediaSlot.fromMap(
              Map<String, dynamic>.from(item as Map),
            ))
        .toList(),
    isBuiltIn: map['isBuiltIn'] == true,
  );

  Map<String, dynamic> toMap() => {
    'schemaVersion': 1,
    'id': id,
    'name': name,
    'description': description,
    'createdAt': createdAt,
    'project': project.toMap(),
    'mediaSlots': mediaSlots.map((slot) => slot.toMap()).toList(),
    'isBuiltIn': isBuiltIn,
  };

  /// Captures the current edit as a reusable structure. Media URIs are replaced
  /// with local slot markers, so a template never depends on the source files.
  static ProjectTemplate fromProject(
    VeloraProject source, {
    required String id,
    required String name,
    String description = '',
  }) {
    if (source.videoTrack.isEmpty) {
      throw const FormatException('أضف مقطعًا مرئيًا قبل حفظ المشروع كقالب.');
    }

    final assetUsage = <String, Set<MediaKind>>{};
    final requiredSourceEnds = <String, int>{};
    void record(String assetId, MediaKind usage, int sourceEndMs) {
      assetUsage.putIfAbsent(assetId, () => <MediaKind>{}).add(usage);
      if (sourceEndMs > (requiredSourceEnds[assetId] ?? 0)) {
        requiredSourceEnds[assetId] = sourceEndMs;
      }
    }

    for (final clip in source.videoTrack) {
      record(clip.assetId, MediaKind.video, clip.trimEndMs);
    }
    for (final clip in source.audioTrack) {
      record(clip.assetId, MediaKind.audio, clip.trimEndMs);
    }
    for (final track in source.videoOverlayTracks) {
      for (final clip in track.clips) {
        record(clip.assetId, MediaKind.video, clip.trimEndMs);
      }
    }

    final assetsById = {for (final asset in source.assets) asset.id: asset};
    final slots = <TemplateMediaSlot>[];
    final templateAssets = <MediaAsset>[];
    for (final assetId in assetUsage.keys) {
      final asset = assetsById[assetId];
      if (asset == null) {
        throw FormatException('القالب يشير إلى وسيط مفقود: $assetId');
      }
      final usages = assetUsage[assetId]!;
      if (usages.length != 1) {
        throw FormatException('لا يمكن تحويل استخدامات الوسيط «${asset.name}» إلى فتحة واحدة آمنة.');
      }
      final usage = usages.single;
      final allowedKinds = usage == MediaKind.audio
          ? const {MediaKind.audio}
          : const {MediaKind.video, MediaKind.image};
      if (!allowedKinds.contains(asset.kind)) {
        throw FormatException('نوع الوسيط «${asset.name}» لا يطابق موضعه في المشروع.');
      }
      final slot = TemplateMediaSlot(
        id: 'asset:$assetId',
        label: asset.name,
        assetId: assetId,
        stickerOverlayIds: const [],
        allowedKinds: allowedKinds,
        requiredSourceEndMs: requiredSourceEnds[assetId] ?? 0,
      );
      slots.add(slot);
      templateAssets.add(MediaAsset(
        id: asset.id,
        uri: 'template://slot/${Uri.encodeComponent(slot.id)}',
        name: asset.name,
        mimeType: asset.mimeType,
        kind: asset.kind,
        durationMs: asset.durationMs,
        width: asset.width,
        height: asset.height,
        sizeBytes: 0,
      ));
    }

    final templateStickers = <StickerOverlay>[];
    for (final sticker in source.stickerOverlays) {
      final slot = TemplateMediaSlot(
        id: 'sticker:${sticker.id}',
        label: sticker.name,
        assetId: null,
        stickerOverlayIds: [sticker.id],
        allowedKinds: const {MediaKind.image},
        requiredSourceEndMs: 0,
      );
      slots.add(slot);
      templateStickers.add(StickerOverlay(
        id: sticker.id,
        uri: 'template://slot/${Uri.encodeComponent(slot.id)}',
        name: sticker.name,
        mimeType: sticker.mimeType,
        startMs: sticker.startMs,
        endMs: sticker.endMs,
        positionX: sticker.positionX,
        positionY: sticker.positionY,
        widthFraction: sticker.widthFraction,
      ));
    }

    final templateProject = VeloraProject(
      id: 'template-snapshot-$id',
      name: name,
      createdAt: DateTime.now().toUtc().toIso8601String(),
      assets: templateAssets,
      videoTrack: source.videoTrack,
      audioTrack: source.audioTrack,
      frameSettings: source.frameSettings,
      colorSettings: source.colorSettings,
      textOverlays: source.textOverlays,
      subtitleTrack: source.subtitleTrack,
      stickerOverlays: templateStickers,
      videoOverlayTracks: source.videoOverlayTracks,
      videoTransitions: source.videoTransitions,
    );
    return ProjectTemplate(
      id: id,
      name: name,
      description: description,
      createdAt: DateTime.now().toUtc().toIso8601String(),
      project: templateProject,
      mediaSlots: slots,
    );
  }
}

class TemplateMediaSlot {
  const TemplateMediaSlot({
    required this.id,
    required this.label,
    required this.allowedKinds,
    required this.requiredSourceEndMs,
    required this.stickerOverlayIds,
    this.assetId,
    this.required = true,
  });

  final String id;
  final String label;
  final String? assetId;
  final List<String> stickerOverlayIds;
  final Set<MediaKind> allowedKinds;
  final int requiredSourceEndMs;
  final bool required;

  bool get requiresSelection =>
      required || assetId != null || stickerOverlayIds.isNotEmpty;

  factory TemplateMediaSlot.fromMap(Map<String, dynamic> map) => TemplateMediaSlot(
    id: map['id'] as String,
    label: map['label'] as String? ?? 'وسيط مطلوب',
    assetId: map['assetId'] as String?,
    stickerOverlayIds: ((map['stickerOverlayIds'] as List<dynamic>?) ?? const [])
        .map((value) => value.toString())
        .toList(),
    allowedKinds: ((map['allowedKinds'] as List<dynamic>?) ?? const [])
        .map(mediaKindFromString)
        .where((kind) => kind != MediaKind.unsupported)
        .toSet(),
    requiredSourceEndMs: ((map['requiredSourceEndMs'] as num?)?.toInt() ?? 0)
        .clamp(0, 1 << 53)
        .toInt(),
    required: map['required'] as bool? ?? true,
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'label': label,
    'assetId': assetId,
    'stickerOverlayIds': stickerOverlayIds,
    'allowedKinds': allowedKinds.map((kind) => kind.name).toList(),
    'requiredSourceEndMs': requiredSourceEndMs,
    'required': required,
  };
}

class TemplateInstantiationResult {
  const TemplateInstantiationResult({
    required this.project,
    required this.adjustments,
  });

  final VeloraProject project;
  final List<String> adjustments;
}

/// Instantiates a new independent project. Replacements keep the template's
/// clip IDs and effects, and source ranges/transitions are safely re-fit.
TemplateInstantiationResult instantiateProjectTemplate({
  required ProjectTemplate template,
  required String projectName,
  required Map<String, MediaAsset> assignments,
}) {
  final adjustments = <String>[];
  final base = template.project;
  if (base.videoTrack.isEmpty) {
    throw const FormatException('القالب لا يحتوي على مقطع مرئي صالح.');
  }
  if (base.assets.any((asset) => Uri.tryParse(asset.uri)?.scheme != 'template') ||
      base.stickerOverlays.any(
        (sticker) => Uri.tryParse(sticker.uri)?.scheme != 'template',
      )) {
    throw const FormatException('القالب يحتوي على وسيط مصدر غير محوّل إلى فتحة.');
  }
  final replacements = <String, MediaAsset>{};
  final stickerReplacements = <String, MediaAsset>{};

  for (final slot in template.mediaSlots) {
    final selected = assignments[slot.id];
    if (selected == null) {
      if (slot.requiresSelection) {
        throw FormatException('اختر وسيطًا للفتحة «${slot.label}».');
      }
      continue;
    }
    final uri = Uri.tryParse(selected.uri);
    if (selected.uri.trim().isEmpty ||
        uri == null ||
        !const {'content', 'file'}.contains(uri.scheme) ||
        (uri.scheme == 'content' && uri.authority.isEmpty) ||
        (uri.scheme == 'file' && uri.path.isEmpty)) {
      throw FormatException('رابط وسيط «${selected.name}» غير صالح.');
    }
    if (!slot.allowedKinds.contains(selected.kind)) {
      throw FormatException('نوع «${selected.name}» غير مناسب للفتحة «${slot.label}».');
    }
    final mimeType = selected.mimeType.toLowerCase();
    final mimeKind = mimeType.startsWith('video/')
        ? MediaKind.video
        : mimeType.startsWith('image/')
            ? MediaKind.image
            : mimeType.startsWith('audio/')
                ? MediaKind.audio
                : null;
    if (mimeKind != null && mimeKind != selected.kind) {
      throw FormatException('نوع ملف «${selected.name}» لا يطابق بيانات الوسيط.');
    }
    if (selected.name.trim().isEmpty) {
      throw const FormatException('اسم أحد الوسائط المحددة فارغ.');
    }
    if (selected.kind != MediaKind.image && selected.durationMs <= 0) {
      throw FormatException('مدة «${selected.name}» غير صالحة.');
    }
    if (slot.assetId != null) {
      final templateAsset = base.assetById(slot.assetId!);
      if (templateAsset == null) {
        throw FormatException('تعذّر العثور على وسيط القالب «${slot.label}».');
      }
      final imageHoldEnd = slot.requiredSourceEndMs > selected.durationMs
          ? slot.requiredSourceEndMs
          : selected.durationMs;
      replacements[slot.assetId!] = MediaAsset(
        id: slot.assetId!,
        uri: selected.uri,
        name: selected.name,
        mimeType: selected.mimeType,
        kind: selected.kind,
        durationMs: selected.kind == MediaKind.image
            ? (imageHoldEnd > 0 ? imageHoldEnd : 5_000)
            : selected.durationMs,
        width: selected.width,
        height: selected.height,
        sizeBytes: selected.sizeBytes,
      );
      if (selected.kind == MediaKind.video &&
          selected.durationMs < slot.requiredSourceEndMs) {
        adjustments.add(
          '«${slot.label}»: الملف أقصر من نطاق القالب؛ سيُقصّ المقطع إلى المدة المتاحة.',
        );
      }
    }
    for (final stickerId in slot.stickerOverlayIds) {
      stickerReplacements[stickerId] = selected;
    }
  }

  final assets = base.assets
      .map((asset) => replacements[asset.id] ?? asset)
      .toList(growable: false);
  if (assets.any((asset) => Uri.tryParse(asset.uri)?.scheme == 'template')) {
    throw const FormatException('بقي وسيط قالب بلا اختيار؛ لم يُنشأ المشروع.');
  }
  final assetsById = {for (final asset in assets) asset.id: asset};

  final videoTrack = <TimelineClip>[];
  for (final clip in base.videoTrack) {
    final asset = assetsById[clip.assetId];
    if (asset == null) throw FormatException('المقطع «${clip.id}» بلا وسيط قالب.');
    if (!const {MediaKind.video, MediaKind.image}.contains(asset.kind)) {
      throw FormatException('الوسيط «${asset.name}» ليس مرئيًا ولا يصلح للمسار الرئيسي.');
    }
    videoTrack.add(_fitTimelineClip(
      clip,
      asset,
      allowStillDuration: true,
      adjustments: adjustments,
    ));
  }

  final videoTransitions = _fitTransitions(
    videoTrack,
    base.videoTransitions,
    adjustments,
  );
  final visualDurationMs = visualTimelineDurationMs(
    videoTrack,
    transitions: videoTransitions,
  );
  final sourceTimelineDurationMs = videoTrack.fold<int>(
    0,
    (total, clip) => (total + clip.durationMs).clamp(0, 1 << 53).toInt(),
  );

  final audioTrack = <TimelineClip>[];
  for (final clip in base.audioTrack) {
    final asset = assetsById[clip.assetId];
    if (asset == null || asset.kind != MediaKind.audio) {
      adjustments.add('حُذف مقطع صوتي بلا وسيط صوتي صالح.');
      continue;
    }
    var fitted = _fitTimelineClip(
      clip,
      asset,
      allowStillDuration: false,
      adjustments: adjustments,
    );
    final outputStartMs = projectTimelineMsToOutputMs(
      videoTrack,
      fitted.timelineStartMs,
      transitions: videoTransitions,
    );
    final remainingMs = visualDurationMs - outputStartMs;
    if (remainingMs <= 0) {
      adjustments.add('حُذف مقطع صوتي يقع بعد نهاية الخط الزمني الجديد.');
      continue;
    }
    final fittedOutputDuration = fitted.effectiveDurationMs;
    final keptOutputDuration = fittedOutputDuration < remainingMs
        ? fittedOutputDuration
        : remainingMs;
    if (keptOutputDuration < fittedOutputDuration) {
      adjustments.add('قُصّ مقطع صوتي ليتناسب مع مدة الفيديو الجديدة.');
      final keptSourceDuration = outputOffsetToSourceMs(
        keptOutputDuration,
        fitted.trimStartMs,
        fitted.trimEndMs,
        fitted.effectiveSpeedRampPoints,
      );
      if (keptSourceDuration <= 0) {
        adjustments.add('حُذف مقطع صوتي أقصر من الدقة الزمنية المتاحة بعد المواءمة.');
        continue;
      }
      final fittedEnd = fitted.trimStartMs + keptSourceDuration;
      fitted = fitted.copyWith(
        trimEndMs: fittedEnd,
        speedRampPoints: fitted.speedRampPoints
            .where((point) => point.timeMs <= fittedEnd)
            .toList(growable: false),
        fadeInMs: fitted.fadeInMs.clamp(0, keptOutputDuration).toInt(),
        fadeOutMs: fitted.fadeOutMs.clamp(0, keptOutputDuration).toInt(),
      );
    }
    audioTrack.add(fitted);
  }

  final videoOverlayTracks = <VideoOverlayTrack>[];
  for (final track in base.videoOverlayTracks) {
    final fittedClips = <VideoOverlayClip>[];
    for (final clip in track.clips) {
      final asset = assetsById[clip.assetId];
      if (asset == null ||
          !const {MediaKind.video, MediaKind.image}.contains(asset.kind)) {
        adjustments.add('حُذف مقطع طبقة فيديو بلا وسيط مرئي صالح.');
        continue;
      }
      final fitted = _fitVideoOverlayClip(
        clip,
        asset,
        sourceTimelineDurationMs,
        adjustments,
      );
      if (fitted != null) fittedClips.add(fitted);
    }
    videoOverlayTracks.add(track.copyWith(clips: fittedClips));
  }

  final textOverlays = <TextOverlay>[];
  for (final item in base.textOverlays) {
    final range = _fitTimeRange(item.startMs, item.endMs, sourceTimelineDurationMs);
    if (range == null) {
      adjustments.add('حُذف نص خارج مدة المشروع الناتج.');
    } else {
      if (range.$1 != item.startMs || range.$2 != item.endMs) {
        adjustments.add('قُصّ توقيت نص ليتناسب مع مدة المشروع الناتج.');
      }
      textOverlays.add(item.copyWith(startMs: range.$1, endMs: range.$2));
    }
  }

  final subtitleTrack = <SubtitleCue>[];
  for (final cue in base.subtitleTrack) {
    final range = _fitTimeRange(cue.startMs, cue.endMs, sourceTimelineDurationMs);
    if (range == null) {
      adjustments.add('حُذفت ترجمة خارج مدة المشروع الناتج.');
    } else {
      if (range.$1 != cue.startMs || range.$2 != cue.endMs) {
        adjustments.add('قُصّ توقيت ترجمة ليتناسب مع مدة المشروع الناتج.');
      }
      subtitleTrack.add(cue.copyWith(startMs: range.$1, endMs: range.$2));
    }
  }

  final stickerOverlays = <StickerOverlay>[];
  for (final sticker in base.stickerOverlays) {
    final range = _fitTimeRange(sticker.startMs, sticker.endMs, sourceTimelineDurationMs);
    final replacement = stickerReplacements[sticker.id];
    if (range == null || replacement == null) {
      adjustments.add('حُذف ملصق بلا وسيط أو خارج مدة المشروع الناتج.');
      continue;
    }
    if (range.$1 != sticker.startMs || range.$2 != sticker.endMs) {
      adjustments.add('قُصّ توقيت ملصق ليتناسب مع مدة المشروع الناتج.');
    }
    stickerOverlays.add(StickerOverlay(
      id: sticker.id,
      uri: replacement.uri,
      name: replacement.name,
      mimeType: replacement.mimeType,
      startMs: range.$1,
      endMs: range.$2,
      positionX: sticker.positionX,
      positionY: sticker.positionY,
      widthFraction: sticker.widthFraction,
    ));
  }

  final project = VeloraProject(
    id: newLocalId(),
    name: projectName.trim().isEmpty ? template.name : projectName.trim(),
    createdAt: DateTime.now().toUtc().toIso8601String(),
    assets: assets,
    videoTrack: videoTrack,
    audioTrack: audioTrack,
    frameSettings: base.frameSettings,
    colorSettings: base.colorSettings,
    textOverlays: textOverlays,
    subtitleTrack: subtitleTrack,
    stickerOverlays: stickerOverlays,
    videoOverlayTracks: videoOverlayTracks,
    videoTransitions: videoTransitions,
  );
  return TemplateInstantiationResult(
    project: project,
    adjustments: adjustments.toSet().toList(growable: false),
  );
}

TimelineClip _fitTimelineClip(
  TimelineClip clip,
  MediaAsset asset, {
  required bool allowStillDuration,
  required List<String> adjustments,
}) {
  final originalEffectiveDuration = clip.effectiveDurationMs.clamp(1, 1 << 53).toInt();
  if (asset.kind == MediaKind.image && allowStillDuration) {
    final remappedTransforms = clip.transformKeyframes
        .map((point) {
          final sourceOffset = (point.timeMs - clip.trimStartMs)
              .clamp(0, clip.durationMs)
              .toInt();
          final outputOffset = sourceOffsetToOutputMs(
            sourceOffset,
            clip.trimStartMs,
            clip.effectiveSpeedRampPoints,
          );
          return point.copyWith(timeMs: outputOffset);
        })
        .where((point) => point.timeMs >= 0 && point.timeMs <= originalEffectiveDuration)
        .toList();
    if (clip.speedRampPoints.isNotEmpty) {
      adjustments.add('أزيل منحنى السرعة من صورة ثابتة مع الحفاظ على زمن عرضها.');
    }
    return clip.copyWith(
      trimStartMs: 0,
      trimEndMs: originalEffectiveDuration,
      speedRampPoints: const [],
      transformKeyframes: normalizeTransformKeyframes(remappedTransforms),
      fadeInMs: clip.fadeInMs.clamp(0, originalEffectiveDuration).toInt(),
      fadeOutMs: clip.fadeOutMs.clamp(0, originalEffectiveDuration).toInt(),
    );
  }

  final sourceDurationMs = asset.durationMs;
  if (sourceDurationMs <= 0) {
    throw FormatException('مدة «${asset.name}» غير صالحة.');
  }
  var startMs = clip.trimStartMs;
  final desiredSpanMs = clip.durationMs.clamp(1, 1 << 53).toInt();
  if (startMs >= sourceDurationMs) startMs = 0;
  var endMs = clip.trimEndMs <= sourceDurationMs && startMs == clip.trimStartMs
      ? clip.trimEndMs
      : (startMs + desiredSpanMs).clamp(0, sourceDurationMs).toInt();
  if (endMs <= startMs) {
    startMs = 0;
    endMs = desiredSpanMs.clamp(1, sourceDurationMs).toInt();
  }

  final changedSourceRange = startMs != clip.trimStartMs || endMs != clip.trimEndMs;
  var speedPoints = clip.speedRampPoints;
  var keyframes = clip.transformKeyframes;
  if (asset.kind == MediaKind.image) {
    speedPoints = const [];
  } else if (changedSourceRange) {
    speedPoints = speedPoints
        .where((point) => point.timeMs >= startMs && point.timeMs <= endMs)
        .toList(growable: false);
    keyframes = keyframes
        .where((point) => point.timeMs >= startMs && point.timeMs <= endMs)
        .toList(growable: false);
    if (speedPoints.length != clip.speedRampPoints.length ||
        keyframes.length != clip.transformKeyframes.length) {
      adjustments.add('أزيلت نقاط سرعة أو تحريك تقع خارج الجزء المتاح من الوسيط الجديد.');
    }
  }
  if (changedSourceRange) {
    adjustments.add('عُدّل قصّ «${asset.name}» ليلائم مدة الملف المحدد.');
  }
  final fitted = clip.copyWith(
    trimStartMs: startMs,
    trimEndMs: endMs,
    speedRampPoints: normalizeSpeedRampPoints(speedPoints),
    transformKeyframes: normalizeTransformKeyframes(keyframes),
  );
  final effectiveDuration = fitted.effectiveDurationMs.clamp(1, 1 << 53).toInt();
  return fitted.copyWith(
    fadeInMs: fitted.fadeInMs.clamp(0, effectiveDuration).toInt(),
    fadeOutMs: fitted.fadeOutMs.clamp(0, effectiveDuration).toInt(),
  );
}

VideoOverlayClip? _fitVideoOverlayClip(
  VideoOverlayClip clip,
  MediaAsset asset,
  int sourceTimelineDurationMs,
  List<String> adjustments,
) {
  final range = _fitTimeRange(
    clip.timelineStartMs,
    clip.timelineEndMs,
    sourceTimelineDurationMs,
  );
  if (range == null) return null;
  final originalDuration = clip.durationMs;
  var trimStart = clip.trimStartMs;
  var trimEnd = clip.trimEndMs;
  if (asset.kind == MediaKind.image) {
    trimStart = 0;
    trimEnd = originalDuration.clamp(1, 1 << 53).toInt();
  } else {
    if (asset.durationMs <= 0) return null;
    if (trimStart >= asset.durationMs) trimStart = 0;
    trimEnd = trimEnd <= asset.durationMs && trimStart == clip.trimStartMs
        ? trimEnd
        : (trimStart + originalDuration).clamp(0, asset.durationMs).toInt();
    if (trimEnd <= trimStart) {
      trimStart = 0;
      trimEnd = originalDuration.clamp(1, asset.durationMs).toInt();
    }
  }
  final allowedTimelineDuration = range.$2 - range.$1;
  final fittedSourceDuration = trimEnd - trimStart;
  if (fittedSourceDuration > allowedTimelineDuration) {
    trimEnd = trimStart + allowedTimelineDuration;
  }
  if (trimEnd <= trimStart) return null;
  if (range.$1 != clip.timelineStartMs || range.$2 != clip.timelineEndMs) {
    adjustments.add('قُصّت طبقة فيديو لتناسب مدة المشروع الناتج.');
  }
  if (trimStart != clip.trimStartMs || trimEnd != clip.trimEndMs) {
    adjustments.add('عُدّل قصّ طبقة فيديو ليلائم الوسيط الجديد.');
  }
  return clip.copyWith(
    trimStartMs: trimStart,
    trimEndMs: trimEnd,
    timelineStartMs: range.$1,
  );
}

List<VideoTransition> _fitTransitions(
  List<TimelineClip> videoTrack,
  List<VideoTransition> original,
  List<String> adjustments,
) {
  final accepted = <VideoTransition>[];
  final ordered = original.toList()
    ..sort((a, b) {
      final aIndex = videoTrack.indexWhere((clip) => clip.id == a.fromClipId);
      final bIndex = videoTrack.indexWhere((clip) => clip.id == b.fromClipId);
      return aIndex.compareTo(bIndex);
    });
  for (final transition in ordered) {
    final boundary = videoTrack.indexWhere((clip) => clip.id == transition.fromClipId);
    if (!transition.type.supported ||
        boundary < 0 ||
        boundary + 1 >= videoTrack.length ||
        videoTrack[boundary + 1].id != transition.toClipId) {
      adjustments.add('أزيل انتقال لم يعد صالحًا بين المقاطع بعد مواءمة المدد.');
      continue;
    }
    final limits = videoTransitionDurationLimits(
      videoTrack: videoTrack,
      transitions: accepted,
      boundaryIndex: boundary,
    );
    final shorterAdjacentClip = videoTrack[boundary].effectiveDurationMs <
            videoTrack[boundary + 1].effectiveDurationMs
        ? videoTrack[boundary].effectiveDurationMs
        : videoTrack[boundary + 1].effectiveDurationMs;
    final balancedMaximum = shorterAdjacentClip ~/ 2;
    final safeMaximum = limits.maxDurationMs < balancedMaximum
        ? limits.maxDurationMs
        : balancedMaximum;
    if (!limits.accepted || safeMaximum < limits.minDurationMs) {
      adjustments.add('أزيل انتقال قصير/متعارض لا يلائم المدد الجديدة بأمان.');
      continue;
    }
    final duration = transition.durationMs
        .clamp(limits.minDurationMs, safeMaximum)
        .toInt();
    final edit = setVideoTransitionSafely(
      videoTrack: videoTrack,
      transitions: accepted,
      boundaryIndex: boundary,
      type: transition.type,
      durationMs: duration,
      newTransitionId: transition.id,
      direction: transition.direction,
      intensity: transition.intensity,
    );
    if (!edit.accepted) {
      adjustments.add('أزيل انتقال تعذّر الحفاظ على جيرانه بعد تغيير المدد.');
      continue;
    }
    accepted
      ..clear()
      ..addAll(edit.transitions!);
    if (duration != transition.durationMs) {
      adjustments.add('قُصّ انتقال «${transition.type.label}» ليلائم المدد الجديدة.');
    }
  }
  return accepted;
}

(int, int)? _fitTimeRange(int startMs, int endMs, int durationMs) {
  if (durationMs <= 0 || endMs <= startMs) return null;
  final start = startMs.clamp(0, durationMs - 1).toInt();
  final end = endMs.clamp(start + 1, durationMs).toInt();
  if (end <= start) return null;
  return (start, end);
}

List<ProjectTemplate> builtInProjectTemplates() => [
  _singleClipTemplate(
    id: 'builtin:opening',
    name: 'مقدمة عصرية',
    description: 'لقطة افتتاحية عمودية مع عنوان قابل للتحرير ولون دافئ.',
    slotId: 'opening-media',
    mediaLabel: 'لقطة المقدمة',
    durationMs: 4_500,
    text: 'اكتب عنوانك هنا',
    textTemplate: 'banner',
    color: VideoColorSettings(warmth: 0.18, contrast: 0.06, saturation: 5),
  ),
  _twoClipTemplate(
    id: 'builtin:short',
    name: 'فيديو قصير',
    description: 'لقطتان عموديتان وانتقال تلاشي وعنوان افتتاحي.',
    firstSlotId: 'short-first',
    secondSlotId: 'short-second',
    transitionType: VideoTransitionType.fade,
    transitionMs: 320,
  ),
  _singleClipTemplate(
    id: 'builtin:quote',
    name: 'اقتباس وترجمة',
    description: 'خلفية من جهازك مع اقتباس وترجمة سفلية قابلين للتعديل.',
    slotId: 'quote-background',
    mediaLabel: 'خلفية الاقتباس',
    durationMs: 6_000,
    text: 'اكتب اقتباسك هنا',
    textTemplate: 'outline',
    color: VideoColorSettings(brightness: -0.04, contrast: 0.12, saturation: -8),
    addSubtitle: true,
  ),
  _montageTemplate(),
];

ProjectTemplate _singleClipTemplate({
  required String id,
  required String name,
  required String description,
  required String slotId,
  required String mediaLabel,
  required int durationMs,
  required String text,
  required String textTemplate,
  required VideoColorSettings color,
  bool addSubtitle = false,
}) {
  final assetId = 'asset-$slotId';
  final asset = _templateVideoAsset(assetId, mediaLabel, durationMs);
  final clip = TimelineClip(
    id: 'clip-$slotId',
    assetId: assetId,
    trimStartMs: 0,
    trimEndMs: durationMs,
  );
  final overlay = TextOverlay(
    id: 'text-$slotId',
    text: text,
    startMs: 0,
    endMs: durationMs,
    templateId: textTemplate,
    fontSizeScale: textTemplate == 'outline' ? 0.075 : 0.06,
    colorArgb: textTemplate == 'outline' ? 0xFFFFD166 : 0xFFFFFFFF,
    backgroundArgb: textTemplate == 'banner' ? 0xB8000000 : null,
    alignment: OverlayTextAlignment.center,
    shadow: textTemplate != 'banner',
    outlineWidthScale: textTemplate == 'outline' ? 0.004 : 0,
    positionY: addSubtitle ? 0.35 : 0.5,
  );
  final project = VeloraProject(
    id: 'template-$id',
    name: name,
    createdAt: 'built-in',
    assets: [asset],
    videoTrack: [clip],
    audioTrack: const [],
    frameSettings: const VideoFrameSettings(aspectRatio: '9:16'),
    colorSettings: color,
    textOverlays: [overlay],
    subtitleTrack: addSubtitle
        ? [SubtitleCue(id: 'subtitle-$slotId', text: 'اكتب ترجمتك هنا', startMs: 0, endMs: durationMs)]
        : const [],
  );
  return ProjectTemplate(
    id: id,
    name: name,
    description: description,
    project: project,
    mediaSlots: [TemplateMediaSlot(
      id: 'asset:$assetId',
      label: mediaLabel,
      assetId: assetId,
      stickerOverlayIds: const [],
      allowedKinds: const {MediaKind.video, MediaKind.image},
      requiredSourceEndMs: durationMs,
    )],
    isBuiltIn: true,
  );
}

ProjectTemplate _twoClipTemplate({
  required String id,
  required String name,
  required String description,
  required String firstSlotId,
  required String secondSlotId,
  required VideoTransitionType transitionType,
  required int transitionMs,
}) {
  const durationMs = 4_000;
  final firstAssetId = 'asset-$firstSlotId';
  final secondAssetId = 'asset-$secondSlotId';
  final firstClipId = 'clip-$firstSlotId';
  final secondClipId = 'clip-$secondSlotId';
  final project = VeloraProject(
    id: 'template-$id',
    name: name,
    createdAt: 'built-in',
    assets: [
      _templateVideoAsset(firstAssetId, 'المقطع الأول', durationMs),
      _templateVideoAsset(secondAssetId, 'المقطع الثاني', durationMs),
    ],
    videoTrack: [
      TimelineClip(id: firstClipId, assetId: firstAssetId, trimStartMs: 0, trimEndMs: durationMs),
      TimelineClip(id: secondClipId, assetId: secondAssetId, trimStartMs: 0, trimEndMs: durationMs),
    ],
    audioTrack: const [],
    frameSettings: const VideoFrameSettings(aspectRatio: '9:16'),
    colorSettings: VideoColorSettings(warmth: 0.05, saturation: -5, contrast: 0.08),
    textOverlays: const [
      TextOverlay(
        id: 'text-short-title',
        text: 'لحظتك تبدأ هنا',
        startMs: 0,
        endMs: 2_800,
        templateId: 'banner',
        fontSizeScale: 0.06,
        backgroundArgb: 0xB8000000,
        positionY: 0.72,
      ),
    ],
    videoTransitions: [VideoTransition(
      id: 'transition-short',
      fromClipId: firstClipId,
      toClipId: secondClipId,
      type: transitionType,
      durationMs: transitionMs,
    )],
  );
  return ProjectTemplate(
    id: id,
    name: name,
    description: description,
    project: project,
    mediaSlots: [
      _visualSlot(firstAssetId, 'اللقطة الأولى', durationMs),
      _visualSlot(secondAssetId, 'اللقطة الثانية', durationMs),
    ],
    isBuiltIn: true,
  );
}

ProjectTemplate _montageTemplate() {
  const durationMs = 3_500;
  final assetIds = ['montage-a', 'montage-b', 'montage-c'];
  final clipIds = ['montage-clip-a', 'montage-clip-b', 'montage-clip-c'];
  final transitions = [
    VideoTransition(
      id: 'transition-montage-ab',
      fromClipId: clipIds[0],
      toClipId: clipIds[1],
      type: VideoTransitionType.dissolve,
      durationMs: 360,
    ),
    VideoTransition(
      id: 'transition-montage-bc',
      fromClipId: clipIds[1],
      toClipId: clipIds[2],
      type: VideoTransitionType.slide,
      durationMs: 360,
      direction: 'left',
    ),
  ];
  final project = VeloraProject(
    id: 'template-builtin:montage',
    name: 'مونتاج متعدد المقاطع',
    createdAt: 'built-in',
    assets: [
      for (var index = 0; index < assetIds.length; index++)
        _templateVideoAsset(assetIds[index], 'لقطة ${index + 1}', durationMs),
    ],
    videoTrack: [
      for (var index = 0; index < assetIds.length; index++)
        TimelineClip(
          id: clipIds[index],
          assetId: assetIds[index],
          trimStartMs: 0,
          trimEndMs: durationMs,
        ),
    ],
    audioTrack: const [],
    frameSettings: const VideoFrameSettings(aspectRatio: '9:16'),
    colorSettings: VideoColorSettings(contrast: 0.12, saturation: -14, warmth: 0.08),
    textOverlays: const [
      TextOverlay(
        id: 'text-montage-caption',
        text: 'اجمع لحظاتك',
        startMs: 300,
        endMs: 3_000,
        templateId: 'outline',
        fontSizeScale: 0.066,
        colorArgb: 0xFFFFD166,
        outlineWidthScale: 0.004,
        positionY: 0.78,
      ),
    ],
    videoTransitions: transitions,
  );
  return ProjectTemplate(
    id: 'builtin:montage',
    name: 'مونتاج متعدد المقاطع',
    description: 'ثلاث لقطات قابلة للاستبدال مع ذوبان وانزلاق وانتقالات قابلة للتحرير.',
    project: project,
    mediaSlots: [
      for (var index = 0; index < assetIds.length; index++)
        _visualSlot(assetIds[index], 'لقطة ${index + 1}', durationMs),
    ],
    isBuiltIn: true,
  );
}

MediaAsset _templateVideoAsset(String id, String name, int durationMs) => MediaAsset(
  id: id,
  uri: 'template://slot/${Uri.encodeComponent('asset:$id')}',
  name: name,
  mimeType: 'video/mp4',
  kind: MediaKind.video,
  durationMs: durationMs,
  width: 1080,
  height: 1920,
  sizeBytes: 0,
);

TemplateMediaSlot _visualSlot(String assetId, String label, int durationMs) =>
    TemplateMediaSlot(
      id: 'asset:$assetId',
      label: label,
      assetId: assetId,
      stickerOverlayIds: const [],
      allowedKinds: const {MediaKind.video, MediaKind.image},
      requiredSourceEndMs: durationMs,
    );
