package com.velora.app

import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption.ATOMIC_MOVE
import java.nio.file.StandardCopyOption.REPLACE_EXISTING
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ProjectJsonStoreTest {
    private lateinit var directory: File

    @Before
    fun setUp() {
        directory = Files.createTempDirectory("velora-project-store-test").toFile()
    }

    @After
    fun tearDown() {
        directory.deleteRecursively()
    }

    @Test
    fun saveReplacesAnExistingProjectAndReadReturnsIt() {
        val store = store()
        val original = """{"id":"project-1","name":"old"}"""
        val updated = """{"id":"project-1","name":"new"}"""

        store.save("project-1", original)
        store.save("project-1", updated)

        assertEquals(updated, File(directory, "project-1.json").readText())
        assertEquals("project-1", store.readProjects().single()["id"])
        assertNoTemporaryFiles()
    }

    @Test
    fun corruptJsonIsSkippedWithoutDeletingItOrHidingValidProjects() {
        val valid = File(directory, "valid.json").apply {
            writeText("""{"id":"valid"}""")
        }
        val corrupt = File(directory, "corrupt.json").apply {
            writeText("""{"id":"truncated"""")
        }
        File(directory, "unfinished.tmp").writeText("not a project")

        val projects = store().readProjects()

        assertEquals(listOf("valid"), projects.map { it["id"] })
        assertTrue(valid.isFile)
        assertTrue(corrupt.isFile)
        assertEquals("""{"id":"truncated""", corrupt.readText())
        assertTrue(File(directory, "unfinished.tmp").isFile)
    }

    @Test
    fun failedReplacementPreservesThePreviousProjectAndCleansTheTemporaryFile() {
        val original = """{"id":"project-2","name":"previous"}"""
        val target = File(directory, "project-2.json").apply { writeText(original) }
        val failingStore = store { _, _ -> throw IOException("injected rename failure") }

        var failed = false
        try {
            failingStore.save("project-2", """{"id":"project-2","name":"next"}""")
        } catch (_: IOException) {
            failed = true
        }

        assertTrue(failed)
        assertEquals(original, target.readText())
        assertNoTemporaryFiles()
    }

    @Test
    fun successfulAtomicRenameDoesNotLeaveASecondProjectCopy() {
        val store = store()
        store.save("project-3", """{"id":"project-3"}""")

        assertEquals(listOf("project-3.json"), directory.listFiles()!!.map { it.name })
    }

    private fun store(
        replace: (File, File) -> Unit = { source, destination ->
            Files.move(source.toPath(), destination.toPath(), ATOMIC_MOVE, REPLACE_EXISTING)
        },
    ) = ProjectJsonStore(directory, ::decodeFixtureJson, replace)

    private fun decodeFixtureJson(text: String): Map<String, Any?> {
        val match = Regex("""^\s*\{\s*"id"\s*:\s*"([^"]+)"\s*\}\s*$""")
            .find(text)
            ?: throw IOException("Invalid fixture JSON")
        return mapOf("id" to match.groupValues[1])
    }

    private fun assertNoTemporaryFiles() {
        assertFalse(directory.listFiles().orEmpty().any { it.name.endsWith(".tmp") })
    }
}
