package com.velora.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProjectTransitionCurvesTest {
    @Test
    fun dissolveMixesIncomingOverOpaqueOutgoing() {
        val outgoing = transitionFrameTransform("dissolve", false, 0.5f, "right", 1f)!!
        val incoming = transitionFrameTransform("dissolve", true, 0.5f, "right", 1f)!!
        assertEquals(1f, outgoing.alpha, 0.0001f)
        assertEquals(0.5f, incoming.alpha, 0.0001f)
        assertEquals(1f, outgoing.scaleX, 0.0001f)
        assertEquals(1f, incoming.scaleX, 0.0001f)
    }

    @Test
    fun fadeHasBlackMidpointAndCrossesInTwoHalves() {
        val outgoingEarly = transitionFrameTransform("fade", false, 0.25f, "right", 1f)!!
        val incomingEarly = transitionFrameTransform("fade", true, 0.25f, "right", 1f)!!
        val outgoingLate = transitionFrameTransform("fade", false, 0.75f, "right", 1f)!!
        val incomingLate = transitionFrameTransform("fade", true, 0.75f, "right", 1f)!!
        assertEquals(0.5f, outgoingEarly.alpha, 0.0001f)
        assertEquals(0f, incomingEarly.alpha, 0.0001f)
        assertEquals(0f, outgoingLate.alpha, 0.0001f)
        assertEquals(0.5f, incomingLate.alpha, 0.0001f)
    }

    @Test
    fun slideMovesBothFramesAndHonorsDirection() {
        val incoming = transitionFrameTransform("slide", true, 0f, "right", 1f)!!
        val outgoing = transitionFrameTransform("slide", false, 0.5f, "right", 1f)!!
        val upward = transitionFrameTransform("slide", true, 0f, "up", 1f)!!
        assertEquals(1f, incoming.anchorX, 0.0001f)
        assertEquals(-0.5f, outgoing.anchorX, 0.0001f)
        assertEquals(-1f, upward.anchorY, 0.0001f)
    }

    @Test
    fun zoomChangesIncomingScaleAndStrength() {
        val full = transitionFrameTransform("zoom", true, 0f, "right", 1f)!!
        val subtle = transitionFrameTransform("zoom", true, 0f, "right", 0.1f)!!
        val end = transitionFrameTransform("zoom", true, 1f, "right", 1f)!!
        assertEquals(0.55f, full.scaleX, 0.0001f)
        assertEquals(0.955f, subtle.scaleX, 0.0001f)
        assertEquals(1f, end.scaleX, 0.0001f)
        assertEquals(0f, full.alpha, 0.0001f)
    }

    @Test
    fun spinChangesRotationAndScaleOnIncomingFrame() {
        val middle = transitionFrameTransform("spin", true, 0.5f, "right", 1f)!!
        val subtle = transitionFrameTransform("spin", true, 0.5f, "right", 0.25f)!!
        val outgoing = transitionFrameTransform("spin", false, 0.5f, "right", 1f)!!
        assertEquals(180f, middle.rotationDegrees, 0.0001f)
        assertEquals(0.775f, middle.scaleX, 0.0001f)
        assertEquals(45f, subtle.rotationDegrees, 0.0001f)
        assertEquals(0f, outgoing.rotationDegrees, 0.0001f)
        assertEquals(1f, outgoing.scaleX, 0.0001f)
    }

    @Test
    fun unsupportedTransitionHasNoFrameTransform() {
        assertNull(transitionFrameTransform("wipe", true, 0.5f, "right", 1f))
        assertNull(transitionFrameTransform("blur", true, 0.5f, "right", 1f))
    }
}
