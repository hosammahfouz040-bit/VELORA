import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';

void main() {
  group('project color settings', () {
    test('legacy project data gets neutral color defaults', () {
      final project = VeloraProject.fromMap({
        'id': 'legacy',
        'assets': <Object>[],
        'videoTrack': <Object>[],
        'audioTrack': <Object>[],
      });

      expect(project.colorSettings, VideoColorSettings.defaults);
      expect(project.colorSettings.toMap(), {
        'brightness': 0.0,
        'contrast': 0.0,
        'saturation': 0.0,
        'warmth': 0.0,
      });
    });

    test('values survive project serialization and reopening', () {
      final project = VeloraProject.empty(id: 'p', name: 'Color').copyWith(
        colorSettings: VideoColorSettings(
          brightness: 0.25,
          contrast: -0.4,
          saturation: 35,
          warmth: 0.4,
        ),
      );

      final reopened = VeloraProject.fromMap(project.toMap());
      expect(reopened.colorSettings, project.colorSettings);
    });

    test('out-of-range and non-finite values are normalized safely', () {
      final settings = VideoColorSettings.fromMap({
        'brightness': 4,
        'contrast': double.negativeInfinity,
        'saturation': -200,
        'warmth': -2,
      });

      expect(settings.brightness, 1);
      expect(settings.contrast, 0);
      expect(settings.saturation, -100);
      expect(settings.warmth, -1);
      expect(
        VideoColorSettings.fromMap({'brightness': double.nan}).brightness,
        0,
      );
    });

    test('copyWith validates updated values against Media3 ranges', () {
      final settings = VideoColorSettings.defaults.copyWith(
        brightness: -3,
        contrast: 2,
        saturation: 150,
        warmth: 4,
      );

      expect(settings.brightness, -1);
      expect(settings.contrast, 1);
      expect(settings.saturation, 100);
      expect(settings.warmth, 1);
    });
  });
}
