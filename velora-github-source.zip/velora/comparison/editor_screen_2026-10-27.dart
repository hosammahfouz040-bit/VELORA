import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';
import '../models/project.dart';
import '../models/timeline_ops.dart';
import '../models/timeline_position.dart';
import '../services/native_bridge.dart';
import 'export_screen.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.project});

  final VeloraProject project;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late VeloraProject _project = widget.project;
  String? _previewAssetId;
  int _previewPositionMs = 0;
  int _playheadMs = 0;
  String? _selectedVisualClipId;
  String? _selectedAudioClipId;
  bool _importing = false;
  bool _saving = false;
  bool _timelinePreviewActive = false;
  bool _isPlaying = false;
  bool _pollingPlayback = false;
  Timer? _playbackTicker;

  @override
  void initState() {
    super.initState();
    if (_project.videoTrack.isEmpty) return;
    final cursor = timelinePositionAt(_project.videoTrack, 0);
    if (cursor == null) return;
    _timelinePreviewActive = true;
    _selectedVisualClipId = cursor.clipId;
    _previewAssetId = cursor.assetId;
    _previewPositionMs = cursor.sourcePositionMs;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _activateTimelineAt(0, forceConfigure: true);
    });
  }

  @override
  void dispose() {
    _playbackTicker?.cancel();
    unawaited(NativeBridge.clearPreview().catchError((_) {}));
    super.dispose();
  }

  Future<void> _persist(VeloraProject next) async {
    final visualTrackChanged = !identical(next.videoTrack, _project.videoTrack);
    setState(() {
      _project = next;
      _saving = true;
    });
    try {
      await NativeBridge.saveProject(next);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('تعذّر حفظ التغييرات: $error')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }

    if (!visualTrackChanged || !mounted) return;
    if (next.videoTrack.isEmpty) {
      _playbackTicker?.cancel();
      _playbackTicker = null;
      setState(() {
        _timelinePreviewActive = false;
        _isPlaying = false;
        _playheadMs = 0;
      });
      final source = _previewAssetId == null
          ? null
          : next.assetById(_previewAssetId!);
      if (source != null) await _setSourcePreview(source);
      return;
    }
    if (_timelinePreviewActive) {
      await _activateTimelineAt(
        _playheadMs,
        forceConfigure: true,
        autoplay: _isPlaying,
      );
    }
  }

  Future<void> _importMedia() async {
    setState(() => _importing = true);
    try {
      final picked = await NativeBridge.pickMedia();
      if (!mounted || picked.isEmpty) return;
      final knownUris = _project.assets.map((asset) => asset.uri).toSet();
      final additions = picked.where((asset) => !knownUris.contains(asset.uri));
      if (additions.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('الوسائط المحددة موجودة في المكتبة بالفعل.'),
          ),
        );
        return;
      }
      final updated = _project.copyWith(
        assets: [..._project.assets, ...additions],
      );
      await _persist(updated);
      if (mounted) await _setSourcePreview(additions.first);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر استيراد الوسائط: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Future<void> _addToTimeline(MediaAsset asset) async {
    if (asset.kind == MediaKind.unsupported) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('صيغة هذا الملف غير مدعومة حاليًا.')),
      );
      return;
    }
    final duration = asset.durationMs > 0
        ? asset.durationMs
        : asset.kind == MediaKind.image
        ? 5000
        : 0;
    if (duration <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تعذّر قراءة مدة الملف؛ لا يمكن وضعه على المخطط الآن.'),
        ),
      );
      return;
    }
    final clip = TimelineClip(
      id: newLocalId(),
      assetId: asset.id,
      trimStartMs: 0,
      trimEndMs: duration,
    );
    if (asset.kind == MediaKind.audio) {
      _selectedAudioClipId = clip.id;
      await _persist(
        _project.copyWith(audioTrack: [..._project.audioTrack, clip]),
      );
    } else {
      _selectedVisualClipId = clip.id;
      _previewAssetId = asset.id;
      _previewPositionMs = 0;
      _timelinePreviewActive = true;
      await _persist(
        _project.copyWith(videoTrack: [..._project.videoTrack, clip]),
      );
    }
    if (mounted) setState(() {});
  }

  Future<void> _removeClip(String clipId, {required bool audio}) async {
    if (audio) {
      final clips = _project.audioTrack
          .where((clip) => clip.id != clipId)
          .toList();
      if (_selectedAudioClipId == clipId) _selectedAudioClipId = null;
      await _persist(_project.copyWith(audioTrack: clips));
    } else {
      final clips = _project.videoTrack
          .where((clip) => clip.id != clipId)
          .toList();
      if (_selectedVisualClipId == clipId) _selectedVisualClipId = null;
      await _persist(_project.copyWith(videoTrack: clips));
    }
  }

  Future<void> _splitSelected() async {
    final id = _selectedVisualClipId;
    if (id == null) return;
    final split = splitClipAtMidpoint(
      _project.videoTrack,
      id,
      secondClipId: newLocalId(),
    );
    if (split == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('يلزم أن تكون مدة المقطع ثانية واحدة على الأقل.'),
        ),
      );
      return;
    }
    await _persist(_project.copyWith(videoTrack: split));
  }

  Future<void> _adjustTrim(
    TimelineClip clip, {
    required bool moveStart,
    required int delta,
  }) async {
    final asset = _project.assetById(clip.assetId);
    if (asset == null) return;
    final start = moveStart ? clip.trimStartMs + delta : clip.trimStartMs;
    final end = moveStart ? clip.trimEndMs : clip.trimEndMs + delta;
    final maxEnd = asset.durationMs > 0 ? asset.durationMs : clip.trimEndMs;
    if (start < 0 || end > maxEnd || end - start < 250) return;
    final clips = _project.videoTrack
        .map(
          (item) => item.id == clip.id
              ? item.copyWith(trimStartMs: start, trimEndMs: end)
              : item,
        )
        .toList();
    await _persist(_project.copyWith(videoTrack: clips));
  }

  Future<void> _selectVisualClip(TimelineClip clip) async {
    final index = _project.videoTrack.indexWhere((item) => item.id == clip.id);
    if (index < 0) return;
    final timelineStartMs = _project.videoTrack
        .take(index)
        .fold<int>(
          0,
          (total, item) => total + (item.durationMs > 0 ? item.durationMs : 0),
        );
    await _activateTimelineAt(timelineStartMs);
  }

  Future<void> _commitTimelinePosition(int positionMs) =>
      _activateTimelineAt(positionMs);

  Future<void> _activateTimelineAt(
    int positionMs, {
    bool forceConfigure = false,
    bool autoplay = false,
  }) async {
    final cursor = timelinePositionAt(_project.videoTrack, positionMs);
    if (cursor == null) return;
    final configurePlaylist = forceConfigure || !_timelinePreviewActive;

    setState(() {
      _timelinePreviewActive = true;
      _playheadMs = cursor.timelinePositionMs;
      _selectedVisualClipId = cursor.clipId;
      _previewAssetId = cursor.assetId;
      _previewPositionMs = cursor.sourcePositionMs;
    });

    try {
      if (configurePlaylist) {
        await NativeBridge.configurePreviewTimeline(
          _project,
          startIndex: cursor.clipIndex,
          clipPositionMs: cursor.clipPositionMs,
          playWhenReady: autoplay,
        );
      } else {
        await NativeBridge.seekPreviewTo(
          mediaItemIndex: cursor.clipIndex,
          clipPositionMs: cursor.clipPositionMs,
        );
        if (autoplay) await NativeBridge.playPreview();
      }
      if (autoplay && mounted) setState(() => _isPlaying = true);
      if (mounted) {
        _startPlaybackTicker(
          interval: _isPlaying
              ? const Duration(milliseconds: 160)
              : const Duration(seconds: 1),
        );
      }
    } catch (error) {
      _playbackTicker?.cancel();
      _playbackTicker = null;
      if (mounted) {
        setState(() => _isPlaying = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر تشغيل/تحريك معاينة المخطط: $error')),
        );
      }
    }
  }

  Future<void> _setSourcePreview(MediaAsset asset, {int positionMs = 0}) async {
    _playbackTicker?.cancel();
    _playbackTicker = null;
    if (mounted) {
      setState(() {
        _timelinePreviewActive = false;
        _isPlaying = false;
        _previewAssetId = asset.id;
        _previewPositionMs = positionMs;
      });
    }
    try {
      await NativeBridge.setPreviewSource(asset, positionMs: positionMs);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('تعذّرت معاينة المصدر: $error')));
      }
    }
  }

  Future<void> _togglePlayback() async {
    if (_project.videoTrack.isEmpty) return;
    if (_isPlaying) {
      try {
        await NativeBridge.pausePreview();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تعذّر إيقاف المعاينة: $error')),
          );
        }
      }
      if (mounted) setState(() => _isPlaying = false);
      _startPlaybackTicker(interval: const Duration(seconds: 1));
      return;
    }

    final totalDurationMs = visualTimelineDurationMs(_project.videoTrack);
    final startMs = _playheadMs >= totalDurationMs ? 0 : _playheadMs;
    await _activateTimelineAt(startMs, autoplay: true);
  }

  void _startPlaybackTicker({required Duration interval}) {
    _playbackTicker?.cancel();
    _playbackTicker = Timer.periodic(
      interval,
      (_) => unawaited(_pollPlaybackState()),
    );
  }

  Future<void> _pollPlaybackState() async {
    if (_pollingPlayback || !_timelinePreviewActive || !mounted) return;
    _pollingPlayback = true;
    try {
      final state = await NativeBridge.getPreviewState();
      final error = state['error']?.toString();
      if (error != null && error.isNotEmpty) {
        _playbackTicker?.cancel();
        _playbackTicker = null;
        if (mounted) {
          setState(() => _isPlaying = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('توقفت معاينة المخطط: $error')),
          );
        }
        return;
      }

      final playbackState = state['playbackState']?.toString();
      if (_isPlaying &&
          playbackState == 'ready' &&
          state['isPlaying'] == false) {
        if (mounted) setState(() => _isPlaying = false);
        _startPlaybackTicker(interval: const Duration(seconds: 1));
        return;
      }
      if (_isPlaying && playbackState == 'ended') {
        final totalDurationMs = visualTimelineDurationMs(_project.videoTrack);
        final endPosition = timelinePositionAt(
          _project.videoTrack,
          totalDurationMs,
        );
        _playbackTicker?.cancel();
        _playbackTicker = null;
        if (mounted) {
          setState(() {
            _isPlaying = false;
            _playheadMs = totalDurationMs;
            if (endPosition != null) {
              _selectedVisualClipId = endPosition.clipId;
              _previewAssetId = endPosition.assetId;
              _previewPositionMs = endPosition.sourcePositionMs;
            }
          });
          _startPlaybackTicker(interval: const Duration(seconds: 1));
        }
        return;
      }
      if (!_isPlaying) return;

      final itemIndex = (state['mediaItemIndex'] as num?)?.toInt() ?? -1;
      final clipPositionMs = (state['positionMs'] as num?)?.toInt() ?? 0;
      final position = timelinePositionForClipOffset(
        _project.videoTrack,
        clipIndex: itemIndex,
        clipPositionMs: clipPositionMs,
      );
      if (position != null && mounted) {
        setState(() {
          _playheadMs = position.timelinePositionMs;
          _selectedVisualClipId = position.clipId;
          _previewAssetId = position.assetId;
          _previewPositionMs = position.sourcePositionMs;
        });
      }
    } catch (error) {
      _playbackTicker?.cancel();
      _playbackTicker = null;
      if (mounted) {
        setState(() => _isPlaying = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر تحديث مؤشر التشغيل: $error')),
        );
      }
    } finally {
      _pollingPlayback = false;
    }
  }

  Future<void> _reorderTrack({
    required bool audio,
    required int oldIndex,
    required int newIndex,
  }) async {
    final source = audio ? [..._project.audioTrack] : [..._project.videoTrack];
    final item = source.removeAt(oldIndex);
    source.insert(newIndex, item);
    if (audio) {
      await _persist(_project.copyWith(audioTrack: source));
    } else {
      await _persist(_project.copyWith(videoTrack: source));
    }
  }

  @override
  Widget build(BuildContext context) {
    final previewAsset = _previewAssetId == null
        ? null
        : _project.assetById(_previewAssetId!);
    final timelineDurationMs = visualTimelineDurationMs(_project.videoTrack);
    final playheadValueMs = _playheadMs.clamp(0, timelineDurationMs).toInt();
    TimelineClip? selectedClip;
    if (_selectedVisualClipId != null) {
      for (final clip in _project.videoTrack) {
        if (clip.id == _selectedVisualClipId) {
          selectedClip = clip;
          break;
        }
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_project.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            Text(
              _saving ? 'جارٍ الحفظ…' : 'محرر فيلورا',
              style: const TextStyle(fontSize: 11, color: Color(0xFFAFBAC5)),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'استيراد وسائط',
            onPressed: _importing ? null : _importMedia,
            icon: _importing
                ? const SizedBox.square(
                    dimension: 19,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.add_to_photos_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          _PreviewPanel(
            asset: previewAsset,
            initialPositionMs: _previewPositionMs,
            timelineMode: _timelinePreviewActive,
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
              children: [
                _sectionHeader(
                  'مكتبة الوسائط',
                  trailing: Text('${_project.assets.length} عنصر'),
                ),
                const SizedBox(height: 8),
                if (_project.assets.isEmpty)
                  _emptyCard('استورد فيديو أو صورة أو ملفًا صوتيًا للبدء.')
                else
                  ..._project.assets.map(_assetCard),
                const SizedBox(height: 18),
                _sectionHeader(
                  'المخطط الزمني · الصورة والصوت الأصلي',
                  trailing: Text('${_project.videoTrack.length} مقطع'),
                ),
                const SizedBox(height: 4),
                const Text(
                  'ترتيب متتابع بقطع مباشر؛ لا توجد انتقالات بين المقاطع في هذه المرحلة.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF9EABB7)),
                ),
                if (timelineDurationMs > 0) ...[
                  const SizedBox(height: 8),
                  _buildTimelineScrubber(timelineDurationMs, playheadValueMs),
                ],
                const SizedBox(height: 8),
                if (_project.videoTrack.isEmpty)
                  _emptyCard('أضف فيديو أو صورة من المكتبة إلى هذا المسار.')
                else
                  ReorderableListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _project.videoTrack.length,
                    onReorderItem: (oldIndex, newIndex) => _reorderTrack(
                      audio: false,
                      oldIndex: oldIndex,
                      newIndex: newIndex,
                    ),
                    itemBuilder: (context, index) {
                      final clip = _project.videoTrack[index];
                      final asset = _project.assetById(clip.assetId);
                      return _clipCard(
                        key: ValueKey(clip.id),
                        clip: clip,
                        asset: asset,
                        audio: false,
                        selected: clip.id == _selectedVisualClipId,
                      );
                    },
                  ),
                if (selectedClip != null) ...[
                  const SizedBox(height: 10),
                  _buildClipProperties(selectedClip),
                ],
                const SizedBox(height: 18),
                _sectionHeader(
                  'المسار الصوتي الإضافي',
                  trailing: Text('${_project.audioTrack.length} مقطع'),
                ),
                const SizedBox(height: 4),
                const Text(
                  'تبدأ المقاطع الصوتية من بداية التصدير وتتتابع بترتيبها؛ ويُحدّ الامتداد بطول المسار المرئي.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF9EABB7)),
                ),
                const SizedBox(height: 8),
                if (_project.audioTrack.isEmpty)
                  _emptyCard('أضف ملفًا صوتيًا من المكتبة عند الحاجة.')
                else
                  ReorderableListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _project.audioTrack.length,
                    onReorderItem: (oldIndex, newIndex) => _reorderTrack(
                      audio: true,
                      oldIndex: oldIndex,
                      newIndex: newIndex,
                    ),
                    itemBuilder: (context, index) {
                      final clip = _project.audioTrack[index];
                      return _clipCard(
                        key: ValueKey(clip.id),
                        clip: clip,
                        asset: _project.assetById(clip.assetId),
                        audio: true,
                        selected: clip.id == _selectedAudioClipId,
                      );
                    },
                  ),
                const SizedBox(height: 14),
                if (_project.videoTrack.isNotEmpty)
                  OutlinedButton.icon(
                    onPressed: _selectedVisualClipId == null
                        ? null
                        : _splitSelected,
                    icon: const Icon(Icons.content_cut_rounded),
                    label: const Text('تقسيم المقطع المحدد من المنتصف'),
                  ),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _project.videoTrack.isEmpty
                      ? null
                      : () => Navigator.of(context).push<void>(
                          MaterialPageRoute(
                            builder: (_) => ExportScreen(project: _project),
                          ),
                        ),
                  icon: const Icon(Icons.ios_share_rounded),
                  label: const Text('إعداد التصدير'),
                  style: FilledButton.styleFrom(
                    backgroundColor: veloraGold,
                    foregroundColor: veloraInk,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title, {Widget? trailing}) => Row(
    children: [
      Expanded(
        child: Text(
          title,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ),
      if (trailing != null)
        DefaultTextStyle(
          style: const TextStyle(color: Color(0xFF9EABB7), fontSize: 12),
          child: trailing,
        ),
    ],
  );

  Widget _buildTimelineScrubber(int totalDurationMs, int valueMs) => Card(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.linear_scale_rounded, color: veloraGold),
              const SizedBox(width: 8),
              const Expanded(child: Text('مؤشر المخطط الزمني')),
              Text(
                '${_formatDuration(valueMs)} / '
                '${_formatDuration(totalDurationMs)}',
                textDirection: TextDirection.ltr,
              ),
              IconButton.filledTonal(
                tooltip: _isPlaying ? 'إيقاف المعاينة' : 'تشغيل المعاينة',
                onPressed: _togglePlayback,
                icon: Icon(
                  _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                ),
              ),
            ],
          ),
          Slider(
            min: 0,
            max: totalDurationMs.toDouble(),
            value: valueMs.toDouble(),
            label: _formatDuration(valueMs),
            onChanged: (value) => setState(() => _playheadMs = value.round()),
            onChangeEnd: (value) => _commitTimelinePosition(value.round()),
          ),
          const Text(
            'تنتقل المعاينة بين القصاصات بقطع مباشر؛ مزامنة مسار الصوت الإضافي ليست ضمن هذه المرحلة.',
            style: TextStyle(fontSize: 11, color: Color(0xFF9EABB7)),
          ),
        ],
      ),
    ),
  );

  Widget _emptyCard(String message) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Text(message, style: const TextStyle(color: Color(0xFFAFBAC5))),
    ),
  );

  Widget _assetCard(MediaAsset asset) {
    final icon = switch (asset.kind) {
      MediaKind.video => Icons.movie_outlined,
      MediaKind.image => Icons.image_outlined,
      MediaKind.audio => Icons.graphic_eq_rounded,
      MediaKind.unsupported => Icons.insert_drive_file_outlined,
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 7),
      child: ListTile(
        dense: true,
        leading: Icon(icon, color: veloraGold),
        title: Text(asset.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(_formatDuration(asset.durationMs)),
        onTap: () => _setSourcePreview(asset),
        trailing: IconButton(
          tooltip: 'إضافة إلى المخطط الزمني',
          onPressed: asset.kind == MediaKind.unsupported
              ? null
              : () => _addToTimeline(asset),
          icon: const Icon(Icons.add_circle_outline_rounded),
        ),
      ),
    );
  }

  Widget _clipCard({
    required Key key,
    required TimelineClip clip,
    required MediaAsset? asset,
    required bool audio,
    required bool selected,
  }) {
    final title = asset?.name ?? 'وسيط غير متاح';
    return Card(
      key: key,
      margin: const EdgeInsets.only(bottom: 7),
      color: selected ? const Color(0xFF263A4A) : veloraPanel,
      child: ListTile(
        dense: true,
        leading: const Icon(
          Icons.drag_indicator_rounded,
          color: Color(0xFF8393A1),
        ),
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(
          '${_formatDuration(clip.trimStartMs)} — ${_formatDuration(clip.trimEndMs)}',
        ),
        onTap: () {
          if (audio) {
            setState(() => _selectedAudioClipId = clip.id);
          } else {
            _selectVisualClip(clip);
          }
        },
        trailing: IconButton(
          tooltip: 'حذف المقطع من المسار',
          onPressed: () => _removeClip(clip.id, audio: audio),
          icon: const Icon(Icons.close_rounded, size: 19),
        ),
      ),
    );
  }

  Widget _buildClipProperties(TimelineClip clip) {
    final asset = _project.assetById(clip.assetId);
    if (asset == null) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'خصائص القص',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              'هذه حدود المصدر للمقطع المحدد، وليست موضع مؤشر تشغيل.',
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.65),
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 8),
            _trimRow(
              label: 'البداية',
              value: clip.trimStartMs,
              onMinus: () => _adjustTrim(clip, moveStart: true, delta: -500),
              onPlus: () => _adjustTrim(clip, moveStart: true, delta: 500),
            ),
            _trimRow(
              label: 'النهاية',
              value: clip.trimEndMs,
              onMinus: () => _adjustTrim(clip, moveStart: false, delta: -500),
              onPlus: () => _adjustTrim(clip, moveStart: false, delta: 500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _trimRow({
    required String label,
    required int value,
    required VoidCallback onMinus,
    required VoidCallback onPlus,
  }) => Row(
    children: [
      SizedBox(width: 62, child: Text(label)),
      IconButton(
        onPressed: onMinus,
        icon: const Icon(Icons.remove_circle_outline),
      ),
      Expanded(
        child: Text(_formatDuration(value), textAlign: TextAlign.center),
      ),
      IconButton(onPressed: onPlus, icon: const Icon(Icons.add_circle_outline)),
    ],
  );
}

class _PreviewPanel extends StatelessWidget {
  const _PreviewPanel({
    required this.asset,
    required this.initialPositionMs,
    required this.timelineMode,
  });

  final MediaAsset? asset;
  final int initialPositionMs;
  final bool timelineMode;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      color: const Color(0xFF05080C),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFF293744)),
    ),
    child: AspectRatio(
      aspectRatio: 16 / 9,
      child: asset == null
          ? const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.play_circle_outline_rounded,
                    size: 42,
                    color: veloraGold,
                  ),
                  SizedBox(height: 7),
                  Text('استورد وسيطًا لعرض معاينة المصدر'),
                ],
              ),
            )
          : asset!.kind == MediaKind.audio
          ? const Center(
              child: Icon(
                Icons.graphic_eq_rounded,
                size: 48,
                color: veloraGold,
              ),
            )
          : asset!.kind == MediaKind.unsupported
          ? const Center(child: Text('صيغة الملف غير مدعومة للمعاينة.'))
          : defaultTargetPlatform == TargetPlatform.android
          ? Stack(
              fit: StackFit.expand,
              children: [
                AndroidView(
                  key: ValueKey(
                    timelineMode ? 'velora-timeline-preview' : asset!.uri,
                  ),
                  viewType: 'velora/preview',
                  creationParams: {
                    'uri': asset!.uri,
                    'kind': asset!.kind.name,
                    'positionMs': initialPositionMs,
                    'imageDurationMs': asset!.durationMs > 0
                        ? asset!.durationMs
                        : 5000,
                    'timelineMode': timelineMode,
                  },
                  creationParamsCodec: const StandardMessageCodec(),
                ),
                Positioned(
                  left: 8,
                  bottom: 7,
                  child: DecoratedBox(
                    decoration: const BoxDecoration(
                      color: Color(0xAA000000),
                      borderRadius: BorderRadius.all(Radius.circular(6)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 4,
                      ),
                      child: Text(
                        timelineMode ? 'معاينة المخطط' : 'معاينة المصدر فقط',
                        style: const TextStyle(fontSize: 10),
                      ),
                    ),
                  ),
                ),
              ],
            )
          : const Center(
              child: Text('معاينة الوسائط الأصلية متاحة حاليًا على Android.'),
            ),
    ),
  );
}

String _formatDuration(int milliseconds) {
  final totalSeconds = (milliseconds / 1000).floor();
  final minutes = totalSeconds ~/ 60;
  final seconds = totalSeconds % 60;
  final centiseconds = (milliseconds % 1000) ~/ 10;
  return '${minutes.toString().padLeft(2, '0')}:'
      '${seconds.toString().padLeft(2, '0')}.'
      '${centiseconds.toString().padLeft(2, '0')}';
}
