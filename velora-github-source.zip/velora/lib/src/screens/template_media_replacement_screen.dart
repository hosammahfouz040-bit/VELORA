import 'package:flutter/material.dart';

import '../models/project.dart';
import '../models/project_templates.dart';
import '../services/native_bridge.dart';

class TemplateMediaReplacementScreen extends StatefulWidget {
  const TemplateMediaReplacementScreen({
    super.key,
    required this.template,
  });

  final ProjectTemplate template;

  @override
  State<TemplateMediaReplacementScreen> createState() =>
      _TemplateMediaReplacementScreenState();
}

class _TemplateMediaReplacementScreenState
    extends State<TemplateMediaReplacementScreen> {
  final Map<String, MediaAsset> _assignments = {};
  late final TextEditingController _nameController;
  String? _busySlotId;
  bool _creating = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(
      text: 'نسخة من ${widget.template.name}',
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _chooseMedia(TemplateMediaSlot slot) async {
    if (_busySlotId != null || _creating) return;
    setState(() {
      _busySlotId = slot.id;
      _error = null;
    });
    try {
      final picked = await NativeBridge.pickMedia();
      if (!mounted) return;
      final candidates = picked
          .where((asset) => slot.allowedKinds.contains(asset.kind))
          .toList(growable: false);
      if (candidates.isEmpty) {
        setState(() {
          _error = 'لم يُحدد ملف مناسب لـ«${slot.label}». اختر صورة أو فيديو مدعومًا.';
        });
        return;
      }
      final chosen = candidates.length == 1
          ? candidates.single
          : await _chooseOne(candidates, slot);
      if (chosen == null || !mounted) return;
      setState(() => _assignments[slot.id] = chosen);
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر اختيار وسيط القالب: $error');
    } finally {
      if (mounted) setState(() => _busySlotId = null);
    }
  }

  Future<MediaAsset?> _chooseOne(
    List<MediaAsset> candidates,
    TemplateMediaSlot slot,
  ) => showDialog<MediaAsset>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text('اختر وسيطًا لـ«${slot.label}»'),
      content: SizedBox(
        width: 420,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: candidates.length,
          itemBuilder: (context, index) {
            final candidate = candidates[index];
            return ListTile(
              leading: Icon(candidate.kind == MediaKind.image
                  ? Icons.image_outlined
                  : candidate.kind == MediaKind.audio
                      ? Icons.audio_file_outlined
                      : Icons.movie_outlined),
              title: Text(candidate.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('${_kindLabel(candidate.kind)} · ${_formatDuration(candidate.durationMs)}'),
              onTap: () => Navigator.of(dialogContext).pop(candidate),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('إلغاء'),
        ),
      ],
    ),
  );

  Future<void> _createProject() async {
    if (_creating || _busySlotId != null) return;
    final missing = widget.template.mediaSlots
        .where((slot) => slot.requiresSelection && !_assignments.containsKey(slot.id))
        .toList(growable: false);
    if (missing.isNotEmpty) {
      setState(() => _error = 'أكمل اختيار الوسائط المطلوبة أولًا.');
      return;
    }

    setState(() {
      _creating = true;
      _error = null;
    });
    try {
      final result = instantiateProjectTemplate(
        template: widget.template,
        projectName: _nameController.text,
        assignments: _assignments,
      );
      if (result.adjustments.isNotEmpty) {
        final proceed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('مواءمة آمنة للمدد'),
            content: SizedBox(
              width: 460,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('تختلف بعض الوسائط عن مدد القالب؛ ستُطبّق هذه التعديلات قبل إنشاء النسخة:'),
                    const SizedBox(height: 12),
                    for (final item in result.adjustments)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text('• $item'),
                      ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('رجوع'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('إنشاء بالمدد الآمنة'),
              ),
            ],
          ),
        );
        if (proceed != true || !mounted) return;
      }
      if (!mounted) return;
      Navigator.of(context).pop(result.project);
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذّر إنشاء نسخة القالب: $error');
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final allRequiredSelected = widget.template.mediaSlots
        .where((slot) => slot.requiresSelection)
        .every((slot) => _assignments.containsKey(slot.id));
    return Scaffold(
      appBar: AppBar(title: Text(widget.template.name)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.template.description),
                  const SizedBox(height: 14),
                  TextField(
                    key: const ValueKey('template-project-name'),
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'اسم المشروع الجديد',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final slot in widget.template.mediaSlots)
            _buildSlotCard(slot),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Card(
              color: const Color(0xFF522D30),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!),
              ),
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              key: const ValueKey('create-project-from-template'),
              onPressed: allRequiredSelected && _busySlotId == null && !_creating
                  ? _createProject
                  : null,
              icon: _creating
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.auto_awesome_rounded),
              label: Text(_creating ? 'جارٍ تجهيز النسخة…' : 'إنشاء مشروع جديد من القالب'),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'سيُحفظ المشروع كنسخة مستقلة؛ لن يتغير القالب أو المشروع الذي أُنشئ منه.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFFAFBAC5), fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildSlotCard(TemplateMediaSlot slot) {
    final selected = _assignments[slot.id];
    final isBusy = _busySlotId == slot.id;
    final isShort = selected != null &&
        selected.kind == MediaKind.video &&
        selected.durationMs < slot.requiredSourceEndMs;
    final allowed = slot.allowedKinds.map(_kindLabel).join(' أو ');
    return Card(
      key: ValueKey('template-slot-${slot.id}'),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.perm_media_outlined, color: Color(0xFFFFD166)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    slot.label,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                if (slot.requiresSelection)
                  const Text('مطلوب', style: TextStyle(color: Color(0xFFFFD166))),
              ],
            ),
            const SizedBox(height: 6),
            Text('الأنواع المقبولة: $allowed'),
            if (slot.requiredSourceEndMs > 0)
              Text('نهاية المصدر المطلوبة: ${_formatDuration(slot.requiredSourceEndMs)}'),
            if (selected != null) ...[
              const SizedBox(height: 8),
              Text('المحدد: ${selected.name} · ${_formatDuration(selected.durationMs)}'),
            ],
            if (isShort)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'الملف أقصر من نطاق القالب؛ ستُقصّ اللقطة وتُراجع الانتقالات قبل الإنشاء.',
                  style: TextStyle(color: Color(0xFFFFD166)),
                ),
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              key: ValueKey('choose-template-media-${slot.id}'),
              onPressed: _busySlotId != null || _creating ? null : () => _chooseMedia(slot),
              icon: isBusy
                  ? const SizedBox.square(
                      dimension: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.folder_open_outlined),
              label: Text(selected == null ? 'اختيار وسيط' : 'استبدال الوسيط'),
            ),
          ],
        ),
      ),
    );
  }
}

String _kindLabel(MediaKind kind) => switch (kind) {
  MediaKind.video => 'فيديو',
  MediaKind.image => 'صورة',
  MediaKind.audio => 'صوت',
  MediaKind.unsupported => 'غير مدعوم',
};

String _formatDuration(int milliseconds) {
  final safeMs = milliseconds.clamp(0, 1 << 53).toInt();
  final totalSeconds = safeMs ~/ 1000;
  final minutes = totalSeconds ~/ 60;
  final seconds = totalSeconds % 60;
  final millis = safeMs % 1000;
  return '${minutes.toString().padLeft(2, '0')}:'
      '${seconds.toString().padLeft(2, '0')}.'
      '${millis.toString().padLeft(3, '0')}';
}
