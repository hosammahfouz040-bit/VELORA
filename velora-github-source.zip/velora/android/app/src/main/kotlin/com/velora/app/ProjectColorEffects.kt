package com.velora.app

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbMatrix

/** Neutral-by-default project color adjustments, bounded to the Media3 API ranges. */
internal data class ProjectColorSettings(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
) {
    init {
        require(brightness.isFinite() && brightness in -1f..1f) {
            "Brightness must be finite and between -1 and 1"
        }
        require(contrast.isFinite() && contrast in -1f..1f) {
            "Contrast must be finite and between -1 and 1"
        }
        require(saturation.isFinite() && saturation in -100f..100f) {
            "Saturation must be finite and between -100 and 100"
        }
        require(warmth.isFinite() && warmth in -1f..1f) {
            "Warmth must be finite and between -1 and 1"
        }
    }

    companion object {
        fun fromMap(raw: Any?): ProjectColorSettings {
            val map = raw as? Map<*, *> ?: return ProjectColorSettings()
            return ProjectColorSettings(
                brightness = boundedFloat(map["brightness"], -1f, 1f),
                contrast = boundedFloat(map["contrast"], -1f, 1f),
                saturation = boundedFloat(map["saturation"], -100f, 100f),
                warmth = boundedFloat(map["warmth"], -1f, 1f),
            )
        }

        /** Mirrors TimelineClip.effectiveColorSettings: absent overrides inherit the project. */
        fun effectiveForClip(
            clip: Map<*, *>,
            projectSettings: ProjectColorSettings,
        ): ProjectColorSettings {
            val override = clip["colorSettingsOverride"] as? Map<*, *> ?: return projectSettings
            return fromMap(override)
        }

        private fun boundedFloat(raw: Any?, minimum: Float, maximum: Float): Float {
            val value = (raw as? Number)?.toDouble() ?: return 0f
            if (!value.isFinite()) return 0f
            return value.coerceIn(minimum.toDouble(), maximum.toDouble()).toFloat()
        }
    }
}

/** Builds reusable Media3 video effects; no effect is emitted for a neutral setting. */
@UnstableApi
internal object ProjectColorEffects {
    fun create(settings: ProjectColorSettings): List<Effect> = buildList {
        if (settings.brightness != 0f) add(HdrSafeBrightness(settings.brightness))
        if (settings.contrast != 0f) add(Contrast(settings.contrast))
        if (settings.warmth != 0f) {
            val scales = projectWarmthRgbScales(settings.warmth)
            add(
                RgbAdjustment.Builder()
                    .setRedScale(scales.first)
                    .setGreenScale(scales.second)
                    .setBlueScale(scales.third)
                    .build(),
            )
        }
        if (settings.saturation != 0f) add(HdrSafeSaturation(settings.saturation))
    }

    /** Media3 Brightness rejects HDR. Keep that stage neutral for HDR rather than failing render. */
    @UnstableApi
    private class HdrSafeBrightness(value: Float) : RgbMatrix {
        private val sdrBrightness = Brightness(value)
        private val hdrIdentity = RgbAdjustment.Builder().build()

        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray =
            if (useHdr) {
                hdrIdentity.getMatrix(presentationTimeUs, true)
            } else {
                sdrBrightness.getMatrix(presentationTimeUs, false)
            }

        override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean = false
    }

    /** Media3 HslAdjustment also rejects HDR, so keep saturation neutral for that input. */
    @UnstableApi
    private class HdrSafeSaturation(value: Float) : GlEffect {
        private val sdrSaturation =
            HslAdjustment.Builder().adjustSaturation(value).build()
        private val hdrIdentity = RgbAdjustment.Builder().build()

        override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
            if (useHdr) {
                hdrIdentity.toGlShaderProgram(context, true)
            } else {
                sdrSaturation.toGlShaderProgram(context, false)
            }
    }
}

/** Subtle red/blue channel balance shared by preview and Transformer export. */
internal fun projectWarmthRgbScales(warmth: Float): Triple<Float, Float, Float> {
    val bounded = if (warmth.isFinite()) warmth.coerceIn(-1f, 1f) else 0f
    return Triple(1f + 0.16f * bounded, 1f, 1f - 0.16f * bounded)
}
