import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';

void main() {
  const ramp = <SpeedRampPoint>[
    SpeedRampPoint(timeMs: 0, speed: 1),
    SpeedRampPoint(timeMs: 5000, speed: 2),
  ];

  test('absolute sampled clock keeps split durations additive', () {
    const sourceStartMs = 0;
    const sourceEndMs = 5000;
    final originalDurationMs = speedAdjustedDurationMs(
      sourceStartMs,
      sourceEndMs,
      ramp,
    );

    // Include positions on and off the absolute 50 ms sample grid.
    for (final splitMs in [500, 501, 1250, 1251, 2500, 4999]) {
      final firstDurationMs = speedAdjustedDurationMs(
        sourceStartMs,
        splitMs,
        ramp,
      );
      final secondDurationMs = speedAdjustedDurationMs(
        splitMs,
        sourceEndMs,
        ramp,
      );
      expect(
        firstDurationMs + secondDurationMs,
        originalDurationMs,
        reason: 'split at source time $splitMs ms',
      );
    }

    // The old per-fragment rounding produced 480 + 2,999 = 3,479 ms here.
    // The cumulative clock keeps the first part at 480 ms and assigns the
    // remaining 2,998 ms to the second part, matching the 3,478 ms original.
    expect(originalDurationMs, 3478);
    expect(speedAdjustedDurationMs(0, 501, ramp), 480);
    expect(speedAdjustedDurationMs(501, 5000, ramp), 2998);
  });

  test('forward and inverse mappings share the cumulative clock at boundaries and ramp points', () {
    const points = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 1),
      SpeedRampPoint(timeMs: 501, speed: 1.1),
      SpeedRampPoint(timeMs: 2000, speed: 1.5),
      SpeedRampPoint(timeMs: 5000, speed: 2),
    ];
    final durationMs = speedAdjustedDurationMs(0, 5000, points);

    expect(sourceOffsetToOutputMs(0, 0, points), 0);
    expect(outputOffsetToSourceMs(0, 0, 5000, points), 0);
    expect(sourceOffsetToOutputMs(5000, 0, points), durationMs);
    expect(outputOffsetToSourceMs(durationMs, 0, 5000, points), 5000);

    for (final sourceOffsetMs in [50, 500, 501, 502, 2000, 4999]) {
      final outputOffsetMs = sourceOffsetToOutputMs(
        sourceOffsetMs,
        0,
        points,
      );
      final restoredSourceOffsetMs = outputOffsetToSourceMs(
        outputOffsetMs,
        0,
        5000,
        points,
      );
      expect(
        sourceOffsetToOutputMs(restoredSourceOffsetMs, 0, points),
        outputOffsetMs,
        reason: 'round trip at source time $sourceOffsetMs ms',
      );
      expect(
        restoredSourceOffsetMs,
        closeTo(sourceOffsetMs, 8),
        reason: 'source quantization at $sourceOffsetMs ms',
      );
    }
  });

  test('constant rates and unaligned variable ramps share native golden values', () {
    const unalignedPoints = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 0.5),
      SpeedRampPoint(timeMs: 175, speed: 1.5),
      SpeedRampPoint(timeMs: 501, speed: 2),
      SpeedRampPoint(timeMs: 1200, speed: 0.5),
      SpeedRampPoint(timeMs: 4000, speed: 8),
    ];

    expect(sourceOffsetToOutputMs(1000, 123, const []), 1000);
    expect(sourceOffsetToOutputMs(1000, 123, const [SpeedRampPoint(timeMs: 0, speed: 2)]), 500);
    expect(sourceOffsetToOutputMs(1000, 123, const [SpeedRampPoint(timeMs: 0, speed: 0.1)]), 10000);
    expect(sourceOffsetToOutputMs(1000, 123, const [SpeedRampPoint(timeMs: 0, speed: 8)]), 125);

    // These shared vectors also appear in ProjectClipMotionTest.kt. Both the
    // trim start (123 ms) and ramp knots (175/501/1200 ms) are off the 50 ms grid.
    expect(speedAdjustedDurationMs(123, 3010, unalignedPoints), 1778);
    expect(sourceOffsetToOutputMs(378, 123, unalignedPoints), 235);
    expect(sourceOffsetToOutputMs(1000, 123, unalignedPoints), 725);
    expect(outputOffsetToSourceMs(500, 123, 3010, unalignedPoints), 792);
    expect(outputOffsetToSourceMs(1000, 123, 3010, unalignedPoints), 1161);
    expect(sourceOffsetToOutputMs(1161, 123, unalignedPoints), 999);
    expect(outputOffsetToSourceMs(1778, 123, 3010, unalignedPoints), 2887);
  });

  test('rates through 8x match durations and higher rates clamp to 8x', () {
    final expected = <double, int>{
      0.1: 10_000,
      1: 1_000,
      8: 125,
      16: 125,
      50: 125,
      100: 125,
    };
    for (final entry in expected.entries) {
      final points = [SpeedRampPoint(timeMs: 123, speed: entry.key)];
      final duration = speedAdjustedDurationMs(123, 1123, points);
      expect(duration, entry.value, reason: 'requested speed ${entry.key}×');
      expect(duration, greaterThan(0));

      final halfOutput = sourceOffsetToOutputMs(500, 123, points);
      final sourceOffset = outputOffsetToSourceMs(halfOutput, 123, 1123, points);
      expect(
        sourceOffsetToOutputMs(sourceOffset, 123, points),
        halfOutput,
        reason: 'inverse at speed ${entry.key}×',
      );
    }
  });

  test('over-limit variable ramps clamp and preserve off-grid timing', () {
    const points = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 0.1),
      SpeedRampPoint(timeMs: 175, speed: 16),
      SpeedRampPoint(timeMs: 501, speed: 50),
      SpeedRampPoint(timeMs: 1200, speed: 100),
      SpeedRampPoint(timeMs: 4000, speed: 100),
    ];
    final safePoints = speedRampPointsForSourceDuration(points, 2887);
    final whole = speedAdjustedDurationMs(123, 3010, points);
    final first = sourceOffsetToOutputMs(501, 123, safePoints);
    final second = sourceOffsetToOutputMs(2386, 624, safePoints);

    expect(safePoints.every((point) => point.speed <= 8), isTrue);
    expect(whole, greaterThan(0));
    expect(first + second, whole);
    expect(outputOffsetToSourceMs(whole, 123, 3010, safePoints), 2887);
    expect(speedAtSourceTime(safePoints, 501).isFinite, isTrue);
  });

  test('invalid values clamp safely and short positive clips retain a millisecond', () {
    expect(
      SpeedRampPoint.fromMap({'timeMs': 0, 'speed': 1000}).speed,
      8,
    );
    expect(
      SpeedRampPoint.fromMap({'timeMs': 0, 'speed': double.infinity}).speed,
      1,
    );
    expect(
      SpeedRampPoint.fromMap({'timeMs': 0, 'speed': double.nan}).speed,
      1,
    );
    expect(
      SpeedRampPoint.fromMap({'timeMs': 0, 'speed': -5}).speed,
      0.1,
    );

    expect(
      speedAdjustedDurationMs(
        40,
        50,
        const [SpeedRampPoint(timeMs: 40, speed: 100)],
      ),
      1,
    );
    expect(
      speedAdjustedDurationMs(
        40,
        41,
        const [SpeedRampPoint(timeMs: 40, speed: 100)],
      ),
      1,
    );
    expect(speedAdjustedDurationMs(40, 40, const []), 0);
  });

  test('a non-zero unaligned source start uses the same absolute clock', () {
    const points = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 1),
      SpeedRampPoint(timeMs: 5000, speed: 2),
    ];
    final wholeDurationMs = speedAdjustedDurationMs(0, 5000, points);
    final prefixDurationMs = speedAdjustedDurationMs(0, 501, points);
    final suffixDurationMs = sourceOffsetToOutputMs(4499, 501, points);

    expect(prefixDurationMs + suffixDurationMs, wholeDurationMs);
    expect(suffixDurationMs, 2998);
    expect(outputOffsetToSourceMs(suffixDurationMs, 501, 5000, points), 4499);
  });
}
