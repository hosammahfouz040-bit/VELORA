package com.velora.app

import androidx.media3.common.MediaItem
import androidx.media3.common.util.SpeedProviderUtil
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

@UnstableApi
class ProjectClipMotionTest {
    private val rampRows = listOf(
        mapOf("timeMs" to 0L, "speed" to 0.5),
        mapOf("timeMs" to 175L, "speed" to 1.5),
        mapOf("timeMs" to 501L, "speed" to 2.0),
        mapOf("timeMs" to 1_200L, "speed" to 0.5),
        mapOf("timeMs" to 4_000L, "speed" to 8.0),
    )
    private val rampPoints = rampRows.mapNotNull(::speedPointFromMap)

    @Test
    fun constantSpeedAndSupportedRangeMatchTheProjectClock() {
        assertEquals(1_000L, sourceOffsetToOutputMs(1_000L, 123L, emptyList()))
        assertEquals(
            500L,
            sourceOffsetToOutputMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 2.0))),
        )
        assertEquals(
            10_000L,
            sourceOffsetToOutputMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 0.1))),
        )
        assertEquals(
            125L,
            sourceOffsetToOutputMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 8.0))),
        )
        assertEquals(500L, roundedMedia3DurationMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 2.0))))
        assertEquals(10_000L, roundedMedia3DurationMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 0.1))))
        assertEquals(125L, roundedMedia3DurationMs(1_000L, 123L, listOf(SpeedRampPoint(0L, 8.0))))
    }

    @Test
    fun ratesAboveVerifiedLimitClampToEightAndRemainPositive() {
        val expectedDurations = linkedMapOf(
            0.1 to 10_000L,
            1.0 to 1_000L,
            8.0 to 125L,
            16.0 to 125L,
            50.0 to 125L,
            100.0 to 125L,
        )
        for ((speed, expectedMs) in expectedDurations) {
            val timing = ProjectClipMotion.timingFromMap(
                mapOf(
                    "trimStartMs" to 123L,
                    "trimEndMs" to 1_123L,
                    "speedRampPoints" to listOf(mapOf("timeMs" to 123L, "speed" to speed)),
                ),
            )
            assertEquals("speed=$speed", expectedMs, timing.outputDurationMs)
            assertEquals(expectedMs, roundedMedia3DurationMs(1_000L, 123L, timing.speedRampPoints))
            assertEquals(false, timing.outputDurationMs <= 0L)

            val halfwayOutput = sourceOffsetToOutputMs(500L, 123L, timing.speedRampPoints)
            val restoredSource = outputOffsetToSourceMs(
                halfwayOutput, 123L, 1_123L, timing.speedRampPoints,
            )
            assertEquals(
                halfwayOutput,
                sourceOffsetToOutputMs(restoredSource, 123L, timing.speedRampPoints),
            )
        }
    }

    @Test
    fun overLimitUnalignedRampClampsAndKeepsSplitAndInverseTimingFinite() {
        val timing = ProjectClipMotion.timingFromMap(
            mapOf(
                "trimStartMs" to 123L,
                "trimEndMs" to 3_010L,
                "speedRampPoints" to listOf(
                    mapOf("timeMs" to 0L, "speed" to 0.1),
                    mapOf("timeMs" to 175L, "speed" to 16.0),
                    mapOf("timeMs" to 501L, "speed" to 50.0),
                    mapOf("timeMs" to 1_200L, "speed" to 100.0),
                    mapOf("timeMs" to 4_000L, "speed" to 16.0),
                ),
            ),
        )
        val whole = timing.outputDurationMs
        val first = sourceOffsetToOutputMs(501L, 123L, timing.speedRampPoints)
        val second = sourceOffsetToOutputMs(2_386L, 624L, timing.speedRampPoints)
        val restored = outputOffsetToSourceMs(whole, 123L, 3_010L, timing.speedRampPoints)

        assertTrue(whole > 0L)
        assertTrue(first >= 0L && second >= 0L)
        assertEquals(whole, first + second)
        assertEquals(2_887L, restored)
        assertTrue(timing.speedProvider.getSpeed(0L).isFinite())
        assertTrue(timing.speedProvider.getSpeed(100_000L).isFinite())
    }

    @Test
    fun invalidSpeedsClampAndShortSourceRangesCannotRoundToZero() {
        val overLimit = ProjectClipMotion.timingFromMap(
            mapOf(
                "trimStartMs" to 0L,
                "trimEndMs" to 1_000L,
                "speedRampPoints" to listOf(mapOf("timeMs" to 0L, "speed" to 1_000.0)),
            ),
        )
        val notFinite = ProjectClipMotion.timingFromMap(
            mapOf(
                "trimStartMs" to 0L,
                "trimEndMs" to 1_000L,
                "speedRampPoints" to listOf(mapOf("timeMs" to 0L, "speed" to Double.NaN)),
            ),
        )
        val short = ProjectClipMotion.timingFromMap(
            mapOf(
                "trimStartMs" to 40L,
                "trimEndMs" to 50L,
                "speedRampPoints" to listOf(mapOf("timeMs" to 40L, "speed" to 100.0)),
            ),
        )

        assertEquals(125L, overLimit.outputDurationMs)
        assertEquals(1.0, notFinite.speedRampPoints.single().speed, 0.0)
        assertEquals(1L, short.outputDurationMs)
        assertEquals(8.0, short.speedRampPoints.single().speed, 0.0)
        assertTrue(short.outputDurationMs > 0L)
    }

    @Test
    fun unalignedRampPointsAndTrimUseTheSameAbsoluteCumulativeClockAsDart() {
        val timing = ProjectClipMotion.timingFromMap(
            mapOf(
                "id" to "ramped",
                "trimStartMs" to 123L,
                "trimEndMs" to 3_010L,
                "speedRampPoints" to rampRows,
            ),
        )

        // Shared golden values are also asserted by test/clip_motion_test.dart.
        assertEquals(1_778L, timing.outputDurationMs)
        assertEquals(235L, sourceOffsetToOutputMs(378L, 123L, rampPoints))
        assertEquals(725L, sourceOffsetToOutputMs(1_000L, 123L, rampPoints))
        assertEquals(792L, outputOffsetToSourceMs(500L, 123L, 3_010L, rampPoints))
        assertEquals(1_161L, outputOffsetToSourceMs(1_000L, 123L, 3_010L, rampPoints))
        assertEquals(999L, sourceOffsetToOutputMs(1_161L, 123L, rampPoints))
        assertEquals(2_887L, outputOffsetToSourceMs(1_778L, 123L, 3_010L, rampPoints))

        val media3DurationUs = SpeedProviderUtil.getDurationAfterSpeedProviderApplied(
            timing.speedProvider,
            timing.sourceDurationMs * 1_000L,
        )
        val media3RoundedDurationMs = (media3DurationUs + 500L) / 1_000L
        assertEquals(timing.outputDurationMs, media3RoundedDurationMs)
    }

    @Test
    fun splittingAtAnOffGridSourceTimeDoesNotChangeTotalDuration() {
        val points = listOf(
            SpeedRampPoint(0L, 1.0),
            SpeedRampPoint(5_000L, 2.0),
        )
        val whole = sourceOffsetToOutputMs(5_000L, 0L, points)
        val first = sourceOffsetToOutputMs(501L, 0L, points)
        val second = sourceOffsetToOutputMs(4_499L, 501L, points)

        assertEquals(3_478L, whole)
        assertEquals(480L, first)
        assertEquals(2_998L, second)
        assertEquals(whole, first + second)
    }

    @Test
    fun duplicateTransformKeyframeTimesUseTheLastSavedValue() {
        val value = evaluateTransformKeyframes(
            listOf(
                TransformKeyframe(1_000L, 0f, 0f, 1f, 0f, 1f, smooth = false),
                TransformKeyframe(2_000L, 0.2f, 0f, 1f, 0f, 1f, smooth = false),
                TransformKeyframe(2_000L, 0.8f, 0f, 1f, 0f, 1f, smooth = false),
                TransformKeyframe(3_000L, 1f, 0f, 1f, 0f, 1f, smooth = false),
            ),
            2_000L,
        )
        assertEquals(0.8f, value.x, 0.0001f)
    }

    @Test
    fun aSingleClipWithoutTransformKeyframesKeepsTheLegacySequentialPath() {
        val clip = mapOf<String, Any?>(
            "id" to "single",
            "trimStartMs" to 0L,
            "trimEndMs" to 1_000L,
        )
        val plan = ProjectTransitionPlan.create(
            visualClips = listOf(clip),
            visualItems = listOf(EditedMediaItem.Builder(MediaItem.EMPTY).build()),
            transitionRows = emptyList(),
            adjustedClipDurationsMs = listOf(1_000L),
            clockItemFactory = { durationMs ->
                EditedMediaItem.Builder(MediaItem.EMPTY)
                    .setDurationUs(durationMs * 1_000L)
                    .build()
            },
        )
        assertEquals(null, plan)
    }

    @Test
    fun aSingleClipWithTransformKeyframesCreatesAPlanWithoutTransitions() {
        val clip = mapOf<String, Any?>(
            "id" to "single-transform",
            "trimStartMs" to 1_000L,
            "trimEndMs" to 5_000L,
            "speedRampPoints" to listOf(
                mapOf("timeMs" to 1_000L, "speed" to 1.0),
                mapOf("timeMs" to 5_000L, "speed" to 2.0),
            ),
            "transformKeyframes" to listOf(
                mapOf(
                    "timeMs" to 1_000L,
                    "positionX" to -0.5,
                    "positionY" to 0.0,
                    "scale" to 1.0,
                    "rotationDegrees" to 0.0,
                    "opacity" to 1.0,
                    "interpolation" to "linear",
                ),
                mapOf(
                    "timeMs" to 5_000L,
                    "positionX" to 0.5,
                    "positionY" to 0.75,
                    "scale" to 3.0,
                    "rotationDegrees" to 90.0,
                    "opacity" to 0.5,
                    "interpolation" to "smooth",
                ),
            ),
        )
        val timing = ProjectClipMotion.timingFromMap(clip)
        val plan = ProjectTransitionPlan.create(
            visualClips = listOf(clip),
            visualItems = listOf(
                EditedMediaItem.Builder(MediaItem.EMPTY)
                    .setDurationUs(timing.sourceDurationMs * 1_000L)
                    .setSpeed(timing.speedProvider)
                    .build(),
            ),
            transitionRows = emptyList(),
            adjustedClipDurationsMs = listOf(timing.outputDurationMs),
            clockItemFactory = { durationMs ->
                EditedMediaItem.Builder(MediaItem.EMPTY)
                    .setDurationUs(durationMs * 1_000L)
                    .build()
            },
        )

        assertEquals(1, plan?.clipWindows?.size)
        assertEquals(timing.outputDurationMs, plan?.totalDurationMs)
        assertEquals(false, plan?.hasTransitions)
        // A one-input plan can produce the exact compositor settings used by both
        // CompositionPlayer preview and Transformer export.
        val outputTimeMs = 1_000L
        plan!!.getOverlaySettings(inputId = 0, presentationTimeUs = outputTimeMs * 1_000L)

        val sourceTimeMs = timing.trimStartMs + timing.sourceOffsetAtOutputMs(outputTimeMs)
        val progress = (sourceTimeMs - 1_000L).toFloat() / 4_000f
        val value = evaluateTransformKeyframes(timing.transformKeyframes, sourceTimeMs)
        assertEquals(-0.5f + progress, value.x, 0.0001f)
        assertEquals(0.75f * progress, value.y, 0.0001f)
        assertEquals(1f + 2f * progress, value.scale, 0.0001f)
        assertEquals(90f * progress, value.rotationDegrees, 0.0001f)
        assertEquals(1f - 0.5f * progress, value.opacity, 0.0001f)
    }

    @Test
    fun speedProviderAnnouncesAbsoluteGridAndUnalignedRampBoundaries() {
        val provider = makeSpeedProvider(123L, 2_887L, rampPoints)

        // Absolute 150 ms grid boundary is 27 ms into the trimmed clip;
        // the 175 ms ramp point is then the next change, 52 ms into the clip.
        assertEquals(27_000L, provider.getNextSpeedChangeTimeUs(0L))
        assertEquals(52_000L, provider.getNextSpeedChangeTimeUs(27_000L))
        assertEquals(77_000L, provider.getNextSpeedChangeTimeUs(52_000L))
        // The trimmed clip starts at 123 ms, so its first partial cell inherits
        // the rate sampled at the preceding absolute grid start (100 ms).
        assertEquals(1.0714285f, provider.getSpeed(0L), 0.00001f)
        assertEquals(1.3571428f, provider.getSpeed(27_000L), 0.00001f)
    }

    @Test
    fun speedMappedProjectTimeRemainsAlignedAcrossAClipTransition() {
        val first = mapOf<String, Any?>(
            "id" to "ramped",
            "trimStartMs" to 123L,
            "trimEndMs" to 3_010L,
            "speedRampPoints" to rampRows,
        )
        val second = mapOf<String, Any?>(
            "id" to "double-speed",
            "trimStartMs" to 40L,
            "trimEndMs" to 1_040L,
            "speedRampPoints" to listOf(mapOf("timeMs" to 40L, "speed" to 2.0)),
        )
        val visualItems = listOf(
            EditedMediaItem.Builder(MediaItem.EMPTY).build(),
            EditedMediaItem.Builder(MediaItem.EMPTY).build(),
        )
        val transition = mapOf<String, Any?>(
            "id" to "ramped-to-double",
            "fromClipId" to "ramped",
            "toClipId" to "double-speed",
            "type" to "dissolve",
            "durationMs" to 100L,
        )
        val transitionPlan = ProjectTransitionPlan.create(
            visualClips = listOf(first, second),
            visualItems = visualItems,
            transitionRows = listOf(transition),
            adjustedClipDurationsMs = listOf(1_778L, 500L),
            clockItemFactory = { durationMs ->
                EditedMediaItem.Builder(MediaItem.EMPTY)
                    .setDurationUs(durationMs * 1_000L)
                    .build()
            },
        )
        val timings = listOf(first, second).map { ProjectClipMotion.timingFromMap(it) }

        assertEquals(1_778L, timings[0].outputDurationMs)
        assertEquals(500L, timings[1].outputDurationMs)
        assertEquals(
            1_753L,
            ProjectClipMotion.mapProjectTimeToOutputMs(2_987L, timings, transitionPlan),
        )
    }

    private fun roundedMedia3DurationMs(
        sourceDurationMs: Long,
        sourceStartMs: Long,
        points: List<SpeedRampPoint>,
    ): Long {
        val durationUs = SpeedProviderUtil.getDurationAfterSpeedProviderApplied(
            makeSpeedProvider(sourceStartMs, sourceDurationMs, points),
            sourceDurationMs * 1_000L,
        )
        return (durationUs + 500L) / 1_000L
    }
}
