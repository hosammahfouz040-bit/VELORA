package com.velora.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

class VeloraPreviewFactory : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
        val parameters = args as? Map<*, *> ?: emptyMap<Any, Any>()
        val uri = parameters["uri"]?.toString().orEmpty()
        val kind = parameters["kind"]?.toString().orEmpty()
        val positionMs = (parameters["positionMs"] as? Number)?.toLong() ?: 0L
        val timelineMode = parameters["timelineMode"] as? Boolean ?: false
        val imageDurationMs = (parameters["imageDurationMs"] as? Number)?.toLong() ?: 5_000L
        return VeloraPreviewView(context, uri, kind, positionMs, timelineMode, imageDurationMs)
    }
}

/** One player is owned by the active platform view and controlled by Flutter. */
internal object VeloraPreviewPlayerRegistry {
    private data class Configuration(
        val items: List<MediaItem>,
        val durationsMs: List<Long>,
        val startIndex: Int,
        val startPositionMs: Long,
        val playWhenReady: Boolean,
    )

    private var activePlayer: ExoPlayer? = null
    private var pendingConfiguration: Configuration? = null
    private var lastError: String? = null

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            lastError = error.message ?: error.errorCodeName
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            lastError = null
        }
    }

    fun attach(
        player: ExoPlayer,
        fallbackItem: MediaItem,
        fallbackPositionMs: Long,
        fallbackDurationMs: Long,
    ) {
        activePlayer?.takeIf { it !== player }?.removeListener(listener)
        activePlayer = player
        player.addListener(listener)
        val configuration = pendingConfiguration ?: Configuration(
            items = listOf(fallbackItem),
            durationsMs = listOf(fallbackDurationMs),
            startIndex = 0,
            startPositionMs = fallbackPositionMs,
            playWhenReady = false,
        )
        try {
            apply(player, configuration)
        } catch (error: Exception) {
            lastError = error.message ?: "تعذّر إعداد معاينة الوسائط"
            player.clearMediaItems()
        }
    }

    fun configureTimeline(
        items: List<MediaItem>,
        durationsMs: List<Long>,
        startIndex: Int,
        startPositionMs: Long,
        playWhenReady: Boolean,
    ) {
        require(items.isNotEmpty()) { "The visual timeline is empty" }
        require(items.size == durationsMs.size) { "Timeline item metadata is inconsistent" }
        val configuration = Configuration(
            items = items,
            durationsMs = durationsMs,
            startIndex = startIndex.coerceIn(0, items.lastIndex),
            startPositionMs = startPositionMs.coerceAtLeast(0L),
            playWhenReady = playWhenReady,
        )
        pendingConfiguration = configuration
        lastError = null
        activePlayer?.let { apply(it, configuration) }
    }

    fun setSource(item: MediaItem, positionMs: Long, durationMs: Long) {
        val configuration = Configuration(
            items = listOf(item),
            durationsMs = listOf(durationMs),
            startIndex = 0,
            startPositionMs = positionMs.coerceAtLeast(0L),
            playWhenReady = false,
        )
        pendingConfiguration = configuration
        lastError = null
        activePlayer?.let { apply(it, configuration) }
    }

    fun clear() {
        pendingConfiguration = null
        lastError = null
        activePlayer?.let { player ->
            player.pause()
            player.clearMediaItems()
        }
    }

    fun seekTo(mediaItemIndex: Int, clipPositionMs: Long) {
        val configuration = pendingConfiguration
        val configuredDuration = configuration?.durationsMs?.getOrNull(mediaItemIndex) ?: 0L
        val safePosition = if (configuredDuration > 0L) {
            clipPositionMs.coerceIn(0L, configuredDuration)
        } else {
            clipPositionMs.coerceAtLeast(0L)
        }
        if (configuration != null && mediaItemIndex in configuration.items.indices) {
            pendingConfiguration = configuration.copy(
                startIndex = mediaItemIndex,
                startPositionMs = safePosition,
            )
            lastError = null
        }

        val player = activePlayer
        if (player != null && mediaItemIndex in 0 until player.mediaItemCount) {
            player.seekTo(mediaItemIndex, safePosition)
            lastError = null
        }
    }

    fun play() {
        pendingConfiguration = pendingConfiguration?.copy(playWhenReady = true)
        activePlayer?.play()
    }

    fun pause() {
        pendingConfiguration = pendingConfiguration?.copy(playWhenReady = false)
        activePlayer?.pause()
    }

    fun state(): Map<String, Any?> {
        val player = activePlayer
        return mapOf(
            "isPlaying" to (player?.isPlaying ?: false),
            "mediaItemIndex" to (player?.currentMediaItemIndex ?: -1),
            "positionMs" to (player?.currentPosition ?: 0L),
            "playbackState" to when (player?.playbackState) {
                Player.STATE_BUFFERING -> "buffering"
                Player.STATE_READY -> "ready"
                Player.STATE_ENDED -> "ended"
                else -> "idle"
            },
            "error" to lastError,
        )
    }

    fun detach(player: ExoPlayer) {
        player.removeListener(listener)
        if (activePlayer === player) activePlayer = null
    }

    private fun apply(player: ExoPlayer, configuration: Configuration) {
        player.pause()
        if (configuration.items.isEmpty()) {
            player.clearMediaItems()
            return
        }
        val index = configuration.startIndex.coerceIn(0, configuration.items.lastIndex)
        val durationMs = configuration.durationsMs[index]
        val positionMs = if (durationMs > 0L) {
            configuration.startPositionMs.coerceIn(0L, durationMs)
        } else {
            configuration.startPositionMs.coerceAtLeast(0L)
        }
        player.setMediaItems(configuration.items, index, positionMs)
        player.prepare()
        if (configuration.playWhenReady) player.play() else player.pause()
    }
}

private class VeloraPreviewView(
    context: Context,
    uriText: String,
    kind: String,
    initialPositionMs: Long,
    timelineMode: Boolean,
    imageDurationMs: Long,
) : PlatformView {
    private var player: ExoPlayer? = null
    private var imageExecutor: ExecutorService? = null
    private var imageLoadTask: Future<*>? = null
    private var previewImage: ImageView? = null
    private var imageLayoutListener: View.OnLayoutChangeListener? = null
    @Volatile private var disposed = false
    @Volatile private var previewBitmap: Bitmap? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val root: View = when {
        timelineMode -> createPlayerView(
            context,
            uriText,
            kind,
            initialPositionMs,
            imageDurationMs,
            timelineMode = true,
        )
        kind == "video" -> createPlayerView(
            context,
            uriText,
            kind,
            initialPositionMs,
            imageDurationMs,
            timelineMode = false,
        )
        kind == "image" -> createImage(context, uriText)
        else -> TextView(context).apply {
            text = "المعاينة متاحة للفيديو والصورة"
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
    }

    private fun createPlayerView(
        context: Context,
        uriText: String,
        kind: String,
        initialPositionMs: Long,
        imageDurationMs: Long,
        timelineMode: Boolean,
    ): View {
        val playerView = PlayerView(context).apply {
            useController = !timelineMode
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        val itemBuilder = MediaItem.Builder().setUri(Uri.parse(uriText))
        val fallbackDuration = if (kind == "image") imageDurationMs else 0L
        if (kind == "image") itemBuilder.setImageDurationMs(imageDurationMs.coerceAtLeast(1L))
        val exoPlayer = ExoPlayer.Builder(context).build()
        player = exoPlayer
        playerView.player = exoPlayer
        VeloraPreviewPlayerRegistry.attach(
            exoPlayer,
            itemBuilder.build(),
            initialPositionMs.coerceAtLeast(0L),
            fallbackDuration,
        )
        return playerView
    }

    private fun createImage(context: Context, uriText: String): View {
        val frame = FrameLayout(context)
        val image = ImageView(context).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "معاينة صورة"
        }
        val failureLabel = TextView(context).apply {
            text = "تعذّر تحميل الصورة"
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            visibility = View.GONE
        }
        frame.addView(
            image,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        frame.addView(
            failureLabel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )

        val executor = Executors.newSingleThreadExecutor()
        imageExecutor = executor
        previewImage = image
        var decodeStarted = false
        fun startDecodeWhenSized() {
            if (decodeStarted || disposed || executor.isShutdown) return
            val targetWidth = image.width
            val targetHeight = image.height
            if (targetWidth <= 0 || targetHeight <= 0) return
            decodeStarted = true
            imageLayoutListener?.let(image::removeOnLayoutChangeListener)
            imageLayoutListener = null
            imageLoadTask = executor.submit {
                val bitmap = try {
                    decodePreviewBitmap(
                        context,
                        Uri.parse(uriText),
                        targetWidth,
                        targetHeight,
                    )
                } catch (_: Exception) {
                    null
                }
                val posted = mainHandler.post {
                    if (disposed || executor.isShutdown) {
                        bitmap?.recycle()
                    } else if (bitmap == null) {
                        failureLabel.visibility = View.VISIBLE
                    } else {
                        previewBitmap = bitmap
                        image.setImageBitmap(bitmap)
                    }
                }
                if (!posted) bitmap?.recycle()
            }
        }
        val layoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            startDecodeWhenSized()
        }
        imageLayoutListener = layoutListener
        image.addOnLayoutChangeListener(layoutListener)
        image.post { startDecodeWhenSized() }
        return frame
    }

    private fun decodePreviewBitmap(
        context: Context,
        uri: Uri,
        targetWidth: Int,
        targetHeight: Int,
    ): Bitmap? {
        if (Thread.currentThread().isInterrupted || disposed) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val scale = minOf(
            1.0,
            targetWidth.toDouble() / bounds.outWidth,
            targetHeight.toDouble() / bounds.outHeight,
        )
        val desiredWidth = (bounds.outWidth * scale).toInt().coerceAtLeast(1)
        val desiredHeight = (bounds.outHeight * scale).toInt().coerceAtLeast(1)
        var sampleSize = 1
        while (sampleSize <= Int.MAX_VALUE / 2) {
            val nextSample = sampleSize * 2
            if (
                bounds.outWidth / nextSample < desiredWidth ||
                bounds.outHeight / nextSample < desiredHeight
            ) {
                break
            }
            sampleSize = nextSample
        }
        if (Thread.currentThread().isInterrupted || disposed) return null
        val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
    }

    override fun getView(): View = root

    override fun dispose() {
        disposed = true
        imageLayoutListener?.let { listener ->
            previewImage?.removeOnLayoutChangeListener(listener)
        }
        imageLayoutListener = null
        previewImage = null
        imageLoadTask?.cancel(true)
        imageExecutor?.shutdownNow()
        imageExecutor = null
        previewBitmap?.recycle()
        previewBitmap = null
        player?.let { active ->
            VeloraPreviewPlayerRegistry.detach(active)
            active.release()
        }
        player = null
    }
}
