import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_timeline_clock.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_transitions.dart';

void main() {
  test('round-trips audio and overlay offsets through speed-adjusted cuts', () {
    const track = [
      TimelineClip(
        id: 'fast',
        assetId: 'asset-fast',
        trimStartMs: 0,
        trimEndMs: 1_000,
        speedRampPoints: [SpeedRampPoint(timeMs: 0, speed: 2)],
      ),
      TimelineClip(
        id: 'normal',
        assetId: 'asset-normal',
        trimStartMs: 0,
        trimEndMs: 1_000,
      ),
    ];
    const transition = VideoTransition(
      id: 'cut-transition',
      fromClipId: 'fast',
      toClipId: 'normal',
      type: VideoTransitionType.fade,
      durationMs: 100,
    );

    final outputMs = projectTimelineMsToOutputMs(
      track,
      1_400,
      transitions: const [transition],
    );
    expect(outputMs, 800);
    expect(
      outputTimelineMsToProjectMs(
        track,
        outputMs,
        transitions: const [transition],
      ),
      1_400,
    );
  });

  test('maps a normal sequential source clock across clips in both directions', () {
    const clips = <TimelineClip>[
      TimelineClip(
        id: 'first',
        assetId: 'asset-first',
        trimStartMs: 1000,
        trimEndMs: 3000,
      ),
      TimelineClip(
        id: 'second',
        assetId: 'asset-second',
        trimStartMs: 5000,
        trimEndMs: 7000,
      ),
    ];

    // The first clip contributes 2,000 ms; 500 ms into clip two is 2,500 ms.
    expect(mapProjectSourceTimeToOutputMs(2500, clips, const []), 2500);
    expect(mapOutputMsToProjectSourceTime(2500, clips, const []), 2500);
  });

  test('maps a varying speed ramp using sampled source/output durations', () {
    const clips = <TimelineClip>[
      TimelineClip(
        id: 'ramped',
        assetId: 'asset-ramped',
        trimStartMs: 1000,
        trimEndMs: 2000,
        speedRampPoints: [
          SpeedRampPoint(timeMs: 1000, speed: 1),
          SpeedRampPoint(timeMs: 2000, speed: 2),
        ],
      ),
    ];

    // Sampling every 50 ms across the 1x-to-2x ramp yields 413.914 ms,
    // rounded to 414 ms for a source-clock position of 500 ms.
    expect(mapProjectSourceTimeToOutputMs(500, clips, const []), 414);
    expect(mapOutputMsToProjectSourceTime(414, clips, const []), 500);

    // The inverse mapping is also checked independently at a non-round offset.
    expect(mapOutputMsToProjectSourceTime(250, clips, const []), 277);
    expect(mapProjectSourceTimeToOutputMs(277, clips, const []), 250);
  });

  test('unaligned speed ramp remains aligned through a transition and round trip', () {
    const ramp = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 0.5),
      SpeedRampPoint(timeMs: 175, speed: 1.5),
      SpeedRampPoint(timeMs: 501, speed: 2),
      SpeedRampPoint(timeMs: 1200, speed: 0.5),
      SpeedRampPoint(timeMs: 4000, speed: 8),
    ];
    const track = <TimelineClip>[
      TimelineClip(
        id: 'ramped',
        assetId: 'asset-ramped',
        trimStartMs: 123,
        trimEndMs: 3010,
        speedRampPoints: ramp,
      ),
      TimelineClip(
        id: 'double-speed',
        assetId: 'asset-double-speed',
        trimStartMs: 40,
        trimEndMs: 1040,
        speedRampPoints: [SpeedRampPoint(timeMs: 40, speed: 2)],
      ),
    ];
    const transition = VideoTransition(
      id: 'ramped-to-double',
      fromClipId: 'ramped',
      toClipId: 'double-speed',
      type: VideoTransitionType.dissolve,
      durationMs: 100,
    );

    expect(track[0].effectiveDurationMs, 1778);
    expect(track[1].effectiveDurationMs, 500);
    expect(
      mapProjectSourceTimeToOutputMs(2987, track, const [transition]),
      1753,
    );
    // Output milliseconds are quantized; 2986 and 2987 can map to the same
    // output millisecond, and the inverse deliberately chooses the earlier.
    expect(
      mapProjectSourceTimeToOutputMs(2986, track, const [transition]),
      1753,
    );
    expect(
      mapOutputMsToProjectSourceTime(1753, track, const [transition]),
      2986,
    );
  });

  test('project clock remains unchanged when a ramped clip is split off-grid', () {
    const ramp = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 1),
      SpeedRampPoint(timeMs: 5000, speed: 2),
    ];
    const wholeClip = TimelineClip(
      id: 'whole',
      assetId: 'asset',
      trimStartMs: 0,
      trimEndMs: 5000,
      speedRampPoints: ramp,
    );
    const splitClips = <TimelineClip>[
      TimelineClip(
        id: 'first',
        assetId: 'asset',
        trimStartMs: 0,
        trimEndMs: 501,
        speedRampPoints: ramp,
      ),
      TimelineClip(
        id: 'second',
        assetId: 'asset',
        trimStartMs: 501,
        trimEndMs: 5000,
        speedRampPoints: ramp,
      ),
    ];

    for (final sourceTimeMs in [0, 500, 501, 502, 1250, 2500, 4999, 5000]) {
      expect(
        mapProjectSourceTimeToOutputMs(sourceTimeMs, splitClips, const []),
        mapProjectSourceTimeToOutputMs(sourceTimeMs, [wholeClip], const []),
        reason: 'source time $sourceTimeMs ms',
      );
    }

    final wholeDurationMs = wholeClip.effectiveDurationMs;
    final splitDurationMs = splitClips.fold<int>(
      0,
      (total, clip) => total + clip.effectiveDurationMs,
    );
    expect(splitDurationMs, wholeDurationMs);

    for (final outputTimeMs in [0, 250, 480, 481, 1000, wholeDurationMs]) {
      expect(
        mapOutputMsToProjectSourceTime(outputTimeMs, splitClips, const []),
        mapOutputMsToProjectSourceTime(outputTimeMs, [wholeClip], const []),
        reason: 'output time $outputTimeMs ms',
      );
    }
  });

  test('maps through an active dissolve overlap and reverses the mapping', () {
    const clips = <TimelineClip>[
      TimelineClip(
        id: 'outgoing',
        assetId: 'asset-outgoing',
        trimStartMs: 0,
        trimEndMs: 1000,
      ),
      TimelineClip(
        id: 'incoming',
        assetId: 'asset-incoming',
        trimStartMs: 0,
        trimEndMs: 1000,
      ),
    ];
    const transitions = <VideoTransition>[
      VideoTransition(
        id: 'outgoing-incoming',
        fromClipId: 'outgoing',
        toClipId: 'incoming',
        type: VideoTransitionType.dissolve,
        durationMs: 200,
      ),
    ];

    // With a 200 ms overlap, source time 1,100 ms maps to composition 950 ms.
    expect(mapProjectSourceTimeToOutputMs(1100, clips, transitions), 950);
    expect(mapOutputMsToProjectSourceTime(950, clips, transitions), 1100);
  });

  test('a 950ms split in a ramped incoming transition maps cumulatively and is rejected', () {
    const ramp = <SpeedRampPoint>[
      SpeedRampPoint(timeMs: 0, speed: 1),
      SpeedRampPoint(timeMs: 1000, speed: 2),
    ];
    const track = <TimelineClip>[
      TimelineClip(id: 'a', assetId: 'a-asset', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(
        id: 'b',
        assetId: 'b-asset',
        trimStartMs: 0,
        trimEndMs: 1000,
        speedRampPoints: ramp,
      ),
    ];
    const incoming = VideoTransition(
      id: 'a-b',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.fade,
      durationMs: 200,
    );

    final layout = layoutVideoTransitions(
      track.map((clip) => clip.id).toList(),
      track.map((clip) => clip.effectiveDurationMs).toList(),
      const [incoming],
    );
    expect(layout.startOfClip(1), 800);
    expect(layout.activeTransitionsByBoundary[0]?.durationMs, 200);
    final position = timelinePositionAt(track, 950, transitions: const [incoming]);
    expect(position, isNotNull);
    final resolvedPosition = position!;
    expect(resolvedPosition.clipId, 'b');
    expect(resolvedPosition.clipIndex, 1);
    expect(resolvedPosition.clipPositionMs, 150);
    expect(resolvedPosition.sourcePositionMs, 158);
    expect(outputOffsetToSourceMs(150, 0, 1000, ramp), 158);

    final splitTrack = splitClipAtPosition(
      track,
      'b',
      playheadMs: 950,
      secondClipId: 'b-second',
      sourceDurationMs: 1000,
      sourceSplitPositionMs: resolvedPosition.sourcePositionMs,
    )!;
    final firstDurationMs = splitTrack[1].effectiveDurationMs;
    final secondDurationMs = splitTrack[2].effectiveDurationMs;
    final splitTransitions = transitionsAfterClipSplit(
      const [incoming],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: firstDurationMs,
      secondSegmentDurationMs: secondDurationMs,
    );
    final originalDurationMs = visualTimelineDurationMs(
      track,
      transitions: const [incoming],
    );
    final splitDurationMs = visualTimelineDurationMs(
      splitTrack,
      transitions: splitTransitions,
    );

    expect(firstDurationMs, 150);
    expect(splitTransitions.single.durationMs, 150);
    expect(splitDurationMs, originalDurationMs + 50);
    expect(
      splitPreservesTransitionSchedule(
        originalTransitions: const [incoming],
        splitTransitions: splitTransitions,
        originalClipId: 'b',
        secondClipId: 'b-second',
        originalTimelineDurationMs: originalDurationMs,
        splitTimelineDurationMs: splitDurationMs,
      ),
      isFalse,
    );
  });

}
