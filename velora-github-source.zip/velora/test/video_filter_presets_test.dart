import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/video_filter_presets.dart';

void main() {
  test('filter catalog contains unique, bounded, editable Media3 grades', () {
    expect(videoFilterPresets.map((preset) => preset.id).toSet(), hasLength(5));
    expect(
      videoFilterPresets.map((preset) => preset.id),
      containsAll(['natural', 'warm', 'cool', 'monochrome', 'cinematic']),
    );
    for (final preset in videoFilterPresets) {
      expect(preset.settings.brightness, inInclusiveRange(-1, 1));
      expect(preset.settings.contrast, inInclusiveRange(-1, 1));
      expect(preset.settings.saturation, inInclusiveRange(-100, 100));
      expect(preset.settings.warmth, inInclusiveRange(-1, 1));
      expect(
        VideoColorSettings.fromMap(preset.settings.toMap()),
        preset.settings,
      );
    }

    final warm = videoFilterPresets.singleWhere((preset) => preset.id == 'warm');
    final cool = videoFilterPresets.singleWhere((preset) => preset.id == 'cool');
    final monochrome = videoFilterPresets.singleWhere(
      (preset) => preset.id == 'monochrome',
    );
    expect(warm.warmth, greaterThan(0));
    expect(cool.warmth, lessThan(0));
    expect(monochrome.saturation, -100);
  });
}
