import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/overlays.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_overlays.dart';
import 'package:velora/src/models/video_transitions.dart';

const _clips = <TimelineClip>[
  TimelineClip(id: 'a', assetId: 'asset-a', trimStartMs: 0, trimEndMs: 1000),
  TimelineClip(id: 'b', assetId: 'asset-b', trimStartMs: 0, trimEndMs: 1000),
  TimelineClip(
    id: 'c',
    assetId: 'asset-c',
    trimStartMs: 120,
    trimEndMs: 1120,
    volume: 0.37,
    fadeInMs: 80,
    fadeOutMs: 140,
    transformKeyframes: [
      ClipTransformKeyframe(
        timeMs: 350,
        positionX: 0.2,
        positionY: -0.1,
        scale: 1.3,
        rotationDegrees: 12,
        opacity: 0.75,
        interpolation: MotionInterpolation.linear,
      ),
    ],
    speedRampPoints: [
      SpeedRampPoint(timeMs: 120, speed: 1),
      SpeedRampPoint(timeMs: 620, speed: 2),
      SpeedRampPoint(timeMs: 1120, speed: 0.8),
    ],
  ),
];

const _transitionAB = VideoTransition(
  id: 'transition-a-b',
  fromClipId: 'a',
  toClipId: 'b',
  type: VideoTransitionType.dissolve,
  durationMs: 200,
  direction: 'up',
  intensity: 0.6,
);

void main() {
  test('reorders an unlinked clip while preserving an existing adjacent transition', () {
    final result = reorderVideoClipSafely(
      videoTrack: _clips,
      transitions: const [_transitionAB],
      draggedClipId: 'c',
      targetClipId: 'a',
      insertAfterTarget: false,
    );

    expect(result.accepted, isTrue);
    expect(result.changed, isTrue);
    expect(result.track?.map((clip) => clip.id), ['c', 'a', 'b']);
    expect(
      result.track!.singleWhere((clip) => clip.id == 'c').toMap(),
      _clips.singleWhere((clip) => clip.id == 'c').toMap(),
    );
    expect(_clips.map((clip) => clip.id), ['a', 'b', 'c']);
    final reorderedLayout = layoutVideoTransitions(
      result.track!.map((clip) => clip.id).toList(),
      result.track!.map((clip) => clip.effectiveDurationMs).toList(),
      const [_transitionAB],
    );
    expect(reorderedLayout.activeTransitionsByBoundary.values.single.id, 'transition-a-b');
    expect(
      visualTimelineDurationMs(result.track!, transitions: const [_transitionAB]),
      visualTimelineDurationMs(_clips, transitions: const [_transitionAB]),
    );
  });

  test('rejects a reorder that would separate or reverse a transition pair', () {
    final separated = reorderVideoClipSafely(
      videoTrack: _clips,
      transitions: const [_transitionAB],
      draggedClipId: 'a',
      targetClipId: 'c',
      insertAfterTarget: true,
    );
    expect(separated.accepted, isFalse);
    expect(separated.changed, isFalse);
    expect(separated.rejectionReason, contains('الانتقال'));
    expect(separated.track, isNull);
    expect(_clips.map((clip) => clip.id), ['a', 'b', 'c']);

    final reversed = reorderVideoClipSafely(
      videoTrack: _clips,
      transitions: const [_transitionAB],
      draggedClipId: 'b',
      targetClipId: 'a',
      insertAfterTarget: false,
    );
    expect(reversed.accepted, isFalse);
    expect(reversed.rejectionReason, contains('بالترتيب نفسه'));
  });

  test('records a valid reorder as one complete-project undo and redo step', () {
    final initial = VeloraProject(
      id: 'reorder-history',
      name: 'اختبار إعادة الترتيب',
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: const [],
      videoTrack: _clips,
      audioTrack: const [
        TimelineClip(
          id: 'audio',
          assetId: 'audio-asset',
          trimStartMs: 250,
          trimEndMs: 900,
          timelineStartMs: 350,
          volume: 0.4,
          fadeInMs: 120,
          fadeOutMs: 180,
        ),
      ],
      textOverlays: const [
        TextOverlay(id: 'title', text: 'عنوان', startMs: 400, endMs: 900),
      ],
      subtitleTrack: const [
        SubtitleCue(id: 'subtitle', text: 'ترجمة', startMs: 500, endMs: 800),
      ],
      stickerOverlays: const [
        StickerOverlay(
          id: 'sticker',
          uri: 'content://sticker',
          name: 'sticker.png',
          mimeType: 'image/png',
          startMs: 600,
          endMs: 950,
        ),
      ],
      videoOverlayTracks: const [
        VideoOverlayTrack(
          id: 'pip-track',
          name: 'PIP',
          clips: [
            VideoOverlayClip(
              id: 'pip',
              assetId: 'asset-b',
              trimStartMs: 100,
              trimEndMs: 700,
              timelineStartMs: 550,
            ),
          ],
        ),
      ],
      videoTransitions: const [_transitionAB],
    );
    final history = ProjectHistory(initial);
    final reordered = reorderVideoClipSafely(
      videoTrack: initial.videoTrack,
      transitions: initial.videoTransitions,
      draggedClipId: 'c',
      targetClipId: 'a',
      insertAfterTarget: false,
    );
    expect(reordered.accepted, isTrue);
    final committed = initial.copyWith(videoTrack: reordered.track);
    history.record(committed);

    expect(history.undo()?.videoTrack.map((clip) => clip.id), ['a', 'b', 'c']);
    final redone = history.redo()!;
    expect(redone.videoTrack.map((clip) => clip.id), ['c', 'a', 'b']);
    expect(
      redone.videoTransitions.map((transition) => transition.toMap()),
      initial.videoTransitions.map((transition) => transition.toMap()),
    );
    expect(
      redone.audioTrack.map((clip) => clip.toMap()),
      initial.audioTrack.map((clip) => clip.toMap()),
    );
    expect(
      redone.textOverlays.map((overlay) => overlay.toMap()),
      initial.textOverlays.map((overlay) => overlay.toMap()),
    );
    expect(
      redone.subtitleTrack.map((cue) => cue.toMap()),
      initial.subtitleTrack.map((cue) => cue.toMap()),
    );
    expect(
      redone.stickerOverlays.map((overlay) => overlay.toMap()),
      initial.stickerOverlays.map((overlay) => overlay.toMap()),
    );
    expect(
      redone.videoOverlayTracks.map((track) => track.toMap()),
      initial.videoOverlayTracks.map((track) => track.toMap()),
    );
  });
}
