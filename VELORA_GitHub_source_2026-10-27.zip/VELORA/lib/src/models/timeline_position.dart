import 'project.dart';

/// Position of a playhead in the sequential visual track.
///
/// [timelinePositionMs] is relative to the start of the whole track, while
/// [sourcePositionMs] is relative to the referenced media asset.
class TimelinePosition {
  const TimelinePosition({
    required this.clipId,
    required this.assetId,
    required this.clipIndex,
    required this.timelinePositionMs,
    required this.clipPositionMs,
    required this.sourcePositionMs,
  });

  final String clipId;
  final String assetId;
  final int clipIndex;
  final int timelinePositionMs;
  final int clipPositionMs;
  final int sourcePositionMs;
}

/// Total duration of positive-length clips on the visual track.
int visualTimelineDurationMs(List<TimelineClip> track) => track.fold<int>(
  0,
  (total, clip) => total + (clip.durationMs > 0 ? clip.durationMs : 0),
);

/// Maps a timeline time to its clip and source-media time.
///
/// Clip ranges are laid out sequentially in list order. Exact internal clip
/// boundaries select the following clip; the track's final boundary selects
/// the end of the final valid clip. Invalid/zero-length ranges are ignored.
TimelinePosition? timelinePositionAt(
  List<TimelineClip> track,
  int requestedPositionMs,
) {
  final totalDurationMs = visualTimelineDurationMs(track);
  if (totalDurationMs <= 0) return null;

  final positionMs = requestedPositionMs.clamp(0, totalDurationMs).toInt();
  final lastValidIndex = track.lastIndexWhere((clip) => clip.durationMs > 0);
  var timelineStartMs = 0;

  for (var index = 0; index < track.length; index++) {
    final clip = track[index];
    final durationMs = clip.durationMs;
    if (durationMs <= 0) continue;

    final timelineEndMs = timelineStartMs + durationMs;
    final isFinalBoundary =
        positionMs == totalDurationMs && index == lastValidIndex;
    if (positionMs < timelineEndMs || isFinalBoundary) {
      final offsetMs = (positionMs - timelineStartMs).clamp(0, durationMs);
      return TimelinePosition(
        clipId: clip.id,
        assetId: clip.assetId,
        clipIndex: index,
        timelinePositionMs: positionMs,
        clipPositionMs: offsetMs,
        sourcePositionMs: clip.trimStartMs + offsetMs,
      );
    }
    timelineStartMs = timelineEndMs;
  }

  return null;
}

/// Maps a player's current playlist item and item-relative position back to the
/// absolute visual timeline and the source-media timestamp.
TimelinePosition? timelinePositionForClipOffset(
  List<TimelineClip> track, {
  required int clipIndex,
  required int clipPositionMs,
}) {
  if (clipIndex < 0 || clipIndex >= track.length) return null;
  final clip = track[clipIndex];
  final durationMs = clip.durationMs;
  if (durationMs <= 0) return null;

  final timelineStartMs = track
      .take(clipIndex)
      .fold<int>(
        0,
        (total, item) => total + (item.durationMs > 0 ? item.durationMs : 0),
      );
  final boundedOffsetMs = clipPositionMs.clamp(0, durationMs).toInt();
  return TimelinePosition(
    clipId: clip.id,
    assetId: clip.assetId,
    clipIndex: clipIndex,
    timelinePositionMs: timelineStartMs + boundedOffsetMs,
    clipPositionMs: boundedOffsetMs,
    sourcePositionMs: clip.trimStartMs + boundedOffsetMs,
  );
}
