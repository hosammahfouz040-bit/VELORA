package com.velora.app

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets

/** File-level project persistence. JSON encoding/decoding stays owned by MainActivity. */
internal class ProjectJsonStore(
    private val directory: File,
    private val decodeJson: (String) -> Map<String, Any?>,
    private val replaceFile: (source: File, destination: File) -> Unit,
) {
    fun save(id: String, json: String) {
        require(id.isNotBlank()) { "Project ID is missing" }
        ensureDirectory()
        val target = projectFile(id)
        val bytes = json.toByteArray(StandardCharsets.UTF_8)
        var temporary: File? = null
        try {
            // Create the temporary file beside the destination so the final rename stays
            // on one filesystem and can replace the project atomically.
            temporary = File.createTempFile("velora-project-", ".tmp", directory)
            FileOutputStream(temporary).use { output ->
                output.write(bytes)
                output.flush()
                output.fd.sync()
            }
            replaceFile(temporary, target)
        } finally {
            temporary?.delete()
        }
    }

    fun readProjects(): List<Map<String, Any?>> = directory
        .listFiles { file -> file.isFile && file.extension == "json" }
        .orEmpty()
        .sortedByDescending(File::lastModified)
        .mapNotNull { file ->
            try {
                decodeJson(file.readText(StandardCharsets.UTF_8))
            } catch (_: Exception) {
                // Keep the unreadable file for recovery; it must not block other projects.
                null
            }
        }

    private fun ensureDirectory() {
        if (!directory.isDirectory && !directory.mkdirs() && !directory.isDirectory) {
            throw IOException("Could not create the project storage directory")
        }
    }

    private fun projectFile(id: String): File {
        val target = File(directory, "$id.json").canonicalFile
        if (target.parentFile != directory.canonicalFile) {
            throw IllegalArgumentException("Project ID is not a valid file name")
        }
        return target
    }
}
