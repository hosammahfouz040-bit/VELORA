import 'package:flutter/material.dart';

import '../theme.dart';
import '../models/project.dart';
import '../services/native_bridge.dart';
import 'editor_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<VeloraProject> _projects = const [];
  bool _loading = true;
  String? _error;
  int _reloadGeneration = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    if (!mounted) return;
    final generation = ++_reloadGeneration;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final projects = await NativeBridge.listProjects();
      if (!mounted || generation != _reloadGeneration) return;
      setState(() {
        _projects = projects;
        _loading = false;
      });
    } catch (error) {
      if (!mounted || generation != _reloadGeneration) return;
      setState(() {
        _loading = false;
        _error = 'تعذّر تحميل المشاريع: $error';
      });
    }
  }

  Future<void> _createProject() async {
    final name = await showDialog<String>(
      context: context,
      builder: (_) => const _CreateProjectDialog(),
    );
    if (name == null || name.isEmpty || !mounted) return;

    final project = VeloraProject.empty(id: newLocalId(), name: name);
    try {
      await NativeBridge.saveProject(project);
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute(builder: (_) => EditorScreen(project: project)),
      );
      if (!mounted) return;
      await _reload();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('تعذّر إنشاء المشروع: $error')));
    }
  }

  Future<void> _openProject(VeloraProject project) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => EditorScreen(project: project)),
    );
    if (!mounted) return;
    await _reload();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: RefreshIndicator(
        onRefresh: _reload,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _buildHero()),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'مشاريعك',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    FilledButton.icon(
                      onPressed: _createProject,
                      icon: const Icon(Icons.add_rounded),
                      label: const Text('مشروع جديد'),
                      style: FilledButton.styleFrom(
                        backgroundColor: veloraGold,
                        foregroundColor: veloraInk,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (_loading)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_error != null)
              SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        OutlinedButton(
                          onPressed: _reload,
                          child: const Text('إعادة المحاولة'),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            else if (_projects.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: _EmptyProjects(),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverList.separated(
                  itemCount: _projects.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final project = _projects[index];
                    return Card(
                      child: ListTile(
                        key: ValueKey('project:${project.id}'),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFF304050),
                          child: Icon(Icons.movie_creation_outlined),
                        ),
                        title: Text(
                          project.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text(
                          '${project.videoTrack.length} مقطع مرئي · '
                          '${project.audioTrack.length} مقطع صوتي',
                        ),
                        trailing: const Icon(Icons.chevron_left_rounded),
                        onTap: () => _openProject(project),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    ),
  );

  Widget _buildHero() => Container(
    margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [Color(0xFF263646), Color(0xFF111923)],
      ),
      border: Border.all(color: const Color(0xFF38495A)),
    ),
    child: const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.auto_awesome, color: veloraGold, size: 19),
            SizedBox(width: 8),
            Text(
              'VELORA',
              style: TextStyle(
                letterSpacing: 2.8,
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: veloraGold,
              ),
            ),
          ],
        ),
        SizedBox(height: 12),
        Text(
          'اصنع قصتك\nبإيقاعك الخاص',
          style: TextStyle(
            height: 1.22,
            fontSize: 27,
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'مساحة تحرير مستقلة تبدأ من وسائطك ومخططك الزمني.',
          style: TextStyle(color: Color(0xFFB9C4CE), height: 1.5),
        ),
      ],
    ),
  );
}

class _CreateProjectDialog extends StatefulWidget {
  const _CreateProjectDialog();

  @override
  State<_CreateProjectDialog> createState() => _CreateProjectDialogState();
}

class _CreateProjectDialogState extends State<_CreateProjectDialog> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: 'مشروع جديد');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final name = _controller.text.trim();
    if (name.isNotEmpty) Navigator.of(context).pop(name);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('إنشاء مشروع'),
    content: TextField(
      controller: _controller,
      autofocus: true,
      textDirection: TextDirection.rtl,
      decoration: const InputDecoration(labelText: 'اسم المشروع'),
      onSubmitted: (_) => _submit(),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(onPressed: _submit, child: const Text('إنشاء')),
    ],
  );
}

class _EmptyProjects extends StatelessWidget {
  const _EmptyProjects();

  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.video_library_outlined, size: 48, color: veloraGold),
          SizedBox(height: 14),
          Text(
            'لا توجد مشاريع بعد',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          SizedBox(height: 6),
          Text(
            'أنشئ مشروعًا جديدًا للبدء باستيراد الوسائط.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFFAFBAC5)),
          ),
        ],
      ),
    ),
  );
}
