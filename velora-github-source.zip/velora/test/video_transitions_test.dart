import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_transitions.dart';

void main() {
  const clips = <TimelineClip>[
    TimelineClip(id: 'a', assetId: 'a', trimStartMs: 0, trimEndMs: 1000),
    TimelineClip(id: 'b', assetId: 'b', trimStartMs: 0, trimEndMs: 1000),
    TimelineClip(id: 'c', assetId: 'c', trimStartMs: 0, trimEndMs: 1000),
  ];
  const first = VideoTransition(
    id: 'ab',
    fromClipId: 'a',
    toClipId: 'b',
    type: VideoTransitionType.dissolve,
    durationMs: 200,
    direction: 'up',
    intensity: 0.65,
  );
  const second = VideoTransition(
    id: 'bc',
    fromClipId: 'b',
    toClipId: 'c',
    type: VideoTransitionType.spin,
    durationMs: 200,
  );

  test('overlap layout shortens duration and chooses incoming clip within transition', () {
    final layout = layoutVideoTransitions(
      clips.map((clip) => clip.id).toList(),
      clips.map((clip) => clip.durationMs).toList(),
      const [first, second],
    );
    expect(layout.clipStartsMs, [0, 800, 1600]);
    expect(layout.totalDurationMs, 2600);
    expect(visualTimelineDurationMs(clips, transitions: const [first, second]), 2600);
    expect(
      timelinePositionAt(clips, 900, transitions: const [first, second])?.clipId,
      'b',
    );
    expect(
      timelinePositionAt(clips, 900, transitions: const [first, second])?.sourcePositionMs,
      100,
    );
  });

  test('overlay time mapping is monotone and maps each 2D cut window onto D', () {
    final ids = clips.map((clip) => clip.id).toList();
    final durations = clips.map((clip) => clip.durationMs).toList();
    expect(mapTransitionTimelineMs(800, ids, durations, const [first, second]), 800);
    expect(mapTransitionTimelineMs(1000, ids, durations, const [first, second]), 900);
    expect(mapTransitionTimelineMs(1200, ids, durations, const [first, second]), 1000);
    expect(mapTransitionTimelineMs(1800, ids, durations, const [first, second]), 1600);
  });

  test('inverse mapping restores user edits from the compressed overlap clock', () {
    final ids = clips.map((clip) => clip.id).toList();
    final durations = clips.map((clip) => clip.durationMs).toList();
    for (final originalMs in [800, 900, 1000, 1100, 1200, 1800, 1900, 2000, 2200]) {
      final outputMs = mapTransitionTimelineMs(originalMs, ids, durations, const [first, second]);
      expect(
        unmapTransitionTimelineMs(outputMs, ids, durations, const [first, second]),
        originalMs,
      );
    }
    expect(unmapTransitionTimelineMs(450, ids, durations, const []), 450);
  });

  test('transition families exposed as supported match preview and export catalog', () {
    expect(
      VideoTransitionType.values.where((type) => type.supported).toSet(),
      {
        VideoTransitionType.fade,
        VideoTransitionType.dissolve,
        VideoTransitionType.slide,
        VideoTransitionType.zoom,
        VideoTransitionType.spin,
      },
    );
  });

  test('safe transition updates respect adjacent overlap capacity and keep neighbors intact', () {
    final limits = videoTransitionDurationLimits(
      videoTrack: clips,
      transitions: const [second],
      boundaryIndex: 0,
    );
    expect(limits.accepted, isTrue);
    expect(limits.maxDurationMs, 800);

    final tooLong = setVideoTransitionSafely(
      videoTrack: clips,
      transitions: const [second],
      boundaryIndex: 0,
      type: VideoTransitionType.slide,
      durationMs: 801,
      newTransitionId: 'new-ab',
    );
    expect(tooLong.accepted, isFalse);
    expect(tooLong.transitions, isNull);
    expect(tooLong.rejectionReason, contains('800'));

    final accepted = setVideoTransitionSafely(
      videoTrack: clips,
      transitions: const [second],
      boundaryIndex: 0,
      type: VideoTransitionType.slide,
      durationMs: 800,
      newTransitionId: 'new-ab',
    );
    expect(accepted.accepted, isTrue);
    expect(accepted.changed, isTrue);
    expect(accepted.transitions, hasLength(2));
    final retainedNeighbor = accepted.transitions!.singleWhere((item) => item.id == 'bc');
    expect(retainedNeighbor.durationMs, 200);
    expect(retainedNeighbor.type, VideoTransitionType.spin);
    final layout = layoutVideoTransitions(
      clips.map((clip) => clip.id).toList(),
      clips.map((clip) => clip.effectiveDurationMs).toList(),
      accepted.transitions!,
    );
    expect(layout.activeTransitionsByBoundary.keys, [0, 1]);

    final unsupported = setVideoTransitionSafely(
      videoTrack: clips,
      transitions: const [],
      boundaryIndex: 0,
      type: VideoTransitionType.wipe,
      durationMs: 200,
      newTransitionId: 'unsupported',
    );
    expect(unsupported.accepted, isFalse);
    expect(unsupported.rejectionReason, contains('غير مدعوم'));

    const crowdedTrack = <TimelineClip>[
      TimelineClip(id: 'a', assetId: 'a', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(id: 'b', assetId: 'b', trimStartMs: 0, trimEndMs: 500),
      TimelineClip(id: 'c', assetId: 'c', trimStartMs: 0, trimEndMs: 1000),
    ];
    const crowdedTransitions = <VideoTransition>[
      VideoTransition(
        id: 'ab-crowded',
        fromClipId: 'a',
        toClipId: 'b',
        type: VideoTransitionType.fade,
        durationMs: 400,
      ),
      VideoTransition(
        id: 'bc-crowded',
        fromClipId: 'b',
        toClipId: 'c',
        type: VideoTransitionType.slide,
        durationMs: 200,
      ),
    ];
    final crowdedLimits = videoTransitionDurationLimits(
      videoTrack: crowdedTrack,
      transitions: crowdedTransitions,
      boundaryIndex: 0,
    );
    expect(crowdedLimits.minDurationMs, 301);
    expect(crowdedLimits.maxDurationMs, 500);
    final wouldActivateNeighbor = setVideoTransitionSafely(
      videoTrack: crowdedTrack,
      transitions: crowdedTransitions,
      boundaryIndex: 0,
      type: VideoTransitionType.zoom,
      durationMs: 300,
      newTransitionId: 'unused',
    );
    expect(wouldActivateNeighbor.accepted, isFalse);
    final safeCrowdedUpdate = setVideoTransitionSafely(
      videoTrack: crowdedTrack,
      transitions: crowdedTransitions,
      boundaryIndex: 0,
      type: VideoTransitionType.zoom,
      durationMs: 301,
      newTransitionId: 'unused',
    );
    expect(safeCrowdedUpdate.accepted, isTrue);
    expect(
      layoutVideoTransitions(
        crowdedTrack.map((clip) => clip.id).toList(),
        crowdedTrack.map((clip) => clip.effectiveDurationMs).toList(),
        safeCrowdedUpdate.transitions!,
      ).activeTransitionsByBoundary.keys,
      [0],
    );
  });

  test('updating a transition is an explicit single undo step and preserves audio', () {
    const audio = TimelineClip(
      id: 'audio',
      assetId: 'music',
      trimStartMs: 100,
      trimEndMs: 900,
      timelineStartMs: 400,
      volume: 0.45,
      fadeInMs: 110,
      fadeOutMs: 150,
    );
    const initialTransition = VideoTransition(
      id: 'ab',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.fade,
      durationMs: 200,
      direction: 'up',
      intensity: 0.6,
    );
    final initialProject = VeloraProject(
      id: 'transition-edit-history',
      name: 'اختبار تعديل الانتقال',
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: const [],
      videoTrack: clips,
      audioTrack: const [audio],
      videoTransitions: const [initialTransition, second],
    );
    final result = setVideoTransitionSafely(
      videoTrack: initialProject.videoTrack,
      transitions: initialProject.videoTransitions,
      boundaryIndex: 0,
      type: VideoTransitionType.zoom,
      durationMs: 350,
      newTransitionId: 'unused-id',
    );
    expect(result.accepted, isTrue);
    expect(result.transitions!.first.id, 'ab');
    expect(result.transitions!.first.direction, 'up');
    expect(result.transitions!.first.intensity, 0.6);
    expect(result.transitions!.last.toMap(), second.toMap());

    final history = ProjectHistory(initialProject);
    final committed = initialProject.copyWith(videoTransitions: result.transitions);
    history.record(committed);
    final undone = history.undo()!;
    expect(undone.videoTransitions.first.type, VideoTransitionType.fade);
    expect(undone.audioTrack.single.toMap(), audio.toMap());
    final redone = history.redo()!;
    expect(redone.videoTransitions.first.type, VideoTransitionType.zoom);
    expect(redone.videoTransitions.first.durationMs, 350);
    expect(redone.audioTrack.single.toMap(), audio.toMap());
  });

  test('adjacent overlaps cannot consume a clip beyond its duration', () {
    const longFirst = VideoTransition(
      id: 'ab-long',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.dissolve,
      durationMs: 700,
    );
    const longSecond = VideoTransition(
      id: 'bc-long',
      fromClipId: 'b',
      toClipId: 'c',
      type: VideoTransitionType.spin,
      durationMs: 700,
    );
    final layout = layoutVideoTransitions(
      clips.map((clip) => clip.id).toList(),
      clips.map((clip) => clip.durationMs).toList(),
      const [longFirst, longSecond],
    );
    expect(layout.activeTransitionsByBoundary.keys, [0]);
    expect(layout.clipStartsMs, [0, 300, 1300]);
    expect(layout.totalDurationMs, 2300);
  });

  test('invalid and unsupported boundaries do not alter the edit duration', () {
    const tooLong = VideoTransition(
      id: 'bad',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.dissolve,
      durationMs: 1200,
    );
    const unavailable = VideoTransition(
      id: 'wipe',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.wipe,
      durationMs: 200,
    );
    final layout = layoutVideoTransitions(
      clips.map((clip) => clip.id).toList(),
      clips.map((clip) => clip.durationMs).toList(),
      const [tooLong],
    );
    expect(layout.totalDurationMs, 3000);
    expect(
      layoutVideoTransitions(
        clips.map((clip) => clip.id).toList(),
        clips.map((clip) => clip.durationMs).toList(),
        const [unavailable],
      ).totalDurationMs,
      3000,
    );
  });

  test('transition fields survive project save, restore, undo and redo', () {
    final oldProject = VeloraProject.empty(id: 'old', name: 'Old');
    expect(VeloraProject.fromMap(oldProject.toMap()).videoTransitions, isEmpty);
    final base = oldProject.copyWith(videoTrack: clips);
    final changed = base.copyWith(videoTransitions: const [first, second]);
    final restored = VeloraProject.fromMap(changed.toMap());
    expect(restored.videoTransitions.map((item) => item.type).toList(), [
      VideoTransitionType.dissolve,
      VideoTransitionType.spin,
    ]);
    expect(restored.videoTransitions.first.durationMs, 200);
    expect(restored.videoTransitions.first.direction, 'up');
    expect(restored.videoTransitions.first.intensity, 0.65);

    final history = ProjectHistory(base);
    history.record(changed);
    expect(history.undo()!.videoTransitions, isEmpty);
    expect(history.redo()!.videoTransitions.length, 2);
  });

  test('splitting a clip retains its incoming cut and moves its outgoing cut', () {
    const outgoing = VideoTransition(
      id: 'bc',
      fromClipId: 'b',
      toClipId: 'c',
      type: VideoTransitionType.slide,
      durationMs: 180,
      direction: 'left',
      intensity: 0.8,
    );
    final remapped = transitionsAfterClipSplit(
      const [first, outgoing],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: 500,
      secondSegmentDurationMs: 500,
    );
    expect(remapped.first.fromClipId, 'a');
    expect(remapped.first.toClipId, 'b');
    expect(remapped.last.fromClipId, 'b-second');
    expect(remapped.last.toClipId, 'c');
    expect(remapped.last.durationMs, 180);
    expect(remapped.last.direction, 'left');
    expect(remapped.last.intensity, 0.8);
  });

  test('split schedule guard allows preserved cuts and rejects shortened or removed cuts', () {
    final preserved = transitionsAfterClipSplit(
      const [first, second],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: 500,
      secondSegmentDurationMs: 500,
    );
    expect(
      splitPreservesTransitionSchedule(
        originalTransitions: const [first, second],
        splitTransitions: preserved,
        originalClipId: 'b',
        secondClipId: 'b-second',
        originalTimelineDurationMs: 2600,
        splitTimelineDurationMs: 2600,
      ),
      isTrue,
    );

    final shortened = transitionsAfterClipSplit(
      const [first, second],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: 50,
      secondSegmentDurationMs: 950,
    );
    expect(shortened.first.durationMs, 50);
    expect(
      splitPreservesTransitionSchedule(
        originalTransitions: const [first, second],
        splitTransitions: shortened,
        originalClipId: 'b',
        secondClipId: 'b-second',
        originalTimelineDurationMs: 2600,
        splitTimelineDurationMs: 2750,
      ),
      isFalse,
    );
    expect(
      splitPreservesTransitionSchedule(
        originalTransitions: const [first, second],
        splitTransitions: const [first],
        originalClipId: 'b',
        secondClipId: 'b-second',
        originalTimelineDurationMs: 2600,
        splitTimelineDurationMs: 2600,
      ),
      isFalse,
    );
    expect(
      splitPreservesTransitionSchedule(
        originalTransitions: const [first, second],
        splitTransitions: preserved,
        originalClipId: 'b',
        secondClipId: 'b-second',
        originalTimelineDurationMs: 2600,
        splitTimelineDurationMs: 2601,
      ),
      isFalse,
    );
  });

  test('splitting inside an overlap shortens only the now-unfit transition', () {
    final track = [
      ...clips,
    ];
    final playheadMs = 950;
    final layoutBefore = layoutVideoTransitions(
      track.map((clip) => clip.id).toList(),
      track.map((clip) => clip.durationMs).toList(),
      const [
        VideoTransition(
          id: 'ab-short', fromClipId: 'a', toClipId: 'b',
          type: VideoTransitionType.fade, durationMs: 100,
        ),
        VideoTransition(
          id: 'bc-short', fromClipId: 'b', toClipId: 'c',
          type: VideoTransitionType.slide, durationMs: 100,
        ),
      ],
    );
    final split = splitClipAtPosition(
      track,
      'b',
      playheadMs: playheadMs,
      secondClipId: 'b-second',
      sourceDurationMs: 1000,
      clipTimelineStartMsOverride: layoutBefore.startOfClip(1),
    )!;
    final remapped = transitionsAfterClipSplit(
      const [
        VideoTransition(
          id: 'ab-short', fromClipId: 'a', toClipId: 'b',
          type: VideoTransitionType.fade, durationMs: 100,
        ),
        VideoTransition(
          id: 'bc-short', fromClipId: 'b', toClipId: 'c',
          type: VideoTransitionType.slide, durationMs: 100,
        ),
      ],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: split[1].durationMs,
      secondSegmentDurationMs: split[2].durationMs,
    );
    final after = layoutVideoTransitions(
      split.map((clip) => clip.id).toList(),
      split.map((clip) => clip.durationMs).toList(),
      remapped,
    );
    expect(split[1].durationMs, 50);
    expect(after.activeTransitionsByBoundary[0]?.durationMs, 50);
    expect(after.activeTransitionsByBoundary[2]?.durationMs, 100);
    expect(after.totalDurationMs, 2850);
    final landedPosition = timelinePositionAt(
      split,
      after.startOfClip(2),
      transitions: remapped,
    );
    expect(landedPosition?.clipId, 'b-second');
    expect(landedPosition?.sourcePositionMs, 50);
  });

  test('speed-mapped playhead split keeps transition edges on the correct segments', () {
    const rampedTrack = <TimelineClip>[
      TimelineClip(id: 'a', assetId: 'a', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(
        id: 'b',
        assetId: 'b',
        trimStartMs: 0,
        trimEndMs: 1000,
        speedRampPoints: [
          SpeedRampPoint(timeMs: 0, speed: 1),
          SpeedRampPoint(timeMs: 1000, speed: 2),
        ],
      ),
      TimelineClip(id: 'c', assetId: 'c', trimStartMs: 0, trimEndMs: 1000),
    ];
    const transitions = <VideoTransition>[
      VideoTransition(
        id: 'a-b',
        fromClipId: 'a',
        toClipId: 'b',
        type: VideoTransitionType.fade,
        durationMs: 100,
      ),
      VideoTransition(
        id: 'b-c',
        fromClipId: 'b',
        toClipId: 'c',
        type: VideoTransitionType.slide,
        durationMs: 100,
        direction: 'left',
      ),
    ];
    final beforeLayout = layoutVideoTransitions(
      rampedTrack.map((clip) => clip.id).toList(),
      rampedTrack.map((clip) => clip.effectiveDurationMs).toList(),
      transitions,
    );
    final playheadMs = beforeLayout.startOfClip(1) + 50;
    final position = timelinePositionAt(
      rampedTrack,
      playheadMs,
      transitions: transitions,
    )!;
    expect(position.clipId, 'b');
    expect(position.sourcePositionMs, 50);

    final split = splitClipAtPosition(
      rampedTrack,
      position.clipId,
      playheadMs: playheadMs,
      secondClipId: 'b-second',
      sourceDurationMs: 1000,
      sourceSplitPositionMs: position.sourcePositionMs,
    )!;
    final remapped = transitionsAfterClipSplit(
      transitions,
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: split[1].effectiveDurationMs,
      secondSegmentDurationMs: split[2].effectiveDurationMs,
    );

    expect(split[1].trimEndMs, 50);
    expect(split[2].trimStartMs, 50);
    expect(remapped.map((item) => (item.id, item.fromClipId, item.toClipId)), [
      ('a-b', 'a', 'b'),
      ('b-c', 'b-second', 'c'),
    ]);
    expect(remapped.first.durationMs, split[1].effectiveDurationMs);
    expect(remapped.last.durationMs, 100);

    final afterLayout = layoutVideoTransitions(
      split.map((clip) => clip.id).toList(),
      split.map((clip) => clip.effectiveDurationMs).toList(),
      remapped,
    );
    final landedPosition = timelinePositionAt(
      split,
      afterLayout.startOfClip(2),
      transitions: remapped,
    );
    expect(landedPosition?.clipId, 'b-second');
    expect(landedPosition?.sourcePositionMs, 50);
  });

  test('zero-output split segments preserve edge transition data without invalid clamps', () {
    const incoming = VideoTransition(
      id: 'incoming',
      fromClipId: 'a',
      toClipId: 'b',
      type: VideoTransitionType.dissolve,
      durationMs: 120,
      direction: 'up',
      intensity: 0.6,
    );
    const outgoing = VideoTransition(
      id: 'outgoing',
      fromClipId: 'b',
      toClipId: 'c',
      type: VideoTransitionType.spin,
      durationMs: 80,
      direction: 'left',
      intensity: 0.7,
    );

    final remapped = transitionsAfterClipSplit(
      const [incoming, outgoing],
      originalClipId: 'b',
      secondClipId: 'b-second',
      firstSegmentDurationMs: 0,
      secondSegmentDurationMs: 0,
    );

    expect(remapped.map((item) => item.id), ['incoming', 'outgoing']);
    expect(remapped.first.toClipId, 'b');
    expect(remapped.first.durationMs, incoming.durationMs);
    expect(remapped.first.type, incoming.type);
    expect(remapped.first.direction, incoming.direction);
    expect(remapped.first.intensity, incoming.intensity);
    expect(remapped.last.fromClipId, 'b-second');
    expect(remapped.last.durationMs, outgoing.durationMs);
    expect(remapped.last.type, outgoing.type);
    expect(remapped.last.direction, outgoing.direction);
    expect(remapped.last.intensity, outgoing.intensity);

    final layout = layoutVideoTransitions(
      const ['a', 'b', 'b-second', 'c'],
      const [1000, 0, 0, 1000],
      remapped,
    );
    expect(layout.activeTransitionsByBoundary, isEmpty);
  });

  test('apply-to-all clamps safely and omits unsupported catalog types', () {
    final applied = applyTransitionToAllBoundaries(
      clips.map((clip) => clip.id).toList(),
      clips.map((clip) => clip.durationMs).toList(),
      const [],
      type: VideoTransitionType.slide,
      durationMs: 900,
    );
    expect(applied, hasLength(2));
    expect(applied.every((item) => item.durationMs == 500), isTrue);
    expect(
      applyTransitionToAllBoundaries(
        clips.map((clip) => clip.id).toList(),
        clips.map((clip) => clip.durationMs).toList(),
        const [],
        type: VideoTransitionType.blur,
        durationMs: 300,
      ),
      isEmpty,
    );
  });

  test('transition edits persist slide direction and zoom/spin intensity', () {
    final slide = setVideoTransitionSafely(
      videoTrack: clips,
      transitions: const [],
      boundaryIndex: 0,
      type: VideoTransitionType.slide,
      durationMs: 100,
      newTransitionId: 'slide-id',
      direction: 'up',
    );
    expect(slide.accepted, isTrue);
    expect(slide.transitions!.single.direction, 'up');

    final zoom = setVideoTransitionSafely(
      videoTrack: clips,
      transitions: slide.transitions!,
      boundaryIndex: 0,
      type: VideoTransitionType.zoom,
      durationMs: 100,
      newTransitionId: 'unused',
      intensity: 0.35,
    );
    expect(zoom.accepted, isTrue);
    expect(zoom.transitions!.single.intensity, 0.35);
    expect(zoom.transitions!.single.direction, 'up');
  });

}
