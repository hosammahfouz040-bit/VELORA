import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'test_support/target_platform.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/video_filter_presets.dart';
import 'package:velora/src/screens/editor_screen.dart';

const _nativeChannel = MethodChannel('velora/native');

class _NativeRecorder {
  final savedProjects = <Map<String, dynamic>>[];

  void install() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          switch (call.method) {
            case 'saveProject':
              savedProjects.add(Map<String, dynamic>.from(call.arguments as Map));
              return null;
            case 'pausePreview':
            case 'clearPreview':
              return null;
            default:
              throw StateError('Unexpected native call: ${call.method}');
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );
  }
}

VeloraProject _project() => VeloraProject(
      id: 'color-controls',
      name: 'Color controls',
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: const [
        MediaAsset(
          id: 'asset-1',
          uri: 'content://media/video/1',
          name: 'one.mp4',
          mimeType: 'video/mp4',
          kind: MediaKind.video,
          durationMs: 4_000,
          width: 640,
          height: 360,
          sizeBytes: 100,
        ),
        MediaAsset(
          id: 'asset-2',
          uri: 'content://media/video/2',
          name: 'two.mp4',
          mimeType: 'video/mp4',
          kind: MediaKind.video,
          durationMs: 4_000,
          width: 640,
          height: 360,
          sizeBytes: 100,
        ),
      ],
      videoTrack: const [
        TimelineClip(
          id: 'clip-1',
          assetId: 'asset-1',
          trimStartMs: 0,
          trimEndMs: 4_000,
        ),
        TimelineClip(
          id: 'clip-2',
          assetId: 'asset-2',
          trimStartMs: 0,
          trimEndMs: 4_000,
        ),
      ],
      audioTrack: const [],
      colorSettings: VideoColorSettings(
        brightness: 0.25,
        contrast: -0.2,
        saturation: 24,
        warmth: 0.1,
      ),
    );

void main() {
  testWidgetsOnPlatform('edits only the selected clip and supports undo, redo, and reset', TargetPlatform.linux, (
    tester,
  ) async {
    final recorder = _NativeRecorder()..install();

    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();

    expect(find.byKey(const ValueKey('clip-color-controls-clip-1')), findsNothing);
    final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip-1'));
    await tester.ensureVisible(clipTap);
    await tester.tap(clipTap);
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('clip-color-controls-clip-1')), findsOneWidget);
    expect(find.byKey(const ValueKey('clip-color-controls-clip-2')), findsNothing);
    final brightnessKey = const ValueKey('clip-color-slider-brightness-clip-1');
    var brightness = tester.widget<Slider>(find.byKey(brightnessKey));
    expect(brightness.value, 0.25);
    expect(brightness.min, -1);
    expect(brightness.max, 1);
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('clip-color-value-brightness-clip-1')),
      ).data,
      '0.25',
    );
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('clip-color-value-contrast-clip-1')),
      ).data,
      '-0.20',
    );
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('clip-color-value-saturation-clip-1')),
      ).data,
      '24',
    );
    expect(
      tester.widget<Text>(
        find.byKey(const ValueKey('clip-color-value-warmth-clip-1')),
      ).data,
      '0.10',
    );

    brightness.onChanged!(0.7);
    await tester.pump();
    brightness = tester.widget<Slider>(find.byKey(brightnessKey));
    brightness.onChangeEnd!(0.7);
    await tester.pumpAndSettle();

    Map<String, dynamic> savedClip(int index) {
      final track = recorder.savedProjects.last['videoTrack'] as List;
      return Map<String, dynamic>.from(track[index] as Map);
    }

    final firstClipAfterEdit = savedClip(0);
    final override = Map<String, dynamic>.from(
      firstClipAfterEdit['colorSettingsOverride'] as Map,
    );
    expect(override['brightness'], 0.7);
    expect(firstClipAfterEdit.containsKey('colorSettingsOverride'), isTrue);
    expect(savedClip(1).containsKey('colorSettingsOverride'), isFalse);

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(savedClip(0).containsKey('colorSettingsOverride'), isFalse);
    expect(
      tester.widget<Slider>(find.byKey(brightnessKey)).value,
      0.25,
    );

    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(
      Map<String, dynamic>.from(savedClip(0)['colorSettingsOverride'] as Map)
          ['brightness'],
      0.7,
    );

    final resetButton = find.byKey(const ValueKey('clip-color-reset-clip-1'));
    await tester.ensureVisible(resetButton);
    await tester.tap(resetButton);
    await tester.pumpAndSettle();
    expect(savedClip(0).containsKey('colorSettingsOverride'), isFalse);
    expect(savedClip(1).containsKey('colorSettingsOverride'), isFalse);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
    await tester.pump();
  });

  testWidgetsOnPlatform('filter presets set editable per-clip Media3 grades and can be undone', TargetPlatform.linux, (
    tester,
  ) async {
    final recorder = _NativeRecorder()..install();

    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();
    final clipTap = find.byKey(const ValueKey('timeline-video-tap-clip-1'));
    await tester.ensureVisible(clipTap);
    await tester.tap(clipTap);
    await tester.pumpAndSettle();

    final preset = videoFilterPresets.singleWhere((item) => item.id == 'warm');
    final warmChip = find.byKey(const ValueKey('video-filter-warm-clip-1'));
    await tester.ensureVisible(warmChip);
    await tester.tap(warmChip);
    await tester.pumpAndSettle();

    final savedTrack = recorder.savedProjects.last['videoTrack'] as List;
    final selectedClip = Map<String, dynamic>.from(savedTrack.first as Map);
    final override = Map<String, dynamic>.from(
      selectedClip['colorSettingsOverride'] as Map,
    );
    expect(override, preset.settings.toMap());
    expect(
      Map<String, dynamic>.from(savedTrack[1] as Map)
          .containsKey('colorSettingsOverride'),
      isFalse,
    );
    expect(
      tester.widget<Slider>(
        find.byKey(const ValueKey('clip-color-slider-warmth-clip-1')),
      ).value,
      preset.warmth,
    );

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    final undoneTrack = recorder.savedProjects.last['videoTrack'] as List;
    expect(
      Map<String, dynamic>.from(undoneTrack.first as Map)
          .containsKey('colorSettingsOverride'),
      isFalse,
    );

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

}
