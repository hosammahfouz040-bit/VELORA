import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'test_support/target_platform.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/screens/editor_screen.dart';

const _nativeChannel = MethodChannel('velora/native');

class _NativeRecorder {
  final savedProjects = <Map<String, dynamic>>[];
  List<Map<String, dynamic>> pickedMedia = const [];
  Map<String, dynamic>? pickedSticker;
  Map<String, dynamic>? extractedAudio;
  Map<String, dynamic>? extractionArguments;

  void install() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_nativeChannel, (call) async {
          switch (call.method) {
            case 'pickMedia':
              return pickedMedia;
            case 'pickSticker':
              return pickedSticker;
            case 'extractVideoAudio':
              extractionArguments = Map<String, dynamic>.from(call.arguments as Map);
              return extractedAudio;
            case 'saveProject':
              savedProjects.add(Map<String, dynamic>.from(call.arguments as Map));
              return null;
            case 'pausePreview':
            case 'clearPreview':
              return null;
            default:
              throw StateError('Unexpected native call: ${call.method}');
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, null),
    );
  }
}

VeloraProject _project() => VeloraProject(
  id: 'multitrack-editor-test',
  name: 'Multitrack editor test',
  createdAt: '2026-10-28T00:00:00.000Z',
  assets: const [
    MediaAsset(
      id: 'main-asset',
      uri: 'content://media/main',
      name: 'main.mp4',
      mimeType: 'video/mp4',
      kind: MediaKind.video,
      durationMs: 5_000,
      width: 1920,
      height: 1080,
      sizeBytes: 100,
    ),
    MediaAsset(
      id: 'music-asset',
      uri: 'content://media/music',
      name: 'music.mp3',
      mimeType: 'audio/mpeg',
      kind: MediaKind.audio,
      durationMs: 3_000,
      width: 0,
      height: 0,
      sizeBytes: 50,
    ),
  ],
  videoTrack: const [
    TimelineClip(
      id: 'main-clip',
      assetId: 'main-asset',
      trimStartMs: 0,
      trimEndMs: 5_000,
    ),
  ],
  audioTrack: const [
    TimelineClip(
      id: 'music-clip',
      assetId: 'music-asset',
      trimStartMs: 0,
      trimEndMs: 3_000,
      timelineStartMs: 500,
      volume: 0.6,
    ),
  ],
);

Map<String, dynamic> _lastAudioClip(_NativeRecorder recorder) {
  final track = recorder.savedProjects.last['audioTrack'] as List;
  return Map<String, dynamic>.from(track.single as Map);
}

Map<String, dynamic> _lastVideoClip(_NativeRecorder recorder) {
  final track = recorder.savedProjects.last['videoTrack'] as List;
  return Map<String, dynamic>.from(track.single as Map);
}

Map<String, dynamic> _lastTextOverlay(_NativeRecorder recorder) {
  final rows = recorder.savedProjects.last['textOverlays'] as List;
  return Map<String, dynamic>.from(rows.last as Map);
}

Map<String, dynamic> _lastStickerOverlay(_NativeRecorder recorder) {
  final rows = recorder.savedProjects.last['stickerOverlays'] as List;
  return Map<String, dynamic>.from(rows.last as Map);
}

Map<String, dynamic> _lastOverlayClip(_NativeRecorder recorder) {
  final tracks = recorder.savedProjects.last['videoOverlayTracks'] as List;
  final firstTrack = Map<String, dynamic>.from(tracks.first as Map);
  final clips = firstTrack['clips'] as List;
  return Map<String, dynamic>.from(clips.first as Map);
}

Finder _editorScrollable() => find
    .descendant(
      of: find.byKey(const ValueKey('editor-screen-scroll')),
      matching: find.byType(Scrollable),
    )
    .first;

Future<void> _scrollTo(
  WidgetTester tester,
  Finder finder, {
  double delta = 240,
}) async {
  await tester.scrollUntilVisible(
    finder,
    delta,
    scrollable: _editorScrollable(),
  );
  await tester.pumpAndSettle();
}

Future<void> _setSlider(
  WidgetTester tester,
  ValueKey<String> key,
  double value,
) async {
  final finder = find.byKey(key);
  await tester.ensureVisible(finder);
  await tester.pumpAndSettle();
  var slider = tester.widget<Slider>(finder);
  slider.onChanged!(value);
  await tester.pump();
  slider = tester.widget<Slider>(finder);
  slider.onChangeEnd!(value);
  await tester.pumpAndSettle();
}

void main() {
  testWidgetsOnPlatform('adds a real video overlay layer and edits its timing with history', TargetPlatform.linux, (
    tester,
  ) async {
    final recorder = _NativeRecorder()
      ..pickedMedia = const [
        {
          'id': 'overlay-asset',
          'uri': 'content://media/overlay',
          'name': 'overlay.mp4',
          'mimeType': 'video/mp4',
          'kind': 'video',
          'durationMs': 3_000,
          'width': 1280,
          'height': 720,
          'sizeBytes': 90,
        },
      ]
      ..install();

    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();
    await tester.tap(find.byKey(const ValueKey('add-video-overlay-button')));
    await tester.pumpAndSettle();

    expect(recorder.savedProjects, isNotEmpty);
    expect((recorder.savedProjects.last['videoTrack'] as List), hasLength(1));
    expect((recorder.savedProjects.last['videoOverlayTracks'] as List), hasLength(1));
    var overlay = _lastOverlayClip(recorder);
    expect(overlay['assetId'], 'overlay-asset');
    expect(overlay['timelineStartMs'], 0);
    expect(overlay['trimEndMs'], 3_000);
    final overlayControls =
        find.byKey(ValueKey('video-overlay-controls-${overlay['id']}'));
    await _scrollTo(tester, overlayControls);
    expect(overlayControls, findsOneWidget);

    await _setSlider(
      tester,
      ValueKey('video-overlay-start-${overlay['id']}'),
      1_000,
    );
    expect(_lastOverlayClip(recorder)['timelineStartMs'], 1_000);
    await _setSlider(
      tester,
      ValueKey('video-overlay-duration-${overlay['id']}'),
      2_000,
    );
    overlay = _lastOverlayClip(recorder);
    expect(overlay['timelineStartMs'], 1_000);
    expect(overlay['trimStartMs'], 0);
    expect(overlay['trimEndMs'], 2_000);

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastOverlayClip(recorder)['trimEndMs'], 3_000);
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(_lastOverlayClip(recorder)['trimEndMs'], 2_000);
  });

  testWidgetsOnPlatform('moves, trims, and changes audio volume with undo and redo', TargetPlatform.linux, (
    tester,
  ) async {
    final recorder = _NativeRecorder()..install();

    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();
    final audioBlock = find.byKey(const ValueKey('timeline-audio-music-clip'));
    await _scrollTo(tester, audioBlock);
    await tester.tap(audioBlock);
    await tester.pumpAndSettle();
    final audioControls =
        find.byKey(const ValueKey('audio-clip-controls-music-clip'));
    await _scrollTo(tester, audioControls);
    expect(audioControls, findsOneWidget);

    await _setSlider(
      tester,
      const ValueKey('audio-timeline-start-music-clip'),
      1_500,
    );
    expect(_lastAudioClip(recorder)['timelineStartMs'], 1_500);
    await _setSlider(
      tester,
      const ValueKey('audio-duration-music-clip'),
      2_000,
    );
    expect(_lastAudioClip(recorder)['trimEndMs'], 2_000);
    await _setSlider(
      tester,
      const ValueKey('audio-source-start-music-clip'),
      500,
    );
    expect(_lastAudioClip(recorder)['trimStartMs'], 500);
    expect(_lastAudioClip(recorder)['trimEndMs'], 2_500);
    await _setSlider(
      tester,
      const ValueKey('audio-volume-music-clip'),
      0.25,
    );
    expect(_lastAudioClip(recorder)['volume'], 0.25);
    await _setSlider(
      tester,
      const ValueKey('audio-fade-in-music-clip'),
      300,
    );
    expect(_lastAudioClip(recorder)['fadeInMs'], 300);
    await _setSlider(
      tester,
      const ValueKey('audio-fade-out-music-clip'),
      450,
    );
    expect(_lastAudioClip(recorder)['fadeOutMs'], 450);

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastAudioClip(recorder)['fadeOutMs'], 0);
    expect(_lastAudioClip(recorder)['fadeInMs'], 300);
    expect(_lastAudioClip(recorder)['volume'], 0.25);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastAudioClip(recorder)['fadeInMs'], 0);
    expect(_lastAudioClip(recorder)['volume'], 0.25);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastAudioClip(recorder)['volume'], 0.6);
    expect(_lastAudioClip(recorder)['timelineStartMs'], 1_500);

    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(_lastAudioClip(recorder)['volume'], 0.25);
    expect(_lastAudioClip(recorder)['fadeInMs'], 300);
    expect(_lastAudioClip(recorder)['fadeOutMs'], 450);
    expect(_lastAudioClip(recorder)['trimStartMs'], 500);
    expect(_lastAudioClip(recorder)['trimEndMs'], 2_500);
  });

  testWidgetsOnPlatform('edits embedded video audio level and fades with undo and redo', TargetPlatform.linux, (tester) async {
    final recorder = _NativeRecorder()..install();
    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();

    final videoTile = find.byKey(const ValueKey('timeline-video-tap-main-clip'));
    await _scrollTo(tester, videoTile);
    await tester.tap(videoTile);
    await tester.pumpAndSettle();
    await _setSlider(
      tester,
      const ValueKey('video-audio-volume-main-clip'),
      0.4,
    );
    expect(_lastVideoClip(recorder)['volume'], 0.4);
    await _setSlider(
      tester,
      const ValueKey('video-audio-fade-in-main-clip'),
      200,
    );
    expect(_lastVideoClip(recorder)['fadeInMs'], 200);
    await _setSlider(
      tester,
      const ValueKey('video-audio-fade-out-main-clip'),
      350,
    );
    expect(_lastVideoClip(recorder)['fadeOutMs'], 350);

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastVideoClip(recorder)['fadeOutMs'], 0);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastVideoClip(recorder)['fadeInMs'], 0);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastVideoClip(recorder)['volume'], 1.0);

    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(_lastVideoClip(recorder)['volume'], 0.4);
    expect(_lastVideoClip(recorder)['fadeInMs'], 200);
    expect(_lastVideoClip(recorder)['fadeOutMs'], 350);
  });

  testWidgetsOnPlatform('extracts selected video sound into an independent editable audio clip', TargetPlatform.linux, (tester) async {
    final recorder = _NativeRecorder()
      ..extractedAudio = const {
        'id': 'extracted-audio-test',
        'uri': 'file:///app/VELORA/ExtractedAudio/clip.m4a',
        'name': 'main - الصوت المستخرج.m4a',
        'mimeType': 'audio/mp4',
        'kind': 'audio',
        'durationMs': 2_500,
        'width': 0,
        'height': 0,
        'sizeBytes': 80,
      }
      ..install();
    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();

    final videoTile = find.byKey(const ValueKey('timeline-video-tap-main-clip'));
    await _scrollTo(tester, videoTile);
    await tester.tap(videoTile);
    await tester.pumpAndSettle();
    final extractButton = find.byKey(const ValueKey('extract-video-audio-main-clip'));
    await _scrollTo(tester, extractButton);
    await tester.tap(extractButton);
    await tester.pumpAndSettle();
    expect(recorder.extractionArguments?['asset'], isA<Map>());
    expect(
      Map<String, dynamic>.from(recorder.extractionArguments!['asset'] as Map)['id'],
      'main-asset',
    );
    expect(
      Map<String, dynamic>.from(recorder.extractionArguments!['clip'] as Map)['id'],
      'main-clip',
    );

    final saved = recorder.savedProjects.last;
    final videoTrack = saved['videoTrack'] as List;
    expect(videoTrack, hasLength(1));
    expect(Map<String, dynamic>.from(videoTrack.single as Map)['id'], 'main-clip');
    final audioTrack = saved['audioTrack'] as List;
    expect(audioTrack, hasLength(2));
    final extractedClip = audioTrack
        .map((item) => Map<String, dynamic>.from(item as Map))
        .singleWhere((clip) => clip['assetId'] == 'extracted-audio-test');
    expect(extractedClip['timelineStartMs'], 0);
    expect(extractedClip['trimStartMs'], 0);
    expect(extractedClip['trimEndMs'], 2_500);
    expect(extractedClip['volume'], 1.0);
    final assets = saved['assets'] as List;
    expect(
      assets.map((asset) => Map<String, dynamic>.from(asset as Map))
          .any((asset) => asset['id'] == 'extracted-audio-test' && asset['kind'] == 'audio'),
      isTrue,
    );

    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(recorder.savedProjects.last['audioTrack'], hasLength(1));
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(recorder.savedProjects.last['audioTrack'], hasLength(2));
  });

  testWidgetsOnPlatform('creates editable text and sticker overlays and records their settings', TargetPlatform.linux, (tester) async {
    final recorder = _NativeRecorder()
      ..pickedSticker = const {
        'id': 'sticker-asset',
        'uri': 'content://stickers/star.png',
        'name': 'star.png',
        'mimeType': 'image/png',
        'kind': 'image',
        'durationMs': 0,
        'width': 512,
        'height': 512,
        'sizeBytes': 120,
      }
      ..install();
    await tester.pumpWidget(MaterialApp(home: EditorScreen(project: _project())));
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('add-text-overlay-button')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const ValueKey('overlay-text-input')), 'عنوان تجريبي');
    await tester.tap(find.text('تم'));
    await tester.pumpAndSettle();
    var text = _lastTextOverlay(recorder);
    expect(text['text'], 'عنوان تجريبي');
    expect(text['templateId'], 'classic');
    expect(text['fontFamily'], 'sans-serif');
    final textId = text['id'] as String;
    await _scrollTo(tester, find.byKey(ValueKey('text-overlay-controls-$textId')));
    await tester.tap(find.byKey(ValueKey('edit-overlay-text-$textId')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const ValueKey('overlay-text-input')), 'عنوان بعد التعديل');
    await tester.tap(find.text('تم'));
    await tester.pumpAndSettle();
    expect(_lastTextOverlay(recorder)['text'], 'عنوان بعد التعديل');
    await _setSlider(tester, ValueKey('overlay-font-size-$textId'), 0.08);
    expect(_lastTextOverlay(recorder)['fontSizeScale'], 0.08);
    final fontField = find.byKey(ValueKey('overlay-font-$textId'));
    await _scrollTo(tester, fontField);
    await tester.tap(fontField);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Serif').last);
    await tester.pumpAndSettle();
    expect(_lastTextOverlay(recorder)['fontFamily'], 'serif');
    await _setSlider(tester, ValueKey('text-overlay-start-$textId'), 1_000);
    text = _lastTextOverlay(recorder);
    expect(text['startMs'], 1_000);
    expect(text['endMs'], 4_000);
    final deleteText = find.byTooltip('حذف النص');
    await tester.ensureVisible(deleteText);
    await tester.tap(deleteText);
    await tester.pumpAndSettle();
    expect(recorder.savedProjects.last['textOverlays'], isEmpty);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect((recorder.savedProjects.last['textOverlays'] as List), hasLength(1));

    final addEmoji = find.byKey(const ValueKey('add-emoji-overlay-button'));
    await _scrollTo(tester, addEmoji, delta: -240);
    await tester.tap(addEmoji);
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('🔥'));
    await tester.pumpAndSettle();
    final emojiOverlay = _lastTextOverlay(recorder);
    expect(emojiOverlay['text'], '🔥');
    expect(emojiOverlay['templateId'], 'emoji');
    expect(emojiOverlay['fontSizeScale'], 0.14);

    final addSticker = find.byKey(const ValueKey('add-sticker-overlay-button'));
    await _scrollTo(tester, addSticker, delta: -240);
    await tester.tap(addSticker);
    await tester.pumpAndSettle();
    final sticker = _lastStickerOverlay(recorder);
    expect(sticker['uri'], 'content://stickers/star.png');
    expect(sticker['startMs'], 0);
    expect(sticker['endMs'], 3_000);
    final stickerId = sticker['id'] as String;
    await _setSlider(tester, ValueKey('sticker-x-$stickerId'), 0.75);
    expect(_lastStickerOverlay(recorder)['positionX'], 0.75);
    await tester.tap(find.byTooltip('تراجع'));
    await tester.pumpAndSettle();
    expect(_lastStickerOverlay(recorder)['positionX'], 0.5);
    await tester.tap(find.byTooltip('إعادة'));
    await tester.pumpAndSettle();
    expect(_lastStickerOverlay(recorder)['positionX'], 0.75);
  });
}
