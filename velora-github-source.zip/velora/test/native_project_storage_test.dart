import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/services/native_bridge.dart';

const _nativeChannel = MethodChannel('velora/native');

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'invalid project rows do not prevent other saved projects from loading',
    () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(_nativeChannel, (call) async {
            if (call.method != 'listProjects') {
              throw StateError('Unexpected native method ${call.method}');
            }
            return [
              {
                'id': 'valid-project',
                'name': 'مشروع صالح',
                'assets': <Object?>[],
                'videoTrack': <Object?>[],
                'audioTrack': <Object?>[],
              },
              {'id': 42, 'assets': 'not-a-list'},
              '{truncated json row}',
            ];
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(_nativeChannel, null),
      );

      final projects = await NativeBridge.listProjects();

      expect(projects.map((project) => project.id).toList(), ['valid-project']);
    },
  );
}
