/// Transition designs exposed by VELORA. Wipe and Blur remain catalogued but
/// unavailable until both preview and Transformer can render them faithfully.
enum VideoTransitionType {
  fade,
  dissolve,
  wipe,
  slide,
  zoom,
  blur,
  spin;

  bool get supported => switch (this) {
    VideoTransitionType.fade ||
    VideoTransitionType.dissolve ||
    VideoTransitionType.slide ||
    VideoTransitionType.zoom ||
    VideoTransitionType.spin => true,
    VideoTransitionType.wipe || VideoTransitionType.blur => false,
  };

  String get category => switch (this) {
    VideoTransitionType.fade || VideoTransitionType.dissolve => 'أساسي',
    VideoTransitionType.wipe || VideoTransitionType.slide => 'حركة',
    VideoTransitionType.zoom || VideoTransitionType.blur || VideoTransitionType.spin => 'سينمائي',
  };

  String get label => switch (this) {
    VideoTransitionType.fade => 'تلاشي عبر الأسود',
    VideoTransitionType.dissolve => 'ذوبان متقاطع',
    VideoTransitionType.wipe => 'مسح',
    VideoTransitionType.slide => 'انزلاق',
    VideoTransitionType.zoom => 'تكبير',
    VideoTransitionType.blur => 'تمويه',
    VideoTransitionType.spin => 'دوران',
  };

  String get description => switch (this) {
    VideoTransitionType.fade => 'يخفت الأول إلى الأسود ثم يظهر التالي.',
    VideoTransitionType.dissolve => 'يمتزج المقطعان تدريجيًا خلال تداخل زمني.',
    VideoTransitionType.wipe => 'يحتاج قناعًا مكانيًا متحركًا غير متاح في Compositor الحالي.',
    VideoTransitionType.slide => 'يدفع المقطع التالي السابق بحركة انزلاق.',
    VideoTransitionType.zoom => 'يكشف التالي بتكبير متحرك.',
    VideoTransitionType.blur => 'يتطلب تمويهًا زمنيًا مخصصًا غير متاح حاليًا.',
    VideoTransitionType.spin => 'يكشف التالي بدوران متحرك.',
  };
}

/// A transition belongs to the cut between two adjacent visual clips.
class VideoTransition {
  const VideoTransition({
    required this.id,
    required this.fromClipId,
    required this.toClipId,
    required this.type,
    required this.durationMs,
    this.direction = 'right',
    this.intensity = 1,
  });

  final String id;
  final String fromClipId;
  final String toClipId;
  final VideoTransitionType type;
  final int durationMs;
  /// Used by directional transitions: left, right, up, or down.
  final String direction;
  /// Normalized effect strength in the range 0..1.
  final double intensity;

  VideoTransition copyWith({
    VideoTransitionType? type,
    int? durationMs,
    String? direction,
    double? intensity,
  }) => VideoTransition(
    id: id,
    fromClipId: fromClipId,
    toClipId: toClipId,
    type: type ?? this.type,
    durationMs: (durationMs ?? this.durationMs).clamp(1, 1 << 53).toInt(),
    direction: _transitionDirection(direction ?? this.direction),
    intensity: _transitionUnit(intensity ?? this.intensity),
  );

  factory VideoTransition.fromMap(Map<String, dynamic> map) {
    final typeName = map['type']?.toString();
    return VideoTransition(
      id: map['id']?.toString() ?? _transitionId(),
      fromClipId: map['fromClipId']?.toString() ?? '',
      toClipId: map['toClipId']?.toString() ?? '',
      type: VideoTransitionType.values.firstWhere(
        (value) => value.name == typeName,
        orElse: () => VideoTransitionType.fade,
      ),
      durationMs: ((map['durationMs'] as num?)?.toInt() ?? 300)
          .clamp(1, 1 << 53)
          .toInt(),
      direction: _transitionDirection(map['direction']?.toString() ?? 'right'),
      intensity: _transitionUnit((map['intensity'] as num?)?.toDouble() ?? 1),
    );
  }

  Map<String, Object> toMap() => {
    'id': id,
    'fromClipId': fromClipId,
    'toClipId': toClipId,
    'type': type.name,
    'durationMs': durationMs,
    'direction': direction,
    'intensity': intensity,
  };
}

class TransitionTimelineLayout {
  const TransitionTimelineLayout({
    required this.clipStartsMs,
    required this.activeTransitionsByBoundary,
    required this.totalDurationMs,
  });

  final List<int> clipStartsMs;
  final Map<int, VideoTransition> activeTransitionsByBoundary;
  final int totalDurationMs;

  int startOfClip(int index) => clipStartsMs[index];
}

TransitionTimelineLayout layoutVideoTransitions(
  List<String> clipIds,
  List<int> clipDurationsMs,
  List<VideoTransition> transitions,
) {
  final count = clipIds.length < clipDurationsMs.length ? clipIds.length : clipDurationsMs.length;
  final durations = clipDurationsMs
      .take(count)
      .map((value) => value.clamp(0, 1 << 53).toInt())
      .toList();
  final byBoundary = <int, VideoTransition>{};
  final occupiedMs = List<int>.filled(count, 0);
  for (var boundary = 0; boundary + 1 < count; boundary++) {
    final candidate = _transitionAt(transitions, clipIds[boundary], clipIds[boundary + 1]);
    if (candidate == null || !candidate.type.supported || durations[boundary] <= 0 || durations[boundary + 1] <= 0) continue;
    final duration = candidate.durationMs;
    if (duration <= 0 || duration > durations[boundary] || duration > durations[boundary + 1]) continue;
    if (occupiedMs[boundary] + duration > durations[boundary] ||
        occupiedMs[boundary + 1] + duration > durations[boundary + 1]) {
      continue;
    }
    byBoundary[boundary] = candidate;
    occupiedMs[boundary] += duration;
    occupiedMs[boundary + 1] += duration;
  }

  final starts = List<int>.filled(count, 0);
  var cursor = 0;
  for (var index = 0; index < count; index++) {
    starts[index] = cursor;
    cursor += durations[index];
    final transition = byBoundary[index];
    if (transition != null) cursor -= transition.durationMs;
  }
  final total = count == 0 ? 0 : (starts.last + durations.last).clamp(0, 1 << 53).toInt();
  return TransitionTimelineLayout(
    clipStartsMs: starts,
    activeTransitionsByBoundary: byBoundary,
    totalDurationMs: total,
  );
}

/// Maps project-time overlays through the compression introduced by overlaps.
/// The 2D neighbourhood around each cut maps to the D-ms overlap window.
int mapTransitionTimelineMs(
  int originalMs,
  List<String> clipIds,
  List<int> clipDurationsMs,
  List<VideoTransition> transitions,
) {
  final layout = layoutVideoTransitions(clipIds, clipDurationsMs, transitions);
  var originalCutMs = 0;
  var compressedBeforeMs = 0;
  for (var boundary = 0; boundary + 1 < clipIds.length; boundary++) {
    final duration = clipDurationsMs[boundary].clamp(0, 1 << 53).toInt();
    originalCutMs += duration;
    final transition = layout.activeTransitionsByBoundary[boundary];
    if (transition == null) continue;
    final overlap = transition.durationMs;
    final start = originalCutMs - overlap;
    final end = originalCutMs + overlap;
    if (originalMs <= start) break;
    if (originalMs < end) {
      final progressMs = originalMs - start;
      return (start - compressedBeforeMs + progressMs ~/ 2)
          .clamp(0, layout.totalDurationMs)
          .toInt();
    }
    compressedBeforeMs += overlap;
  }
  return (originalMs - compressedBeforeMs).clamp(0, layout.totalDurationMs).toInt();
}

/// Inverse mapping for timeline controls: converts composition-clock edits back
/// to the stable, pre-transition project clock used by stored overlays.
int unmapTransitionTimelineMs(
  int compositionMs,
  List<String> clipIds,
  List<int> clipDurationsMs,
  List<VideoTransition> transitions,
) {
  final layout = layoutVideoTransitions(clipIds, clipDurationsMs, transitions);
  var originalCutMs = 0;
  var compressedBeforeMs = 0;
  for (var boundary = 0; boundary + 1 < clipIds.length; boundary++) {
    originalCutMs += clipDurationsMs[boundary].clamp(0, 1 << 53).toInt();
    final transition = layout.activeTransitionsByBoundary[boundary];
    if (transition == null) continue;
    final overlap = transition.durationMs;
    final outputStart = originalCutMs - compressedBeforeMs - overlap;
    final outputEnd = outputStart + overlap;
    if (compositionMs <= outputStart) break;
    if (compositionMs < outputEnd) {
      return originalCutMs - overlap + (compositionMs - outputStart) * 2;
    }
    compressedBeforeMs += overlap;
  }
  return (compositionMs + compressedBeforeMs).clamp(0, 1 << 53).toInt();
}

/// Keeps transitions attached to the edges of a split clip: incoming remains
/// on the first segment and outgoing moves to the second. An edge transition
/// is shortened only when its adjacent new segment is too short to contain it.
List<VideoTransition> transitionsAfterClipSplit(
  List<VideoTransition> transitions, {
  required String originalClipId,
  required String secondClipId,
  required int firstSegmentDurationMs,
  required int secondSegmentDurationMs,
}) => [
  for (final transition in transitions)
    if (transition.toClipId == originalClipId)
      VideoTransition(
        id: transition.id,
        fromClipId: transition.fromClipId,
        toClipId: originalClipId,
        type: transition.type,
        durationMs: transition.durationMs <= 0 || firstSegmentDurationMs <= 0
            ? transition.durationMs
            : transition.durationMs.clamp(1, firstSegmentDurationMs).toInt(),
        direction: transition.direction,
        intensity: transition.intensity,
      )
    else if (transition.fromClipId == originalClipId)
      VideoTransition(
        id: transition.id,
        fromClipId: secondClipId,
        toClipId: transition.toClipId,
        type: transition.type,
        durationMs: transition.durationMs <= 0 || secondSegmentDurationMs <= 0
            ? transition.durationMs
            : transition.durationMs.clamp(1, secondSegmentDurationMs).toInt(),
        direction: transition.direction,
        intensity: transition.intensity,
      )
    else
      transition,
];

/// Reports whether applying a split preserves every existing transition's
/// duration and remapped endpoints without changing the composition duration.
/// Outgoing transitions move to [secondClipId]; incoming transitions remain
/// attached to [originalClipId].
bool splitPreservesTransitionSchedule({
  required List<VideoTransition> originalTransitions,
  required List<VideoTransition> splitTransitions,
  required String originalClipId,
  required String secondClipId,
  required int originalTimelineDurationMs,
  required int splitTimelineDurationMs,
}) {
  if (splitTransitions.length != originalTransitions.length ||
      splitTimelineDurationMs != originalTimelineDurationMs) {
    return false;
  }

  final matchedIndexes = <int>{};
  for (final original in originalTransitions) {
    var matchIndex = -1;
    for (var index = 0; index < splitTransitions.length; index++) {
      if (!matchedIndexes.contains(index) &&
          splitTransitions[index].id == original.id) {
        matchIndex = index;
        break;
      }
    }
    if (matchIndex < 0) return false;

    matchedIndexes.add(matchIndex);
    final splitTransition = splitTransitions[matchIndex];
    final expectedFromClipId = original.fromClipId == originalClipId
        ? secondClipId
        : original.fromClipId;
    if (splitTransition.fromClipId != expectedFromClipId ||
        splitTransition.toClipId != original.toClipId ||
        splitTransition.durationMs < original.durationMs) {
      return false;
    }
  }
  return matchedIndexes.length == splitTransitions.length;
}

List<VideoTransition> applyTransitionToAllBoundaries(
  List<String> clipIds,
  List<int> clipDurationsMs,
  List<VideoTransition> existing, {
  required VideoTransitionType type,
  required int durationMs,
}) {
  final count = clipIds.length < clipDurationsMs.length ? clipIds.length : clipDurationsMs.length;
  if (!type.supported || count < 2) return existing;
  final halfShortestClip = clipDurationsMs.take(count).fold<int>(
    1 << 53,
    (current, value) => value < current ? value : current,
  ) ~/ 2;
  if (halfShortestClip <= 0) return const [];
  final safeDuration = durationMs.clamp(1, halfShortestClip).toInt();
  return [
    for (var boundary = 0; boundary + 1 < count; boundary++)
      VideoTransition(
        id: 'transition_${clipIds[boundary]}_${clipIds[boundary + 1]}',
        fromClipId: clipIds[boundary],
        toClipId: clipIds[boundary + 1],
        type: type,
        durationMs: safeDuration,
      ),
  ];
}

VideoTransition? _transitionAt(
  List<VideoTransition> transitions,
  String fromClipId,
  String toClipId,
) {
  for (final transition in transitions) {
    if (transition.fromClipId == fromClipId && transition.toClipId == toClipId) {
      return transition;
    }
  }
  return null;
}

String _transitionDirection(String value) =>
    const {'left', 'right', 'up', 'down'}.contains(value) ? value : 'right';

double _transitionUnit(double value) =>
    value.isFinite ? value.clamp(0, 1).toDouble() : 1;

String _transitionId() => 'transition_${DateTime.now().microsecondsSinceEpoch}';
