package com.velora.app

import android.graphics.Matrix
import androidx.media3.common.Effect
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation

/** The persisted project-level framing values used by both preview and export. */
internal data class ProjectFrameSettings(
    val aspectRatio: String = "source",
    val fitMode: String = "fit",
    val positionX: Float = 0f,
    val positionY: Float = 0f,
    val rotationQuarterTurns: Int = 0,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
) {
    val targetAspectRatio: Float?
        get() = when (aspectRatio) {
            "9:16" -> 9f / 16f
            "16:9" -> 16f / 9f
            "1:1" -> 1f
            "4:5" -> 4f / 5f
            else -> null
        }

    companion object {
        fun fromMap(raw: Any?): ProjectFrameSettings {
            val map = raw as? Map<*, *> ?: return ProjectFrameSettings()
            val ratio = map["aspectRatio"]?.toString()?.takeIf {
                it in setOf("source", "9:16", "16:9", "1:1", "4:5")
            } ?: "source"
            fun offset(key: String): Float {
                val value = (map[key] as? Number)?.toFloat() ?: 0f
                return if (value.isFinite()) value.coerceIn(-1f, 1f) else 0f
            }
            val turns = (map["rotationQuarterTurns"] as? Number)?.toInt() ?: 0
            return ProjectFrameSettings(
                aspectRatio = ratio,
                fitMode = if (map["fitMode"]?.toString() == "fill") "fill" else "fit",
                positionX = offset("positionX"),
                positionY = offset("positionY"),
                rotationQuarterTurns = ((turns % 4) + 4) % 4,
                flipHorizontal = map["flipHorizontal"] as? Boolean ?: false,
                flipVertical = map["flipVertical"] as? Boolean ?: false,
            )
        }
    }
}

/**
 * Builds the same Media3 Effect objects for ExoPlayer preview and Transformer.
 * The final matrix maps the rotated input into a fixed-ratio output canvas while
 * keeping the requested fit/fill and pan values.
 */
@UnstableApi
internal object ProjectFrameEffects {
    fun createPreview(settings: ProjectFrameSettings): List<Effect> {
        if (
            settings.aspectRatio == "source" &&
            settings.rotationQuarterTurns == 0 &&
            !settings.flipHorizontal &&
            !settings.flipVertical
        ) return emptyList()
        return create(settings, 720)
    }

    fun create(settings: ProjectFrameSettings, outputHeight: Int): List<Effect> {
        require(outputHeight > 0) { "Output height must be positive" }
        val effects = createOrientationEffects(settings).toMutableList()
        val targetAspect = settings.targetAspectRatio
        if (targetAspect == null) {
            // This is exactly the pre-framing export behavior for old projects.
            effects += Presentation.createForHeight(outputHeight)
        } else {
            effects += ProjectFrameTransformation(
                targetAspectRatio = targetAspect,
                fill = settings.fitMode == "fill",
                positionX = settings.positionX,
                positionY = settings.positionY,
                outputHeight = outputHeight,
            )
        }
        return effects
    }

    /** Rotate/flip PIP source content without applying the main frame's crop to it. */
    fun createOverlay(settings: ProjectFrameSettings, outputHeight: Int): List<Effect> {
        require(outputHeight > 0) { "Output height must be positive" }
        return createOrientationEffects(settings) + Presentation.createForHeight(outputHeight)
    }

    private fun createOrientationEffects(settings: ProjectFrameSettings): List<Effect> {
        val effects = mutableListOf<Effect>()
        // The editor stores clockwise turns; Media3's rotation is counterclockwise.
        val rotation = ((4 - settings.rotationQuarterTurns) % 4) * 90f
        if (rotation != 0f) {
            effects += ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(rotation)
                .build()
        }
        // Apply flips after rotation so horizontal/vertical mean the final frame axes.
        if (settings.flipHorizontal || settings.flipVertical) {
            effects += ScaleAndRotateTransformation.Builder()
                .setScale(
                    if (settings.flipHorizontal) -1f else 1f,
                    if (settings.flipVertical) -1f else 1f,
                )
                .build()
        }
        return effects
    }
}

@UnstableApi
private class ProjectFrameTransformation(
    private val targetAspectRatio: Float,
    private val fill: Boolean,
    private val positionX: Float,
    private val positionY: Float,
    private val outputHeight: Int,
) : MatrixTransformation {
    private var matrix = Matrix()

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        require(inputWidth > 0 && inputHeight > 0) { "Input frame dimensions must be positive" }
        val inputAspect = inputWidth.toFloat() / inputHeight
        var scaleX = 1f
        var scaleY = 1f
        if (fill) {
            if (inputAspect > targetAspectRatio) {
                scaleX = inputAspect / targetAspectRatio
            } else {
                scaleY = targetAspectRatio / inputAspect
            }
        } else if (inputAspect > targetAspectRatio) {
            scaleY = targetAspectRatio / inputAspect
        } else {
            scaleX = inputAspect / targetAspectRatio
        }
        val translateX = (1f - scaleX) * positionX
        val translateY = (1f - scaleY) * positionY
        matrix = Matrix().apply {
            setScale(scaleX, scaleY)
            postTranslate(translateX, translateY)
        }
        val width = (
            kotlin.math.floor(
                (outputHeight * targetAspectRatio / 2f + 0.5f).toDouble(),
            ).toInt() * 2
        ).coerceAtLeast(2)
        return Size(width, outputHeight)
    }

    override fun getMatrix(presentationTimeUs: Long): Matrix = Matrix(matrix)

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean = false
}
