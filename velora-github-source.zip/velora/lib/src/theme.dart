import 'package:flutter/material.dart';

const Color veloraInk = Color(0xFF111923);
const Color veloraPanel = Color(0xFF1B2733);
const Color veloraGold = Color(0xFFD6A756);
const Color veloraCanvas = Color(0xFF0B1118);
