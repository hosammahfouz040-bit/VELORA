import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';

VeloraProject _project(String name, {List<TimelineClip>? videoTrack}) =>
    VeloraProject(
      id: 'history-project',
      name: name,
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: const [
        MediaAsset(
          id: 'asset',
          uri: 'content://media/video/1',
          name: 'clip.mp4',
          mimeType: 'video/mp4',
          kind: MediaKind.video,
          durationMs: 5000,
          width: 1920,
          height: 1080,
          sizeBytes: 100,
        ),
      ],
      videoTrack: videoTrack ?? const [],
      audioTrack: const [],
    );

void main() {
  test('undo and redo restore complete project snapshots', () {
    final first = _project('first');
    final clip = const TimelineClip(
      id: 'clip',
      assetId: 'asset',
      trimStartMs: 0,
      trimEndMs: 3000,
    );
    final second = _project('second', videoTrack: [clip]);
    final third = second.copyWith(
      videoTrack: [clip.copyWith(trimStartMs: 500)],
    );
    final history = ProjectHistory(first);

    expect(history.canUndo, isFalse);
    expect(history.canRedo, isFalse);
    history.record(second);
    history.record(third);
    expect(history.canUndo, isTrue);
    expect(history.undo()!.videoTrack.single.trimStartMs, 0);
    expect(history.undo()!.name, 'first');
    expect(history.undo(), isNull);
    expect(history.canRedo, isTrue);
    expect(history.redo()!.name, 'second');
    expect(history.redo()!.videoTrack.single.trimStartMs, 500);
    expect(history.redo(), isNull);
  });

  test('new edit after undo discards redo branch', () {
    final history = ProjectHistory(_project('one'));
    history.record(_project('two'));
    history.record(_project('three'));

    expect(history.undo()!.name, 'two');
    history.record(_project('branch'));

    expect(history.canRedo, isFalse);
    expect(history.undo()!.name, 'two');
    expect(history.redo()!.name, 'branch');
  });

  test('snapshots isolate mutable project lists and retain project data', () {
    final mutableTrack = <TimelineClip>[
      const TimelineClip(
        id: 'original',
        assetId: 'asset',
        trimStartMs: 0,
        trimEndMs: 2500,
      ),
    ];
    final initial = _project('saved', videoTrack: mutableTrack);
    final history = ProjectHistory(initial);
    mutableTrack.add(
      const TimelineClip(
        id: 'later-mutation',
        assetId: 'asset',
        trimStartMs: 2500,
        trimEndMs: 5000,
      ),
    );
    history.record(_project('edited'));

    final restored = history.undo()!;
    expect(restored.name, 'saved');
    expect(restored.videoTrack, hasLength(1));
    expect(restored.videoTrack.single.id, 'original');
    expect(restored.assets.single.uri, 'content://media/video/1');
  });

  test('undo and redo preserve visual order and all audio clips across edits', () {
    const firstVisual = TimelineClip(
      id: 'visual-1',
      assetId: 'asset',
      trimStartMs: 0,
      trimEndMs: 1000,
    );
    const secondVisual = TimelineClip(
      id: 'visual-2',
      assetId: 'asset',
      trimStartMs: 1000,
      trimEndMs: 3000,
    );
    const audioAsset = MediaAsset(
      id: 'audio-asset',
      uri: 'content://media/audio/1',
      name: 'music.m4a',
      mimeType: 'audio/mp4',
      kind: MediaKind.audio,
      durationMs: 8000,
      width: 0,
      height: 0,
      sizeBytes: 200,
    );
    const firstAudio = TimelineClip(
      id: 'audio-1',
      assetId: 'audio-asset',
      trimStartMs: 0,
      trimEndMs: 4000,
    );
    const secondAudio = TimelineClip(
      id: 'audio-2',
      assetId: 'audio-asset',
      trimStartMs: 4000,
      trimEndMs: 8000,
    );
    final initial = _project('initial', videoTrack: [firstVisual, secondVisual])
        .copyWith(
          assets: [..._project('assets').assets, audioAsset],
          audioTrack: [firstAudio, secondAudio],
        );
    final reordered = initial.copyWith(
      videoTrack: [secondVisual, firstVisual],
      audioTrack: [secondAudio, firstAudio],
    );
    final laterEdit = reordered.copyWith(
      videoTrack: [secondVisual.copyWith(trimStartMs: 1500), firstVisual],
      audioTrack: [secondAudio],
    );
    final history = ProjectHistory(initial);

    history.record(reordered);
    history.record(laterEdit);
    final restoredOrder = history.undo()!;
    expect(restoredOrder.videoTrack.map((clip) => clip.id), [
      'visual-2',
      'visual-1',
    ]);
    expect(restoredOrder.audioTrack.map((clip) => clip.id), ['audio-2', 'audio-1']);

    final restoredInitial = history.undo()!;
    expect(restoredInitial.videoTrack.map((clip) => clip.id), [
      'visual-1',
      'visual-2',
    ]);
    expect(restoredInitial.audioTrack.map((clip) => clip.id), ['audio-1', 'audio-2']);
    expect(restoredInitial.assets, hasLength(2));

    final restoredRedo = history.redo()!;
    expect(restoredRedo.videoTrack.map((clip) => clip.id), [
      'visual-2',
      'visual-1',
    ]);
    expect(restoredRedo.audioTrack.map((clip) => clip.id), ['audio-2', 'audio-1']);
  });

  test('undo and redo restore audio placement, trim, gain and fades', () {
    const initialAudio = TimelineClip(
      id: 'music',
      assetId: 'audio-asset',
      trimStartMs: 400,
      trimEndMs: 5400,
      timelineStartMs: 1200,
      volume: 0.65,
      fadeInMs: 500,
      fadeOutMs: 800,
    );
    const initialProject = VeloraProject(
      id: 'audio-history',
      name: 'Audio',
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: [],
      videoTrack: [],
      audioTrack: [initialAudio],
    );
    final changed = initialProject.copyWith(
      audioTrack: [
        initialAudio.copyWith(
          trimStartMs: 800,
          trimEndMs: 5000,
          timelineStartMs: 2300,
          volume: 0.25,
          fadeInMs: 1000,
          fadeOutMs: 300,
        ),
      ],
    );
    final history = ProjectHistory(initialProject);
    history.record(changed);

    final undo = history.undo()!.audioTrack.single;
    expect(undo.timelineStartMs, 1200);
    expect(undo.trimStartMs, 400);
    expect(undo.trimEndMs, 5400);
    expect(undo.volume, 0.65);
    expect(undo.fadeInMs, 500);
    expect(undo.fadeOutMs, 800);

    final redo = history.redo()!.audioTrack.single;
    expect(redo.timelineStartMs, 2300);
    expect(redo.trimStartMs, 800);
    expect(redo.trimEndMs, 5000);
    expect(redo.volume, 0.25);
    expect(redo.fadeInMs, 1000);
    expect(redo.fadeOutMs, 300);
  });

  test('history is bounded to its configured number of snapshots', () {
    final history = ProjectHistory(_project('0'), maxEntries: 3);
    history.record(_project('1'));
    history.record(_project('2'));
    history.record(_project('3'));

    expect(history.undo()!.name, '2');
    expect(history.undo()!.name, '1');
    expect(history.undo(), isNull);
  });
}
