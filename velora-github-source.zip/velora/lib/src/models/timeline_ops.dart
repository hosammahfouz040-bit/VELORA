import 'clip_motion.dart';
import 'project.dart';
import 'video_transitions.dart';

class VideoTrackReorderResult {
  const VideoTrackReorderResult({
    required this.track,
    this.rejectionReason,
    this.changed = false,
  });

  final List<TimelineClip>? track;
  final String? rejectionReason;
  final bool changed;

  bool get accepted => track != null;
}

/// Reorders one visual clip only when every stored transition remains attached
/// to the same ordered, adjacent clip pair and retains its active/inactive state.
/// [insertAfterTarget] selects the drop half of [targetClipId].
VideoTrackReorderResult reorderVideoClipSafely({
  required List<TimelineClip> videoTrack,
  required List<VideoTransition> transitions,
  required String draggedClipId,
  required String targetClipId,
  required bool insertAfterTarget,
}) {
  final clipIds = videoTrack.map((clip) => clip.id).toSet();
  if (clipIds.length != videoTrack.length ||
      videoTrack.any((clip) => clip.id.trim().isEmpty)) {
    return const VideoTrackReorderResult(
      track: null,
      rejectionReason: 'لا يمكن ترتيب المسار لأن معرّفات بعض المقاطع غير صالحة أو مكررة.',
    );
  }
  final sourceIndex = videoTrack.indexWhere((clip) => clip.id == draggedClipId);
  final targetIndex = videoTrack.indexWhere((clip) => clip.id == targetClipId);
  if (sourceIndex < 0 || targetIndex < 0) {
    return const VideoTrackReorderResult(
      track: null,
      rejectionReason: 'تعذّر تحديد المقطع المصدر أو موضع الإسقاط.',
    );
  }
  if (sourceIndex == targetIndex) {
    return VideoTrackReorderResult(track: videoTrack);
  }

  final candidate = List<TimelineClip>.of(videoTrack)..removeAt(sourceIndex);
  final targetIndexAfterRemoval =
      candidate.indexWhere((clip) => clip.id == targetClipId);
  if (targetIndexAfterRemoval < 0) {
    return const VideoTrackReorderResult(
      track: null,
      rejectionReason: 'موضع الإسقاط لم يعد صالحًا؛ لم يُعتمد الترتيب.',
    );
  }
  candidate.insert(
    targetIndexAfterRemoval + (insertAfterTarget ? 1 : 0),
    videoTrack[sourceIndex],
  );
  var sameOrder = true;
  for (var index = 0; index < candidate.length; index++) {
    if (candidate[index].id != videoTrack[index].id) {
      sameOrder = false;
      break;
    }
  }
  if (sameOrder) return VideoTrackReorderResult(track: videoTrack);

  for (final transition in transitions) {
    final fromIndex = candidate.indexWhere((clip) => clip.id == transition.fromClipId);
    final toIndex = candidate.indexWhere((clip) => clip.id == transition.toClipId);
    if (fromIndex < 0 || toIndex != fromIndex + 1) {
      return VideoTrackReorderResult(
        track: null,
        rejectionReason:
            'رُفض الترتيب: يجب أن يبقى المقطعان المرتبطان بالانتقال '
            'من «${transition.fromClipId}» إلى «${transition.toClipId}» '
            'متجاورين وبالترتيب نفسه.',
      );
    }
  }

  final originalLayout = layoutVideoTransitions(
    videoTrack.map((clip) => clip.id).toList(),
    videoTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final candidateLayout = layoutVideoTransitions(
    candidate.map((clip) => clip.id).toList(),
    candidate.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final originalActive = originalLayout.activeTransitionsByBoundary.values
      .map(_transitionSignature)
      .toSet();
  final candidateActive = candidateLayout.activeTransitionsByBoundary.values
      .map(_transitionSignature)
      .toSet();
  for (final transition in transitions) {
    final signature = _transitionSignature(transition);
    if (originalActive.contains(signature) != candidateActive.contains(signature)) {
      return VideoTrackReorderResult(
        track: null,
        rejectionReason:
            'رُفض الترتيب: سيؤدي تغيير الجوار إلى تغيير صلاحية الانتقال '
            'من «${transition.fromClipId}» إلى «${transition.toClipId}».',
      );
    }
  }

  return VideoTrackReorderResult(track: candidate, changed: true);
}

String _transitionSignature(VideoTransition transition) => [
  transition.id,
  transition.fromClipId,
  transition.toClipId,
  transition.type.name,
  transition.durationMs.toString(),
  transition.direction,
  transition.intensity.toString(),
].join('\u0000');

class VideoClipTrimResult {
  const VideoClipTrimResult({
    required this.track,
    this.rejectionReason,
    this.changed = false,
  });

  final List<TimelineClip>? track;
  final String? rejectionReason;
  final bool changed;

  bool get accepted => track != null;
}

class VideoSpeedRampEditResult {
  const VideoSpeedRampEditResult({
    required this.track,
    this.rejectionReason,
    this.changed = false,
  });

  final List<TimelineClip>? track;
  final String? rejectionReason;
  final bool changed;

  bool get accepted => track != null;
}

/// Applies one clip's speed curve only if it keeps the exact active transition
/// schedule. A duration change must not silently disable or activate a cut.
VideoSpeedRampEditResult updateVideoClipSpeedRampSafely({
  required List<TimelineClip> videoTrack,
  required List<VideoTransition> transitions,
  required String clipId,
  required List<SpeedRampPoint> speedRampPoints,
}) {
  final index = videoTrack.indexWhere((clip) => clip.id == clipId);
  if (index < 0 || videoTrack.lastIndexWhere((clip) => clip.id == clipId) != index) {
    return const VideoSpeedRampEditResult(
      track: null,
      rejectionReason: 'تعذّر تحديد المقطع المطلوب تعديل سرعته بشكل فريد.',
    );
  }

  final currentClip = videoTrack[index];
  final normalizedPoints = normalizeSpeedRampPoints(speedRampPoints);
  if (_sameSpeedRampPoints(
    normalizeSpeedRampPoints(currentClip.speedRampPoints),
    normalizedPoints,
  )) {
    return VideoSpeedRampEditResult(track: videoTrack);
  }

  final candidateTrack = List<TimelineClip>.of(videoTrack)
    ..[index] = currentClip.copyWith(speedRampPoints: normalizedPoints);
  if (candidateTrack[index].effectiveDurationMs <= 0) {
    return const VideoSpeedRampEditResult(
      track: null,
      rejectionReason: 'ينتج عن منحنى السرعة مقطع بلا مدة صالحة.',
    );
  }

  final originalLayout = layoutVideoTransitions(
    videoTrack.map((clip) => clip.id).toList(),
    videoTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final candidateLayout = layoutVideoTransitions(
    candidateTrack.map((clip) => clip.id).toList(),
    candidateTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  for (var boundary = 0; boundary < videoTrack.length - 1; boundary++) {
    final before = originalLayout.activeTransitionsByBoundary[boundary];
    final after = candidateLayout.activeTransitionsByBoundary[boundary];
    if ((before == null) != (after == null) ||
        (before != null && after != null &&
            _transitionSignature(before) != _transitionSignature(after))) {
      return const VideoSpeedRampEditResult(
        track: null,
        rejectionReason:
            'رُفض منحنى السرعة لأنه سيغيّر صلاحية انتقال مرتبط بالمقطع.',
      );
    }
  }

  return VideoSpeedRampEditResult(track: candidateTrack, changed: true);
}

bool _sameSpeedRampPoints(
  List<SpeedRampPoint> first,
  List<SpeedRampPoint> second,
) => first.length == second.length &&
    List<bool>.generate(
      first.length,
      (index) => first[index].timeMs == second[index].timeMs &&
          first[index].speed == second[index].speed,
    ).every((same) => same);

/// Applies an existing source-boundary trim only when it preserves the active
/// state and exact stored parameters of every transition. No transition is
/// removed, shortened, or activated/deactivated as a side effect.
VideoClipTrimResult trimVideoClipSafely({
  required List<TimelineClip> videoTrack,
  required List<VideoTransition> transitions,
  required String clipId,
  required bool moveStart,
  required int requestedMs,
  required int sourceDurationMs,
}) {
  final index = videoTrack.indexWhere((clip) => clip.id == clipId);
  if (index < 0 || videoTrack.lastIndexWhere((clip) => clip.id == clipId) != index) {
    return const VideoClipTrimResult(
      track: null,
      rejectionReason: 'تعذّر تحديد المقطع المطلوب قصّه بشكل فريد.',
    );
  }
  final currentClip = videoTrack[index];
  if (requestedMs == (moveStart ? currentClip.trimStartMs : currentClip.trimEndMs)) {
    return VideoClipTrimResult(track: videoTrack);
  }
  final updatedClip = updateClipTrimBoundary(
    currentClip,
    moveStart: moveStart,
    requestedMs: requestedMs,
    sourceDurationMs: sourceDurationMs,
  );
  if (updatedClip == null) {
    return const VideoClipTrimResult(
      track: null,
      rejectionReason: 'حدّ القص غير صالح أو يتجاوز حدود المصدر.',
    );
  }
  if (updatedClip.trimStartMs == videoTrack[index].trimStartMs &&
      updatedClip.trimEndMs == videoTrack[index].trimEndMs) {
    return VideoClipTrimResult(track: videoTrack);
  }

  final candidateTrack = List<TimelineClip>.of(videoTrack);
  candidateTrack[index] = updatedClip;
  final originalLayout = layoutVideoTransitions(
    videoTrack.map((clip) => clip.id).toList(),
    videoTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final candidateLayout = layoutVideoTransitions(
    candidateTrack.map((clip) => clip.id).toList(),
    candidateTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  var activeSchedulePreserved =
      originalLayout.activeTransitionsByBoundary.length ==
      candidateLayout.activeTransitionsByBoundary.length;
  if (activeSchedulePreserved) {
    for (final entry in originalLayout.activeTransitionsByBoundary.entries) {
      final candidateTransition =
          candidateLayout.activeTransitionsByBoundary[entry.key];
      if (candidateTransition == null ||
          _transitionSignature(candidateTransition) !=
              _transitionSignature(entry.value)) {
        activeSchedulePreserved = false;
        break;
      }
    }
  }
  if (!activeSchedulePreserved) {
    VideoTransition? linkedTransition;
    for (final transition in transitions) {
      if (transition.fromClipId == clipId || transition.toClipId == clipId) {
        linkedTransition = transition;
        break;
      }
    }
    final linked = linkedTransition;
    final details = linked == null
        ? ''
        : ' بين «${linked.fromClipId}» و«${linked.toClipId}»';
    return VideoClipTrimResult(
      track: null,
      rejectionReason: 'رُفض القص لأنه سيغيّر صلاحية الانتقال$details.',
    );
  }
  return VideoClipTrimResult(track: candidateTrack, changed: true);
}

class VideoTransitionDurationLimits {
  const VideoTransitionDurationLimits({
    required this.minDurationMs,
    required this.maxDurationMs,
    this.rejectionReason,
  });

  final int minDurationMs;
  final int maxDurationMs;
  final String? rejectionReason;
  bool get accepted => minDurationMs >= 1 && maxDurationMs >= minDurationMs;
}

/// Returns the strict maximum duration that this boundary can occupy while
/// retaining the currently active transitions on both adjacent clips.
VideoTransitionDurationLimits videoTransitionDurationLimits({
  required List<TimelineClip> videoTrack,
  required List<VideoTransition> transitions,
  required int boundaryIndex,
}) {
  if (boundaryIndex < 0 || boundaryIndex + 1 >= videoTrack.length) {
    return const VideoTransitionDurationLimits(
      minDurationMs: 1,
      maxDurationMs: 0,
      rejectionReason: 'لا يوجد حدّ فاصل صالح بين مقطعين هنا.',
    );
  }
  final clipIds = videoTrack.map((clip) => clip.id).toSet();
  if (clipIds.length != videoTrack.length ||
      videoTrack.any((clip) => clip.id.trim().isEmpty)) {
    return const VideoTransitionDurationLimits(
      minDurationMs: 1,
      maxDurationMs: 0,
      rejectionReason: 'تعذّر تحديد المقطعين المتجاورين بشكل فريد.',
    );
  }
  final fromClipId = videoTrack[boundaryIndex].id;
  final toClipId = videoTrack[boundaryIndex + 1].id;
  final targetRows = transitions.where(
    (item) => item.fromClipId == fromClipId && item.toClipId == toClipId,
  );
  if (targetRows.length > 1) {
    return const VideoTransitionDurationLimits(
      minDurationMs: 1,
      maxDurationMs: 0,
      rejectionReason: 'توجد انتقالات مكررة على الحدّ نفسه.',
    );
  }
  final leftDurationMs = videoTrack[boundaryIndex].effectiveDurationMs;
  final rightDurationMs = videoTrack[boundaryIndex + 1].effectiveDurationMs;
  if (leftDurationMs <= 0 || rightDurationMs <= 0) {
    return const VideoTransitionDurationLimits(
      minDurationMs: 1,
      maxDurationMs: 0,
      rejectionReason: 'يجب أن يكون المقطعان بطول موجب قبل إضافة انتقال.',
    );
  }
  final layout = layoutVideoTransitions(
    videoTrack.map((clip) => clip.id).toList(),
    videoTrack.map((clip) => clip.effectiveDurationMs).toList(),
    transitions,
  );
  final incomingDurationMs =
      layout.activeTransitionsByBoundary[boundaryIndex - 1]?.durationMs ?? 0;
  final outgoingDurationMs =
      layout.activeTransitionsByBoundary[boundaryIndex + 1]?.durationMs ?? 0;
  final availableLeftMs = leftDurationMs - incomingDurationMs;
  final availableRightMs = rightDurationMs - outgoingDurationMs;
  var minimum = 1;
  final nextBoundary = boundaryIndex + 1;
  if (nextBoundary + 1 < videoTrack.length &&
      !layout.activeTransitionsByBoundary.containsKey(nextBoundary)) {
    final nextFromId = videoTrack[nextBoundary].id;
    final nextToId = videoTrack[nextBoundary + 1].id;
    VideoTransition? inactiveOutgoing;
    for (final transition in transitions) {
      if (transition.fromClipId == nextFromId &&
          transition.toClipId == nextToId) {
        inactiveOutgoing = transition;
        break;
      }
    }
    if (inactiveOutgoing != null &&
        inactiveOutgoing.type.supported &&
        inactiveOutgoing.durationMs > 0 &&
        inactiveOutgoing.durationMs <= videoTrack[nextBoundary + 1].effectiveDurationMs) {
      final keepInactiveAtLeast =
          rightDurationMs - inactiveOutgoing.durationMs + 1;
      if (keepInactiveAtLeast > minimum) minimum = keepInactiveAtLeast;
    }
  }
  final maximum = availableLeftMs < availableRightMs
      ? availableLeftMs
      : availableRightMs;
  final safeMaximum = maximum > 0 ? maximum : 0;
  final accepted = safeMaximum >= minimum;
  return VideoTransitionDurationLimits(
    minDurationMs: minimum,
    maxDurationMs: safeMaximum,
    rejectionReason: accepted
        ? null
        : 'لا توجد مدة متاحة لهذا الانتقال دون المساس بانتقال مجاور.',
  );
}

class VideoTransitionEditResult {
  const VideoTransitionEditResult({
    required this.transitions,
    this.rejectionReason,
    this.changed = false,
  });

  final List<VideoTransition>? transitions;
  final String? rejectionReason;
  final bool changed;

  bool get accepted => transitions != null;
}

/// Adds or updates one adjacent-boundary transition without shortening,
/// removing, activating, or deactivating any other transition.
VideoTransitionEditResult setVideoTransitionSafely({
  required List<TimelineClip> videoTrack,
  required List<VideoTransition> transitions,
  required int boundaryIndex,
  required VideoTransitionType type,
  required int durationMs,
  required String newTransitionId,
  String? direction,
  double? intensity,
}) {
  if (!type.supported) {
    return const VideoTransitionEditResult(
      transitions: null,
      rejectionReason: 'هذا النوع غير مدعوم في المعاينة الفعلية.',
    );
  }
  final limits = videoTransitionDurationLimits(
    videoTrack: videoTrack,
    transitions: transitions,
    boundaryIndex: boundaryIndex,
  );
  if (!limits.accepted) {
    return VideoTransitionEditResult(
      transitions: null,
      rejectionReason: limits.rejectionReason,
    );
  }
  final transitionIds = transitions.map((item) => item.id).toSet();
  if (transitionIds.length != transitions.length ||
      transitions.any((item) => item.id.trim().isEmpty)) {
    return const VideoTransitionEditResult(
      transitions: null,
      rejectionReason: 'بيانات معرّفات الانتقالات غير فريدة؛ لم يُعتمد التعديل.',
    );
  }
  if (durationMs < limits.minDurationMs || durationMs > limits.maxDurationMs) {
    return VideoTransitionEditResult(
      transitions: null,
      rejectionReason:
          'مدة الانتقال يجب أن تكون بين ${limits.minDurationMs} و${limits.maxDurationMs} مللي ثانية.',
    );
  }

  final fromClipId = videoTrack[boundaryIndex].id;
  final toClipId = videoTrack[boundaryIndex + 1].id;
  final matchingIndexes = <int>[
    for (var index = 0; index < transitions.length; index++)
      if (transitions[index].fromClipId == fromClipId &&
          transitions[index].toClipId == toClipId)
        index,
  ];
  if (matchingIndexes.length > 1) {
    return const VideoTransitionEditResult(
      transitions: null,
      rejectionReason: 'توجد انتقالات مكررة على الحدّ نفسه؛ لم يُعتمد التغيير.',
    );
  }
  final existingIndex = matchingIndexes.isEmpty ? null : matchingIndexes.single;
  final existing = existingIndex == null ? null : transitions[existingIndex];
  final rawDirection = direction ?? existing?.direction ?? 'right';
  final requestedDirection = const {'left', 'right', 'up', 'down'}
          .contains(rawDirection)
      ? rawDirection
      : 'right';
  final rawIntensity = intensity ?? existing?.intensity ?? 1;
  final requestedIntensity = rawIntensity.isFinite
      ? rawIntensity.clamp(0, 1).toDouble()
      : 1.0;
  if (existing != null &&
      existing.type == type &&
      existing.durationMs == durationMs &&
      existing.direction == requestedDirection &&
      existing.intensity == requestedIntensity) {
    return VideoTransitionEditResult(transitions: transitions);
  }

  final transitionId = existing?.id ?? newTransitionId.trim();
  if (transitionId.isEmpty ||
      (existing == null && transitions.any((item) => item.id == transitionId))) {
    return const VideoTransitionEditResult(
      transitions: null,
      rejectionReason: 'تعذّر إنشاء معرّف فريد للانتقال.',
    );
  }
  final updatedTransition = VideoTransition(
    id: transitionId,
    fromClipId: fromClipId,
    toClipId: toClipId,
    type: type,
    durationMs: durationMs,
    direction: requestedDirection,
    intensity: requestedIntensity,
  );
  final candidate = List<VideoTransition>.of(transitions);
  if (existingIndex == null) {
    candidate.add(updatedTransition);
  } else {
    candidate[existingIndex] = updatedTransition;
  }

  final clipIds = videoTrack.map((clip) => clip.id).toList();
  final clipDurationsMs = videoTrack.map((clip) => clip.effectiveDurationMs).toList();
  final originalLayout = layoutVideoTransitions(clipIds, clipDurationsMs, transitions);
  final candidateLayout = layoutVideoTransitions(clipIds, clipDurationsMs, candidate);
  final activeTarget = candidateLayout.activeTransitionsByBoundary[boundaryIndex];
  if (activeTarget == null ||
      _transitionSignature(activeTarget) != _transitionSignature(updatedTransition)) {
    return const VideoTransitionEditResult(
      transitions: null,
      rejectionReason: 'سيؤدي هذا الانتقال إلى تعارض مع انتقال مجاور؛ لم يُعتمد.',
    );
  }
  for (var boundary = 0; boundary < clipIds.length - 1; boundary++) {
    if (boundary == boundaryIndex) continue;
    final before = originalLayout.activeTransitionsByBoundary[boundary];
    final after = candidateLayout.activeTransitionsByBoundary[boundary];
    if ((before == null) != (after == null) ||
        (before != null && after != null &&
            _transitionSignature(before) != _transitionSignature(after))) {
      return VideoTransitionEditResult(
        transitions: null,
        rejectionReason:
            'سيؤدي تغيير الانتقال إلى تعطيل أو تغيير انتقال مجاور عند الحد ${boundary + 1}.',
      );
    }
  }
  return VideoTransitionEditResult(transitions: candidate, changed: true);
}

/// Splits a visual clip at the absolute playhead position on a sequential track.
/// When a speed ramp or transition makes the timeline clock differ from the
/// source clock, pass the mapped source-media position in [sourceSplitPositionMs].
/// Returns null when the split point is outside the source trim or on its edge.
List<TimelineClip>? splitClipAtPosition(
  List<TimelineClip> track,
  String clipId, {
  required int playheadMs,
  required String secondClipId,
  required int sourceDurationMs,
  int? clipTimelineStartMsOverride,
  int? sourceSplitPositionMs,
}) {
  final index = track.indexWhere((clip) => clip.id == clipId);
  if (index < 0 ||
      secondClipId.isEmpty ||
      track.any((clip) => clip.id == secondClipId)) {
    return null;
  }

  final clip = track[index];
  if (clip.trimStartMs < 0 ||
      clip.durationMs <= 1 ||
      (sourceDurationMs > 0 && clip.trimEndMs > sourceDurationMs)) {
    return null;
  }
  final clipTimelineStartMs = clipTimelineStartMsOverride ?? track
      .take(index)
      .fold<int>(
        0,
        (total, item) => total + (item.durationMs > 0 ? item.durationMs : 0),
      );
  final offsetMs = playheadMs - clipTimelineStartMs;
  if (sourceSplitPositionMs == null &&
      (offsetMs <= 0 || offsetMs >= clip.durationMs)) {
    return null;
  }
  final sourceSplitMs = sourceSplitPositionMs ?? (clip.trimStartMs + offsetMs);
  if (sourceSplitMs <= clip.trimStartMs || sourceSplitMs >= clip.trimEndMs) return null;
  final first = clip.copyWith(trimEndMs: sourceSplitMs);
  final second = TimelineClip(
    id: secondClipId,
    assetId: clip.assetId,
    trimStartMs: sourceSplitMs,
    trimEndMs: clip.trimEndMs,
    timelineStartMs: clip.timelineStartMs,
    volume: clip.volume,
    fadeInMs: clip.fadeInMs,
    fadeOutMs: clip.fadeOutMs,
    transformKeyframes: clip.transformKeyframes,
    speedRampPoints: clip.speedRampPoints,
    colorSettingsOverride: clip.colorSettingsOverride,
  );
  return [...track.take(index), first, second, ...track.skip(index + 1)];
}

/// Parses seconds entered by the user into the millisecond timeline unit.
/// Three decimal places represent millisecond precision.
int? parseTimelineSeconds(String input) {
  final seconds = double.tryParse(input.trim().replaceAll(',', '.'));
  if (seconds == null || !seconds.isFinite || seconds < 0) return null;
  final milliseconds = seconds * 1000;
  if (!milliseconds.isFinite || milliseconds > 9007199254740991) return null;
  return milliseconds.round();
}

/// Adjusts one source trim boundary without allowing a zero-length clip.
/// [sourceDurationMs] bounds the end when the source duration is known; a
/// non-positive duration keeps the existing end as the safe upper bound.
TimelineClip? updateClipTrimBoundary(
  TimelineClip clip, {
  required bool moveStart,
  required int requestedMs,
  required int sourceDurationMs,
}) {
  if (clip.durationMs <= 0) return null;
  if (moveStart) {
    if (sourceDurationMs > 0 && clip.trimEndMs > sourceDurationMs) return null;
    var maximumStartMs = clip.trimEndMs - 1;
    if (sourceDurationMs > 0 && sourceDurationMs - 1 < maximumStartMs) {
      maximumStartMs = sourceDurationMs - 1;
    }
    if (maximumStartMs < 0) return null;
    final startMs = requestedMs.clamp(0, maximumStartMs).toInt();
    if (startMs == clip.trimStartMs) return null;
    return clip.copyWith(trimStartMs: startMs);
  }

  if (clip.trimStartMs < 0) return null;
  final minimumEndMs = clip.trimStartMs + 1;
  final maximumEndMs = sourceDurationMs > 0
      ? sourceDurationMs
      : clip.trimEndMs;
  if (maximumEndMs < minimumEndMs) return null;
  final endMs = requestedMs.clamp(minimumEndMs, maximumEndMs).toInt();
  if (endMs == clip.trimEndMs) return null;
  return clip.copyWith(trimEndMs: endMs);
}

/// Splits a visual clip into two adjacent source ranges at the midpoint.
/// Returns null when the clip is missing or too short to split safely.
List<TimelineClip>? splitClipAtMidpoint(
  List<TimelineClip> track,
  String clipId, {
  required String secondClipId,
}) {
  final index = track.indexWhere((clip) => clip.id == clipId);
  if (index < 0) return null;

  final clip = track[index];
  if (clip.durationMs < 1000) return null;
  final midpoint = clip.trimStartMs + (clip.durationMs ~/ 2);
  if (midpoint <= clip.trimStartMs || midpoint >= clip.trimEndMs) return null;

  final first = clip.copyWith(trimEndMs: midpoint);
  final second = TimelineClip(
    id: secondClipId,
    assetId: clip.assetId,
    trimStartMs: midpoint,
    trimEndMs: clip.trimEndMs,
    transformKeyframes: clip.transformKeyframes,
    speedRampPoints: clip.speedRampPoints,
    colorSettingsOverride: clip.colorSettingsOverride,
  );
  return [...track.take(index), first, second, ...track.skip(index + 1)];
}
