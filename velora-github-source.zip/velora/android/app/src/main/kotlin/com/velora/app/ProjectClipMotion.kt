package com.velora.app

import androidx.media3.common.C
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import kotlin.math.roundToLong

internal const val SPEED_SAMPLE_STEP_US = 50_000L
internal const val MIN_SPEED_MULTIPLIER = 0.1
// Keep the advertised cap at Media3’s presently verified safe boundary.
// Higher values remain clamped until high-speed runtime behavior is validated.
internal const val MAX_SPEED_MULTIPLIER = 8.0
private const val SPEED_SAMPLE_STEP_MS = SPEED_SAMPLE_STEP_US / 1_000L
private const val MAX_SAFE_MILLIS = 9_007_199_254_740_992L

internal data class TransformKeyframe(
    val timeMs: Long,
    val x: Float,
    val y: Float,
    val scale: Float,
    val rotationDegrees: Float,
    val opacity: Float,
    val smooth: Boolean,
)

internal data class SpeedRampPoint(val timeMs: Long, val speed: Double)

internal data class TransformValue(
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1f,
    val rotationDegrees: Float = 0f,
    val opacity: Float = 1f,
)

@UnstableApi
internal data class ProjectClipTiming(
    val id: String,
    val trimStartMs: Long,
    val trimEndMs: Long,
    val transformKeyframes: List<TransformKeyframe>,
    val speedRampPoints: List<SpeedRampPoint>,
) {
    val sourceDurationMs: Long get() = (trimEndMs - trimStartMs).coerceAtLeast(0L)
    val speedProvider: SpeedProvider get() = makeSpeedProvider(trimStartMs, sourceDurationMs, speedRampPoints)
    /** Same absolute, sampled source clock used by Dart's TimelineClip.effectiveDurationMs. */
    val outputDurationMs: Long
        get() = sourceOffsetToOutputMs(sourceDurationMs, trimStartMs, speedRampPoints)

    fun sourceOffsetAtOutputMs(outputOffsetMs: Long): Long =
        outputOffsetToSourceMs(outputOffsetMs, trimStartMs, trimEndMs, speedRampPoints)
}

internal object ProjectClipMotion {
    fun timingFromMap(row: Map<*, *>): ProjectClipTiming {
        val start = (row["trimStartMs"] as? Number)?.toLong() ?: 0L
        val end = (row["trimEndMs"] as? Number)?.toLong() ?: start
        val sourceDurationMs = (end - start).coerceAtLeast(0L)
        return ProjectClipTiming(
            id = row["id"]?.toString().orEmpty(),
            trimStartMs = start,
            trimEndMs = end,
            transformKeyframes = normalizeTransformKeyframes(
                mapRows(row["transformKeyframes"]).mapNotNull(::pointFromMap),
            ),
            speedRampPoints = normalizeSpeedPoints(
                mapRows(row["speedRampPoints"]).mapNotNull(::speedPointFromMap),
                maxSpeedForSourceDurationMs(sourceDurationMs),
            ),
        )
    }

    fun hasMotion(row: Map<*, *>): Boolean =
        mapRows(row["transformKeyframes"]).isNotEmpty() || mapRows(row["speedRampPoints"]).isNotEmpty()

    fun speedProviderForClip(row: Map<*, *>): SpeedProvider {
        val timing = timingFromMap(row)
        return timing.speedProvider
    }

    fun mapProjectTimeToOutputMs(
        sourceProjectMs: Long,
        timings: List<ProjectClipTiming>,
        transitionPlan: ProjectTransitionPlan?,
    ): Long {
        if (timings.isEmpty()) return 0L
        val sourceTime = sourceProjectMs.coerceIn(0L, MAX_SAFE_MILLIS)
        var sourceCursor = 0L
        var outputCursor = 0L
        for ((index, timing) in timings.withIndex()) {
            val sourceDuration = timing.sourceDurationMs
            if (sourceTime <= sourceCursor + sourceDuration || index == timings.lastIndex) {
                val localSource = (sourceTime - sourceCursor).coerceIn(0L, sourceDuration)
                val localOutput = sourceOffsetToOutputMs(
                    localSource,
                    timing.trimStartMs,
                    timing.speedRampPoints,
                ).coerceIn(0L, timing.outputDurationMs)
                val preTransitionTime = outputCursor + localOutput
                return transitionPlan?.mapOriginalTimeMs(
                    preTransitionTime,
                    timings.map { it.outputDurationMs },
                ) ?: preTransitionTime
            }
            sourceCursor += sourceDuration
            outputCursor += timing.outputDurationMs
        }
        return 0L
    }
}

@UnstableApi
internal fun makeSpeedProvider(
    sourceStartMs: Long,
    sourceDurationMs: Long,
    points: List<SpeedRampPoint>,
): SpeedProvider {
    val sorted = normalizeSpeedPoints(points)
    if (sorted.isEmpty()) return SpeedProvider.DEFAULT
    val constant = sorted.all { it.speed == sorted.first().speed }
    val sourceStartUs = sourceStartMs * 1_000L
    val durationUs = sourceDurationMs.coerceAtLeast(0L) * 1_000L
    return object : SpeedProvider {
        override fun getSpeed(timeUs: Long): Float {
            val absoluteSourceUs = sourceStartUs + timeUs.coerceAtLeast(0L)
            val gridCellStartUs =
                Math.floorDiv(absoluteSourceUs, SPEED_SAMPLE_STEP_US) * SPEED_SAMPLE_STEP_US
            val lastRampBoundaryUs = sorted.asSequence()
                .map { it.timeMs * 1_000L }
                .filter { it <= absoluteSourceUs }
                .lastOrNull()
            val sampledBoundaryUs = lastRampBoundaryUs?.let {
                maxOf(gridCellStartUs, it)
            } ?: gridCellStartUs
            return speedAt(sorted, sampledBoundaryUs / 1_000L).toFloat()
        }

        override fun getNextSpeedChangeTimeUs(timeUs: Long): Long {
            val localTimeUs = timeUs.coerceAtLeast(0L)
            if (constant || localTimeUs >= durationUs) return C.TIME_UNSET

            // Match the canonical Dart clock: cells start on absolute 50 ms source
            // boundaries, with every speed-ramp point inserted as an extra boundary.
            val absoluteSourceUs = sourceStartUs + localTimeUs
            val nextGridBoundaryUs =
                (Math.floorDiv(absoluteSourceUs, SPEED_SAMPLE_STEP_US) + 1L) *
                    SPEED_SAMPLE_STEP_US
            val nextRampBoundaryUs = sorted.asSequence()
                .map { it.timeMs * 1_000L }
                .firstOrNull { it > absoluteSourceUs }
            val nextAbsoluteUs = nextRampBoundaryUs?.let {
                minOf(nextGridBoundaryUs, it)
            } ?: nextGridBoundaryUs
            val nextLocalUs = nextAbsoluteUs - sourceStartUs
            return if (nextLocalUs <= localTimeUs || nextLocalUs >= durationUs) {
                C.TIME_UNSET
            } else {
                nextLocalUs
            }
        }
    }
}

/** Maps a source-clock span to output time using the same rounded cumulative clock as Dart. */
internal fun sourceOffsetToOutputMs(
    sourceOffsetMs: Long,
    sourceStartMs: Long,
    points: List<SpeedRampPoint>,
): Long {
    val target = sourceOffsetMs.coerceIn(0L, MAX_SAFE_MILLIS)
    if (target == 0L || points.isEmpty()) return target
    val sorted = normalizeSpeedPoints(points)
    val sourceEndMs = sourceStartMs + target
    val clock = SpeedRampOutputClock(sorted, sourceEndMs)
    return (clock.at(sourceEndMs) - clock.at(sourceStartMs))
        .coerceIn(0L, MAX_SAFE_MILLIS)
}

/** Inverts the same rounded cumulative clock used by Dart; ties choose the earlier source ms. */
internal fun outputOffsetToSourceMs(
    outputOffsetMs: Long,
    sourceStartMs: Long,
    sourceEndMs: Long,
    points: List<SpeedRampPoint>,
): Long {
    val target = outputOffsetMs.coerceIn(0L, MAX_SAFE_MILLIS)
    val sourceDuration = (sourceEndMs - sourceStartMs).coerceIn(0L, MAX_SAFE_MILLIS)
    if (target == 0L || sourceDuration == 0L || points.isEmpty()) {
        return target.coerceAtMost(sourceDuration)
    }

    val sorted = normalizeSpeedPoints(points)
    val clock = SpeedRampOutputClock(sorted, sourceStartMs + sourceDuration)
    val sourceStartClock = clock.at(sourceStartMs)
    val outputDuration = (clock.at(sourceStartMs + sourceDuration) - sourceStartClock)
        .coerceIn(0L, MAX_SAFE_MILLIS)
    if (target >= outputDuration) return sourceDuration

    val boundedTarget = target.coerceIn(0L, outputDuration)
    var low = 0L
    var high = sourceDuration
    while (low < high) {
        val middle = (low + high) / 2L
        val outputAtMiddle = clock.at(sourceStartMs + middle) - sourceStartClock
        if (outputAtMiddle < boundedTarget) low = middle + 1L else high = middle
    }

    val upperOffset = low
    val lowerOffset = (upperOffset - 1L).coerceIn(0L, sourceDuration)
    val upperError = kotlin.math.abs(
        clock.at(sourceStartMs + upperOffset) - sourceStartClock - boundedTarget,
    )
    val lowerError = kotlin.math.abs(
        clock.at(sourceStartMs + lowerOffset) - sourceStartClock - boundedTarget,
    )
    return if (lowerError <= upperError) lowerOffset else upperOffset
}

/**
 * Rounded cumulative output-time clock over absolute source timestamps.
 * The speed at each cell start is held until the next absolute 50 ms boundary
 * or ramp point, exactly mirroring lib/src/models/clip_motion.dart.
 */
private class SpeedRampOutputClock(
    private val ramp: List<SpeedRampPoint>,
    private val throughSourceTimeMs: Long,
) {
    private val breakpoints = mutableListOf<Long>()
    private val prefixOutputMs = mutableListOf<Double>()
    private val intervalSpeeds = mutableListOf<Double>()

    init {
        if (ramp.size < 2 || throughSourceTimeMs <= ramp.first().timeMs) return
        breakpoints += ramp.first().timeMs
        prefixOutputMs += 0.0
        var cursor = ramp.first().timeMs
        var nextRampPointIndex = 1
        val integrationEndMs = minOf(ramp.last().timeMs, throughSourceTimeMs)
        while (cursor < integrationEndMs) {
            val nextGridBoundary =
                (Math.floorDiv(cursor, SPEED_SAMPLE_STEP_MS) + 1L) * SPEED_SAMPLE_STEP_MS
            val nextRampPoint = ramp[nextRampPointIndex].timeMs
            val next = minOf(nextGridBoundary, nextRampPoint, integrationEndMs)
            val speed = speedAt(ramp, cursor).toFloat().toDouble()
            intervalSpeeds += speed
            prefixOutputMs += prefixOutputMs.last() + (next - cursor).toDouble() / speed
            breakpoints += next
            cursor = next
            if (cursor == nextRampPoint) nextRampPointIndex++
        }
    }

    fun at(sourceTimeMs: Long): Long = rawAt(sourceTimeMs).roundToLong()
        .coerceIn(-MAX_SAFE_MILLIS, MAX_SAFE_MILLIS)

    private fun rawAt(sourceTimeMs: Long): Double {
        if (ramp.isEmpty()) return sourceTimeMs.toDouble()
        val first = ramp.first()
        val last = ramp.last()
        val firstSpeed = first.speed.toFloat().toDouble()
        val lastSpeed = last.speed.toFloat().toDouble()
        if (sourceTimeMs <= first.timeMs) return sourceTimeMs.toDouble() / firstSpeed

        val outputBeforeRamp = first.timeMs.toDouble() / firstSpeed
        if (ramp.size == 1 || sourceTimeMs >= last.timeMs) {
            val rampOutput = if (ramp.size == 1) 0.0 else prefixOutputMs.last()
            return outputBeforeRamp + rampOutput +
                (sourceTimeMs - last.timeMs).toDouble() / lastSpeed
        }
        if (breakpoints.isNotEmpty() &&
            sourceTimeMs >= breakpoints.last() &&
            sourceTimeMs <= throughSourceTimeMs
        ) {
            return outputBeforeRamp + prefixOutputMs.last()
        }

        var low = 0
        var high = breakpoints.lastIndex
        while (low < high) {
            val middle = (low + high) / 2
            if (breakpoints[middle + 1] <= sourceTimeMs) low = middle + 1 else high = middle
        }
        return outputBeforeRamp + prefixOutputMs[low] +
            (sourceTimeMs - breakpoints[low]).toDouble() / intervalSpeeds[low]
    }
}

private fun maxSpeedForSourceDurationMs(sourceDurationMs: Long): Double =
    if (sourceDurationMs <= 0L) {
        MAX_SPEED_MULTIPLIER
    } else {
        minOf(MAX_SPEED_MULTIPLIER, sourceDurationMs.toDouble())
            .coerceAtLeast(MIN_SPEED_MULTIPLIER)
    }

private fun normalizeSpeedPoints(
  points: List<SpeedRampPoint>,
    maxSpeed: Double = MAX_SPEED_MULTIPLIER,
): List<SpeedRampPoint> {
    val safeMaxSpeed = maxSpeed.coerceIn(MIN_SPEED_MULTIPLIER, MAX_SPEED_MULTIPLIER)
    val sorted = points.map { point ->
        SpeedRampPoint(
            timeMs = point.timeMs.coerceIn(0L, MAX_SAFE_MILLIS),
            speed = if (point.speed.isFinite()) {
                point.speed.coerceIn(MIN_SPEED_MULTIPLIER, safeMaxSpeed)
            } else {
                1.0
            },
        )
    }.sortedBy { it.timeMs }
    val normalized = mutableListOf<SpeedRampPoint>()
    for (point in sorted) {
        if (normalized.lastOrNull()?.timeMs == point.timeMs) {
            normalized[normalized.lastIndex] = point
        } else {
            normalized += point
        }
    }
    return normalized
}

private fun speedAt(points: List<SpeedRampPoint>, sourceTimeMs: Long): Double {
    if (points.isEmpty()) return 1.0
    if (sourceTimeMs <= points.first().timeMs) return points.first().speed
    if (sourceTimeMs >= points.last().timeMs) return points.last().speed
    val rightIndex = points.indexOfFirst { it.timeMs >= sourceTimeMs }
    val left = points[rightIndex - 1]
    val right = points[rightIndex]
    val span = right.timeMs - left.timeMs
    if (span <= 0L) return right.speed
    val t = (sourceTimeMs - left.timeMs).toDouble() / span
    return left.speed + (right.speed - left.speed) * t
}

internal fun evaluateTransformKeyframes(points: List<TransformKeyframe>, timeMs: Long): TransformValue {
    val frames = normalizeTransformKeyframes(points)
    if (frames.isEmpty()) return TransformValue()
    if (timeMs <= frames.first().timeMs) return frames.first().value()
    if (timeMs >= frames.last().timeMs) return frames.last().value()
    val rightIndex = frames.indexOfFirst { it.timeMs >= timeMs }
    if (rightIndex <= 0) return frames.first().value()
    val left = frames[rightIndex - 1]
    val right = frames[rightIndex]
    val span = right.timeMs - left.timeMs
    if (span <= 0L) return right.value()
    var t = (timeMs - left.timeMs).toFloat() / span
    if (left.smooth) t = t * t * (3f - 2f * t)
    return TransformValue(
        x = left.x + (right.x - left.x) * t,
        y = left.y + (right.y - left.y) * t,
        scale = left.scale + (right.scale - left.scale) * t,
        rotationDegrees = left.rotationDegrees + (right.rotationDegrees - left.rotationDegrees) * t,
        opacity = left.opacity + (right.opacity - left.opacity) * t,
    )
}

private fun normalizeTransformKeyframes(points: List<TransformKeyframe>): List<TransformKeyframe> {
    val byTime = linkedMapOf<Long, TransformKeyframe>()
    points.sortedBy { it.timeMs }.forEach { point -> byTime[point.timeMs] = point }
    return byTime.values.toList()
}

internal fun pointFromMap(map: Map<*, *>): TransformKeyframe? {
    val timeMs = (map["timeMs"] as? Number)?.toLong() ?: return null
    return TransformKeyframe(
        timeMs = timeMs.coerceIn(0L, MAX_SAFE_MILLIS),
        x = safeRange(map["positionX"], 0f, -1f, 1f),
        y = safeRange(map["positionY"], 0f, -1f, 1f),
        scale = safeRange(map["scale"], 1f, 0.05f, 10f),
        rotationDegrees = safeRange(map["rotationDegrees"], 0f, -3600f, 3600f),
        opacity = safeRange(map["opacity"], 1f, 0f, 1f),
        smooth = map["interpolation"]?.toString() != "linear",
    )
}

internal fun speedPointFromMap(map: Map<*, *>): SpeedRampPoint? {
    val timeMs = (map["timeMs"] as? Number)?.toLong() ?: return null
    return SpeedRampPoint(
        timeMs = timeMs.coerceAtLeast(0L),
        speed = safeSpeedRange(map["speed"]),
    )
}

private fun TransformKeyframe.value() = TransformValue(x, y, scale, rotationDegrees, opacity)

private fun safeRange(raw: Any?, fallback: Float, min: Float, max: Float): Float {
    val value = (raw as? Number)?.toFloat() ?: fallback
    return if (value.isFinite()) value.coerceIn(min, max) else fallback
}

private fun mapRows(raw: Any?): List<Map<*, *>> =
    (raw as? List<*>)?.mapNotNull { it as? Map<*, *> } ?: emptyList()

private fun safeSpeedRange(raw: Any?): Double {
    val value = (raw as? Number)?.toDouble() ?: return 1.0
    return if (value.isFinite()) {
        value.coerceIn(MIN_SPEED_MULTIPLIER, MAX_SPEED_MULTIPLIER)
    } else {
        1.0
    }
}
