package com.velora.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ProjectColorSettingsTest {
    @Test
    fun missingColorSettingsUseNeutralValues() {
        assertEquals(ProjectColorSettings(), ProjectColorSettings.fromMap(null))
        assertEquals(ProjectColorSettings(), ProjectColorSettings.fromMap(emptyMap<String, Any>()))
    }

    @Test
    fun normalValuesArePreserved() {
        val settings = ProjectColorSettings.fromMap(
            mapOf("brightness" to 0.25, "contrast" to -0.4, "saturation" to 35.0, "warmth" to 0.3),
        )

        assertEquals(0.25f, settings.brightness, 0f)
        assertEquals(-0.4f, settings.contrast, 0f)
        assertEquals(35f, settings.saturation, 0f)
        assertEquals(0.3f, settings.warmth, 0f)
    }

    @Test
    fun eachClipUsesItsOverrideOrInheritsProjectSettings() {
        val projectSettings = ProjectColorSettings(
            brightness = 0.2f,
            contrast = -0.3f,
            saturation = 18f,
            warmth = 0.2f,
        )
        val overriddenClip = mapOf(
            "colorSettingsOverride" to mapOf(
                "brightness" to -0.6,
                "contrast" to 0.45,
                "saturation" to 72,
                "warmth" to -0.5,
            ),
        )
        val otherClip = mapOf(
            "colorSettingsOverride" to mapOf(
                "brightness" to 0.7,
                "contrast" to -0.8,
                "saturation" to -35,
            ),
        )
        val legacyClip = mapOf("id" to "legacy-clip")

        assertEquals(
            ProjectColorSettings(-0.6f, 0.45f, 72f, -0.5f),
            ProjectColorSettings.effectiveForClip(overriddenClip, projectSettings),
        )
        assertEquals(
            ProjectColorSettings(0.7f, -0.8f, -35f),
            ProjectColorSettings.effectiveForClip(otherClip, projectSettings),
        )
        assertEquals(
            projectSettings,
            ProjectColorSettings.effectiveForClip(legacyClip, projectSettings),
        )
        assertEquals(
            projectSettings,
            ProjectColorSettings.effectiveForClip(
                mapOf("colorSettingsOverride" to null),
                projectSettings,
            ),
        )
    }

    @Test
    fun explicitEmptyOverrideRemainsNeutral() {
        val projectSettings = ProjectColorSettings(
            brightness = 0.4f,
            contrast = -0.25f,
            saturation = 25f,
        )

        assertEquals(
            ProjectColorSettings(),
            ProjectColorSettings.effectiveForClip(
                mapOf("colorSettingsOverride" to emptyMap<String, Any>()),
                projectSettings,
            ),
        )
    }

    @Test
    fun outOfRangeValuesAreClampedToMedia3Ranges() {
        val settings = ProjectColorSettings.fromMap(
            mapOf("brightness" to 3, "contrast" to -4, "saturation" to 140),
        )

        assertEquals(1f, settings.brightness, 0f)
        assertEquals(-1f, settings.contrast, 0f)
        assertEquals(100f, settings.saturation, 0f)
        assertEquals(1f, settings.warmth, 0f)
    }

    @Test
    fun finiteDoubleOverflowValuesClampBeforeFloatConversion() {
        val settings = ProjectColorSettings.fromMap(
            mapOf(
                "brightness" to Double.MAX_VALUE,
                "contrast" to Double.MAX_VALUE,
                "saturation" to Double.MAX_VALUE,
                "warmth" to Double.MAX_VALUE,
            ),
        )

        assertEquals(1f, settings.brightness, 0f)
        assertEquals(1f, settings.contrast, 0f)
        assertEquals(100f, settings.saturation, 0f)
        assertEquals(1f, settings.warmth, 0f)
    }

    @Test
    fun warmthUsesOpposingRedAndBlueScales() {
        assertEquals(1.16f, projectWarmthRgbScales(1f).first, 0.0001f)
        assertEquals(0.84f, projectWarmthRgbScales(1f).third, 0.0001f)
        assertEquals(0.84f, projectWarmthRgbScales(-1f).first, 0.0001f)
        assertEquals(1.16f, projectWarmthRgbScales(-1f).third, 0.0001f)
        assertEquals(Triple(1f, 1f, 1f), projectWarmthRgbScales(0f))
    }

    @Test
    fun invalidAndNonFiniteValuesFallBackToNeutral() {
        val settings = ProjectColorSettings.fromMap(
            mapOf(
                "brightness" to Double.NaN,
                "contrast" to Double.POSITIVE_INFINITY,
                "saturation" to "not-a-number",
                "warmth" to Double.NaN,
            ),
        )

        assertEquals(0f, settings.brightness, 0f)
        assertEquals(0f, settings.contrast, 0f)
        assertEquals(0f, settings.saturation, 0f)
        assertEquals(0f, settings.warmth, 0f)
    }
}
