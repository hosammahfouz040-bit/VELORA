/// A parallel visual track above the primary sequential video track.
/// Track list order is the composition z-order (earlier entries are higher).
class VideoOverlayTrack {
  const VideoOverlayTrack({
    required this.id,
    required this.name,
    this.clips = const [],
  });

  final String id;
  final String name;
  final List<VideoOverlayClip> clips;

  VideoOverlayTrack copyWith({String? name, List<VideoOverlayClip>? clips}) =>
      VideoOverlayTrack(
        id: id,
        name: name ?? this.name,
        clips: clips ?? this.clips,
      );

  factory VideoOverlayTrack.fromMap(Map<String, dynamic> map) =>
      VideoOverlayTrack(
        id: map['id'] as String? ?? _videoOverlayId(),
        name: map['name'] as String? ?? 'فيديو إضافي',
        clips: ((map['clips'] as List<dynamic>?) ?? const [])
            .map((item) => VideoOverlayClip.fromMap(
                  Map<String, dynamic>.from(item as Map),
                ))
            .toList(),
      );

  Map<String, Object> toMap() => {
        'id': id,
        'name': name,
        'clips': clips.map((clip) => clip.toMap()).toList(),
      };
}

/// One timed image/video segment placed on a parallel video track.
/// It deliberately has no audio flag: secondary-track source audio is muted to
/// prevent accidental duplication of the main video's embedded audio.
class VideoOverlayClip {
  const VideoOverlayClip({
    required this.id,
    required this.assetId,
    required this.trimStartMs,
    required this.trimEndMs,
    required this.timelineStartMs,
    this.positionX = 0.78,
    this.positionY = 0.22,
    this.widthFraction = 0.28,
    this.heightFraction = 0.28,
  });

  final String id;
  final String assetId;
  final int trimStartMs;
  final int trimEndMs;
  final int timelineStartMs;
  /// Normalized center position in the final frame (0..1 from left/top).
  final double positionX;
  final double positionY;
  /// Width and height as fractions of the final composition frame.
  final double widthFraction;
  final double heightFraction;

  int get durationMs => trimEndMs - trimStartMs;
  int get timelineEndMs => timelineStartMs + durationMs;

  bool isVisibleAt(int timelineMs) =>
      timelineMs >= timelineStartMs && timelineMs < timelineEndMs;

  bool overlaps(VideoOverlayClip other) =>
      timelineStartMs < other.timelineEndMs &&
      other.timelineStartMs < timelineEndMs;

  VideoOverlayClip copyWith({
    int? trimStartMs,
    int? trimEndMs,
    int? timelineStartMs,
    double? positionX,
    double? positionY,
    double? widthFraction,
    double? heightFraction,
  }) =>
      VideoOverlayClip(
        id: id,
        assetId: assetId,
        trimStartMs: (trimStartMs ?? this.trimStartMs)
            .clamp(0, 1 << 53)
            .toInt(),
        trimEndMs: (trimEndMs ?? this.trimEndMs)
            .clamp(0, 1 << 53)
            .toInt(),
        timelineStartMs: (timelineStartMs ?? this.timelineStartMs)
            .clamp(0, 1 << 53)
            .toInt(),
        positionX: _boundedUnit(positionX ?? this.positionX),
        positionY: _boundedUnit(positionY ?? this.positionY),
        widthFraction: _boundedSize(widthFraction ?? this.widthFraction),
        heightFraction: _boundedSize(heightFraction ?? this.heightFraction),
      );

  factory VideoOverlayClip.fromMap(Map<String, dynamic> map) =>
      VideoOverlayClip(
        id: map['id'] as String? ?? _videoOverlayId(),
        assetId: map['assetId'] as String? ?? '',
        trimStartMs: _safeMs(map['trimStartMs']),
        trimEndMs: _safeMs(map['trimEndMs']),
        timelineStartMs: _safeMs(map['timelineStartMs']),
        positionX: _safeDouble(map['positionX'], 0.78, 0, 1),
        positionY: _safeDouble(map['positionY'], 0.22, 0, 1),
        widthFraction: _safeDouble(map['widthFraction'], 0.28, 0.05, 1),
        heightFraction: _safeDouble(map['heightFraction'], 0.28, 0.05, 1),
      );

  Map<String, Object> toMap() => {
        'id': id,
        'assetId': assetId,
        'trimStartMs': trimStartMs,
        'trimEndMs': trimEndMs,
        'timelineStartMs': timelineStartMs,
        'positionX': positionX,
        'positionY': positionY,
        'widthFraction': widthFraction,
        'heightFraction': heightFraction,
      };
}

int _safeMs(Object? raw) =>
    ((raw as num?)?.toInt() ?? 0).clamp(0, 1 << 53).toInt();

double _safeDouble(Object? raw, double fallback, double min, double max) {
  final value = (raw as num?)?.toDouble() ?? fallback;
  return value.isFinite ? value.clamp(min, max).toDouble() : fallback;
}

double _boundedUnit(double value) =>
    value.isFinite ? value.clamp(0, 1).toDouble() : 0.5;

double _boundedSize(double value) =>
    value.isFinite ? value.clamp(0.05, 1).toDouble() : 0.28;

String _videoOverlayId() =>
    'pip_${DateTime.now().microsecondsSinceEpoch}_${DateTime.now().millisecond}';
