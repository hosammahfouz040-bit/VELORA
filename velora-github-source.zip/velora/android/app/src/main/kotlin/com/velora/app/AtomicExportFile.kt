package com.velora.app

import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * Copies a completed Transformer output to a same-directory staging file, then
 * atomically renames it to the user-visible .mp4 destination. The destination
 * is never exposed while bytes are still being copied.
 */
internal fun publishExportFileAtomically(
    source: File,
    destination: File,
    ensureActive: () -> Unit,
    trackOutput: (File?) -> Unit,
) {
    val directory = destination.parentFile
        ?: throw IOException("Export destination has no parent directory")
    if (!directory.isDirectory && !directory.mkdirs() && !directory.isDirectory) {
        throw IOException("Could not create the export destination directory")
    }
    val stagingFile = File(directory, ".${destination.name}.${UUID.randomUUID()}.partial")
    var publishedByThisOperation = false
    try {
        ensureActive()
        trackOutput(stagingFile)
        source.inputStream().use { input ->
            stagingFile.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    ensureActive()
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                }
                output.fd.sync()
            }
        }
        ensureActive()
        if (destination.exists()) {
            throw IOException("Export destination already exists")
        }
        if (!stagingFile.renameTo(destination)) {
            throw IOException("Could not atomically publish the completed MP4")
        }
        publishedByThisOperation = true
        trackOutput(destination)
        ensureActive()
    } catch (error: Throwable) {
        stagingFile.delete()
        if (publishedByThisOperation) destination.delete()
        runCatching { trackOutput(null) }
        throw error
    }
}
