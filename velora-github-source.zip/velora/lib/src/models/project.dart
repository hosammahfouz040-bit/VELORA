import 'clip_motion.dart';
import 'overlays.dart';
import 'video_overlays.dart';
import 'video_transitions.dart';

enum MediaKind { video, image, audio, unsupported }

enum FrameFitMode { fit, fill }

/// Project-wide visual framing, shared by the preview and the Media3 export.
/// `source` is the backwards-compatible default: keep each source's aspect ratio.
class VideoFrameSettings {
  const VideoFrameSettings({
    this.aspectRatio = 'source',
    this.fitMode = FrameFitMode.fit,
    this.positionX = 0,
    this.positionY = 0,
    this.rotationQuarterTurns = 0,
    this.flipHorizontal = false,
    this.flipVertical = false,
  });

  static const defaults = VideoFrameSettings();
  static const supportedAspectRatios = <String>[
    'source',
    '9:16',
    '16:9',
    '1:1',
    '4:5',
  ];

  final String aspectRatio;
  final FrameFitMode fitMode;
  /// Normalized framing offsets in the range -1..1 (left/top to right/bottom).
  final double positionX;
  final double positionY;
  /// Clockwise quarter turns, normalized to 0..3.
  final int rotationQuarterTurns;
  final bool flipHorizontal;
  final bool flipVertical;

  double? get targetAspectRatio => switch (aspectRatio) {
    '9:16' => 9 / 16,
    '16:9' => 16 / 9,
    '1:1' => 1,
    '4:5' => 4 / 5,
    _ => null,
  };

  VideoFrameSettings copyWith({
    String? aspectRatio,
    FrameFitMode? fitMode,
    double? positionX,
    double? positionY,
    int? rotationQuarterTurns,
    bool? flipHorizontal,
    bool? flipVertical,
  }) => VideoFrameSettings(
    aspectRatio: supportedAspectRatios.contains(aspectRatio)
        ? aspectRatio!
        : this.aspectRatio,
    fitMode: fitMode ?? this.fitMode,
    positionX: _normalizedOffset(positionX ?? this.positionX),
    positionY: _normalizedOffset(positionY ?? this.positionY),
    rotationQuarterTurns:
        (((rotationQuarterTurns ?? this.rotationQuarterTurns) % 4) + 4) % 4,
    flipHorizontal: flipHorizontal ?? this.flipHorizontal,
    flipVertical: flipVertical ?? this.flipVertical,
  );

  factory VideoFrameSettings.fromMap(Object? raw) {
    if (raw is! Map) return defaults;
    final map = Map<String, dynamic>.from(raw);
    final rawRatio = map['aspectRatio']?.toString();
    final ratio = supportedAspectRatios.contains(rawRatio) ? rawRatio! : 'source';
    final rawMode = map['fitMode']?.toString();
    final mode = rawMode == 'fill' ? FrameFitMode.fill : FrameFitMode.fit;
    final rawTurns = (map['rotationQuarterTurns'] as num?)?.toInt() ?? 0;
    return VideoFrameSettings(
      aspectRatio: ratio,
      fitMode: mode,
      positionX: _normalizedOffset((map['positionX'] as num?)?.toDouble() ?? 0),
      positionY: _normalizedOffset((map['positionY'] as num?)?.toDouble() ?? 0),
      rotationQuarterTurns: ((rawTurns % 4) + 4) % 4,
      flipHorizontal: map['flipHorizontal'] as bool? ?? false,
      flipVertical: map['flipVertical'] as bool? ?? false,
    );
  }

  Map<String, Object> toMap() => {
    'aspectRatio': aspectRatio,
    'fitMode': fitMode.name,
    'positionX': positionX,
    'positionY': positionY,
    'rotationQuarterTurns': rotationQuarterTurns,
    'flipHorizontal': flipHorizontal,
    'flipVertical': flipVertical,
  };

  @override
  bool operator ==(Object other) =>
      other is VideoFrameSettings &&
      other.aspectRatio == aspectRatio &&
      other.fitMode == fitMode &&
      other.positionX == positionX &&
      other.positionY == positionY &&
      other.rotationQuarterTurns == rotationQuarterTurns &&
      other.flipHorizontal == flipHorizontal &&
      other.flipVertical == flipVertical;

  @override
  int get hashCode => Object.hash(
    aspectRatio,
    fitMode,
    positionX,
    positionY,
    rotationQuarterTurns,
    flipHorizontal,
    flipVertical,
  );
}

/// Project-wide, neutral-by-default color corrections consumed by Media3.
class VideoColorSettings {
  factory VideoColorSettings({
    double brightness = 0,
    double contrast = 0,
    double saturation = 0,
    double warmth = 0,
  }) => VideoColorSettings._(
    brightness: _boundedColorValue(brightness, -1, 1),
    contrast: _boundedColorValue(contrast, -1, 1),
    saturation: _boundedColorValue(saturation, -100, 100),
    warmth: _boundedColorValue(warmth, -1, 1),
  );

  const VideoColorSettings._({
    required this.brightness,
    required this.contrast,
    required this.saturation,
    required this.warmth,
  });

  static const defaults = VideoColorSettings._(
    brightness: 0,
    contrast: 0,
    saturation: 0,
    warmth: 0,
  );

  final double brightness;
  final double contrast;
  final double saturation;
  /// Red/blue channel balance, -1 cool through 0 neutral to +1 warm.
  final double warmth;

  factory VideoColorSettings.fromMap(Object? raw) {
    if (raw is! Map) return defaults;
    return VideoColorSettings(
      brightness: _colorValueFromMap(raw['brightness'], -1, 1),
      contrast: _colorValueFromMap(raw['contrast'], -1, 1),
      saturation: _colorValueFromMap(raw['saturation'], -100, 100),
      warmth: _colorValueFromMap(raw['warmth'], -1, 1),
    );
  }

  Map<String, Object> toMap() => {
    'brightness': brightness,
    'contrast': contrast,
    'saturation': saturation,
    'warmth': warmth,
  };

  VideoColorSettings copyWith({
    double? brightness,
    double? contrast,
    double? saturation,
    double? warmth,
  }) => VideoColorSettings(
    brightness: brightness ?? this.brightness,
    contrast: contrast ?? this.contrast,
    saturation: saturation ?? this.saturation,
    warmth: warmth ?? this.warmth,
  );

  @override
  bool operator ==(Object other) =>
      other is VideoColorSettings &&
      other.brightness == brightness &&
      other.contrast == contrast &&
      other.saturation == saturation &&
      other.warmth == warmth;

  @override
  int get hashCode => Object.hash(brightness, contrast, saturation, warmth);
}

double _colorValueFromMap(Object? raw, double minimum, double maximum) {
  if (raw is! num) return 0;
  return _boundedColorValue(raw.toDouble(), minimum, maximum);
}

double _boundedColorValue(double value, double minimum, double maximum) =>
    value.isFinite ? value.clamp(minimum, maximum).toDouble() : 0;

double _normalizedOffset(double value) =>
    value.isFinite ? value.clamp(-1, 1).toDouble() : 0;

MediaKind mediaKindFromString(Object? value) {
  return MediaKind.values.firstWhere(
    (kind) => kind.name == value,
    orElse: () => MediaKind.unsupported,
  );
}

class MediaAsset {
  const MediaAsset({
    required this.id,
    required this.uri,
    required this.name,
    required this.mimeType,
    required this.kind,
    required this.durationMs,
    required this.width,
    required this.height,
    required this.sizeBytes,
  });

  final String id;
  final String uri;
  final String name;
  final String mimeType;
  final MediaKind kind;
  final int durationMs;
  final int width;
  final int height;
  final int sizeBytes;

  factory MediaAsset.fromMap(Map<String, dynamic> map) => MediaAsset(
    id: map['id'] as String,
    uri: map['uri'] as String,
    name: map['name'] as String? ?? 'وسيط بلا اسم',
    mimeType: map['mimeType'] as String? ?? 'application/octet-stream',
    kind: mediaKindFromString(map['kind']),
    durationMs: (map['durationMs'] as num?)?.toInt() ?? 0,
    width: (map['width'] as num?)?.toInt() ?? 0,
    height: (map['height'] as num?)?.toInt() ?? 0,
    sizeBytes: (map['sizeBytes'] as num?)?.toInt() ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'uri': uri,
    'name': name,
    'mimeType': mimeType,
    'kind': kind.name,
    'durationMs': durationMs,
    'width': width,
    'height': height,
    'sizeBytes': sizeBytes,
  };
}

class TimelineClip {
  const TimelineClip({
    required this.id,
    required this.assetId,
    required this.trimStartMs,
    required this.trimEndMs,
    this.timelineStartMs = 0,
    this.volume = 1.0,
    this.fadeInMs = 0,
    this.fadeOutMs = 0,
    this.transformKeyframes = const [],
    this.speedRampPoints = const [],
    this.colorSettingsOverride,
  });

  final String id;
  final String assetId;
  final int trimStartMs;
  final int trimEndMs;

  /// Start position on the project timeline (used by the independent audio track).
  final int timelineStartMs;

  /// Linear gain in the inclusive range 0..1, plus fade durations in milliseconds.
  final double volume;
  final int fadeInMs;
  final int fadeOutMs;
  final List<ClipTransformKeyframe> transformKeyframes;
  final List<SpeedRampPoint> speedRampPoints;

  /// Null inherits project-level settings; used by visual-track clips only.
  final VideoColorSettings? colorSettingsOverride;

  int get durationMs => trimEndMs - trimStartMs;
  List<SpeedRampPoint> get effectiveSpeedRampPoints =>
      speedRampPointsForSourceDuration(speedRampPoints, durationMs);

  int get effectiveDurationMs => speedAdjustedDurationMs(
    trimStartMs,
    trimEndMs,
    effectiveSpeedRampPoints,
  );
  int get timelineEndMs => timelineStartMs + durationMs;

  VideoColorSettings effectiveColorSettings(VideoColorSettings projectSettings) =>
      colorSettingsOverride ?? projectSettings;

  TimelineClip copyWith({
    int? trimStartMs,
    int? trimEndMs,
    int? timelineStartMs,
    double? volume,
    int? fadeInMs,
    int? fadeOutMs,
    List<ClipTransformKeyframe>? transformKeyframes,
    List<SpeedRampPoint>? speedRampPoints,
    VideoColorSettings? colorSettingsOverride,
    bool clearColorSettingsOverride = false,
  }) => TimelineClip(
    id: id,
    assetId: assetId,
    trimStartMs: trimStartMs ?? this.trimStartMs,
    trimEndMs: trimEndMs ?? this.trimEndMs,
    timelineStartMs: timelineStartMs ?? this.timelineStartMs,
    volume: volume ?? this.volume,
    fadeInMs: fadeInMs ?? this.fadeInMs,
    fadeOutMs: fadeOutMs ?? this.fadeOutMs,
    transformKeyframes: transformKeyframes ?? this.transformKeyframes,
    speedRampPoints: speedRampPoints ?? this.speedRampPoints,
    colorSettingsOverride: clearColorSettingsOverride
        ? null
        : colorSettingsOverride ?? this.colorSettingsOverride,
  );

  factory TimelineClip.fromMap(Map<String, dynamic> map) => TimelineClip(
    id: map['id'] as String,
    assetId: map['assetId'] as String,
    trimStartMs: (map['trimStartMs'] as num?)?.toInt() ?? 0,
    trimEndMs: (map['trimEndMs'] as num?)?.toInt() ?? 0,
    timelineStartMs: ((map['timelineStartMs'] as num?)?.toInt() ?? 0)
        .clamp(0, 9007199254740991)
        .toInt(),
    volume: ((map['volume'] as num?)?.toDouble() ?? 1.0)
        .clamp(0, 1)
        .toDouble(),
    fadeInMs: ((map['fadeInMs'] as num?)?.toInt() ?? 0)
        .clamp(0, 9007199254740991)
        .toInt(),
    fadeOutMs: ((map['fadeOutMs'] as num?)?.toInt() ?? 0)
        .clamp(0, 9007199254740991)
        .toInt(),
    transformKeyframes: _motionRows(map['transformKeyframes'])
        .map(ClipTransformKeyframe.fromMap)
        .toList(),
    speedRampPoints: _motionRows(map['speedRampPoints'])
        .map(SpeedRampPoint.fromMap)
        .toList(),
    colorSettingsOverride: map['colorSettingsOverride'] is Map
        ? VideoColorSettings.fromMap(map['colorSettingsOverride'])
        : null,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'assetId': assetId,
    'trimStartMs': trimStartMs,
    'trimEndMs': trimEndMs,
    'timelineStartMs': timelineStartMs,
    'volume': volume,
    'fadeInMs': fadeInMs,
    'fadeOutMs': fadeOutMs,
    'transformKeyframes': transformKeyframes.map((point) => point.toMap()).toList(),
    'speedRampPoints': speedRampPoints.map((point) => point.toMap()).toList(),
    if (colorSettingsOverride != null)
      'colorSettingsOverride': colorSettingsOverride!.toMap(),
  };
}

class VeloraProject {
  const VeloraProject({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.assets,
    required this.videoTrack,
    required this.audioTrack,
    this.frameSettings = VideoFrameSettings.defaults,
    this.colorSettings = VideoColorSettings.defaults,
    this.textOverlays = const [],
    this.subtitleTrack = const [],
    this.stickerOverlays = const [],
    this.videoOverlayTracks = const [],
    this.videoTransitions = const [],
  });

  final String id;
  final String name;
  final String createdAt;
  final List<MediaAsset> assets;
  final List<TimelineClip> videoTrack;
  final List<TimelineClip> audioTrack;
  final VideoFrameSettings frameSettings;
  final VideoColorSettings colorSettings;
  final List<TextOverlay> textOverlays;
  final List<SubtitleCue> subtitleTrack;
  final List<StickerOverlay> stickerOverlays;
  final List<VideoOverlayTrack> videoOverlayTracks;
  final List<VideoTransition> videoTransitions;

  factory VeloraProject.empty({required String id, required String name}) =>
      VeloraProject(
        id: id,
        name: name,
        createdAt: DateTime.now().toUtc().toIso8601String(),
        assets: const [],
        videoTrack: const [],
        audioTrack: const [],
      );

  factory VeloraProject.fromMap(Map<String, dynamic> map) => VeloraProject(
    id: map['id'] as String,
    name: map['name'] as String? ?? 'مشروع جديد',
    createdAt: map['createdAt'] as String? ?? '',
    assets: ((map['assets'] as List<dynamic>?) ?? const [])
        .map((item) => MediaAsset.fromMap(Map<String, dynamic>.from(item as Map)))
        .toList(),
    videoTrack: ((map['videoTrack'] as List<dynamic>?) ?? const [])
        .map((item) => TimelineClip.fromMap(Map<String, dynamic>.from(item as Map)))
        .toList(),
    audioTrack: _audioTrackFromMap(map['audioTrack']),
    frameSettings: VideoFrameSettings.fromMap(map['frameSettings']),
    colorSettings: VideoColorSettings.fromMap(map['colorSettings']),
    textOverlays: _overlayList(map['textOverlays'], TextOverlay.fromMap),
    subtitleTrack: _overlayList(map['subtitleTrack'], SubtitleCue.fromMap),
    stickerOverlays: _overlayList(map['stickerOverlays'], StickerOverlay.fromMap),
    videoOverlayTracks: ((map['videoOverlayTracks'] as List<dynamic>?) ?? const [])
        .map((item) => VideoOverlayTrack.fromMap(
              Map<String, dynamic>.from(item as Map),
            ))
        .toList(),
    videoTransitions: ((map['videoTransitions'] as List<dynamic>?) ?? const [])
        .map((item) => VideoTransition.fromMap(
              Map<String, dynamic>.from(item as Map),
            ))
        .toList(),
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'createdAt': createdAt,
    'assets': assets.map((asset) => asset.toMap()).toList(),
    'videoTrack': videoTrack.map((clip) => clip.toMap()).toList(),
    'audioTrack': audioTrack.map((clip) => clip.toMap()).toList(),
    'frameSettings': frameSettings.toMap(),
    'colorSettings': colorSettings.toMap(),
    'textOverlays': textOverlays.map((item) => item.toMap()).toList(),
    'subtitleTrack': subtitleTrack.map((item) => item.toMap()).toList(),
    'stickerOverlays': stickerOverlays.map((item) => item.toMap()).toList(),
    'videoOverlayTracks': videoOverlayTracks.map((item) => item.toMap()).toList(),
    'videoTransitions': videoTransitions.map((item) => item.toMap()).toList(),
  };

  VeloraProject copyWith({
    String? name,
    List<MediaAsset>? assets,
    List<TimelineClip>? videoTrack,
    List<TimelineClip>? audioTrack,
    VideoFrameSettings? frameSettings,
    VideoColorSettings? colorSettings,
    List<TextOverlay>? textOverlays,
    List<SubtitleCue>? subtitleTrack,
    List<StickerOverlay>? stickerOverlays,
    List<VideoOverlayTrack>? videoOverlayTracks,
    List<VideoTransition>? videoTransitions,
  }) => VeloraProject(
    id: id,
    name: name ?? this.name,
    createdAt: createdAt,
    assets: assets ?? this.assets,
    videoTrack: videoTrack ?? this.videoTrack,
    audioTrack: audioTrack ?? this.audioTrack,
    frameSettings: frameSettings ?? this.frameSettings,
    colorSettings: colorSettings ?? this.colorSettings,
    textOverlays: textOverlays ?? this.textOverlays,
    subtitleTrack: subtitleTrack ?? this.subtitleTrack,
    stickerOverlays: stickerOverlays ?? this.stickerOverlays,
    videoOverlayTracks: videoOverlayTracks ?? this.videoOverlayTracks,
    videoTransitions: videoTransitions ?? this.videoTransitions,
  );

  MediaAsset? assetById(String assetId) {
    for (final asset in assets) {
      if (asset.id == assetId) return asset;
    }
    return null;
  }
}

List<TimelineClip> _audioTrackFromMap(Object? rawTrack) {
  final rows = (rawTrack as List<dynamic>?) ?? const [];
  var legacyCursorMs = 0;
  return rows.map((item) {
    final row = Map<String, dynamic>.from(item as Map);
    var clip = TimelineClip.fromMap(row);
    if (!row.containsKey('timelineStartMs')) {
      clip = clip.copyWith(timelineStartMs: legacyCursorMs);
    }
    if (clip.timelineEndMs > legacyCursorMs) {
      legacyCursorMs = clip.timelineEndMs;
    }
    return clip;
  }).toList();
}

String newLocalId() =>
    '${DateTime.now().microsecondsSinceEpoch}_${DateTime.now().millisecond}';

List<Map<String, dynamic>> _motionRows(Object? raw) => (raw as List<dynamic>? ?? const [])
    .whereType<Map>()
    .map((item) => Map<String, dynamic>.from(item))
    .toList();

List<T> _overlayList<T>(Object? raw, T Function(Map<String, dynamic>) fromMap) {
  final rows = raw as List<dynamic>? ?? const [];
  return rows
      .map((item) => fromMap(Map<String, dynamic>.from(item as Map)))
      .toList();
}
