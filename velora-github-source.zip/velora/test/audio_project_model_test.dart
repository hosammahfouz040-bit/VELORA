import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';

Map<String, dynamic> _projectMap(List<Map<String, dynamic>> audioTrack) => {
  'id': 'project',
  'name': 'Project',
  'createdAt': '2026-10-28T00:00:00.000Z',
  'assets': const [],
  'videoTrack': const [],
  'audioTrack': audioTrack,
};

Map<String, dynamic> _oldClip(String id, int durationMs) => {
  'id': id,
  'assetId': 'asset-$id',
  'trimStartMs': 0,
  'trimEndMs': durationMs,
};

void main() {
  test('legacy audio clips without positions retain sequential placement', () {
    final project = VeloraProject.fromMap(
      _projectMap([_oldClip('a', 1800), _oldClip('b', 2400)]),
    );

    expect(project.audioTrack.map((clip) => clip.timelineStartMs), [0, 1800]);
    expect(project.audioTrack.map((clip) => clip.volume), [1, 1]);
    expect(project.audioTrack.map((clip) => clip.fadeInMs), [0, 0]);
    expect(
      VeloraProject.fromMap(project.toMap()).audioTrack.map(
        (clip) => clip.timelineStartMs,
      ),
      [0, 1800],
    );
  });

  test('new audio fields round-trip; invalid gain and negative values are bounded', () {
    final project = VeloraProject.fromMap(
      _projectMap([
        {
          ..._oldClip('music', 5000),
          'timelineStartMs': -300,
          'volume': 1.7,
          'fadeInMs': 1500,
          'fadeOutMs': 900,
        },
      ]),
    );
    final clip = project.audioTrack.single;
    expect(clip.timelineStartMs, 0);
    expect(clip.volume, 1);
    expect(clip.fadeInMs, 1500);
    expect(clip.fadeOutMs, 900);

    final restored = VeloraProject.fromMap(project.toMap()).audioTrack.single;
    expect(restored.timelineStartMs, 0);
    expect(restored.volume, 1);
    expect(restored.fadeInMs, 1500);
    expect(restored.fadeOutMs, 900);
  });
}
