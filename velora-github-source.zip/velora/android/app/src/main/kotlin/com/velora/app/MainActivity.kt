package com.velora.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.content.Intent
import android.database.Cursor
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.system.Os
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.audio.ToInt16PcmAudioProcessor
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.UUID
import java.util.concurrent.CancellationException
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : FlutterActivity() {
    private lateinit var methodChannel: MethodChannel
    private var pendingPickerResult: MethodChannel.Result? = null
    private var pendingPickerMode: String = "media"
    private var activeExport: ExportState? = null
    private var activeAudioExtraction: AudioExtractionState? = null

    override fun onStop() {
        VeloraPreviewPlayerRegistry.pause()
        super.onStop()
    }

    override fun onDestroy() {
        cancelActiveExport("Activity destroyed before export completed")
        cancelActiveAudioExtraction("Activity destroyed before audio extraction completed")
        VeloraPreviewPlayerRegistry.clear()
        super.onDestroy()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "velora/preview",
            VeloraPreviewFactory(),
        )
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel.setMethodCallHandler(::handleMethodCall)
    }

    @androidx.media3.common.util.UnstableApi
    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "pickMedia" -> launchMediaPicker(result, "media")
            "pickSticker" -> launchMediaPicker(result, "sticker")
            "pickReplacementMedia" -> {
                val kind = (call.arguments as? Map<*, *>)?.get("kind")?.toString().orEmpty()
                if (kind !in setOf("video", "image", "audio")) {
                    result.error("invalid_media_kind", "Unsupported replacement media kind", null)
                } else {
                    launchMediaPicker(result, "replace_$kind")
                }
            }
            "pickSubtitle" -> launchMediaPicker(result, "subtitle")
            "loadStickerBytes" -> {
                try {
                    val uriText = (call.arguments as? Map<*, *>)?.get("uri")?.toString()
                        ?: throw IllegalArgumentException("Sticker URI is missing")
                    val bytes = contentResolver.openInputStream(Uri.parse(uriText))?.use { it.readBytes() }
                        ?: throw IllegalArgumentException("Unable to read sticker")
                    require(bytes.size <= MAX_STICKER_BYTES) { "Sticker image is too large to preview" }
                    result.success(bytes)
                } catch (error: Exception) {
                    result.error("sticker_read_failed", error.message, null)
                }
            }
            "configurePreviewTimeline" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing preview configuration")
                    configurePreviewTimeline(args)
                    result.success(null)
                } catch (error: MediaAccessException) {
                    result.error("media_access_lost", error.message, error.details)
                } catch (error: Exception) {
                    result.error("preview_timeline_setup_failed", error.message, null)
                }
            }
            "setPreviewSource" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing source preview")
                    val uriText = args["uri"]?.toString()
                        ?: throw IllegalArgumentException("Media URI is missing")
                    val kind = args["kind"]?.toString().orEmpty()
                    if (kind == "video" || kind == "image") {
                        val positionMs = (args["positionMs"] as? Number)?.toLong() ?: 0L
                        val durationMs = (args["durationMs"] as? Number)?.toLong()
                            ?.takeIf { it > 0L } ?: 5_000L
                        val sourceBuilder = MediaItem.Builder().setUri(Uri.parse(uriText))
                        if (kind == "image") sourceBuilder.setImageDurationMs(durationMs)
                        VeloraPreviewPlayerRegistry.setSource(
                            sourceBuilder.build(),
                            positionMs,
                            durationMs,
                            ProjectFrameSettings.fromMap(args["frameSettings"]),
                            ProjectColorSettings.fromMap(args["colorSettings"]),
                        )
                    } else {
                        VeloraPreviewPlayerRegistry.clear()
                    }
                    result.success(null)
                } catch (error: Exception) {
                    result.error("preview_source_failed", error.message, null)
                }
            }
            "seekPreview" -> {
                val args = call.arguments as? Map<*, *>
                val itemIndex = (args?.get("mediaItemIndex") as? Number)?.toInt()
                val clipPositionMs = (args?.get("clipPositionMs") as? Number)?.toLong()
                val timelinePositionMs = (args?.get("timelinePositionMs") as? Number)?.toLong()
                if (itemIndex == null || clipPositionMs == null) {
                    result.error("invalid_preview_position", "A timeline item and position are required", null)
                } else {
                    VeloraPreviewPlayerRegistry.seekTo(itemIndex, clipPositionMs, timelinePositionMs)
                    result.success(null)
                }
            }
            "playPreview" -> {
                VeloraPreviewPlayerRegistry.play()
                result.success(null)
            }
            "pausePreview" -> {
                VeloraPreviewPlayerRegistry.pause()
                result.success(null)
            }
            "clearPreview" -> {
                VeloraPreviewPlayerRegistry.clear()
                result.success(null)
            }
            "getPreviewState" -> result.success(VeloraPreviewPlayerRegistry.state())
            "listProjects" -> {
                try {
                    result.success(readProjects())
                } catch (error: Exception) {
                    result.error("project_read_failed", error.message, null)
                }
            }
            "listTemplates" -> {
                try {
                    result.success(readTemplates())
                } catch (error: Exception) {
                    result.error("template_read_failed", error.message, null)
                }
            }
            "saveTemplate" -> {
                try {
                    val template = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing template data")
                    saveTemplate(template)
                    result.success(null)
                } catch (error: Exception) {
                    result.error("template_save_failed", error.message, null)
                }
            }
            "deleteTemplate" -> {
                try {
                    val id = (call.arguments as? Map<*, *>)?.get("id")?.toString()
                        ?: throw IllegalArgumentException("Template ID is missing")
                    result.success(deleteTemplate(id))
                } catch (error: Exception) {
                    result.error("template_delete_failed", error.message, null)
                }
            }
            "saveProject" -> {
                try {
                    val project = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing project map")
                    saveProject(project)
                    result.success(null)
                } catch (error: Exception) {
                    result.error("project_save_failed", error.message, null)
                }
            }
            "exportProject" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing export arguments")
                    val project = args["project"] as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing project data")
                    val height = (args["height"] as? Number)?.toInt() ?: 720
                    startExport(project, height, result)
                } catch (error: Exception) {
                    result.error("export_setup_failed", error.message, null)
                }
            }
            "cancelExport" -> result.success(cancelActiveExport("Export cancelled by user"))
            "extractVideoAudio" -> {
                try {
                    val args = call.arguments as? Map<*, *>
                        ?: throw IllegalArgumentException("Missing audio extraction arguments")
                    val asset = args["asset"] as? Map<*, *>
                        ?: throw IllegalArgumentException("Video asset is missing")
                    val clip = args["clip"] as? Map<*, *>
                        ?: throw IllegalArgumentException("Video clip is missing")
                    startVideoAudioExtraction(asset, clip, result)
                } catch (error: Exception) {
                    result.error("audio_extract_setup_failed", error.message, null)
                }
            }
            "cancelAudioExtraction" -> result.success(
                cancelActiveAudioExtraction("Audio extraction cancelled by user"),
            )
            else -> result.notImplemented()
        }
    }

    @Deprecated("Uses Activity result API to retain compatibility with FlutterActivity")
    private fun launchMediaPicker(result: MethodChannel.Result, mode: String) {
        if (pendingPickerResult != null) {
            result.error("picker_busy", "A media picker is already open", null)
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            when (mode) {
                "sticker" -> {
                    type = "image/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/png", "image/webp"))
                }
                "replace_video" -> type = "video/*"
                "replace_image" -> {
                    type = "image/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*"))
                }
                "replace_audio" -> type = "audio/*"
                "subtitle" -> {
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf("application/x-subrip", "application/srt", "text/plain", "application/octet-stream"),
                    )
                }
                else -> {
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf("video/*", "image/*", "audio/*"),
                    )
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pendingPickerResult = result
        pendingPickerMode = mode
        try {
            startActivityForResult(intent, PICK_MEDIA_REQUEST)
        } catch (error: Exception) {
            pendingPickerResult = null
            result.error("picker_unavailable", error.message, null)
        }
    }

    @Deprecated("Uses Activity result API to retain compatibility with FlutterActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_MEDIA_REQUEST) return
        val result = pendingPickerResult ?: return
        val mode = pendingPickerMode
        pendingPickerResult = null
        pendingPickerMode = "media"
        if (resultCode != RESULT_OK || data == null) {
            result.success(if (mode == "media") emptyList<Map<String, Any>>() else null)
            return
        }

        try {
            val uris = mutableListOf<Uri>()
            val clipData = data.clipData
            if (clipData != null) {
                for (index in 0 until clipData.itemCount) {
                    clipData.getItemAt(index).uri?.let(uris::add)
                }
            } else {
                data.data?.let(uris::add)
            }
            val permissionFlags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            if (mode != "subtitle") {
                uris.distinctBy(Uri::toString).forEach { uri ->
                    if (uri.scheme == "content") {
                        if ((permissionFlags and Intent.FLAG_GRANT_READ_URI_PERMISSION) == 0) {
                            throw MediaPermissionException(uri)
                        }
                        try {
                            contentResolver.takePersistableUriPermission(uri, permissionFlags)
                        } catch (_: SecurityException) {
                            throw MediaPermissionException(uri)
                        }
                        val persisted = contentResolver.persistedUriPermissions.any {
                            it.uri == uri && it.isReadPermission
                        }
                        if (!persisted) throw MediaPermissionException(uri)
                    }
                }
            }
            when {
                mode.startsWith("replace_") -> {
                    val selectedUris = uris.distinctBy(Uri::toString)
                    require(selectedUris.size == 1) { "Choose exactly one replacement file" }
                    result.success(describeMedia(selectedUris.single()))
                }
                mode == "subtitle" -> {
                    val uri = uris.firstOrNull()
                        ?: throw IllegalArgumentException("No subtitle file was selected")
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalArgumentException("Unable to read subtitle file")
                    require(bytes.size <= MAX_SUBTITLE_BYTES) { "Subtitle file is too large" }
                    result.success(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
                }
                mode == "sticker" -> {
                    val uri = uris.firstOrNull()
                        ?: throw IllegalArgumentException("No image was selected")
                    val asset = describeMedia(uri)
                    require(asset["mimeType"] == "image/png" || asset["mimeType"] == "image/webp") {
                        "Choose a PNG or WebP image for a transparent sticker"
                    }
                    result.success(asset)
                }
                else -> result.success(uris.distinctBy(Uri::toString).map(::describeMedia))
            }
        } catch (error: MediaPermissionException) {
            result.error(
                "media_permission_not_persisted",
                "تعذّر حفظ إذن قراءة الملف؛ لم تُضف أي مراجع جديدة للمشروع. اختر الملف من موفّر مستندات يدعم الوصول الدائم أو من موقع محلي.",
                mapOf("uri" to error.uri.toString()),
            )
        } catch (error: Exception) {
            result.error("media_metadata_failed", error.message, null)
        }
    }

    private fun describeMedia(uri: Uri): Map<String, Any> {
        val name = queryDisplayName(uri) ?: "وسيط-${UUID.randomUUID()}"
        val contentType = contentResolver.getType(uri)
        val lowerName = name.lowercase()
        val mime = contentType ?: when {
            lowerName.endsWith(".mp4") || lowerName.endsWith(".mov") || lowerName.endsWith(".mkv") -> "video/mp4"
            lowerName.endsWith(".png") -> "image/png"
            lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") -> "image/jpeg"
            lowerName.endsWith(".webp") -> "image/webp"
            lowerName.endsWith(".wav") -> "audio/wav"
            lowerName.endsWith(".m4a") -> "audio/mp4"
            lowerName.endsWith(".mp3") -> "audio/mpeg"
            else -> "application/octet-stream"
        }
        val kind = when {
            mime.startsWith("video/") -> "video"
            mime.startsWith("image/") -> "image"
            mime.startsWith("audio/") -> "audio"
            else -> when {
                lowerName.endsWith(".mp4") || lowerName.endsWith(".mov") || lowerName.endsWith(".mkv") -> "video"
                lowerName.endsWith(".png") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".webp") -> "image"
                lowerName.endsWith(".mp3") || lowerName.endsWith(".wav") || lowerName.endsWith(".m4a") || lowerName.endsWith(".aac") -> "audio"
                else -> "unsupported"
            }
        }
        var durationMs = if (kind == "image") 5_000L else 0L
        var width = 0
        var height = 0
        if (kind == "image") {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                width = bounds.outWidth.coerceAtLeast(0)
                height = bounds.outHeight.coerceAtLeast(0)
            } catch (_: Exception) {
                // Image dimensions are optional for the media library.
            }
        }
        if (kind == "video" || kind == "audio") {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 0
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 0
            } catch (_: Exception) {
                // A zero duration is kept explicit; the editor will not silently invent a video duration.
            } finally {
                try {
                    retriever.release()
                } catch (_: Exception) {
                }
            }
        }
        return mapOf(
            "id" to UUID.randomUUID().toString(),
            "uri" to uri.toString(),
            "name" to name,
            "mimeType" to mime,
            "kind" to kind,
            "durationMs" to durationMs,
            "width" to width,
            "height" to height,
            "sizeBytes" to querySize(uri),
        )
    }

    private fun queryDisplayName(uri: Uri): String? = queryColumn(uri, OpenableColumns.DISPLAY_NAME)

    private fun querySize(uri: Uri): Long = queryColumn(uri, OpenableColumns.SIZE)?.toLongOrNull() ?: 0L

    private fun queryColumn(uri: Uri, column: String): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(column), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(column)
                if (index >= 0 && !cursor.isNull(index)) cursor.getString(index) else null
            } else {
                null
            }
        } finally {
            cursor?.close()
        }
    }

    private fun projectsDirectory(): File = File(filesDir, "velora/projects").apply { mkdirs() }

    private fun templatesDirectory(): File = File(filesDir, "velora/templates").apply { mkdirs() }

    private fun saveTemplate(template: Map<*, *>) {
        val id = template["id"]?.toString()?.takeIf { it.matches(Regex("[A-Za-z0-9_-]+")) }
            ?: throw IllegalArgumentException("Template ID is invalid")
        if (template["isBuiltIn"] == true) {
            throw IllegalArgumentException("Built-in templates cannot be overwritten")
        }
        val json = JSONObject()
        template.forEach { (key, value) ->
            if (key != null) json.put(key.toString(), toJsonValue(value))
        }
        File(templatesDirectory(), "$id.json").writeText(json.toString(), Charsets.UTF_8)
    }

    private fun readTemplates(): List<Map<String, Any?>> = templatesDirectory()
        .listFiles { file -> file.isFile && file.extension == "json" }
        .orEmpty()
        .sortedByDescending(File::lastModified)
        .mapNotNull { file ->
            runCatching { jsonObjectToMap(JSONObject(file.readText(Charsets.UTF_8))) }
                .getOrNull()
        }

    private fun deleteTemplate(id: String): Boolean {
        val safeId = id.takeIf { it.matches(Regex("[A-Za-z0-9_-]+")) }
            ?: throw IllegalArgumentException("Template ID is invalid")
        return File(templatesDirectory(), "$safeId.json").takeIf { it.isFile }?.delete() ?: false
    }

    private fun projectJsonStore() = ProjectJsonStore(
        directory = projectsDirectory(),
        decodeJson = { json -> jsonObjectToMap(JSONObject(json)) },
        replaceFile = { source, destination ->
            // POSIX rename within the same directory atomically replaces the old file.
            // If it fails, the old destination remains intact and ProjectJsonStore removes
            // only the unfinished temporary file.
            Os.rename(source.absolutePath, destination.absolutePath)
        },
    )

    private fun saveProject(project: Map<*, *>) {
        val id = project["id"]?.toString()?.takeIf { it.isNotBlank() }
            ?: throw IllegalArgumentException("Project ID is missing")
        val json = JSONObject()
        project.forEach { (key, value) ->
            if (key != null) json.put(key.toString(), toJsonValue(value))
        }
        projectJsonStore().save(id, json.toString())
    }

    private fun readProjects(): List<Map<String, Any?>> = projectJsonStore().readProjects()

    private fun toJsonValue(value: Any?): Any? = when (value) {
        null -> JSONObject.NULL
        is Map<*, *> -> JSONObject().also { json ->
            value.forEach { (key, nested) ->
                if (key != null) json.put(key.toString(), toJsonValue(nested))
            }
        }
        is Iterable<*> -> JSONArray().also { array -> value.forEach { array.put(toJsonValue(it)) } }
        is Array<*> -> JSONArray().also { array -> value.forEach { array.put(toJsonValue(it)) } }
        else -> value
    }

    private fun jsonObjectToMap(json: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = fromJsonValue(json.opt(key))
        }
        return output
    }

    private fun fromJsonValue(value: Any?): Any? = when (value) {
        JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { fromJsonValue(value.opt(it)) }
        else -> value
    }

    @androidx.media3.common.util.UnstableApi
    private fun startVideoAudioExtraction(
        asset: Map<*, *>,
        clip: Map<*, *>,
        result: MethodChannel.Result,
    ) {
        if (activeExport != null || activeAudioExtraction != null) {
            result.error("media_operation_busy", "Another media operation is already running", null)
            return
        }
        if (asset["kind"]?.toString() != "video") {
            result.error("invalid_audio_source", "Select a video clip to extract its sound", null)
            return
        }
        val uriText = asset["uri"]?.toString()
            ?: throw IllegalArgumentException("Video media URI is missing")
        val audioInfo = inspectAudioTrack(uriText)
        if (!audioInfo.hasAudio) {
            result.error("video_has_no_audio", "The selected video has no embedded audio track", null)
            return
        }
        val channels = audioInfo.channelCount
            ?: throw IllegalArgumentException("Could not determine the embedded audio channel count")
        require(channels in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
            "Embedded audio with $channels channels is unsupported"
        }
        val outputDurationMs = ProjectClipMotion.timingFromMap(clip).outputDurationMs
        require(outputDurationMs > 0L) { "The selected video clip has no usable duration" }

        val outputDirectory = File(
            getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir,
            "VELORA/ExtractedAudio",
        ).apply { mkdirs() }
        if (!outputDirectory.isDirectory) {
            throw IllegalStateException("Could not create the app's audio extraction directory")
        }
        val outputFile = File(outputDirectory, "velora-audio-${UUID.randomUUID()}.m4a")
        val state = AudioExtractionState(result, outputFile)
        activeAudioExtraction = state
        try {
            val audioItem = createSourceAudioItem(
                asset = asset.mapKeys { it.key.toString() },
                clip = clip.mapKeys { it.key.toString() },
                durationMs = outputDurationMs,
                includeClipAudioSettings = false,
            )
            val transformer = Transformer.Builder(this)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (state.cancelled.get()) return
                        try {
                            if (!outputFile.isFile || outputFile.length() <= 0L) {
                                throw IllegalStateException("Media3 produced no extracted audio data")
                            }
                            val extractedInfo = inspectAudioFile(outputFile.absolutePath)
                            if (!extractedInfo.hasAudio) {
                                throw IllegalStateException("Media3 output did not contain an audio track")
                            }
                            val retriever = MediaMetadataRetriever()
                            val durationMs = try {
                                retriever.setDataSource(outputFile.absolutePath)
                                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                                    ?.toLongOrNull() ?: 0L
                            } finally {
                                runCatching { retriever.release() }
                            }
                            if (durationMs <= 0L) {
                                throw IllegalStateException("Could not determine the extracted audio duration")
                            }
                            val rawName = asset["name"]?.toString()?.substringBeforeLast('.')
                                ?.takeIf { it.isNotBlank() } ?: "video"
                            val assetMap = mapOf(
                                "id" to "extracted-audio-${UUID.randomUUID()}",
                                "uri" to Uri.fromFile(outputFile).toString(),
                                "name" to "$rawName - الصوت المستخرج.m4a",
                                "mimeType" to "audio/mp4",
                                "kind" to "audio",
                                "durationMs" to durationMs,
                                "width" to 0,
                                "height" to 0,
                                "sizeBytes" to outputFile.length(),
                            )
                            state.keepOutput = true
                            runOnUiThread {
                                completeAudioExtraction(state) { state.result.success(assetMap) }
                            }
                        } catch (error: Exception) {
                            Log.e(TAG, "Could not register extracted audio", error)
                            runOnUiThread {
                                completeAudioExtraction(state) {
                                    state.result.error("audio_extract_failed", error.message, null)
                                }
                            }
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        Log.e(TAG, "Media3 audio extraction failed", exportException)
                        runOnUiThread {
                            completeAudioExtraction(state) {
                                state.result.error(
                                    "audio_extract_failed",
                                    exportException.message ?: "Media3 could not extract the video audio",
                                    null,
                                )
                            }
                        }
                    }
                })
                .build()
            state.transformer = transformer
            transformer.start(audioItem, outputFile.absolutePath)
        } catch (error: Exception) {
            completeAudioExtraction(state) {
                state.result.error("audio_extract_failed", error.message, null)
            }
        }
    }

    private fun inspectAudioFile(path: String): AudioTrackInfo {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(path)
            for (index in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(index)
                val mimeType = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mimeType.startsWith("audio/")) {
                    val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    } else {
                        null
                    }
                    return AudioTrackInfo(hasAudio = true, channelCount = channelCount)
                }
            }
            AudioTrackInfo(hasAudio = false, channelCount = null)
        } catch (error: Exception) {
            throw IllegalArgumentException("Could not inspect extracted audio at $path", error)
        } finally {
            runCatching { extractor.release() }
        }
    }

    private fun cancelActiveAudioExtraction(message: String): Boolean {
        val state = activeAudioExtraction ?: return false
        if (!state.cancelled.compareAndSet(false, true)) return false
        runCatching { state.transformer?.cancel() }
        state.outputFile.delete()
        completeAudioExtraction(state) {
            state.result.error("audio_extract_cancelled", message, null)
        }
        return true
    }

    private fun completeAudioExtraction(
        state: AudioExtractionState,
        deliverResult: () -> Unit,
    ) {
        if (!state.resultSent.compareAndSet(false, true)) return
        if (activeAudioExtraction === state) activeAudioExtraction = null
        state.transformer = null
        if (!state.keepOutput) state.outputFile.delete()
        deliverResult()
    }

    private class MediaPermissionException(val uri: Uri) : Exception()

    private class MediaAccessException(
        message: String,
        val details: Map<String, String>,
    ) : Exception(message)

    private fun ensureProjectMediaReadable(project: Map<*, *>) {
        val assets = mapList(project["assets"]).associateBy { it["id"]?.toString().orEmpty() }
        val references = linkedMapOf<String, Map<String, String>>()
        fun addAssetReference(assetId: String?) {
            if (assetId.isNullOrBlank() || references.containsKey("asset:$assetId")) return
            val asset = assets[assetId] ?: return
            references["asset:$assetId"] = mapOf(
                "assetId" to assetId,
                "name" to (asset["name"]?.toString() ?: "ملف وسائط"),
                "kind" to (asset["kind"]?.toString() ?: "video"),
                "uri" to (asset["uri"]?.toString() ?: ""),
            )
        }
        mapList(project["videoTrack"]).forEach { addAssetReference(it["assetId"]?.toString()) }
        mapList(project["audioTrack"]).forEach { addAssetReference(it["assetId"]?.toString()) }
        mapList(project["videoOverlayTracks"]).forEach { track ->
            mapList(track["clips"]).forEach { addAssetReference(it["assetId"]?.toString()) }
        }
        mapList(project["stickerOverlays"]).forEach { sticker ->
            val stickerId = sticker["id"]?.toString().orEmpty()
            references["sticker:$stickerId"] = mapOf(
                "stickerId" to stickerId,
                "name" to (sticker["name"]?.toString() ?: "ملصق"),
                "kind" to "image",
                "uri" to (sticker["uri"]?.toString() ?: ""),
            )
        }

        for (reference in references.values) {
            val uriText = reference["uri"].orEmpty()
            val uri = try { Uri.parse(uriText) } catch (_: Exception) { null }
            val details = reference.filterKeys { it != "uri" }
            val inaccessible = {
                MediaAccessException(
                    "تعذّر الوصول إلى «${reference["name"]}». أعد اختيار الملف لاستعادة الرابط دون تعديل بقية المشروع.",
                    details,
                )
            }
            if (uri == null || (uri.scheme != "content" && uri.scheme != "file")) throw inaccessible()
            if (uri.scheme == "content") {
                val hasPersistedReadGrant = contentResolver.persistedUriPermissions.any {
                    it.uri == uri && it.isReadPermission
                }
                if (!hasPersistedReadGrant) throw inaccessible()
            }
            try {
                val stream = contentResolver.openInputStream(uri) ?: throw inaccessible()
                stream.use { }
            } catch (error: MediaAccessException) {
                throw error
            } catch (_: Exception) {
                throw inaccessible()
            }
        }
    }

    @androidx.media3.common.util.UnstableApi
    private fun configurePreviewTimeline(args: Map<*, *>) {
        val project = args["project"] as? Map<*, *>
            ?: throw IllegalArgumentException("Project data is missing")
        ensureProjectMediaReadable(project)
        val assets = mapList(project["assets"]).associateBy { it["id"]?.toString().orEmpty() }
        val clips = mapList(project["videoTrack"])
        require(clips.isNotEmpty()) { "Add a visual clip before previewing the timeline" }

        val items = ArrayList<MediaItem>(clips.size)
        val sourceDurationsMs = ArrayList<Long>(clips.size)
        clips.forEachIndexed { index, clip ->
            val asset = assets[clip["assetId"]?.toString()]
                ?: throw IllegalArgumentException("Visual clip $index has no media asset")
            val kind = asset["kind"]?.toString().orEmpty()
            require(kind == "video" || kind == "image") {
                "Only videos and images can be previewed on the visual track"
            }
            val uriText = asset["uri"]?.toString()
                ?: throw IllegalArgumentException("Visual clip $index has no media URI")
            val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                ?: throw IllegalArgumentException("Visual clip $index has no trim start")
            val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                ?: throw IllegalArgumentException("Visual clip $index has no trim end")
            require(startMs >= 0L && endMs > startMs) {
                "Visual clip $index has an invalid trim range"
            }
            val durationMs = endMs - startMs
            val assetDurationMs = (asset["durationMs"] as? Number)?.toLong() ?: 0L
            if (kind == "video" && assetDurationMs > 0L) {
                require(endMs <= assetDurationMs) {
                    "Visual clip $index ends beyond the source video duration"
                }
            }

            val builder = MediaItem.Builder()
                .setMediaId(clip["id"]?.toString() ?: "visual-$index")
                .setUri(Uri.parse(uriText))
            if (kind == "image") {
                builder.setImageDurationMs(durationMs)
            } else {
                builder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build(),
                )
            }
            items += builder.build()
            sourceDurationsMs += durationMs
        }

        val startIndex = (args["startIndex"] as? Number)?.toInt() ?: 0
        require(startIndex in items.indices) { "Preview start item is out of range" }
        val startPositionMs = (args["clipPositionMs"] as? Number)?.toLong() ?: 0L
        val playWhenReady = args["playWhenReady"] as? Boolean ?: false
        val sourceTimelineDurationMs = sourceDurationsMs.sum()
        val frameSettings = ProjectFrameSettings.fromMap(project["frameSettings"])
        val colorSettings = ProjectColorSettings.fromMap(project["colorSettings"])
        val previewVisualItems = clips.map { clip ->
            val asset = assets[clip["assetId"]?.toString()]
                ?: throw IllegalArgumentException("A visual clip references a missing asset")
            createEditedItem(
                asset = asset,
                clip = clip,
                outputHeight = PREVIEW_OUTPUT_HEIGHT,
                isVisual = true,
                frameSettings = frameSettings,
                colorSettings = colorSettings,
                explicitDurationForCompositionPlayer = true,
            )
        }
        val durationsMs = previewVisualItems.map { item ->
            (item.getPresentationDurationUs() + 500L) / 1_000L
        }
        require(durationsMs.all { it > 0L }) {
            "A visual clip rounds to zero milliseconds after speed adjustment"
        }
        val totalDurationMs = durationsMs.sum()
        val clipTimings = clips.map { ProjectClipMotion.timingFromMap(it) }
        val transitionRows = mapList(project["videoTransitions"])
        val transitionPlan = ProjectTransitionPlan.create(
            visualClips = clips,
            visualItems = previewVisualItems,
            transitionRows = transitionRows,
            adjustedClipDurationsMs = durationsMs,
            clockItemFactory = ::createTransitionClockItem,
        )
        val compositionDurationMs = transitionPlan?.totalDurationMs ?: totalDurationMs
        val timelineMapper: (Long) -> Long = { originalTime ->
            ProjectClipMotion.mapProjectTimeToOutputMs(originalTime, clipTimings, transitionPlan)
        }
        val videoLayerPlan = ProjectVideoLayers.create(
            project = project,
            assets = assets,
            totalDurationMs = compositionDurationMs,
            frameSettings = frameSettings,
            outputHeight = PREVIEW_OUTPUT_HEIGHT,
            colorSettings = colorSettings,
            sourceTimelineDurationMs = sourceTimelineDurationMs,
            timelineMapper = timelineMapper,
        )
        val compositionSequences = mutableListOf<EditedMediaItemSequence>()
        if (transitionPlan != null) {
            compositionSequences += transitionPlan.primaryVideoSequence
            compositionSequences += videoLayerPlan.overlaySequences.map { it.sequence }
            compositionSequences += transitionPlan.videoSequences
            compositionSequences += buildEmbeddedAudioSequences(clips, assets, transitionPlan)
        } else {
            compositionSequences += videoLayerPlan.overlaySequences.map { it.sequence }
            compositionSequences += EditedMediaItemSequence.withVideoFrom(previewVisualItems)

            // Preserve the existing single sequential source-audio stream when no transitions are set.
            val embeddedAudioBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
            var embeddedAudioCursorMs = 0L
            var hasEmbeddedAudio = false
            var visualCursorMs = 0L
            val audioInfoCache = mutableMapOf<String, AudioTrackInfo>()
            for ((index, clip) in clips.withIndex()) {
                val asset = assets[clip["assetId"]?.toString()]
                    ?: throw IllegalArgumentException("Visual clip $index has no media asset")
                val durationMs = durationsMs[index]
                if (asset["kind"]?.toString() == "video") {
                    val assetId = asset["id"]?.toString().orEmpty()
                    val uri = asset["uri"]?.toString()
                        ?: throw IllegalArgumentException("Video asset has no URI")
                    val info = audioInfoCache.getOrPut(assetId) { inspectAudioTrack(uri) }
                    if (info.hasAudio) {
                        val channels = info.channelCount
                            ?: throw IllegalArgumentException("Could not determine the embedded audio channel count for $uri")
                        require(channels in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                            "Embedded audio with $channels channels is unsupported in preview"
                        }
                        val gapMs = visualCursorMs - embeddedAudioCursorMs
                        if (gapMs > 0L) embeddedAudioBuilder.addGap(gapMs * 1_000L)
                        embeddedAudioBuilder.addItem(createSourceAudioItem(asset, clip))
                        embeddedAudioCursorMs = visualCursorMs + durationMs
                        hasEmbeddedAudio = true
                    }
                }
                visualCursorMs += durationMs
            }
            if (hasEmbeddedAudio) compositionSequences += embeddedAudioBuilder.build()
        }
        val compositionBuilder = Composition.Builder(compositionSequences)
        if (transitionPlan != null) {
            compositionBuilder.setVideoCompositorSettings(
                createTransitionCompositorSettings(videoLayerPlan, transitionPlan),
            )
        } else {
            videoLayerPlan.compositorSettings?.let { compositionBuilder.setVideoCompositorSettings(it) }
        }
        // Reuse the export overlay effect so text, subtitles, and stickers are visible
        // during preview with the same timestamps and rendering as the encoded output.
        ProjectOverlayEffects.create(this, project, timelineMapper)?.let { overlayEffect ->
            compositionBuilder.setEffects(Effects(emptyList(), listOf(overlayEffect)))
        }
        val previewComposition = compositionBuilder.build()
        val compositionPositionMs = ((args["timelinePositionMs"] as? Number)?.toLong() ?: 0L)
            .coerceIn(0L, compositionDurationMs)

        val audioClips = mapList(project["audioTrack"]).mapNotNull { clip ->
            val asset = assets[clip["assetId"]?.toString()] ?: return@mapNotNull null
            if (asset["kind"]?.toString() != "audio") return@mapNotNull null
            val trimStartMs = (clip["trimStartMs"] as? Number)?.toLong() ?: 0L
            val trimEndMs = (clip["trimEndMs"] as? Number)?.toLong() ?: 0L
            val startMs = (clip["timelineStartMs"] as? Number)?.toLong() ?: 0L
            if (trimStartMs < 0L || trimEndMs <= trimStartMs || startMs < 0L || startMs >= sourceTimelineDurationMs) {
                return@mapNotNull null
            }
            val mappedStartMs = timelineMapper(startMs)
            if (mappedStartMs >= compositionDurationMs) return@mapNotNull null
            val durationMs = minOf(trimEndMs - trimStartMs, compositionDurationMs - mappedStartMs)
            VeloraPreviewPlayerRegistry.AudioClip(
                id = clip["id"]?.toString() ?: UUID.randomUUID().toString(),
                uri = asset["uri"]?.toString() ?: return@mapNotNull null,
                trimStartMs = trimStartMs,
                trimEndMs = trimStartMs + durationMs,
                timelineStartMs = mappedStartMs,
                volume = ((clip["volume"] as? Number)?.toFloat() ?: 1f).let {
                    if (it.isFinite()) it.coerceIn(0f, 1f) else 1f
                },
                fadeInMs = ((clip["fadeInMs"] as? Number)?.toLong() ?: 0L).coerceIn(0L, durationMs),
                fadeOutMs = ((clip["fadeOutMs"] as? Number)?.toLong() ?: 0L).coerceIn(0L, durationMs),
            )
        }
        VeloraPreviewPlayerRegistry.configureTimeline(
            items,
            durationsMs,
            startIndex,
            startPositionMs,
            playWhenReady,
            audioClips,
            frameSettings,
            colorSettings,
            previewComposition,
            compositionPositionMs,
            compositionDurationMs,
        )
    }

    @androidx.media3.common.util.UnstableApi
    private fun startExport(project: Map<*, *>, height: Int, result: MethodChannel.Result) {
        if (activeExport != null || activeAudioExtraction != null) {
            result.error("export_busy", "Another media operation is already running", null)
            return
        }
        if (height != 720 && height != 1080) {
            result.error("invalid_resolution", "Only 720p and 1080p are configured", null)
            return
        }

        val assets = mapList(project["assets"]).associateBy { it["id"]?.toString().orEmpty() }
        val visualClips = mapList(project["videoTrack"])
        val audioClips = mapList(project["audioTrack"])
        val frameSettings = ProjectFrameSettings.fromMap(project["frameSettings"])
        val colorSettings = ProjectColorSettings.fromMap(project["colorSettings"])
        if (visualClips.isEmpty()) {
            result.error("empty_timeline", "Add at least one video or image before exporting", null)
            return
        }

        var tempFile: File? = null
        var exportState: ExportState? = null
        try {
            ensureProjectMediaReadable(project)
            Log.i(TAG, "Export requested: height=${height}p, visualClips=${visualClips.size}, audioClips=${audioClips.size}")
            val visualItems = mutableListOf<EditedMediaItem>()
            // Keep embedded source audio in one sequential track. A sequence per
            // video clip makes Media3 open many decoders concurrently on long edits.
            val embeddedAudioSequenceBuilder = EditedMediaItemSequence.Builder(
                setOf(C.TRACK_TYPE_AUDIO),
            )
            var hasEmbeddedAudio = false
            var embeddedAudioCursorMs = 0L
            var totalVisualDurationMs = 0L
            var totalSourceTimelineDurationMs = 0L
            val audioInfoByAssetId = mutableMapOf<String, AudioTrackInfo>()

            for ((clipIndex, clip) in visualClips.withIndex()) {
                val asset = assets[clip["assetId"]?.toString()]
                    ?: throw IllegalArgumentException("A visual clip references a missing asset")
                val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("A visual clip start time is missing")
                val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("A visual clip end time is missing")
                require(startMs >= 0L && endMs > startMs) {
                    "Visual clip range must have a non-negative start and positive duration"
                }
                val durationMs = endMs - startMs
                val visualItem = createEditedItem(
                    asset,
                    clip,
                    height,
                    isVisual = true,
                    frameSettings = frameSettings,
                    colorSettings = colorSettings,
                    explicitDurationForCompositionPlayer = true,
                )
                visualItems += visualItem
                val effectiveDurationMs = (visualItem.getPresentationDurationUs() + 500L) / 1_000L

                if (asset["kind"]?.toString() == "video") {
                    val assetId = asset["id"]?.toString().orEmpty()
                    val uriText = asset["uri"]?.toString()
                        ?: throw IllegalArgumentException("A video asset has no media URI")
                    val audioInfo = audioInfoByAssetId.getOrPut(assetId) {
                        inspectAudioTrack(uriText)
                    }
                    if (audioInfo.hasAudio) {
                        val channelCount = audioInfo.channelCount
                            ?: throw IllegalArgumentException(
                                "Could not determine the embedded audio channel count for $uriText",
                            )
                        require(channelCount in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                            "Embedded audio with $channelCount channels is unsupported; use a source with at most $MAX_NORMALIZED_AUDIO_CHANNELS channels"
                        }
                        val gapMs = totalVisualDurationMs - embeddedAudioCursorMs
                        if (gapMs > 0L) embeddedAudioSequenceBuilder.addGap(gapMs * 1_000L)
                        embeddedAudioSequenceBuilder.addItem(createSourceAudioItem(asset, clip))
                        hasEmbeddedAudio = true
                        embeddedAudioCursorMs = totalVisualDurationMs + effectiveDurationMs
                        Log.d(TAG, "Export clip $clipIndex: embedded audio included")
                    } else {
                        Log.d(TAG, "Export clip $clipIndex: source video has no audio")
                    }
                }
                totalVisualDurationMs += effectiveDurationMs
                totalSourceTimelineDurationMs += durationMs
            }

            val adjustedVisualDurationsMs = visualItems.map { item ->
                (item.getPresentationDurationUs() + 500L) / 1_000L
            }
            require(adjustedVisualDurationsMs.all { it > 0L }) {
                "A visual clip rounds to zero milliseconds after speed adjustment"
            }
            val clipTimings = visualClips.map { ProjectClipMotion.timingFromMap(it) }
            val transitionPlan = ProjectTransitionPlan.create(
                visualClips = visualClips,
                visualItems = visualItems,
                transitionRows = mapList(project["videoTransitions"]),
                adjustedClipDurationsMs = adjustedVisualDurationsMs,
                clockItemFactory = ::createTransitionClockItem,
            )
            val compositionDurationMs = transitionPlan?.totalDurationMs ?: totalVisualDurationMs
            val timelineMapper: (Long) -> Long = { originalTime ->
                ProjectClipMotion.mapProjectTimeToOutputMs(originalTime, clipTimings, transitionPlan)
            }

            val positionedAudio = mutableListOf<PositionedAudioClip>()
            for (clip in audioClips) {
                val asset = assets[clip["assetId"]?.toString()]
                    ?: throw IllegalArgumentException("An audio clip references a missing asset")
                if (asset["kind"]?.toString() != "audio") {
                    throw IllegalArgumentException("The audio track contains a non-audio asset")
                }
                val assetId = asset["id"]?.toString().orEmpty()
                val uriText = asset["uri"]?.toString()
                    ?: throw IllegalArgumentException("An audio asset has no media URI")
                val startMs = (clip["trimStartMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("An audio clip source start is missing")
                val endMs = (clip["trimEndMs"] as? Number)?.toLong()
                    ?: throw IllegalArgumentException("An audio clip source end is missing")
                val timelineStartMs = (clip["timelineStartMs"] as? Number)?.toLong() ?: 0L
                require(startMs >= 0L && endMs > startMs && timelineStartMs >= 0L) {
                    "Audio clip source range and timeline position must be non-negative and non-empty"
                }
                if (timelineStartMs >= totalSourceTimelineDurationMs) continue
                val mappedTimelineStartMs = timelineMapper(timelineStartMs)
                if (mappedTimelineStartMs >= compositionDurationMs) continue
                val usedDurationMs = minOf(endMs - startMs, compositionDurationMs - mappedTimelineStartMs)
                val audioInfo = audioInfoByAssetId.getOrPut(assetId) { inspectAudioTrack(uriText) }
                require(audioInfo.hasAudio) { "The selected audio asset has no audio track" }
                val channelCount = audioInfo.channelCount
                    ?: throw IllegalArgumentException("Could not determine audio channel count for $uriText")
                require(channelCount in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                    "Audio with $channelCount channels is unsupported; use a source with at most $MAX_NORMALIZED_AUDIO_CHANNELS channels"
                }
                val cappedClip = clip.toMutableMap().apply {
                    put("timelineStartMs", mappedTimelineStartMs)
                    put("trimEndMs", startMs + usedDurationMs)
                    put("fadeInMs", ((clip["fadeInMs"] as? Number)?.toLong() ?: 0L).coerceIn(0L, usedDurationMs))
                    put("fadeOutMs", ((clip["fadeOutMs"] as? Number)?.toLong() ?: 0L).coerceIn(0L, usedDurationMs))
                    put("volume", ((clip["volume"] as? Number)?.toDouble() ?: 1.0).let {
                        if (it.isFinite()) it.coerceIn(0.0, 1.0) else 1.0
                    })
                }
                positionedAudio += PositionedAudioClip(
                    asset = asset,
                    clip = cappedClip,
                    timelineStartMs = mappedTimelineStartMs,
                    durationMs = usedDurationMs,
                )
            }

            // Keep the current Media3 Transformer: one visual sequence plus source
            // audio and as many added-audio sequences as the overlap layout requires.
            // Non-overlapping clips share a sequence, limiting decoder usage.
            val audioLaneBuilders = mutableListOf<EditedMediaItemSequence.Builder>()
            val audioLaneEndsMs = mutableListOf<Long>()
            val sortedAudio = positionedAudio.sortedWith(
                compareBy<PositionedAudioClip> { it.timelineStartMs }
                    .thenBy { it.clip["id"]?.toString().orEmpty() },
            )
            for (entry in sortedAudio) {
                val laneIndex = audioLaneEndsMs.indexOfFirst { it <= entry.timelineStartMs }
                    .let { if (it < 0) audioLaneEndsMs.size else it }
                if (laneIndex == audioLaneBuilders.size) {
                    audioLaneBuilders += EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                    audioLaneEndsMs += 0L
                }
                val gapMs = entry.timelineStartMs - audioLaneEndsMs[laneIndex]
                if (gapMs > 0L) audioLaneBuilders[laneIndex].addGap(gapMs * 1_000L)
                audioLaneBuilders[laneIndex].addItem(
                    createEditedItem(entry.asset, entry.clip, height, isVisual = false),
                )
                audioLaneEndsMs[laneIndex] = entry.timelineStartMs + entry.durationMs
            }

            val videoLayerPlan = ProjectVideoLayers.create(
                project = project,
                assets = assets,
                totalDurationMs = compositionDurationMs,
                frameSettings = frameSettings,
                outputHeight = height,
                colorSettings = colorSettings,
                sourceTimelineDurationMs = totalSourceTimelineDurationMs,
                timelineMapper = timelineMapper,
            )
            val sequences = mutableListOf<EditedMediaItemSequence>()
            if (transitionPlan != null) {
                sequences += transitionPlan.primaryVideoSequence
                sequences += videoLayerPlan.overlaySequences.map { it.sequence }
                sequences += transitionPlan.videoSequences
                sequences += buildEmbeddedAudioSequences(visualClips, assets, transitionPlan)
            } else {
                sequences += videoLayerPlan.overlaySequences.map { it.sequence }
                sequences += EditedMediaItemSequence.withVideoFrom(visualItems)
                if (hasEmbeddedAudio) sequences += embeddedAudioSequenceBuilder.build()
            }
            sequences += audioLaneBuilders.map { it.build() }
            val compositionBuilder = Composition.Builder(sequences)
            if (transitionPlan != null) {
                compositionBuilder.setVideoCompositorSettings(
                    createTransitionCompositorSettings(videoLayerPlan, transitionPlan),
                )
            } else {
                videoLayerPlan.compositorSettings?.let(compositionBuilder::setVideoCompositorSettings)
            }
            ProjectOverlayEffects.create(this, project, timelineMapper)?.let { overlayEffect ->
                compositionBuilder.setEffects(Effects(emptyList(), listOf(overlayEffect)))
            }
            val composition = compositionBuilder.build()
            Log.i(TAG, "Building Media3 composition: sequences=${sequences.size}, audioClips=${positionedAudio.size}, addedAudioLanes=${audioLaneBuilders.size}")

            val outputFile = File(cacheDir, "velora-${UUID.randomUUID()}.mp4")
            tempFile = outputFile
            val state = ExportState(result, outputFile)
            exportState = state
            activeExport = state

            val transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        Log.i(TAG, "Media3 encoding completed; outputBytes=${outputFile.length()}")
                        if (state.cancelled.get() || !state.publishStarted.compareAndSet(false, true)) {
                            outputFile.delete()
                            return
                        }
                        val publishingThread = Thread({
                            state.publishingThread = Thread.currentThread()
                            try {
                                Log.i(TAG, "Publishing encoded MP4 to device storage")
                                ensureExportActive(state)
                                val saved = publishExport(outputFile, state)
                                Log.i(TAG, "MP4 published successfully: ${saved["path"]}")
                                outputFile.delete()
                                if (state.cancelled.get()) {
                                    cleanupPublishedExport(state)
                                    return@Thread
                                }
                                runOnUiThread {
                                    if (state.cancelled.get()) {
                                        cleanupPublishedExport(state)
                                        return@runOnUiThread
                                    }
                                    releasePublishedExportTracking(state)
                                    completeExport(state) { state.result.success(saved) }
                                }
                            } catch (error: OutOfMemoryError) {
                                Log.e(TAG, "Not enough memory while publishing the MP4", error)
                                outputFile.delete()
                                cleanupPublishedExport(state)
                                if (!state.cancelled.get()) {
                                    runOnUiThread {
                                        if (!state.cancelled.get()) {
                                            completeExport(state) {
                                                state.result.error(
                                                    "export_memory_error",
                                                    "تعذّر حفظ الفيديو بسبب نقص الذاكرة. أغلق التطبيقات الأخرى وحاول بدقة أقل.",
                                                    null,
                                                )
                                            }
                                        }
                                    }
                                }
                            } catch (error: Exception) {
                                Log.e(TAG, "Failed to publish encoded MP4", error)
                                outputFile.delete()
                                cleanupPublishedExport(state)
                                if (!state.cancelled.get()) {
                                    runOnUiThread {
                                        if (!state.cancelled.get()) {
                                            completeExport(state) {
                                                state.result.error("export_save_failed", error.message, null)
                                            }
                                        }
                                    }
                                }
                            } finally {
                                state.publishingThread = null
                            }
                        }, "VeloraExportPublisher")
                        state.publishingThread = publishingThread
                        publishingThread.start()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        Log.e(
                            TAG,
                            "Media3 encoding failed: code=${exportException.errorCode}, message=${exportException.message}",
                            exportException,
                        )
                        outputFile.delete()
                        if (state.cancelled.get()) return
                        val sourceAccessError = try {
                            ensureProjectMediaReadable(project)
                            null
                        } catch (error: MediaAccessException) {
                            error
                        }
                        var rootCause: Throwable = exportException
                        var causeDepth = 0
                        while (
                            rootCause.cause != null &&
                            rootCause.cause !== rootCause &&
                            causeDepth < 16
                        ) {
                            rootCause = rootCause.cause!!
                            causeDepth++
                        }
                        val failureMessage = sourceAccessError?.message ?: if (rootCause is OutOfMemoryError) {
                            "توقّف ترميز الفيديو بسبب نقص الذاكرة. أغلق التطبيقات الأخرى وحاول تصدير 720p."
                        } else {
                            val detail = exportException.message
                                ?: rootCause.message
                                ?: "لا تتوفر تفاصيل إضافية؛ رمز Media3: ${exportException.errorCode}"
                            "فشل ترميز الفيديو: $detail"
                        }
                        runOnUiThread {
                            if (!state.cancelled.get()) {
                                cleanupPublishedExport(state)
                                completeExport(state) {
                                    state.result.error(
                                        if (sourceAccessError != null) "media_access_lost" else "media3_export_failed",
                                        failureMessage,
                                        sourceAccessError?.details,
                                    )
                                }
                            }
                        }
                    }
                })
                .build()
            state.transformer = transformer
            Log.i(TAG, "Starting Media3 Transformer at ${height}p: ${outputFile.name}")
            transformer.start(composition, outputFile.absolutePath)
        } catch (error: OutOfMemoryError) {
            Log.e(TAG, "Insufficient memory while preparing video export", error)
            tempFile?.delete()
            val state = exportState
            val message = "تعذّر بدء التصدير بسبب نقص الذاكرة. أغلق التطبيقات الأخرى وحاول بدقة أقل."
            if (state == null) {
                result.error("export_memory_error", message, null)
            } else if (!state.cancelled.get()) {
                completeExport(state) {
                    state.result.error("export_memory_error", message, null)
                }
            }
        } catch (error: Exception) {
            Log.e(TAG, "Failed to prepare or start Media3 export", error)
            tempFile?.delete()
            val state = exportState
            val errorCode = if (error is MediaAccessException) "media_access_lost" else "export_setup_failed"
            val errorDetails = (error as? MediaAccessException)?.details
            if (state == null) {
                result.error(errorCode, error.message, errorDetails)
            } else if (!state.cancelled.get()) {
                completeExport(state) {
                    state.result.error(errorCode, error.message, errorDetails)
                }
            }
        }
    }

    private fun createEditedItem(
        asset: Map<String, Any?>,
        clip: Map<String, Any?>,
        outputHeight: Int,
        isVisual: Boolean,
        frameSettings: ProjectFrameSettings = ProjectFrameSettings(),
        colorSettings: ProjectColorSettings = ProjectColorSettings(),
        explicitDurationForCompositionPlayer: Boolean = false,
    ): EditedMediaItem {
        val uriText = asset["uri"]?.toString()
            ?: throw IllegalArgumentException("Media URI is missing")
        val kind = asset["kind"]?.toString() ?: ""
        if (isVisual && kind != "video" && kind != "image") {
            throw IllegalArgumentException("Only video and image assets belong on the visual track")
        }
        if (!isVisual && kind != "audio") {
            throw IllegalArgumentException("Only audio assets belong on the audio track")
        }
        val startMs = (clip["trimStartMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Clip start time is missing")
        val endMs = (clip["trimEndMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Clip end time is missing")
        if (endMs <= startMs) throw IllegalArgumentException("Clip duration must be positive")

        val mediaBuilder = MediaItem.Builder().setUri(Uri.parse(uriText))
        if (kind == "image") {
            if (!isVisual) throw IllegalArgumentException("An image cannot be placed on the audio track")
            mediaBuilder.setImageDurationMs(endMs - startMs)
        } else {
            mediaBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build(),
            )
        }
        // Shared by timeline preview and Transformer export; resolve color per visual item.
        val effectiveColorSettings = if (isVisual) {
            ProjectColorSettings.effectiveForClip(clip, colorSettings)
        } else {
            colorSettings
        }
        val effects = when {
            isVisual -> Effects(
                emptyList(),
                ProjectFrameEffects.create(frameSettings, outputHeight) +
                    ProjectColorEffects.create(effectiveColorSettings),
            )
            kind == "audio" -> createNormalizedAudioEffects(
                volume = ((clip["volume"] as? Number)?.toDouble() ?: 1.0).coerceIn(0.0, 1.0),
                fadeInMs = ((clip["fadeInMs"] as? Number)?.toLong() ?: 0L).coerceAtLeast(0L),
                fadeOutMs = ((clip["fadeOutMs"] as? Number)?.toLong() ?: 0L).coerceAtLeast(0L),
                durationMs = endMs - startMs,
                timelineStartMs = ((clip["timelineStartMs"] as? Number)?.toLong() ?: 0L).coerceAtLeast(0L),
            )
            else -> Effects(emptyList(), emptyList())
        }
        val builder = EditedMediaItem.Builder(mediaBuilder.build()).setEffects(effects)
        if (isVisual && ProjectClipMotion.hasMotion(clip)) {
            builder.setSpeed(ProjectClipMotion.speedProviderForClip(clip))
        }
        if (kind == "image") builder.setFrameRate(30)
        if (explicitDurationForCompositionPlayer) {
            builder.setDurationUs((endMs - startMs) * 1_000L)
        }
        return builder.build()
    }

    @androidx.media3.common.util.UnstableApi
    private fun createTransitionClockItem(durationMs: Long): EditedMediaItem {
        require(durationMs > 0L) { "Transition clock duration must be positive" }
        val clockFile = File(cacheDir, "velora-transition-clock.png")
        if (!clockFile.exists()) {
            val bitmap = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
            try {
                bitmap.eraseColor(Color.BLACK)
                clockFile.outputStream().use { output ->
                    check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                        "Could not create transition clock frame"
                    }
                }
            } finally {
                bitmap.recycle()
            }
        }
        val mediaItem = MediaItem.Builder()
            .setUri(Uri.fromFile(clockFile))
            .setImageDurationMs(durationMs)
            .build()
        return EditedMediaItem.Builder(mediaItem)
            .setDurationUs(durationMs * 1_000L)
            .setFrameRate(30)
            .build()
    }

    @androidx.media3.common.util.UnstableApi
    private fun createTransitionCompositorSettings(
        layerPlan: ProjectVideoLayerPlan,
        transitionPlan: ProjectTransitionPlan,
    ): VideoCompositorSettings = object : VideoCompositorSettings {
        private val pipCount = layerPlan.overlaySequences.size
        private val mainClipInputId = 1 + pipCount + transitionPlan.clipWindows.lastIndex

        override fun getOutputSize(inputSizes: List<Size>): Size {
            require(inputSizes.size > mainClipInputId) {
                "The main transition video input is missing from the compositor"
            }
            return inputSizes[mainClipInputId]
        }

        override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
            return when {
                inputId == 0 -> StaticOverlaySettings.Builder().setAlphaScale(0f).build()
                inputId in 1..pipCount -> layerPlan.compositorSettings
                    ?.getOverlaySettings(inputId - 1, presentationTimeUs)
                    ?: StaticOverlaySettings.Builder().build()
                else -> transitionPlan.getOverlaySettings(inputId - 1 - pipCount, presentationTimeUs)
            }
        }
    }

    @androidx.media3.common.util.UnstableApi
    private fun buildEmbeddedAudioSequences(
        visualClips: List<Map<String, Any?>>,
        assets: Map<String, Map<String, Any?>>,
        transitionPlan: ProjectTransitionPlan,
    ): List<EditedMediaItemSequence> {
        data class Segment(
            val clipIndex: Int,
            val asset: Map<String, Any?>,
            val clip: Map<String, Any?>,
            val startMs: Long,
            val durationMs: Long,
            val fadeInMs: Long,
            val fadeInDelayMs: Long,
            val fadeOutMs: Long,
            val fadeOutStartMs: Long,
        )
        val segments = mutableListOf<Segment>()
        val audioInfoCache = mutableMapOf<String, AudioTrackInfo>()
        for ((index, clip) in visualClips.withIndex()) {
            val asset = assets[clip["assetId"]?.toString()] ?: continue
            if (asset["kind"]?.toString() != "video") continue
            val uri = asset["uri"]?.toString()
                ?: throw IllegalArgumentException("Video asset has no URI")
            val assetId = asset["id"]?.toString().orEmpty()
            val info = audioInfoCache.getOrPut(assetId) { inspectAudioTrack(uri) }
            if (!info.hasAudio) continue
            val channels = info.channelCount
                ?: throw IllegalArgumentException("Could not determine the embedded audio channel count for $uri")
            require(channels in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
                "Embedded audio with $channels channels is unsupported"
            }
            val window = transitionPlan.clipWindows[index]
            val incoming = transitionPlan.transitionWindows[index - 1]
            val outgoing = transitionPlan.transitionWindows[index]
            val incomingMs = incoming?.durationMs ?: 0L
            val outgoingMs = outgoing?.durationMs ?: 0L
            val fadeInDelayMs = if (incoming?.spec?.type == "fade") incomingMs / 2L else 0L
            val fadeInMs = if (incoming?.spec?.type == "fade") incomingMs - fadeInDelayMs else incomingMs
            val fadeOutMs = if (outgoing?.spec?.type == "fade") outgoingMs / 2L else outgoingMs
            val fadeOutStartMs = (window.durationMs - outgoingMs).coerceAtLeast(0L)
            segments += Segment(
                clipIndex = index,
                asset = asset,
                clip = clip,
                startMs = window.startMs,
                durationMs = window.durationMs,
                fadeInMs = fadeInMs,
                fadeInDelayMs = fadeInDelayMs,
                fadeOutMs = fadeOutMs,
                fadeOutStartMs = fadeOutStartMs,
            )
        }
        if (segments.isEmpty()) return emptyList()

        val laneBuilders = mutableListOf<EditedMediaItemSequence.Builder>()
        val laneEndsMs = mutableListOf<Long>()
        for (segment in segments.sortedWith(compareBy<Segment> { it.startMs }.thenBy { it.clipIndex })) {
            val laneIndex = laneEndsMs.indexOfFirst { it <= segment.startMs }
                .let { if (it < 0) laneEndsMs.size else it }
            if (laneIndex == laneBuilders.size) {
                laneBuilders += EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                laneEndsMs += 0L
            }
            val gapMs = segment.startMs - laneEndsMs[laneIndex]
            if (gapMs > 0L) laneBuilders[laneIndex].addGap(gapMs * 1_000L)
            laneBuilders[laneIndex].addItem(
                createSourceAudioItem(
                    asset = segment.asset,
                    clip = segment.clip,
                    durationMs = segment.durationMs,
                    fadeInMs = segment.fadeInMs,
                    fadeInDelayMs = segment.fadeInDelayMs,
                    fadeOutMs = segment.fadeOutMs,
                    fadeOutStartMs = segment.fadeOutStartMs,
                    timelineStartMs = segment.startMs,
                ),
            )
            laneEndsMs[laneIndex] = segment.startMs + segment.durationMs
        }
        return laneBuilders.map { it.build() }
    }

    private fun createSourceAudioItem(
        asset: Map<String, Any?>,
        clip: Map<String, Any?>,
        durationMs: Long? = null,
        fadeInMs: Long = 0L,
        fadeInDelayMs: Long = 0L,
        fadeOutMs: Long = 0L,
        fadeOutStartMs: Long? = null,
        timelineStartMs: Long = 0L,
        includeClipAudioSettings: Boolean = true,
    ): EditedMediaItem {
        require(asset["kind"]?.toString() == "video") {
            "Only video assets can provide embedded source audio"
        }
        val uriText = asset["uri"]?.toString()
            ?: throw IllegalArgumentException("Video media URI is missing")
        val startMs = (clip["trimStartMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Video clip start time is missing")
        val endMs = (clip["trimEndMs"] as? Number)?.toLong()
            ?: throw IllegalArgumentException("Video clip end time is missing")
        require(startMs >= 0L && endMs > startMs) { "Video audio clip range is invalid" }

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(uriText))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build(),
            )
            .build()
        val sourceDurationMs = endMs - startMs
        val outputDurationMs = durationMs ?: ProjectClipMotion.timingFromMap(clip).outputDurationMs
        require(outputDurationMs > 0L) { "Embedded audio output duration must be positive" }
        val clipVolume = if (includeClipAudioSettings) {
            ((clip["volume"] as? Number)?.toDouble() ?: 1.0).let {
                if (it.isFinite()) it.coerceIn(0.0, 1.0) else 1.0
            }
        } else {
            1.0
        }
        val clipFadeInMs = if (includeClipAudioSettings) {
            (clip["fadeInMs"] as? Number)?.toLong()?.coerceIn(0L, outputDurationMs) ?: 0L
        } else {
            0L
        }
        val clipFadeOutMs = if (includeClipAudioSettings) {
            (clip["fadeOutMs"] as? Number)?.toLong()?.coerceIn(0L, outputDurationMs) ?: 0L
        } else {
            0L
        }
        val builder = EditedMediaItem.Builder(mediaItem)
            .setRemoveVideo(true)
            .setDurationUs(sourceDurationMs * 1_000L)
            .setEffects(
                createNormalizedAudioEffects(
                    volume = clipVolume,
                    fadeInMs = fadeInMs,
                    fadeInDelayMs = fadeInDelayMs,
                    fadeOutMs = fadeOutMs,
                    fadeOutStartMs = fadeOutStartMs,
                    clipFadeInMs = clipFadeInMs,
                    clipFadeOutMs = clipFadeOutMs,
                    durationMs = outputDurationMs,
                    timelineStartMs = timelineStartMs,
                ),
            )
        if (ProjectClipMotion.hasMotion(clip)) {
            builder.setSpeed(ProjectClipMotion.speedProviderForClip(clip))
        }
        return builder.build()
    }

    private fun createNormalizedAudioEffects(
        volume: Double = 1.0,
        fadeInMs: Long = 0L,
        fadeInDelayMs: Long = 0L,
        fadeOutMs: Long = 0L,
        fadeOutStartMs: Long? = null,
        clipFadeInMs: Long = 0L,
        clipFadeOutMs: Long = 0L,
        durationMs: Long = 0L,
        timelineStartMs: Long = 0L,
    ): Effects {
        val channelMixer = ChannelMixingAudioProcessor()
        for (inputChannels in 1..MAX_NORMALIZED_AUDIO_CHANNELS) {
            channelMixer.putChannelMixingMatrix(
                ChannelMixingMatrix.createForConstantPower(inputChannels, OUTPUT_AUDIO_CHANNELS),
            )
        }
        val safeDurationUs = durationMs.coerceAtLeast(0L) * 1_000L
        val safeFadeInUs = (fadeInMs.coerceAtLeast(0L) * 1_000L).coerceAtMost(safeDurationUs)
        val safeFadeInDelayUs = (fadeInDelayMs.coerceAtLeast(0L) * 1_000L).coerceAtMost(safeDurationUs)
        val safeFadeOutUs = (fadeOutMs.coerceAtLeast(0L) * 1_000L).coerceAtMost(safeDurationUs)
        val safeClipFadeInUs = (clipFadeInMs.coerceAtLeast(0L) * 1_000L).coerceAtMost(safeDurationUs)
        val safeClipFadeOutUs = (clipFadeOutMs.coerceAtLeast(0L) * 1_000L).coerceAtMost(safeDurationUs)
        val safeFadeOutStartUs = (
            (fadeOutStartMs?.coerceAtLeast(0L)?.times(1_000L))
                ?: (safeDurationUs - safeFadeOutUs)
            ).coerceIn(0L, safeDurationUs)
        val baseGain = volume.coerceIn(0.0, 1.0).toFloat()
        val timelineStartUs = timelineStartMs.coerceAtLeast(0L) * 1_000L
        val gainProvider = object : GainProcessor.GainProvider {
            override fun getGainFactorAtSamplePosition(samplePosition: Long, sampleRate: Int): Float {
                // Media3 1.11 forwards the stream's composition-timeline offset to
                // GainProcessor. Convert it back to this clipped item's local time.
                val streamPositionUs = samplePosition * 1_000_000L / sampleRate
                val positionUs = (streamPositionUs - timelineStartUs).coerceAtLeast(0L)
                var factor = baseGain
                if (safeFadeInUs > 0L) {
                    val fadePositionUs = (positionUs - safeFadeInDelayUs).coerceAtLeast(0L)
                    factor *= (fadePositionUs.toFloat() / safeFadeInUs).coerceIn(0f, 1f)
                }
                if (safeFadeOutUs > 0L) {
                    val fadeEndUs = safeFadeOutStartUs + safeFadeOutUs
                    val remainingUs = (fadeEndUs - positionUs).coerceAtLeast(0L)
                    factor *= (remainingUs.toFloat() / safeFadeOutUs).coerceIn(0f, 1f)
                }
                if (safeClipFadeInUs > 0L) {
                    factor *= (positionUs.toFloat() / safeClipFadeInUs).coerceIn(0f, 1f)
                }
                if (safeClipFadeOutUs > 0L) {
                    val remainingUs = (safeDurationUs - positionUs).coerceAtLeast(0L)
                    factor *= (remainingUs.toFloat() / safeClipFadeOutUs).coerceIn(0f, 1f)
                }
                return factor.coerceIn(0f, 1f)
            }

            override fun isUnityUntil(samplePosition: Long, sampleRate: Int): Long =
                if (
                    baseGain == 1f &&
                    safeFadeInUs == 0L &&
                    safeFadeInDelayUs == 0L &&
                    safeFadeOutUs == 0L &&
                    safeClipFadeInUs == 0L &&
                    safeClipFadeOutUs == 0L
                ) {
                    C.TIME_END_OF_SOURCE
                } else {
                    C.TIME_UNSET
                }
        }
        val sampleRateNormalizer = SonicAudioProcessor().apply {
            setSpeed(1f)
            setPitch(1f)
            setOutputSampleRateHz(OUTPUT_AUDIO_SAMPLE_RATE_HZ)
        }
        return Effects(
            listOf(
                ToInt16PcmAudioProcessor(),
                channelMixer,
                sampleRateNormalizer,
                GainProcessor(gainProvider),
            ),
            emptyList(),
        )
    }

    private fun inspectAudioTrack(uriText: String): AudioTrackInfo {
        val parsedUri = Uri.parse(uriText)
        if (parsedUri.scheme == "file") {
            val path = parsedUri.path
                ?: throw IllegalArgumentException("Audio file URI has no filesystem path")
            return inspectAudioFile(path)
        }
        val extractor = MediaExtractor()
        val descriptor = try {
            contentResolver.openAssetFileDescriptor(parsedUri, "r")
                ?: throw IllegalArgumentException("Could not open media descriptor for $uriText")
        } catch (error: Exception) {
            runCatching { extractor.release() }
            throw error
        }
        return try {
            val length = descriptor.length
            when {
                length > 0L -> extractor.setDataSource(
                    descriptor.fileDescriptor,
                    descriptor.startOffset,
                    length,
                )
                descriptor.startOffset == 0L -> extractor.setDataSource(descriptor.fileDescriptor)
                else -> throw IllegalArgumentException(
                    "Media provider did not expose a usable file length for $uriText",
                )
            }
            for (index in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(index)
                val mimeType = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mimeType.startsWith("audio/")) {
                    val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    } else {
                        null
                    }
                    return AudioTrackInfo(hasAudio = true, channelCount = channelCount)
                }
            }
            AudioTrackInfo(hasAudio = false, channelCount = null)
        } catch (error: Exception) {
            throw IllegalArgumentException(
                "Could not inspect audio tracks for $uriText",
                error,
            )
        } finally {
            runCatching { extractor.release() }
            runCatching { descriptor.close() }
        }
    }

    private data class AudioTrackInfo(
        val hasAudio: Boolean,
        val channelCount: Int?,
    )

    private fun mapList(value: Any?): List<Map<String, Any?>> =
        (value as? List<*>)?.mapNotNull { item ->
            val row = item as? Map<*, *> ?: return@mapNotNull null
            row.entries.associate { (key, nested) -> key.toString() to nested }
        } ?: emptyList()

    private fun publishExport(tempFile: File, state: ExportState): Map<String, String> {
        ensureExportActive(state)
        if (!tempFile.exists() || tempFile.length() == 0L) {
            throw IllegalStateException("Transformer produced no MP4 data")
        }
        val fileName = "VELORA_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            publishToMediaStore(tempFile, fileName, state)
        } else {
            val directory = File(
                getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir,
                "VELORA",
            )
            val destination = File(directory, fileName)
            publishExportFileAtomically(
                source = tempFile,
                destination = destination,
                ensureActive = { ensureExportActive(state) },
                trackOutput = { output -> synchronized(state) { state.publishedFile = output } },
            )
            mapOf(
                "uri" to Uri.fromFile(destination).toString(),
                "path" to destination.absolutePath,
            )
        }
    }

    private fun publishToMediaStore(
        tempFile: File,
        fileName: String,
        state: ExportState,
    ): Map<String, String> {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/VELORA")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a MediaStore entry")
        synchronized(state) { state.publishedUri = uri }
        try {
            ensureExportActive(state)
            val output = contentResolver.openOutputStream(uri, "w")
                ?: throw IllegalStateException("Could not open the output destination")
            tempFile.inputStream().use { input -> output.use { copyCancellable(input, it, state) } }
            ensureExportActive(state)
            val completed = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            val updatedRows = contentResolver.update(uri, completed, null, null)
            if (updatedRows <= 0) {
                throw IllegalStateException("Could not finalize the MediaStore output")
            }
            ensureExportActive(state)
        } catch (error: Exception) {
            contentResolver.delete(uri, null, null)
            synchronized(state) {
                if (state.publishedUri == uri) state.publishedUri = null
            }
            throw error
        }
        return mapOf(
            "uri" to uri.toString(),
            "path" to "Movies/VELORA/$fileName",
        )
    }

    private fun copyCancellable(
        input: java.io.InputStream,
        output: java.io.OutputStream,
        state: ExportState,
    ) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            ensureExportActive(state)
            val count = input.read(buffer)
            if (count < 0) return
            output.write(buffer, 0, count)
        }
    }

    private fun ensureExportActive(state: ExportState) {
        if (state.cancelled.get() || Thread.currentThread().isInterrupted) {
            throw CancellationException("Export cancelled")
        }
    }

    private fun cancelActiveExport(message: String): Boolean {
        val state = activeExport ?: return false
        if (!state.cancelled.compareAndSet(false, true)) return false
        Log.w(TAG, "Export cancellation requested: $message")

        state.publishingThread?.interrupt()
        try {
            state.transformer?.cancel()
        } catch (error: Throwable) {
            Log.w(TAG, "Media3 cancellation raised an error", error)
            // Cancellation must still resolve the pending Flutter result.
        }
        state.temporaryOutput?.delete()
        cleanupPublishedExport(state)
        completeExport(state) {
            state.result.error("export_cancelled", message, null)
        }
        return true
    }

    private fun completeExport(state: ExportState, deliverResult: () -> Unit) {
        if (!state.resultSent.compareAndSet(false, true)) return
        if (activeExport === state) activeExport = null
        state.transformer = null
        state.temporaryOutput = null
        state.publishingThread = null
        deliverResult()
    }

    private fun cleanupPublishedExport(state: ExportState) {
        val output = synchronized(state) {
            val uri = state.publishedUri
            val file = state.publishedFile
            state.publishedUri = null
            state.publishedFile = null
            uri to file
        }
        output.first?.let { uri -> runCatching { contentResolver.delete(uri, null, null) } }
        output.second?.let { file -> runCatching { file.delete() } }
    }

    private fun releasePublishedExportTracking(state: ExportState) {
        synchronized(state) {
            state.publishedUri = null
            state.publishedFile = null
        }
    }

    private data class PositionedAudioClip(
        val asset: Map<String, Any?>,
        val clip: Map<String, Any?>,
        val timelineStartMs: Long,
        val durationMs: Long,
    )

    private class AudioExtractionState(
        val result: MethodChannel.Result,
        val outputFile: File,
    ) {
        val resultSent = AtomicBoolean(false)
        val cancelled = AtomicBoolean(false)
        @Volatile var transformer: Transformer? = null
        @Volatile var keepOutput: Boolean = false
    }

    private class ExportState(
        val result: MethodChannel.Result,
        @Volatile var temporaryOutput: File? = null,
    ) {
        val resultSent = AtomicBoolean(false)
        val cancelled = AtomicBoolean(false)
        val publishStarted = AtomicBoolean(false)

        @Volatile var transformer: Transformer? = null
        @Volatile var publishingThread: Thread? = null
        @Volatile var publishedUri: Uri? = null
        @Volatile var publishedFile: File? = null
    }

    companion object {
        private const val TAG = "VeloraExport"
        private const val CHANNEL = "velora/native"
        private const val PICK_MEDIA_REQUEST = 7401
        private const val MAX_SUBTITLE_BYTES = 2 * 1024 * 1024
        private const val MAX_STICKER_BYTES = 20 * 1024 * 1024
        private const val PREVIEW_OUTPUT_HEIGHT = 720
        private const val MAX_NORMALIZED_AUDIO_CHANNELS = 6
        private const val OUTPUT_AUDIO_CHANNELS = 2
        private const val OUTPUT_AUDIO_SAMPLE_RATE_HZ = 48_000
    }
}
