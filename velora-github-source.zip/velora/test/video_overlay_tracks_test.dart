import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/video_overlays.dart';

void main() {
  test('video layer timing is start-inclusive, end-exclusive, and overlap-aware', () {
    const first = VideoOverlayClip(
      id: 'one',
      assetId: 'a',
      trimStartMs: 0,
      trimEndMs: 2000,
      timelineStartMs: 1000,
    );
    const touching = VideoOverlayClip(
      id: 'touching',
      assetId: 'b',
      trimStartMs: 0,
      trimEndMs: 500,
      timelineStartMs: 3000,
    );
    const overlapping = VideoOverlayClip(
      id: 'overlap',
      assetId: 'c',
      trimStartMs: 400,
      trimEndMs: 1400,
      timelineStartMs: 2500,
    );

    expect(first.isVisibleAt(999), isFalse);
    expect(first.isVisibleAt(1000), isTrue);
    expect(first.isVisibleAt(2999), isTrue);
    expect(first.isVisibleAt(3000), isFalse);
    expect(first.overlaps(touching), isFalse);
    expect(first.overlaps(overlapping), isTrue);
    expect(overlapping.overlaps(first), isTrue);
  });

  test('video overlay tracks round-trip with geometry/timing and undo/redo', () {
    final initial = VeloraProject.empty(id: 'pip-project', name: 'PIP');
    const clip = VideoOverlayClip(
      id: 'pip-1',
      assetId: 'asset-video',
      trimStartMs: 125,
      trimEndMs: 2125,
      timelineStartMs: 800,
      positionX: 0.72,
      positionY: 0.24,
      widthFraction: 0.31,
      heightFraction: 0.4,
    );
    const track = VideoOverlayTrack(
      id: 'overlay-track-1',
      name: 'نافذة جانبية',
      clips: [clip],
    );
    const mainAsset = MediaAsset(
      id: 'main-asset', uri: 'content://main', name: 'main.mp4',
      mimeType: 'video/mp4', kind: MediaKind.video, durationMs: 5000,
      width: 1920, height: 1080, sizeBytes: 100,
    );
    const audioAsset = MediaAsset(
      id: 'audio-asset', uri: 'content://audio', name: 'music.mp3',
      mimeType: 'audio/mpeg', kind: MediaKind.audio, durationMs: 5000,
      width: 0, height: 0, sizeBytes: 50,
    );
    const mainClip = TimelineClip(
      id: 'main-clip', assetId: 'main-asset', trimStartMs: 0, trimEndMs: 5000,
    );
    const audioClip = TimelineClip(
      id: 'audio-clip', assetId: 'audio-asset', trimStartMs: 0, trimEndMs: 3000,
      timelineStartMs: 1000,
    );
    final changed = initial.copyWith(
      assets: const [mainAsset, audioAsset],
      videoTrack: const [mainClip],
      audioTrack: const [audioClip],
      videoOverlayTracks: const [track],
    );
    final restored = VeloraProject.fromMap(changed.toMap());

    expect(restored.videoOverlayTracks.single.id, track.id);
    expect(restored.videoOverlayTracks.single.clips.single.assetId, clip.assetId);
    expect(restored.videoOverlayTracks.single.clips.single.trimStartMs, 125);
    expect(restored.videoOverlayTracks.single.clips.single.trimEndMs, 2125);
    expect(restored.videoOverlayTracks.single.clips.single.timelineStartMs, 800);
    expect(restored.videoOverlayTracks.single.clips.single.positionX, 0.72);
    expect(restored.videoOverlayTracks.single.clips.single.positionY, 0.24);
    expect(restored.videoOverlayTracks.single.clips.single.widthFraction, 0.31);
    expect(restored.videoOverlayTracks.single.clips.single.heightFraction, 0.4);
    expect(restored.videoTrack.single.id, mainClip.id);
    expect(restored.audioTrack.single.id, audioClip.id);
    expect(restored.audioTrack.single.timelineStartMs, 1000);

    final history = ProjectHistory(initial);
    history.record(changed);
    expect(history.undo()!.videoOverlayTracks, isEmpty);
    expect(history.redo()!.videoOverlayTracks.single.clips.single.id, clip.id);
  });

  test('legacy projects without overlay tracks stay loadable', () {
    final project = VeloraProject.empty(id: 'legacy', name: 'Old format');
    final map = project.toMap()..remove('videoOverlayTracks');
    expect(VeloraProject.fromMap(map).videoOverlayTracks, isEmpty);
  });
}
