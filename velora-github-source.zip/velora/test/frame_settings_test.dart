import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/frame_geometry.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';

void main() {
  group('project framing settings', () {
    test('legacy project data gets source-preserving defaults', () {
      final project = VeloraProject.fromMap({
        'id': 'legacy',
        'assets': <Object>[],
        'videoTrack': <Object>[],
        'audioTrack': <Object>[],
      });

      expect(project.frameSettings.aspectRatio, 'source');
      expect(project.frameSettings.fitMode, FrameFitMode.fit);
      expect(project.frameSettings.rotationQuarterTurns, 0);
      expect(project.frameSettings.positionX, 0);
      expect(project.frameSettings.positionY, 0);
      expect(project.frameSettings.flipHorizontal, isFalse);
      expect(project.frameSettings.flipVertical, isFalse);
    });

    test('framing values survive project save and reopen', () {
      final project = VeloraProject.empty(id: 'p', name: 'Framing').copyWith(
        frameSettings: const VideoFrameSettings(
          aspectRatio: '4:5',
          fitMode: FrameFitMode.fill,
          positionX: 0.35,
          positionY: -0.6,
          rotationQuarterTurns: 3,
          flipHorizontal: true,
          flipVertical: false,
        ),
      );

      final reopened = VeloraProject.fromMap(project.toMap());
      expect(reopened.frameSettings, project.frameSettings);
    });

    test('invalid stored values are safely clamped and normalized', () {
      final settings = VideoFrameSettings.fromMap({
        'aspectRatio': 'unsupported',
        'fitMode': 'unknown',
        'positionX': 8,
        'positionY': double.nan,
        'rotationQuarterTurns': -1,
      });

      expect(settings.aspectRatio, 'source');
      expect(settings.fitMode, FrameFitMode.fit);
      expect(settings.positionX, 1);
      expect(settings.positionY, 0);
      expect(settings.rotationQuarterTurns, 3);
    });

    test('frame transform values are part of undo and redo snapshots', () {
      final initial = VeloraProject.empty(id: 'p', name: 'Undo');
      final changed = initial.copyWith(
        frameSettings: initial.frameSettings.copyWith(
          aspectRatio: '1:1',
          fitMode: FrameFitMode.fill,
          rotationQuarterTurns: 1,
          flipVertical: true,
        ),
      );
      final history = ProjectHistory(initial);
      history.record(changed);

      expect(history.undo()!.frameSettings, initial.frameSettings);
      expect(history.redo()!.frameSettings, changed.frameSettings);
    });
  });

  group('frame geometry', () {
    test('timeline preview keeps a stable source aspect across unlike clips', () {
      const settings = VideoFrameSettings();
      expect(
        previewStageAspectRatio(
          settings: settings,
          timelineMode: true,
          timelineSourceAspectRatio: 16 / 9,
          selectedSourceAspectRatio: 9 / 16,
        ),
        closeTo(16 / 9, 0.000001),
      );
      expect(
        previewStageAspectRatio(
          settings: settings,
          timelineMode: false,
          timelineSourceAspectRatio: 16 / 9,
          selectedSourceAspectRatio: 9 / 16,
        ),
        closeTo(9 / 16, 0.000001),
      );
      expect(
        previewStageAspectRatio(
          settings: const VideoFrameSettings(aspectRatio: '1:1'),
          timelineMode: true,
          timelineSourceAspectRatio: 16 / 9,
          selectedSourceAspectRatio: 9 / 16,
        ),
        1,
      );
    });

    const landscape = VideoFrameSettings(
      aspectRatio: '9:16',
      fitMode: FrameFitMode.fit,
    );

    test('fit contains a landscape source in a portrait frame', () {
      final geometry = computeFrameGeometry(
        sourceWidth: 1920,
        sourceHeight: 1080,
        outputHeight: 720,
        settings: landscape,
      );

      expect(geometry.outputWidth, 406);
      expect(geometry.outputHeight, 720);
      expect(geometry.scaleX, 1);
      expect(geometry.scaleY, closeTo(9 / 16 / (16 / 9), 0.000001));
    });

    test('fill scales to cover and pan remains within safe crop bounds', () {
      final geometry = computeFrameGeometry(
        sourceWidth: 1920,
        sourceHeight: 1080,
        outputHeight: 720,
        settings: landscape.copyWith(
          fitMode: FrameFitMode.fill,
          positionX: 1,
          positionY: -1,
        ),
      );

      expect(geometry.scaleX, closeTo((16 / 9) / (9 / 16), 0.000001));
      expect(geometry.scaleY, 1);
      expect(geometry.translateX, closeTo(1 - geometry.scaleX, 0.000001));
      expect(geometry.translateY, 0);
    });

    test('quarter-turn rotation swaps source dimensions before framing', () {
      final geometry = computeFrameGeometry(
        sourceWidth: 1920,
        sourceHeight: 1080,
        outputHeight: 720,
        settings: const VideoFrameSettings(
          aspectRatio: '9:16',
          rotationQuarterTurns: 1,
        ),
      );

      // A 90-degree rotation turns the source portrait before it is fitted.
      expect(geometry.scaleX, closeTo((9 / 16) / (9 / 16), 0.000001));
      expect(geometry.scaleY, 1);
    });
  });
}
