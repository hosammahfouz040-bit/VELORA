import 'dart:typed_data';

import 'package:flutter/services.dart';

import '../models/project.dart';
import '../models/project_templates.dart';

class NativeBridge {
  NativeBridge._();

  static const MethodChannel _channel = MethodChannel('velora/native');
  static final Map<String, Future<Uint8List?>> _stickerBytesCache = {};

  static Future<List<MediaAsset>> pickMedia() async {
    final rows = await _channel.invokeListMethod<Object?>('pickMedia') ?? [];
    return rows
        .map(
          (row) => MediaAsset.fromMap(Map<String, dynamic>.from(row! as Map)),
        )
        .toList();
  }

  static Future<MediaAsset?> pickSticker() async {
    final row = await _channel.invokeMapMethod<Object?, Object?>('pickSticker');
    if (row == null) return null;
    return MediaAsset.fromMap(Map<String, dynamic>.from(row));
  }

  static Future<MediaAsset?> pickReplacementMedia(MediaKind kind) async {
    if (kind != MediaKind.video &&
        kind != MediaKind.image &&
        kind != MediaKind.audio) {
      throw ArgumentError.value(kind, 'kind', 'Unsupported replacement media kind');
    }
    final row = await _channel.invokeMapMethod<Object?, Object?>(
      'pickReplacementMedia',
      {'kind': kind.name},
    );
    if (row == null) return null;
    return MediaAsset.fromMap(Map<String, dynamic>.from(row));
  }

  static Future<String?> pickSubtitleFile() async =>
      _channel.invokeMethod<String>('pickSubtitle');

  static Future<Uint8List?> loadStickerBytes(String uri) =>
      _stickerBytesCache.putIfAbsent(uri, () async {
        try {
          return await _channel.invokeMethod<Uint8List>(
            'loadStickerBytes',
            {'uri': uri},
          );
        } on PlatformException {
          _stickerBytesCache.remove(uri);
          return null;
        }
      });

  static Future<List<VeloraProject>> listProjects() async {
    final rows = await _channel.invokeListMethod<Object?>('listProjects') ?? [];
    final projects = <VeloraProject>[];
    for (final row in rows) {
      try {
        projects.add(
          VeloraProject.fromMap(Map<String, dynamic>.from(row! as Map)),
        );
      } catch (_) {
        // Ignore this invalid project row only; the native JSON file is left intact.
      }
    }
    return projects;
  }

  static Future<void> saveProject(VeloraProject project) async {
    await _channel.invokeMethod<void>('saveProject', project.toMap());
  }

  static Future<List<ProjectTemplate>> listTemplates() async {
    final rows = await _channel.invokeListMethod<Object?>('listTemplates') ?? [];
    return rows
        .map((row) => ProjectTemplate.fromMap(
              Map<String, dynamic>.from(row! as Map),
            ))
        .toList();
  }

  static Future<void> saveTemplate(ProjectTemplate template) async {
    await _channel.invokeMethod<void>('saveTemplate', template.toMap());
  }

  static Future<void> deleteTemplate(String id) async {
    await _channel.invokeMethod<void>('deleteTemplate', {'id': id});
  }

  static Future<MediaAsset> extractVideoAudio(
    MediaAsset asset,
    TimelineClip clip,
  ) async {
    final row = await _channel.invokeMapMethod<Object?, Object?>(
      'extractVideoAudio',
      {'asset': asset.toMap(), 'clip': clip.toMap()},
    );
    if (row == null) throw PlatformException(code: 'empty_audio_extraction_result');
    return MediaAsset.fromMap(Map<String, dynamic>.from(row));
  }

  static Future<bool> cancelAudioExtraction() async =>
      await _channel.invokeMethod<bool>('cancelAudioExtraction') ?? false;

  static Future<void> configurePreviewTimeline(
    VeloraProject project, {
    required int startIndex,
    required int clipPositionMs,
    required int timelinePositionMs,
    required bool playWhenReady,
  }) async {
    await _channel.invokeMethod<void>('configurePreviewTimeline', {
      'project': project.toMap(),
      'startIndex': startIndex,
      'clipPositionMs': clipPositionMs,
      'timelinePositionMs': timelinePositionMs,
      'playWhenReady': playWhenReady,
    });
  }

  static Future<void> setPreviewSource(
    MediaAsset asset, {
    int positionMs = 0,
    VideoFrameSettings frameSettings = VideoFrameSettings.defaults,
    VideoColorSettings colorSettings = VideoColorSettings.defaults,
  }) async {
    await _channel.invokeMethod<void>('setPreviewSource', {
      'uri': asset.uri,
      'kind': asset.kind.name,
      'positionMs': positionMs < 0 ? 0 : positionMs,
      'durationMs': asset.durationMs,
      'frameSettings': frameSettings.toMap(),
      'colorSettings': colorSettings.toMap(),
    });
  }

  static Future<void> seekPreviewTo({
    required int mediaItemIndex,
    required int clipPositionMs,
    required int timelinePositionMs,
  }) async {
    await _channel.invokeMethod<void>('seekPreview', {
      'mediaItemIndex': mediaItemIndex,
      'clipPositionMs': clipPositionMs < 0 ? 0 : clipPositionMs,
      'timelinePositionMs': timelinePositionMs < 0 ? 0 : timelinePositionMs,
    });
  }

  static Future<void> playPreview() async {
    await _channel.invokeMethod<void>('playPreview');
  }

  static Future<void> pausePreview() async {
    await _channel.invokeMethod<void>('pausePreview');
  }

  static Future<void> clearPreview() async {
    await _channel.invokeMethod<void>('clearPreview');
  }

  static Future<Map<String, dynamic>> getPreviewState() async {
    final state = await _channel.invokeMapMethod<Object?, Object?>(
      'getPreviewState',
    );
    if (state == null) throw PlatformException(code: 'empty_preview_state');
    return state.map((key, value) => MapEntry(key.toString(), value));
  }

  static Future<bool> cancelExport() async =>
      await _channel.invokeMethod<bool>('cancelExport') ?? false;

  static Future<Map<String, dynamic>> exportProject(
    VeloraProject project,
    int height,
  ) async {
    final result = await _channel.invokeMapMethod<Object?, Object?>(
      'exportProject',
      {'project': project.toMap(), 'height': height},
    );
    if (result == null) throw PlatformException(code: 'empty_export_result');
    return result.map((key, value) => MapEntry(key.toString(), value));
  }
}
