import 'package:flutter_test/flutter_test.dart';
import 'package:velora/src/models/clip_motion.dart';
import 'package:velora/src/models/project.dart';
import 'package:velora/src/models/project_history.dart';
import 'package:velora/src/models/timeline_ops.dart';
import 'package:velora/src/models/timeline_position.dart';
import 'package:velora/src/models/video_transitions.dart';

void main() {
  const track = [
    TimelineClip(
      id: 'before',
      assetId: 'asset-a',
      trimStartMs: 0,
      trimEndMs: 5000,
    ),
    TimelineClip(
      id: 'selected',
      assetId: 'asset-b',
      trimStartMs: 1000,
      trimEndMs: 7000,
    ),
  ];

  test('splits selected clip at playhead and preserves source ranges', () {
    final split = splitClipAtPosition(
      track,
      'selected',
      playheadMs: 7250,
      secondClipId: 'selected-second',
      sourceDurationMs: 7000,
    );

    expect(split, isNotNull);
    expect(split, hasLength(3));
    expect(split![0].id, 'before');
    expect(split[1].id, 'selected');
    expect(split[1].trimStartMs, 1000);
    expect(split[1].trimEndMs, 3250);
    expect(split[2].id, 'selected-second');
    expect(split[2].assetId, 'asset-b');
    expect(split[2].trimStartMs, 3250);
    expect(split[2].trimEndMs, 7000);
    expect(visualTimelineDurationMs(split), visualTimelineDurationMs(track));

    // The source project must remain untouched until the caller commits it.
    expect(track[1].trimStartMs, 1000);
    expect(track[1].trimEndMs, 7000);
  });

  test('splits at an explicit speed-mapped source position and preserves clip data', () {
    const rampedClip = TimelineClip(
      id: 'ramped',
      assetId: 'ramped-asset',
      trimStartMs: 1000,
      trimEndMs: 2000,
      timelineStartMs: 345,
      volume: 0.42,
      fadeInMs: 110,
      fadeOutMs: 220,
      transformKeyframes: [
        ClipTransformKeyframe(timeMs: 1250, positionX: 0.25, scale: 1.2),
      ],
      speedRampPoints: [
        SpeedRampPoint(timeMs: 1000, speed: 1),
        SpeedRampPoint(timeMs: 2000, speed: 2),
      ],
    );
    final position = timelinePositionAt([rampedClip], 250)!;
    expect(position.sourcePositionMs, 1277);

    final split = splitClipAtPosition(
      [rampedClip],
      'ramped',
      playheadMs: 250,
      secondClipId: 'ramped-second',
      sourceDurationMs: 5000,
      sourceSplitPositionMs: position.sourcePositionMs,
    );

    expect(split, hasLength(2));
    expect(split![0].trimStartMs, 1000);
    expect(split[0].trimEndMs, 1277);
    expect(split[1].id, 'ramped-second');
    expect(split[1].trimStartMs, 1277);
    expect(split[1].trimEndMs, 2000);
    expect(split[1].timelineStartMs, rampedClip.timelineStartMs);
    expect(split[1].volume, rampedClip.volume);
    expect(split[1].fadeInMs, rampedClip.fadeInMs);
    expect(split[1].fadeOutMs, rampedClip.fadeOutMs);
    expect(
      split[1].transformKeyframes.map((point) => point.toMap()).toList(),
      rampedClip.transformKeyframes.map((point) => point.toMap()).toList(),
    );
    expect(
      split[1].speedRampPoints.map((point) => point.toMap()).toList(),
      rampedClip.speedRampPoints.map((point) => point.toMap()).toList(),
    );
    expect(rampedClip.trimStartMs, 1000);
    expect(rampedClip.trimEndMs, 2000);
  });

  test('speed curve edits affect only the selected clip and recalculate duration', () {
    final track = [
      const TimelineClip(
        id: 'first',
        assetId: 'asset-a',
        trimStartMs: 0,
        trimEndMs: 4_000,
      ),
      const TimelineClip(
        id: 'second',
        assetId: 'asset-b',
        trimStartMs: 0,
        trimEndMs: 4_000,
        speedRampPoints: [SpeedRampPoint(timeMs: 0, speed: 1.5)],
      ),
    ];
    final requestedRamp = [
      const SpeedRampPoint(timeMs: 0, speed: 0.5),
      const SpeedRampPoint(timeMs: 4_000, speed: 2),
    ];

    final result = updateVideoClipSpeedRampSafely(
      videoTrack: track,
      transitions: const [],
      clipId: 'first',
      speedRampPoints: requestedRamp,
    );

    expect(result.accepted, isTrue);
    expect(result.changed, isTrue);
    expect(
      result.track![0].speedRampPoints
          .map((point) => [point.timeMs, point.speed])
          .toList(),
      [
        [0, 0.5],
        [4_000, 2.0],
      ],
    );
    expect(result.track![0].effectiveDurationMs, lessThan(4_000));
    expect(result.track![1].speedRampPoints.single.timeMs, 0);
    expect(result.track![1].speedRampPoints.single.speed, 1.5);
    expect(track[0].speedRampPoints, isEmpty);
  });

  test('speed edits reject a curve that disables an active transition', () {
    final track = [
      const TimelineClip(
        id: 'first',
        assetId: 'asset-a',
        trimStartMs: 0,
        trimEndMs: 1_500,
      ),
      const TimelineClip(
        id: 'second',
        assetId: 'asset-b',
        trimStartMs: 0,
        trimEndMs: 1_500,
      ),
    ];
    const transitions = [
      VideoTransition(
        id: 'transition',
        fromClipId: 'first',
        toClipId: 'second',
        type: VideoTransitionType.fade,
        durationMs: 1_000,
      ),
    ];

    final result = updateVideoClipSpeedRampSafely(
      videoTrack: track,
      transitions: transitions,
      clipId: 'first',
      speedRampPoints: const [SpeedRampPoint(timeMs: 0, speed: 2)],
    );

    expect(result.accepted, isFalse);
    expect(result.rejectionReason, contains('انتقال'));
    expect(track.first.speedRampPoints, isEmpty);
  });

  test('does not split when playhead is outside the clip or on its edge', () {
    expect(
      splitClipAtPosition(
        track,
        'selected',
        playheadMs: 5000,
        secondClipId: 'second',
        sourceDurationMs: 7000,
      ),
      isNull,
    );
    expect(
      splitClipAtPosition(
        track,
        'selected',
        playheadMs: 11000,
        secondClipId: 'second',
        sourceDurationMs: 7000,
      ),
      isNull,
    );
    expect(
      splitClipAtPosition(
        track,
        'selected',
        playheadMs: 4000,
        secondClipId: 'second',
        sourceDurationMs: 7000,
      ),
      isNull,
    );
  });

  test('split rejects invalid source ranges and duplicate clip ids', () {
    const invalidRange = [
      TimelineClip(
        id: 'invalid',
        assetId: 'asset',
        trimStartMs: 0,
        trimEndMs: 6000,
      ),
    ];
    expect(
      splitClipAtPosition(
        invalidRange,
        'invalid',
        playheadMs: 3000,
        secondClipId: 'new',
        sourceDurationMs: 5000,
      ),
      isNull,
    );

    expect(
      splitClipAtPosition(
        track,
        'selected',
        playheadMs: 7250,
        secondClipId: 'before',
        sourceDurationMs: 7000,
      ),
      isNull,
    );
  });

  test('parses entered timeline positions to millisecond precision', () {
    expect(parseTimelineSeconds('12.345'), 12345);
    expect(parseTimelineSeconds(' 0,007 '), 7);
    expect(parseTimelineSeconds('not-a-time'), isNull);
    expect(parseTimelineSeconds('-0.1'), isNull);
    expect(parseTimelineSeconds('Infinity'), isNull);
  });

  test('trim boundaries support millisecond precision and keep clips valid', () {
    const clip = TimelineClip(
      id: 'trim',
      assetId: 'asset',
      trimStartMs: 1000,
      trimEndMs: 4000,
    );

    final start = updateClipTrimBoundary(
      clip,
      moveStart: true,
      requestedMs: 1123,
      sourceDurationMs: 9000,
    );
    expect(start?.trimStartMs, 1123);
    expect(start?.trimEndMs, 4000);

    final end = updateClipTrimBoundary(
      clip,
      moveStart: false,
      requestedMs: 3876,
      sourceDurationMs: 9000,
    );
    expect(end?.trimStartMs, 1000);
    expect(end?.trimEndMs, 3876);

    // The tested source bound must also contain the clip's existing end.
    final boundedStart = updateClipTrimBoundary(
      clip.copyWith(trimEndMs: 3500),
      moveStart: true,
      requestedMs: 9000,
      sourceDurationMs: 3500,
    );
    expect(boundedStart?.trimStartMs, 3499);
    expect(boundedStart!.durationMs, greaterThan(0));

    final boundedEnd = updateClipTrimBoundary(
      clip,
      moveStart: false,
      requestedMs: 0,
      sourceDurationMs: 9000,
    );
    expect(boundedEnd?.trimEndMs, 1001);
    expect(boundedEnd!.durationMs, 1);
  });

  test('trim can repair an overlong end but cannot preserve invalid ranges', () {
    const overlong = TimelineClip(
      id: 'overlong',
      assetId: 'asset',
      trimStartMs: 1000,
      trimEndMs: 6000,
    );
    final correctedEnd = updateClipTrimBoundary(
      overlong,
      moveStart: false,
      requestedMs: 4500,
      sourceDurationMs: 5000,
    );
    expect(correctedEnd?.trimEndMs, 4500);
    expect(correctedEnd!.trimEndMs, lessThanOrEqualTo(5000));

    expect(
      updateClipTrimBoundary(
        overlong,
        moveStart: true,
        requestedMs: 1500,
        sourceDurationMs: 5000,
      ),
      isNull,
    );
    expect(
      updateClipTrimBoundary(
        overlong.copyWith(trimStartMs: -20),
        moveStart: false,
        requestedMs: 1000,
        sourceDurationMs: 5000,
      ),
      isNull,
    );
  });

  test('unknown source duration keeps edits within the saved trim range', () {
    const clip = TimelineClip(
      id: 'legacy',
      assetId: 'legacy-asset',
      trimStartMs: 100,
      trimEndMs: 900,
    );

    final movedStart = updateClipTrimBoundary(
      clip,
      moveStart: true,
      requestedMs: 0,
      sourceDurationMs: 0,
    );
    expect(movedStart?.trimStartMs, 0);
    expect(movedStart?.trimEndMs, 900);

    expect(
      updateClipTrimBoundary(
        clip,
        moveStart: false,
        requestedMs: 1200,
        sourceDurationMs: 0,
      ),
      isNull,
    );

    final split = splitClipAtPosition(
      [clip],
      'legacy',
      playheadMs: 400,
      secondClipId: 'legacy-second',
      sourceDurationMs: 0,
    );
    expect(split, hasLength(2));
    expect(split![0].trimStartMs, 100);
    expect(split[0].trimEndMs, 500);
    expect(split[1].trimStartMs, 500);
    expect(split[1].trimEndMs, 900);
  });

  test('trim operation rejects invalid and unchanged boundaries', () {
    const clip = TimelineClip(
      id: 'trim',
      assetId: 'asset',
      trimStartMs: 100,
      trimEndMs: 200,
    );
    expect(
      updateClipTrimBoundary(
        clip,
        moveStart: true,
        requestedMs: 100,
        sourceDurationMs: 500,
      ),
      isNull,
    );
    expect(
      updateClipTrimBoundary(
        clip,
        moveStart: false,
        requestedMs: 200,
        sourceDurationMs: 500,
      ),
      isNull,
    );
    expect(
      updateClipTrimBoundary(
        clip.copyWith(trimEndMs: 100),
        moveStart: false,
        requestedMs: 500,
        sourceDurationMs: 500,
      ),
      isNull,
    );
  });

  test('speed-ramp split at an off-grid source time preserves output duration', () {
    const rampedClip = TimelineClip(
      id: 'ramped-split',
      assetId: 'ramped-asset',
      trimStartMs: 0,
      trimEndMs: 5000,
      speedRampPoints: [
        SpeedRampPoint(timeMs: 0, speed: 1),
        SpeedRampPoint(timeMs: 5000, speed: 2),
      ],
    );
    final originalDurationMs = rampedClip.effectiveDurationMs;
    final split = splitClipAtPosition(
      [rampedClip],
      rampedClip.id,
      playheadMs: 480,
      secondClipId: 'ramped-split-second',
      sourceDurationMs: 5000,
      sourceSplitPositionMs: 501,
    );

    expect(split, hasLength(2));
    expect(split![0].effectiveDurationMs, 480);
    expect(split[1].effectiveDurationMs, 2998);
    expect(
      split[0].effectiveDurationMs + split[1].effectiveDurationMs,
      originalDurationMs,
    );
  });

  test('supports millisecond-level splits and rejects empty fragments', () {
    const shortTrack = [
      TimelineClip(
        id: 'short',
        assetId: 'asset',
        trimStartMs: 40,
        trimEndMs: 43,
      ),
    ];
    final split = splitClipAtPosition(
      shortTrack,
      'short',
      playheadMs: 2,
      secondClipId: 'short-2',
      sourceDurationMs: 43,
    );
    expect(split, isNotNull);
    expect(split![0].durationMs, 2);
    expect(split[1].durationMs, 1);
    expect(
      splitClipAtPosition(
        shortTrack,
        'short',
        playheadMs: 40,
        secondClipId: 'empty',
        sourceDurationMs: 43,
      ),
      isNull,
    );
  });

  test('safe trims retain speed ramps and preserve active transition parameters', () {
    const transition = VideoTransition(
      id: 'trim-transition',
      fromClipId: 'left',
      toClipId: 'right',
      type: VideoTransitionType.dissolve,
      durationMs: 200,
      direction: 'left',
      intensity: 0.7,
    );
    const ramp = [
      SpeedRampPoint(timeMs: 0, speed: 0.5),
      SpeedRampPoint(timeMs: 1000, speed: 2),
    ];
    const linkedTrack = [
      TimelineClip(id: 'left', assetId: 'a', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(
        id: 'right',
        assetId: 'b',
        trimStartMs: 0,
        trimEndMs: 1000,
        speedRampPoints: ramp,
      ),
    ];

    final result = trimVideoClipSafely(
      videoTrack: linkedTrack,
      transitions: const [transition],
      clipId: 'right',
      moveStart: true,
      requestedMs: 200,
      sourceDurationMs: 1000,
    );
    expect(result.accepted, isTrue);
    expect(result.changed, isTrue);
    expect(result.track![1].trimStartMs, 200);
    expect(result.track![1].speedRampPoints, ramp);
    expect(result.track![1].effectiveDurationMs, isNot(0));
    final layout = layoutVideoTransitions(
      result.track!.map((clip) => clip.id).toList(),
      result.track!.map((clip) => clip.effectiveDurationMs).toList(),
      const [transition],
    );
    expect(layout.activeTransitionsByBoundary.values.single.toMap(), transition.toMap());
    expect(linkedTrack[1].trimStartMs, 0);

    final audio = const TimelineClip(
      id: 'audio',
      assetId: 'music',
      trimStartMs: 250,
      trimEndMs: 900,
      timelineStartMs: 350,
      volume: 0.4,
      fadeInMs: 120,
      fadeOutMs: 180,
    );
    final initialProject = VeloraProject(
      id: 'trim-history',
      name: 'اختبار تاريخ القص',
      createdAt: '2026-10-28T00:00:00.000Z',
      assets: const [],
      videoTrack: linkedTrack,
      audioTrack: [audio],
      videoTransitions: const [transition],
    );
    final history = ProjectHistory(initialProject);
    final committed = initialProject.copyWith(videoTrack: result.track);
    history.record(committed);
    final undone = history.undo()!;
    expect(undone.videoTrack[1].trimStartMs, 0);
    expect(undone.audioTrack.single.toMap(), audio.toMap());
    final redone = history.redo()!;
    expect(redone.videoTrack[1].trimStartMs, 200);
    expect(redone.audioTrack.single.toMap(), audio.toMap());
    expect(redone.videoTransitions.single.toMap(), transition.toMap());
  });

  test('rejects trims that deactivate or activate an existing transition', () {
    const transition = VideoTransition(
      id: 'trim-transition',
      fromClipId: 'left',
      toClipId: 'right',
      type: VideoTransitionType.fade,
      durationMs: 200,
    );
    const activeTrack = [
      TimelineClip(id: 'left', assetId: 'a', trimStartMs: 0, trimEndMs: 1000),
      TimelineClip(id: 'right', assetId: 'b', trimStartMs: 0, trimEndMs: 1000),
    ];
    final deactivated = trimVideoClipSafely(
      videoTrack: activeTrack,
      transitions: const [transition],
      clipId: 'left',
      moveStart: true,
      requestedMs: 801,
      sourceDurationMs: 1000,
    );
    expect(deactivated.accepted, isFalse);
    expect(deactivated.rejectionReason, contains('الانتقال'));
    expect(activeTrack.first.trimStartMs, 0);

    const inactiveTrack = [
      TimelineClip(id: 'left', assetId: 'a', trimStartMs: 850, trimEndMs: 1000),
      TimelineClip(id: 'right', assetId: 'b', trimStartMs: 0, trimEndMs: 1000),
    ];
    final activated = trimVideoClipSafely(
      videoTrack: inactiveTrack,
      transitions: const [transition],
      clipId: 'left',
      moveStart: true,
      requestedMs: 0,
      sourceDurationMs: 1000,
    );
    expect(activated.accepted, isFalse);
    expect(activated.rejectionReason, contains('الانتقال'));
  });
}
