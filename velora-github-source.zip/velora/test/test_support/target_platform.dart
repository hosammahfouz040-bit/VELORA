import 'dart:ui' show Size;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Finder iconButtonForTooltip(String tooltip) => find.ancestor(
  of: find.byTooltip(tooltip),
  matching: find.byType(IconButton),
);

void testWidgetsOnPlatform(
  String description,
  TargetPlatform platform,
  Future<void> Function(WidgetTester tester) callback,
) {
  testWidgets(description, (tester) async {
    tester.view.physicalSize = const Size(1200, 2200);
    tester.view.devicePixelRatio = 1;
    try {
      await callback(tester);
    } finally {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    }
  }, variant: TargetPlatformVariant.only(platform));
}
