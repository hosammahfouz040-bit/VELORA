package com.velora.app

/** Pure frame parameters used by both preview and Transformer transition compositors. */
internal data class TransitionFrameTransform(
    val alpha: Float = 1f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotationDegrees: Float = 0f,
    val anchorX: Float = 0f,
    val anchorY: Float = 0f,
)

/** Returns the actual per-input frame transform, or null for an unimplemented transition. */
internal fun transitionFrameTransform(
    type: String,
    isIncoming: Boolean,
    progress: Float,
    direction: String,
    intensity: Float,
): TransitionFrameTransform? {
    val p = progress.coerceIn(0f, 1f)
    val strength = intensity.coerceIn(0f, 1f)
    var alpha = 1f
    var scaleX = 1f
    var scaleY = 1f
    var rotation = 0f
    var anchorX = 0f
    var anchorY = 0f

    when (type) {
        "fade" -> {
            alpha = if (isIncoming) {
                if (p < 0.5f) 0f else (p - 0.5f) * 2f
            } else {
                if (p < 0.5f) 1f - p * 2f else 0f
            }
        }
        // Incoming frames are alpha-blended over the still-opaque outgoing frame.
        "dissolve" -> if (isIncoming) alpha = p
        "slide" -> {
            val vector = directionVector(direction)
            val amount = if (isIncoming) 1f - p else -p
            anchorX = vector.first * amount
            anchorY = vector.second * amount
            if (isIncoming) alpha = p
        }
        "zoom" -> if (isIncoming) {
            scaleX = 1f - (1f - 0.55f) * (1f - p) * strength
            scaleY = scaleX
            alpha = p
        }
        "spin" -> if (isIncoming) {
            scaleX = 0.55f + 0.45f * p
            scaleY = scaleX
            rotation = (1f - p) * 360f * strength
            alpha = p
        }
        else -> return null
    }
    return TransitionFrameTransform(
        alpha = alpha.coerceIn(0f, 1f),
        scaleX = scaleX,
        scaleY = scaleY,
        rotationDegrees = rotation,
        anchorX = anchorX.coerceIn(-1f, 1f),
        anchorY = anchorY.coerceIn(-1f, 1f),
    )
}

private fun directionVector(direction: String): Pair<Float, Float> = when (direction) {
    "left" -> -1f to 0f
    // NDC +Y points up. An "up" slide enters from below, so its incoming offset is -Y.
    "up" -> 0f to -1f
    "down" -> 0f to 1f
    else -> 1f to 0f
}
