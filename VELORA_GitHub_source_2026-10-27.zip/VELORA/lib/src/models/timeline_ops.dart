import 'project.dart';

/// Splits a visual clip into two adjacent source ranges at the midpoint.
/// Returns null when the clip is missing or too short to split safely.
List<TimelineClip>? splitClipAtMidpoint(
  List<TimelineClip> track,
  String clipId, {
  required String secondClipId,
}) {
  final index = track.indexWhere((clip) => clip.id == clipId);
  if (index < 0) return null;

  final clip = track[index];
  if (clip.durationMs < 1000) return null;
  final midpoint = clip.trimStartMs + (clip.durationMs ~/ 2);
  if (midpoint <= clip.trimStartMs || midpoint >= clip.trimEndMs) return null;

  final first = clip.copyWith(trimEndMs: midpoint);
  final second = TimelineClip(
    id: secondClipId,
    assetId: clip.assetId,
    trimStartMs: midpoint,
    trimEndMs: clip.trimEndMs,
  );
  return [...track.take(index), first, second, ...track.skip(index + 1)];
}
